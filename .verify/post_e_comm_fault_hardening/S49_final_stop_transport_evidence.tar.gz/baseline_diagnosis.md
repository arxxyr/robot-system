# 2026-09-29 基线失败只读诊断

本说明只记录源码核查与失败边界，不替代原始日志或最终验收。两次 Orin 失败结果由 root 通报；本诊断未独立读取远端原日志、未运行 Cargo。下列源码路径相对仓库根目录，行号为本轮核查时位置。本次只新增此说明文件。

## 默认 workspace：缺少带 fault backend 的 S1 测试实件

root 通报：`cargo test --locked --workspace` 在 `dimos_workflow_e2e` 得到 16 PASS / 2 FAIL；两个失败均在 S1 启动时报告 unknown backend `fault_inject`。

源码已确认这两个用例的构建前置：

- `crates/robot-rpc/tests/dimos_workflow_e2e.rs:13–24` 明确要求先构建 release workspace，再构建带 `test-fault-backend` 的 `s1_daemon`；缺该 feature 时两个 failure 用例在 bring-up 期失败。
- `crates/robot-s1/Cargo.toml:60–69` 明确该 backend 永不进入默认 feature；测试前须显式构建，不能修改默认组合来掩盖前置遗漏。
- `crates/robot-rpc/tests/common/dual_ctx.rs:159–176` 的 failure profile 使用 `fault_inject`，并排除分发键重合的 `mock_dwell`。
- `crates/robot-rpc/tests/common/subprocess.rs:434–463` 选择实件的顺序是 `B4_E2E_BIN_*` 显式绑定、同 target 的 release、最后 debug。因此仅给 `cargo test --workspace` 增加 `robot-s1/test-fault-backend`，不能保证替换原来被选中的 release 或显式 peer。

结论：已确认上述失败签名与缺失的 S1 测试 peer 构建前置一致，不需要修改生产代码。最小复验是先在本轮隔离构建目录执行 `cargo build --locked --release -p robot-s1 --bin s1_daemon --features test-fault-backend`，记录实际 artifact 的来源、feature、profile 与 SHA，再显式绑定本轮 S0/S1/Gateway 三件后重跑原默认 workspace 测试。带 fault backend 的实件仅供软件测试，不作为正式安装产物。原 16/2 失败保留，复验结果另记。

后续若扩大为全 feature，`crates/robot-rpc/Cargo.toml:181–184` 会启用 `w3_gateway_owned`；该套在 `tests/w3_gateway_owned.rs:27–36` 还要求同源 dev/unwind S1 的 `ROBOT_W3_S1_UNWIND_BIN` 以及显式 release S1。不能通过直接改成 `--all-features` 跳过这些前置。

## S1 并行库测试：两个终态事件等待超时

root 通报：S1 定向库测试默认并行得到 284 PASS / 2 FAIL；`completed_terminal_event_breaks_loop_after_grace` 与 `cancelled_terminal_event_round_trip` 在 `runtime.rs:733` 等待 2 秒超时，伴随 iceoryx2 的 `Unable to establish connection to new sender` 日志。

已确认的源码事实：

- `crates/robot-s1/src/events_drain/runtime.rs:801–830`、`:864–883` 的两个用例直接调用 `handle.join()`，不经过本轮等价 lint 改写的 `EventsDrainRegistry::join_all()`（`:291–296`）。
- 夹具先建立 subscriber，再启动 publisher；`:490–522` 的 ready 仅证明 publisher factory 已完成，没有订阅端连接握手或预热。用例随后直接发送唯一终态事件。
- 测试配置 `:708–714` 的 grace 为 20ms；`:606–621` 在该配置下只刷新一次 publisher 连接并睡眠 20ms，之后 publisher 析构。接收端 `:719–737` 才通过 `latest()` 轮询；2 秒等待期限不等于 sender 存活 2 秒。生产默认 grace 为 1000ms（`:118–123`），本轮未改。
- 本测试模块没有测试间串行锁；`:672–676` 只用 PID 与原子序号隔离 topic。`:679–700` 泄漏测试 Node，可能增加累积资源压力，但没有证据证明本次发生资源耗尽。
- `3rd-party/iceoryx2/src/port/details/receiver.rs:712–730` 的普通 PubSub 连接创建失败可被记录为 warning 后返回成功；底层 `:154–181` 区分连接创建与 sender 数据段打开失败。单条概括日志不足以确认具体失败原因或其所属测试。

候选解释：并行调度或资源压力使首次接收连接未能在测试的短终态窗口内建立，导致 sender 退出后无法取得终态。源码支持该机制存在，但当前没有逐用例时序或底层错误证据，不能宣称已证实并发根因、资源耗尽或上游缺陷。

最小判别复验：保持同一来源、feature、权限、资源限制及原 timeout/grace，先单独运行 `cargo test --locked -p robot-s1 --lib events_drain::runtime::tests -- --test-threads=1 --nocapture`；需要区分同进程其他测试影响时，再运行一次完整 S1 库串行门。串行通过仅证明该条件下通过，不覆盖原默认并行失败。若仍失败，应读取同 sender ID 前后的具体 zero-copy/data-segment 错误；不通过增大 timeout、清理全局 IPC 或改变生产语义过门。本文不预填任何复验结果。

## macOS 全 workspace 的平台限制

已读取本轮 `clippy_workspace_isolated.log`。现有 S0 在 macOS 存在 Linux API 守门缺口：`crates/robot-s0/src/serial_io_thread.rs:258–262` 无条件调用 Linux 专属 `robot_core::thread`；`clear_estop_transaction/dirfd.rs:174` 与 `latch_lock.rs:494` 使用 Linux `O_PATH`；多个测试引用被 `crates/robot-s0/src/lib.rs:135–136` 限定在 Linux 的 `rt_thread`。这与本轮 RPC 回环改动无关，本轮不修改这些 S0 路径。

`docs/00_design.md:5` 的服务端目标为 Linux；`.github/workflows/ci.yml:3–7` 将 macOS 定位于早期前五步，而实际 `:61–66` 已对两平台执行全 workspace 门，存在历史范围漂移。macOS 定向通过不能宣称全 workspace 通过；Linux 门须依真实 Orin 软件结果另记。四处新 nightly `map_unwrap_or` lint 已做等价改写，其最终验收由 root 记录。

本轮以上诊断均不改变右 H2 整体 FAIL、D15 OPEN、`deployable=false`、现场物理状态未重新确认及无新硬件 GO 的边界。
