import pathlib,json,hashlib
root=pathlib.Path.cwd(); manifest=root/'final_build_manifest.json'
rows=json.loads(manifest.read_text())['files']
for row in rows:
 p=root/row['path']
 if 'link' in row: assert p.is_symlink() and str(p.readlink())==row['link'],row
 else:
  data=p.read_bytes();assert len(data)==row['bytes'] and hashlib.sha256(data).hexdigest()==row['sha256'],row
peers=json.loads((root/'b4_peers_manifest.json').read_text())
for row in peers.values():
 p=pathlib.Path(row['path']);assert len(p.read_bytes())==row['bytes'] and hashlib.sha256(p.read_bytes()).hexdigest()==row['sha256'],row
p=root/'build/debug/comm_fault_e2e'
result={'source_matches':True,'source_count':len(rows),'manifest_sha256':hashlib.sha256(manifest.read_bytes()).hexdigest(),'bound_peers_unchanged':True,'comm_fault_e2e':{'path':str(p),'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'bytes':p.stat().st_size,'profile':'dev','scope':'仅软件工具构建，不是正式release测量件批准'}}
(root/'final_source_after.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(result,ensure_ascii=False))
