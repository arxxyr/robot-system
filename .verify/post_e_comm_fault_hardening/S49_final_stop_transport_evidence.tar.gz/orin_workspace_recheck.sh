set -eu
export PATH=/home/loosqk/.cargo/bin:/home/loosqk/.local/bin:$PATH
cd /home/loosqk/repo/robot/robot-system/target/post_e_h2_rt/s49/rpc_transport_20260929_01
uv run --no-project python - <<'PY'
import pathlib,json,hashlib,time
rows=json.loads(pathlib.Path('final_build_manifest.json').read_text())['files']
changed=['crates/robot-rpc/src/state_convert.rs','crates/robot-s1/src/events_drain/runtime.rs','crates/robot-s1/src/rr_server/wire.rs','crates/robot-tests/src/bin/hello_pubsub.rs','scripts/post_e_h2_artifacts.py','scripts/tests/test_post_e_h2_artifacts.py']
record=[]
for name in changed:
 p=pathlib.Path(name); before=p.stat().st_mtime_ns; digest=hashlib.sha256(p.read_bytes()).hexdigest(); p.touch()
 record.append({'path':name,'before_mtime_ns':before,'after_mtime_ns':p.stat().st_mtime_ns,'sha256':digest})
for row in rows:
 p=pathlib.Path(row['path'])
 if 'link' in row: assert p.is_symlink() and str(p.readlink())==row['link'],row
 else: assert len(p.read_bytes())==row['bytes'] and hashlib.sha256(p.read_bytes()).hexdigest()==row['sha256'],row
pathlib.Path('source_mtime_refresh.json').write_text(json.dumps({'verified':True,'count':len(rows),'files':record},indent=2)+'\n')
PY
uv run --no-project python gate.py fmt_recompiled_source -- cargo fmt --all
uv run --no-project python gate.py clippy_recompiled_workspace -- env RUSTC_WRAPPER= CARGO_TARGET_DIR=build CARGO_BUILD_JOBS=2 cargo clippy --all --all-targets -- -D warnings
uv run --no-project python gate.py build_b4_peers -- env RUSTC_WRAPPER= CARGO_TARGET_DIR=build CARGO_BUILD_JOBS=2 cargo build --locked -p robot-s0 -p robot-s1 -p robot-rpc --bin s0_daemon --bin s1_daemon --bin robot_rpc_gateway --features robot-s1/test-fault-backend,robot-rpc/client --message-format=json
uv run --no-project python - <<'PY'
import pathlib,json,hashlib,shutil
root=pathlib.Path.cwd(); out=root/'b4_peers';out.mkdir()
names=['s0_daemon','s1_daemon','robot_rpc_gateway']; rows={}
for line in pathlib.Path('build_b4_peers.log').read_text().splitlines():
 try: row=json.loads(line)
 except ValueError: continue
 if row.get('reason')=='compiler-artifact' and row.get('executable') and row['target']['name'] in names: rows[row['target']['name']]=row
assert set(rows)==set(names),rows.keys()
assert 'test-fault-backend' in rows['s1_daemon']['features']
result={}
for name,row in rows.items():
 src=pathlib.Path(row['executable']);dst=out/name
 assert root in src.parents,src
 shutil.copy2(src,dst)
 result[name]={'path':str(dst),'sha256':hashlib.sha256(dst.read_bytes()).hexdigest(),'bytes':dst.stat().st_size,'features':row['features'],'profile':row['profile'],'source':row['executable']}
pathlib.Path('b4_peers_manifest.json').write_text(json.dumps(result,indent=2)+'\n')
PY
uv run --no-project python gate.py test_workspace_bound_peers -- env RUSTC_WRAPPER= CARGO_TARGET_DIR=build CARGO_BUILD_JOBS=2 B4_E2E_BIN_S0_DAEMON="$PWD/b4_peers/s0_daemon" B4_E2E_BIN_S1_DAEMON="$PWD/b4_peers/s1_daemon" B4_E2E_BIN_ROBOT_RPC_GATEWAY="$PWD/b4_peers/robot_rpc_gateway" cargo test --locked --workspace
