from pathlib import Path
import datetime,hashlib,json,subprocess,tarfile,io
repo=Path.cwd(); root=repo/'target/post_e_h2_rt/s49/delayed_ack_20260929'; verify=repo/'.verify/post_e_comm_fault_hardening'
def digest(data):return hashlib.sha256(data).hexdigest()
def ref(path):
 data=path.read_bytes();return {'path':str(path.relative_to(repo)),'bytes':len(data),'sha256':digest(data)}
source=json.loads((root/'final_software_changes.json').read_text())
assert subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()==source['base_commit']
for row in source['files']:
 p=repo/row['path'];assert p.stat().st_size==row['bytes'] and digest(p.read_bytes())==row['sha256'],row
 # 保存所有本轮软件变更的完整源码，基线未变文件仍由Git承接。
 dst=root/'source'/row['path'];dst.parent.mkdir(parents=True,exist_ok=True);dst.write_bytes(p.read_bytes())
ci=repo/'.github/workflows/ci.yml';dst=root/'source/.github/workflows/ci.yml';dst.parent.mkdir(parents=True,exist_ok=True);dst.write_bytes(ci.read_bytes())
required=['fmt_recompiled_source','clippy_recompiled_workspace','clippy_final_measurement','test_final_comm_fault','integration_final_rpc_transport','python_final_h2','unit_s1_runtime_isolated','build_final_comm_fault','build_b4_peers','test_workspace_bound_peers_serial']
for label in required:
 row=json.loads((root/'orin'/f'{label}.json').read_text());assert row['wait_returncode']==0 and row['reaped'],label
assert digest((verify/'H_evidence.tar.gz').read_bytes())=='3337206531273c274c050875ab0545e2a98e5c172e0f5f050591b19d100fafab'
(root/'archive_scope.md').write_text('''# 本包范围

本轮S49独立软件证据包，不改写旧H_evidence.tar.gz。完整gate日志、真实wait回执、两主机软件来源清单、Orin42原件及前后只读快照、开发期失败、独审与root结论在本包内。

source/包含本轮13项软件变更及CI文件；未改基线文件由Git 5213848efb37bb382c451892334ae7a25bb6c26a承接，不重复封装603项全部来源或ELF。最终权威来源清单为orin_final_build_manifest.json（5fcbda...2539），含辅助文件及符号链接；CLAUDE后续仅状态文档漂移。dev工具和冻结测试peer实际ELF留在Orin独立目录，身份在final_source_after.json及b4_peers_manifest.json。

原始默认并行失败不以串行通过覆盖。local_receipts_verified.json的空文件是首次辅助汇总扫描自身输出时失败留下的原件，v2修正后成功；它不是测试回执。0.44秒根Clippy不用于最终来源验收。CI尚未在线运行。右H2 FAIL、D15 OPEN、deployable=false保持。
''')
excluded={'orin_source_manifest_final.json','closeout_docs.py'}
files=[p for p in root.iterdir() if p.is_file() and p.suffix in {'.json','.log','.md','.py','.sh'} and p.name not in excluded]
files += [p for folder in ['orin','source'] for p in (root/folder).rglob('*') if p.is_file()]
files=sorted(files)
index=[{'path':str(p.relative_to(root)),'bytes':p.stat().st_size,'sha256':digest(p.read_bytes())} for p in files]
index_data=(json.dumps(index,ensure_ascii=False,indent=2)+'\n').encode()
archive=verify/'S49_final_stop_transport_evidence.tar.gz'
with tarfile.open(archive,'x:gz') as t:
 for p in files:t.add(p,arcname=str(p.relative_to(root)))
 info=tarfile.TarInfo('archive_index.json');info.size=len(index_data);t.addfile(info,io.BytesIO(index_data))
with tarfile.open(archive) as t:
 assert len(t.getmembers())==len(index)+1
 for row in index:
  data=t.extractfile(row['path']).read();assert len(data)==row['bytes'] and digest(data)==row['sha256'],row
now=datetime.datetime.now(datetime.timezone.utc).isoformat()
summary={
 'schema':'S49_FINAL_STOP_TRANSPORT_SOFTWARE_V1','status':'SOFTWARE_ACCEPTED_WITH_BASELINE_LIMITS','recorded_at':now,
 'source':{'base_commit':source['base_commit'],'software_changes':source['files'],'remote_manifest_sha256':'5fcbda255164cf91455d76183f2579abe737a2706c43ec36e634027220752539','remote_source_count':603,'scope':'602文件及1符号链接，含辅助来源；13项软件变更与最终已验快照一致，后续CLAUDE仅状态文档变化'},
 'remote_workspace':'/home/loosqk/repo/robot/robot-system/target/post_e_h2_rt/s49/rpc_transport_20260929_01',
 'toolchain':{'orin':'rustc 1.100.0-nightly (cea272fa3 2026-09-07)','local_final':'rustc 1.101.0-nightly (c1070d693 2026-09-28)'},
 'local':{'new_rpc_unit_passed':2,'loopback_tests_passed':6,'artifact_python_passed':15,'targeted_clippy':'PASS','full_workspace':'FAIL_LINUX_API_PLATFORM_LIMIT','full_python':'FAIL_LINUX_API_PLATFORM_LIMIT'},
 'orin':{'required_gates':required,'robot_tests_lib_passed':4,'new_rpc_unit_included':2,'comm_fault_tool_passed':182,'loopback_tests_passed':6,'loopback_scenarios':9,'positive_server_elapsed_ns':2101190176,'servers_joined_with_zero_active_requests':9,'python_passed':66,'s1_runtime_isolated_passed':14,'workspace_serial':{'passed':2214,'failed':0,'ignored':9,'test_threads':1,'bound_test_peers':'orin/b4_peers_manifest.json','count_scope':'72个独立测试或doc组，2223个具名条目无重复；不同gate计数不相加'},'default_parallel_status':'OPEN_S1_EVENT_RECEIVE_TIMEOUT'},
 'preserved_failures':[
  {'receipt':'clippy_workspace.json','reason':'本机旧编译缓存与变动后的nightly不兼容'},
  {'receipt':'clippy_workspace_isolated.json','reason':'本机Linux API限制及4个nightly lint；lint已等价修复，平台未改'},
  {'receipt':'clippy_rpc_transport.json','reason':'开发期三项测试lint，随后已修复'},
  {'receipt':'python_h2_artifacts_final.json','reason':'macOS扩大Python套66项中的Linux接口限制，2失败4错误；窄15项及Orin66项通过'},
  {'receipt':'orin/test_workspace.json','reason':'默认workspace的dimos工作流16通过2失败，缺fault peer前置；本轮绑定后串行18项通过'},
  {'receipt':'orin/test_final_affected.json','reason':'S1默认并行284通过2事件接收超时；具体根因OPEN，串行通过不回写'}],
 'not_accepted_as_final_source_proof':'orin/clippy_final_workspace.json：tar旧mtime可能复用缓存；以source_mtime_refresh及clippy_recompiled_workspace为准',
 'operational_state':json.loads((root/'orin_state_comparison.json').read_text()),
 'review':{'status':'APPROVED_INDEPENDENT_SOFTWARE_REVIEW','member':'independent_review.md','sha256':digest((root/'independent_review.md').read_bytes())},
 'evidence_archive':{**ref(archive),'members':len(index)+1,'indexed_files':len(index),'index_sha256':digest(index_data),'per_file_sha256_verified':True,'orin_original_files':42},
 'retention':'旧H大包SHA不变，本包独立保存本轮来源、通过与失败；ELF留在Orin隔离目录。提交身份在后生commit回执记录。',
 'limits':{'hardware_started':False,'formally_installed':False,'ci_executed':False,'right_h2':'FAIL','D15':'OPEN','deployable':False,'physical_state':'UNKNOWN','scope':'模拟回执不证明真实gateway grace、RR/Lower退休或硬件断扭；正式release测量件未重新批准。'}}
summary_path=verify/'S49_final_stop_transport.json';summary_path.write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n')
p=verify/'H.json';h=json.loads(p.read_text())
h['work_state']='S49_FINAL_DISABLE_TRANSPORT_SOFTWARE_ACCEPTED'
h['status']='S49_SOFTWARE_ACCEPTED_RIGHT_H2_REMAINS_FAIL'
h['review_status']='APPROVED_INDEPENDENT_S49_SOFTWARE_REVIEW'
h['resume_from']='2026-09-29软件续作已验收：最终Disable真实tonic回环、Orin编译/定向测试及绑定peer串行workspace通过；默认并行S1两例超时仍OPEN。右H2原整体FAIL、D15 OPEN；未正式安装或硬件重测。下一真实尝试需新来源/产物准备、当次现场事实和独立GO。'
h['software']['s49'].update(status=summary['status'],summary=ref(summary_path),evidence_archive=summary['evidence_archive'],review=summary['review'],validation=summary['orin'],operational_state=summary['operational_state'])
h['next_h2']['current_resume_note']='本轮最终Disable延迟回执软件回归及Orin串行workspace已通过；默认并行S1两例超时仍OPEN。右H2原run/report仍整体FAIL。未来真实重测需新源码/正式测量产物、现场事实、独立GO和新输出目录，旧重插答复及已消费输出不可复用。'
h['stop_after_current']['state']='软件阶段已验收，按既有规则提交且本轮不push；新硬件和正式安装须另具当次现场事实及授权。'
h['review']['scope_note']+=' 2026-09-29最终Disable软件回归独审通过，实际来源/42原件/串行workspace及前后快照见software.s49；默认并行S1失败保持OPEN，不改变右H2整体FAIL。'
h['retention']+=' S49独立小包另保存本轮42份Orin原件及本机日志/源码/评审；旧H大包SHA和全部硬件记录不变。'
plan=repo/h['plan']['path'];h['plan'].update(lines=len(plan.read_text().splitlines()),sha256=digest(plan.read_bytes()))
h['updated_at']=now;p.write_text(json.dumps(h,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'summary':ref(summary_path),'archive':summary['evidence_archive']},ensure_ascii=False))
