set -eu
export PATH=/home/loosqk/.cargo/bin:/home/loosqk/.local/bin:$PATH
cd /home/loosqk/repo/robot/robot-system/target/post_e_h2_rt/s49/rpc_transport_20260929_01
sha256sum -c final_update.sha256
tar -xzf final_update.tar.gz
uv run --no-project python - <<'PY'
import pathlib,json,hashlib
manifest=pathlib.Path('final_build_manifest.json')
rows=json.loads(manifest.read_text())['files']
for row in rows:
 p=pathlib.Path(row['path'])
 if 'link' in row: assert p.is_symlink() and str(p.readlink())==row['link'],row
 else:
  data=p.read_bytes()
  assert len(data)==row['bytes'] and hashlib.sha256(data).hexdigest()==row['sha256'],row
result={'verified':True,'count':len(rows),'manifest_sha256':hashlib.sha256(manifest.read_bytes()).hexdigest()}
pathlib.Path('final_source_verified.json').write_text(json.dumps(result,indent=2)+'\n')
print(result)
PY
uv run --no-project python gate.py fmt_final_build -- cargo fmt --all
uv run --no-project python gate.py clippy_final_workspace -- env RUSTC_WRAPPER= CARGO_TARGET_DIR=build CARGO_BUILD_JOBS=2 cargo clippy --all --all-targets -- -D warnings
uv run --no-project python gate.py clippy_final_measurement -- env RUSTC_WRAPPER= CARGO_TARGET_DIR=build CARGO_BUILD_JOBS=2 cargo clippy --locked -p robot-tests --no-default-features --features comm-fault-e2e,real-hw --bin comm_fault_e2e --lib --test final_stop_transport --message-format=json -- -D warnings
uv run --no-project python gate.py test_final_affected -- env RUSTC_WRAPPER= CARGO_TARGET_DIR=build CARGO_BUILD_JOBS=2 cargo test --locked -p robot-rpc -p robot-s1 -p robot-tests --lib --bin hello_pubsub
uv run --no-project python gate.py python_final_h2 -- uv run --no-project python -m unittest discover -s scripts/tests -p 'test_*.py' -v
uv run --no-project python gate.py test_final_comm_fault -- env RUSTC_WRAPPER= CARGO_TARGET_DIR=build CARGO_BUILD_JOBS=2 cargo test --locked -p robot-tests --features comm-fault-e2e --bin comm_fault_e2e --lib
uv run --no-project python gate.py integration_final_rpc_transport -- env RUSTC_WRAPPER= CARGO_TARGET_DIR=build CARGO_BUILD_JOBS=2 cargo test --locked -p robot-tests --features comm-fault-rpc --test final_stop_transport -- --ignored --test-threads=1 --nocapture
uv run --no-project python gate.py build_final_comm_fault -- env RUSTC_WRAPPER= CARGO_TARGET_DIR=build CARGO_BUILD_JOBS=2 cargo build --locked -p robot-tests --features comm-fault-e2e --bin comm_fault_e2e
