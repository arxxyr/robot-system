set -eu
export PATH=/home/loosqk/.cargo/bin:/home/loosqk/.local/bin:$PATH
cd /home/loosqk/repo/robot/robot-system/target/post_e_h2_rt/s49/rpc_transport_20260929_01
uv run --no-project python - <<'PY'
import pathlib,json,hashlib,time
rows=json.loads(pathlib.Path('final_build_manifest.json').read_text())['files']
changed=['crates/robot-rpc/src/state_convert.rs','crates/robot-s1/src/events_drain/runtime.rs','crates/robot-s1/src/rr_server/wire.rs','crates/robot-tests/src/bin/hello_pubsub.rs','scripts/post_e_h2_artifacts.py','scripts/tests/test_post_e_h2_artifacts.py']
record=[]
for name in changed:
 p=pathlib.Path(name); before=p.stat().st_mtime_ns; digest=hashlib.sha256(p.read_bytes()).hexdigest(); p.touch()
 record.append({'path':name,'before_mtime_ns':before,'after_mtime_ns':p.stat().st_mtime_ns,'sha256':digest})
for row in rows:
 p=pathlib.Path(row['path'])
 if 'link' in row: assert p.is_symlink() and str(p.readlink())==row['link'],row
 else: assert len(p.read_bytes())==row['bytes'] and hashlib.sha256(p.read_bytes()).hexdigest()==row['sha256'],row
pathlib.Path('source_mtime_refresh.json').write_text(json.dumps({'verified':True,'count':len(rows),'files':record},indent=2)+'\n')
PY
uv run --no-project python gate.py fmt_recompiled_source -- cargo fmt --all
uv run --no-project python gate.py clippy_recompiled_workspace -- env RUSTC_WRAPPER= CARGO_TARGET_DIR=build CARGO_BUILD_JOBS=2 cargo clippy --all --all-targets -- -D warnings
overall=0
uv run --no-project python gate.py python_final_h2 -- uv run --no-project python -m unittest discover -s scripts/tests -p 'test_*.py' -v || overall=1
uv run --no-project python gate.py integration_final_rpc_transport -- env RUSTC_WRAPPER= CARGO_TARGET_DIR=build CARGO_BUILD_JOBS=2 cargo test --locked -p robot-tests --features comm-fault-rpc --test final_stop_transport -- --ignored --test-threads=1 --nocapture || overall=1
uv run --no-project python gate.py unit_s1_runtime_isolated -- env RUSTC_WRAPPER= CARGO_TARGET_DIR=build CARGO_BUILD_JOBS=2 cargo test --locked -p robot-s1 --lib events_drain::runtime::tests -- --test-threads=1 || overall=1
uv run --no-project python gate.py test_final_comm_fault -- env RUSTC_WRAPPER= CARGO_TARGET_DIR=build CARGO_BUILD_JOBS=2 cargo test --locked -p robot-tests --features comm-fault-e2e --bin comm_fault_e2e --lib || overall=1
uv run --no-project python gate.py build_final_comm_fault -- env RUSTC_WRAPPER= CARGO_TARGET_DIR=build CARGO_BUILD_JOBS=2 cargo build --locked -p robot-tests --features comm-fault-e2e --bin comm_fault_e2e || overall=1
exit "$overall"
