import hashlib,json,pathlib,re,sys
root=pathlib.Path(__file__).resolve().parent
receipts=[]
for directory in [root,root/'orin']:
 if not directory.exists():continue
 for file in sorted(directory.glob('*.json')):
  if not file.with_suffix('.log').is_file():continue
  record=json.loads(file.read_text())
  if not isinstance(record,dict) or not {'wait_returncode','reaped','log_sha256','command'}<=record.keys():continue
  log=directory/pathlib.Path(record['log']).name
  data=log.read_bytes()
  assert len(data)==record['log_bytes'] and hashlib.sha256(data).hexdigest()==record['log_sha256'],file
  assert record['reaped'] is True and isinstance(record['pid'],int) and record['pid']>0,file
  tests=[dict(zip(['passed','failed','ignored','measured','filtered'],map(int,row))) for row in re.findall(r'test result: \w+\. (\d+) passed; (\d+) failed; (\d+) ignored; (\d+) measured; (\d+) filtered out',data.decode(errors='replace'))]
  py=re.findall(r'Ran (\d+) tests? in',data.decode(errors='replace'))
  receipts.append({'receipt':str(file.relative_to(root)),'wait_returncode':record['wait_returncode'],'sha256_verified':True,'tests':tests,'python_test_count':list(map(int,py))})
print(json.dumps(receipts,ensure_ascii=False,indent=2))
