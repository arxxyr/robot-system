import hashlib,json,pathlib,tarfile,sys
root=pathlib.Path.cwd(); label=sys.argv[1]
files=set()
for receipt in root.glob('*.json'):
 try: r=json.loads(receipt.read_text())
 except ValueError: continue
 if not isinstance(r,dict) or 'wait_returncode' not in r: continue
 log=root/r['log']; data=log.read_bytes()
 assert log.parent==root and r['reaped'] and r['pid']>0
 assert hashlib.sha256(data).hexdigest()==r['log_sha256'] and len(data)==r['log_bytes']
 files.update([receipt,log])
for name in ['source_manifest.json','source_verified.json','final_build_manifest.json','final_source_verified.json','source_mtime_refresh.json','b4_peers_manifest.json','final_source_after.json','gate.py']:
 p=root/name
 if p.exists():files.add(p)
rows=[{'path':p.name,'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'bytes':p.stat().st_size} for p in sorted(files)]
index=root/(label+'_index.json');index.write_text(json.dumps(rows,indent=2)+'\n')
archive=root/(label+'.tar.gz')
with tarfile.open(archive,'x:gz') as t:
 for p in sorted(files):t.add(p,arcname=p.name)
 t.add(index,arcname=index.name)
print(json.dumps({'path':archive.name,'sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'bytes':archive.stat().st_size,'files':len(files)}))
