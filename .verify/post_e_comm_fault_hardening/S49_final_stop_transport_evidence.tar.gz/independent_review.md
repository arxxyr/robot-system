# 独立软件验收评审

评审者：next_step_review（非实现作者）。最终结论：本轮核心软件、绑定隔离测试 peer 的完整 workspace 串行复验及最终前后状态核验通过，可收口本软件阶段。原默认并行 S1 失败仍 OPEN；不宣称默认并行全绿、真实 gateway/RR/Lower 验收或硬件通过。

## 已完成的源码与本机检查

- 最终 Disable 使用 `robot_tests::comm_fault_rpc::final_stop_rpc`，现场工具和跨平台集成测试共用真实连接、请求生成及 Ack 校验。请求序号只有一份，不产生独立计数器撞幂等键。
- 最终传输 3 秒、普通传输 2 秒、业务 2000ms 及既有 gateway grace 500ms 保持。服务模拟只证明工具及 tonic 传输，不证明真实 gateway grace、Lower 退休或硬件断扭。
- `comm-fault-rpc` 未改变默认 feature；将其展开后，`comm-fault-e2e` 的依赖 feature 集合与旧定义相同。产物校验仍严格比较实际三项 feature，原 CLI recipe 不变。独立 Python artifact 测试 15/15 通过。
- 四处新 nightly lint 调整语义等价：缺失/错误仍为空 Vec，成功仍执行原转换；S1 仍在锁内取出句柄、锁外逐个 join。无 S0 变更。
- 本机 source.json 的 13 项清单、最终定向 Clippy/单测/集成日志已逐 SHA 和大小核验。2 项单测与 6 个集成测试的 9 场景通过；阳性服务实际延迟 2101792416ns。
- 曾发现并要求移除客户端 RAW 时钟与 tonic 2/3 秒期限的跨时钟精确边界断言。当前保留实际返回状态、同域服务延迟和原始计时；未放宽任何业务预算。

## Orin 核心证据

- `orin_evidence_core.tar.gz` 实测 SHA-256 为 `25fa9fa5bcea6ca97bda597d8e91c30e9521acb1fe0c9c0b8b638733aa3885c3`，132269 bytes。`orin/evidence_core_index.json` 的 36 件原件逐项 bytes/SHA 及包内字节一致。
- 15 份 gate 回执均核验对应日志 SHA/bytes、PID、开始/结束时序及 `reaped=true`；已读 `gate.py`，该字段在原 `Popen.wait()` 返回后生成。两个原 exit 101 保持失败，不汇入成功门。
- 最终清单 SHA 为 `5fcbda255164cf91455d76183f2579abe737a2706c43ec36e634027220752539`，603 项由 602 个文件与 AGENTS.md→CLAUDE.md 符号链接组成。当前本地仅 CLAUDE.md 有后续文档变化，软件 bytes/SHA 完整匹配。
- 六项 mtime 刷新记录的 SHA 与最终清单一致，新 mtime 均晚于旧值；后续根 Clippy 在刷新之后执行，日志明确重新 Checking robot-rpc、robot-s1、robot-tests、robot-cli，编译耗时 7.64 秒，exit 0。认可 `clippy_recompiled_workspace`；不以仅 0.44 秒的 `clippy_final_workspace` 证明最终源新鲜编译。
- `clippy_final_measurement` 原 Cargo JSON 中 robot_tests、final_stop_transport、comm_fault_e2e 均 `fresh=false`，实际 feature 完整等于 `comm-fault-e2e, comm-fault-rpc, real-hw`；exit 0，无放宽严格闭包。
- `test_final_comm_fault`：lib 4/4（其中本次共用 RPC 2 项）与工具 182/182。`build_final_comm_fault` 的开发构建 exit 0，不将它描述为生产/测量 release 冻结产物。
- `integration_final_rpc_transport`：6 个测试、9 场景通过。阳性服务 RAW 延迟 2101190176ns，正确非 dry-run Ack 保持原请求身份；同 2100ms 普通连接与 3300ms 最终连接实际返回 Cancelled/Timeout expired。服务错误、错误身份、dry-run、零完成时间、非状态 3、状态 RPC 错误均按预期拒绝。9 场景都已 join 服务且 active_requests=0。
- `python_final_h2`：66/66，包含新 artifact 正例和缺失、多余、重复 feature 反例。

## 最终补件与收尾验收

- `orin_evidence_final.tar.gz` 实测 SHA-256 为 `007d94b7da09ff4f8d46da904bb9cbf078cd181b8c9049da5df15613d2704dfa`，189078 bytes。最终索引 42 件原件逐项 bytes/SHA 及包内字节一致，旧 36 件的内容与索引保持不变。
- 新增 build_b4_peers 与 test_workspace_bound_peers_serial 均原 Popen.wait 返回 0、reaped=true；日志大小、SHA 与回执相符。三个 peer 的 Cargo metadata 与冻结清单逐项一致；S1 显式启用 test-fault-backend，均为 dev profile。脚本用 copy2 复制到本轮独立 b4_peers 路径，workspace 通过三条 B4_E2E_BIN_* 环境变量精确绑定这些副本，不用正式安装件。
- `cargo test --locked --workspace -- --test-threads=1` 成功。独立重算 72 组 running/result 一一对应，共 2214 passed、0 failed、9 ignored；按 Cargo runner/文档组检查 2223 条实际测试名称，无重复项，没有把子测试结果再加一次。该计数单独属于本轮绑定 peer 的串行命令，不与前述定向门相加。
- Orin 原生工具链身份前后相同：rustc 1.100.0-nightly，commit `cea272fa356e94bd2ee2cadf376630aa0683867a`，host aarch64-unknown-linux-gnu。它与本机 macOS 1.101.0-nightly 为不同 nightly，未混称同一编译器验证。
- 独立比较 orin_before.log 与 orin_after.log：只多出 systemctl 批量输出的五个空行，所有非空行完全相同。正式源码 HEAD ca14f0e 保持 clean，四个正式安装文件 SHA 相同，六服务均 inactive/dead/MainPID=0；限定四类控制程序的 pgrep 无输出。已核相应 SSH 原始回执、日志 SHA/大小与真实退出回收。
- 最终源复检再次核验 603 项内容与清单 SHA；三个冻结 peer 字节/SHA 未变。comm_fault_e2e 的 dev 构建身份有独立 SHA/大小记录，仍非正式 release 测量产物批准。
- HANDOFF、10_verification 与当前状态入口的已验范围、原失败及硬件边界一致；10_verification 的 Rust 路径拼写提醒 root 将连字符改为下划线，不影响验收语义。

## 保留的失败与范围边界

- `test_workspace` 原 exit 101（dimos_workflow_e2e 两例失败）保留。随后补足本轮隔离 fault peer 的串行通过不改写原运行。
- `test_final_affected` 原默认并行 exit 101，S1 284 通过、2 失败保持。`unit_s1_runtime_isolated` 串行 14/14 只属于后续判别，不回写默认并行结果；具体根因未定。
- 一次独立只读清单检查把符号链接误当普通文件触发 KeyError；随后按 602 文件加 1 符号链接完整复验通过，未修改源码或原证据。
- marker/latch 本轮未重读；现场电源、支撑与接触区 UNKNOWN。右 H2 原整体 FAIL、D15 OPEN、deployable=false 保持；本报告不授权现场动作，不证明当前物理电源或扭矩状态。
