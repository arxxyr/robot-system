set -eu
export PATH=/home/loosqk/.cargo/bin:/home/loosqk/.local/bin:$PATH
export CARGO_HOME=/home/loosqk/robot-checks/viz-orin-a6957cc-20260930-r1/cargo-home
export CARGO_NET_OFFLINE=true
export RUSTUP_AUTO_INSTALL=0
export PYTHONDONTWRITEBYTECODE=1
cd /home/loosqk/robot-checks/feetech-wheel-raw-read-20261008-r1/bootstrap
sha256sum -c - <<'SHA_INPUTS'
bd2b3f7bb8527cd9ecec73894171638e9cf378656b89e284a585c3baa37b8731  artifacts.py
dad9bbc9405b8fac4d60d6efe794b36750e6a6f9ce9fdeba3debf7d3e1b9a471  natural_runner.py
e2b168721646cc1fd4e622d8b1fc746b8d6dbf8a62720fe9415c4ed6ca51b1b0  expected_source.json
0478ca5523a31ed67b82f253f15c9a88b37c896e1b081cf51f444547b2d066b8  source_export.json
6217bdca0fa5cc3fad77b0a92225e76f7017a041ba3d38c9e3199dc69d7ab881  source-inputs.tar.gz
39c0b54228ccbc1c3461668bccd0481885f49e975642024e4d4d021702b6f055  test_roster.json
f7b12ad1b9162f23b80a4ae527f32884d6253d46739930367cae1208989f1573  candidate_manifest_r1.json
d7c3f1debdb7be4dc6eaef4b05f27b3d792bde611ce607d94a920d2b9be5ff57  receive_source.py
c4f5e9b17f042433ee6141c33b0b5376ed0b10dd0098482dd0d37bb731eadc03  run_raw_read.py
SHA_INPUTS
uv run --no-project python receive_source.py
exec taskset -c 0-3 uv run --no-project python run_raw_read.py
