"""仅解包本轮普通编译输入并逐件核验；不执行源码、Cargo或硬件。"""
import hashlib,importlib.util,json,os,stat,tarfile
from pathlib import Path,PurePosixPath
BASE=Path('/home/loosqk/robot-checks/feetech-wheel-raw-read-20261008-r1');BOOT=BASE/'bootstrap';SOURCE=BASE/'source'
spec=importlib.util.spec_from_file_location('artifacts',BOOT/'artifacts.py');a=importlib.util.module_from_spec(spec);spec.loader.exec_module(a)
expected=a.strict_json((BOOT/'expected_source.json').read_text());meta=a.strict_json((BOOT/'source_export.json').read_text());archive=BOOT/'source-inputs.tar.gz'
a.require(meta['source_manifest']==expected and meta['archive']=={'sha256':a.sha256(archive),'bytes':archive.stat().st_size} and meta['artifacts_sha256']==a.sha256(BOOT/'artifacts.py'),'传输身份不匹配')
a.require(os.getuid()==1000 and os.getgid()==1000 and Path('/proc/sys/kernel/random/boot_id').read_text().strip()=='6cf7ee3e-a3c5-4c91-80bc-4ca924818b53','主机身份变化')
a.require(not os.path.lexists(SOURCE),'源目录必须新建');SOURCE.mkdir();seen=set()
with tarfile.open(archive,'r:gz') as tar:
 for member in tar:
  name=member.name;relative=PurePosixPath(name);a.require(member.isfile() and not member.islnk() and not member.issym() and not relative.is_absolute() and '..' not in relative.parts and str(relative)==name and name not in seen and name in expected['files'],'拒绝额外/重复/非普通输入')
  item=meta['files'][name];a.require(member.size==item['bytes'] and member.mode==item['mode'],'size/mode不同');stream=tar.extractfile(member);a.require(stream is not None,'成员不可读');data=stream.read(item['bytes']+1);a.require(len(data)==item['bytes'] and hashlib.sha256(data).hexdigest()==item['sha256'],'成员原文不同');dest=SOURCE/name;dest.parent.mkdir(parents=True,exist_ok=True)
  with dest.open('xb') as output:output.write(data)
  dest.chmod(item['mode']);a.require(dest.resolve()==dest and stat.S_ISREG(dest.lstat().st_mode) and a.sha256(dest)==item['sha256'] and dest.stat().st_size==item['bytes'] and stat.S_IMODE(dest.stat().st_mode)==item['mode'],'解包读回不同');seen.add(name)
a.require(seen==set(expected['files']) and not os.path.lexists(SOURCE/'.git') and a.snapshot_source(SOURCE,sorted(seen))==expected,'源集合/身份不同')
result={'status':'PASS_RECEIVE_ONLY','source_kind':'exported snapshot','native_git_head':None,'source_files':len(seen),'aggregate':expected['source_manifest_sha256'],'source_export_sha256':a.sha256(BOOT/'source_export.json'),'archive_sha256':a.sha256(archive)}
with (BOOT/'receive_result.json').open('x') as f:json.dump(result,f,ensure_ascii=False,indent=2);f.write('\n')
print(json.dumps(result,ensure_ascii=False))
