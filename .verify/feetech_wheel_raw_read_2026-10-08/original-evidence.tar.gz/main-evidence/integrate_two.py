"""验收后整合原始读回两源；精确备份、原子更换，失败恢复。"""
import importlib.util
import json
import os
import stat
import subprocess
from pathlib import Path

root = Path('/Users/loosqk/repo/rust/robot-system')
candidate = Path('/Users/loosqk/.codex/worktrees/feetech-wheel-raw-read/robot-system')
area = root / 'target/wheel_raw_read_integration_2026-10-08'
spec = importlib.util.spec_from_file_location('helpers', root / 'scripts/post_e_h2_artifacts.py')
a = importlib.util.module_from_spec(spec)
spec.loader.exec_module(a)
manifest_path = candidate / 'target/wheel_raw_read/freeze_r1/candidate_manifest_r1.json'
assert a.sha256(manifest_path) == 'f7b12ad1b9162f23b80a4ae527f32884d6253d46739930367cae1208989f1573'
manifest = json.loads(manifest_path.read_text())
expected = a.read_pinned_json(manifest['expected_source'])
approval_path = area / 'root_acceptance_r1.json'
approval = json.loads(approval_path.read_text())
assert approval['status'] == 'PASS_SCOPED_SOFTWARE_APPROVED_FOR_MAIN_INTEGRATION'
assert approval['source_manifest_sha256'] == expected['source_manifest_sha256']
children = []

def git(*args):
    child = subprocess.Popen(['git', *args], cwd=root, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    out, err = child.communicate()
    children.append({'argv': ['git', *args], 'pid': child.pid,
                     'exit_code': child.returncode, 'actual_wait_reap': True})
    assert child.returncode == 0, err.decode()
    return out.decode()

def snapshot():
    names = git('ls-files', '-z', '--cached', '--others', '--exclude-standard').rstrip('\0').split('\0')
    return a.snapshot_source(root, names)

base_head = git('rev-parse', 'HEAD').strip()
assert base_head == 'fb390abf1b96177a1f1c48800d158cdaebdf5cfc'
assert git('status', '--porcelain=v1', '--untracked-files=all') == ''
before = snapshot()
assert before['source_manifest_sha256'] == manifest['baseline_source_aggregate']
backup = area / 'main_backup_r1'
backup.mkdir()
payloads = {}
old = {}
for name, row in manifest['changed_against_deadline'].items():
    target = root / name
    source = candidate / name
    assert not target.is_symlink() and not source.is_symlink()
    if row['old'] is None:
        assert name not in before['files'] and not target.exists()
        old[name] = None
    else:
        assert before['files'][name] == row['old']
        old[name] = (target.read_bytes(), stat.S_IMODE(target.stat().st_mode))
        saved = backup / name
        saved.parent.mkdir(parents=True, exist_ok=True)
        saved.write_bytes(old[name][0])
        saved.chmod(old[name][1])
    assert source.stat().st_size == row['new']['bytes'] and a.sha256(source) == row['new']['sha256']
    assert bool(source.stat().st_mode & stat.S_IXUSR) == row['new']['executable']
    payloads[name] = (source.read_bytes(), stat.S_IMODE(source.stat().st_mode))

def replace(path, data, mode):
    temp = path.with_name(path.name + '.raw_integrate_tmp')
    with temp.open('xb') as output:
        output.write(data)
    temp.chmod(mode)
    os.replace(temp, path)

written = []
try:
    for name, value in payloads.items():
        replace(root / name, *value)
        written.append(name)
    after = snapshot()
    assert after == expected
    changed = set(git('diff', '--name-only').splitlines())
    changed.update(git('ls-files', '--others', '--exclude-standard').splitlines())
    assert changed == set(payloads)
except BaseException:
    for name in reversed(written):
        if old[name] is None:
            (root / name).unlink()
        else:
            replace(root / name, *old[name])
    raise

receipt = {'status': 'PASS_EXACT_TWO_OVERLAYS_SAME_NATIVE_SOURCE',
           'base_head': base_head, 'source_count': 597,
           'before': before, 'after': after, 'changed_sources': written,
           'root_acceptance_sha256': a.sha256(approval_path),
           'git_children': children,
           'limits': '仅精确源码整合；不是新的测试、硬件、部署或推送'}
with (area / 'root_integration_r1.json').open('x') as output:
    json.dump(receipt, output, ensure_ascii=False, indent=2)
    output.write('\n')
print(json.dumps({k: receipt[k] for k in ('status', 'source_count', 'changed_sources')}, ensure_ascii=False))
