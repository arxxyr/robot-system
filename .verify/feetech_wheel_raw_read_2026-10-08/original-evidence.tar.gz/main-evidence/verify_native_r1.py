"""仅读本机取回原件；不执行Cargo、SSH或设备IO。"""
import ast
import hashlib
import importlib.util
import json
import re
import stat
from pathlib import Path, PurePosixPath

ROOT = Path(__file__).parent / 'native-r1'
QA = ROOT / 'orin-originals/qa'
REMOTE = PurePosixPath('/home/loosqk/robot-checks/feetech-wheel-raw-read-20261008-r1/qa')


def pin(path):
    raw = path.read_bytes()
    return {'path': str(path), 'sha256': hashlib.sha256(raw).hexdigest(), 'bytes': len(raw)}


def load(path):
    return json.loads(path.read_text())


def canonical(value):
    return json.dumps(value, sort_keys=True, separators=(',', ':'), ensure_ascii=False).encode()


def save(path, value):
    raw = json.dumps(value, ensure_ascii=False, indent=2) + '\n'
    if path.exists():
        assert path.read_text() == raw, '既有回执与当前原件派生不同，不覆盖'
    else:
        with path.open('x') as stream:
            stream.write(raw)


def local(remote):
    path = PurePosixPath(remote)
    assert path.is_absolute() and '..' not in path.parts
    relative = path.relative_to(REMOTE)
    actual = QA / relative
    assert actual.resolve() == actual and stat.S_ISREG(actual.lstat().st_mode)
    return actual


spec = importlib.util.spec_from_file_location('artifacts', ROOT / 'artifacts.py')
a = importlib.util.module_from_spec(spec)
spec.loader.exec_module(a)
plan = load(ROOT / 'execution_plan.json')
expected = a.validate_source_manifest(load(ROOT / 'expected_source.json'))
roster = load(ROOT / 'test_roster.json')
result = load(QA / 'result.json')
assert len(expected['files']) == 597 and expected['source_manifest_sha256'] == '5c8c4c049ba57874f550f4dad7a60c47d9c00df4514310c8f980979d3969ec9f'
assert result['status'] == 'PASS' and result.get('error') is None and result['deployable'] is False
assert result['source_aggregate'] == expected['source_manifest_sha256'] and result['source_count'] == 597
assert result['compiler_window'] == result['source_window'] == 'PASS'
assert result['compiler_before'] == result['compiler_after'] == {'release': '1.101.0-nightly', 'commit_hash': '1d81eb4ad9cd207e3e638bd32b17ec4fce8412a6', 'host': 'aarch64-unknown-linux-gnu'}
assert result['planned_command_names'] == plan['commands_in_order'] and result['all_planned_commands_completed'] is True
assert result['not_run'] == [] and result['interrupted_signal'] is None and result['identity'] == plan['expected_identity']
assert len(result['receipts']) == 15
rows = []
identity_keys = ['name', 'argv', 'cwd', 'env', 'removed_env_keys', 'started_at', 'started_monotonic_ns',
                 'timeout_seconds', 'stdout', 'stderr', 'launch_receipt', 'completion_receipt', 'pid', 'identity']
previous_end = None
for name, reference in zip(plan['commands_in_order'], result['receipts']):
    completion_path = local(reference['path'])
    assert pin(completion_path)['sha256'] == reference['sha256']
    row = load(completion_path)
    launch = load(local(row['launch_receipt']))
    assert row['completion_receipt'] == reference['path'] and row['name'] == name
    assert all(row[key] == launch[key] for key in identity_keys)
    assert launch['reaped'] is False and launch['exit_code'] is None and launch['signals'] == [] and 'runner_error' not in launch
    assert row['reaped'] is True and row['exit_code'] == 0 and row['signals'] == [] and 'runner_error' not in row
    assert row['budget_exceeded'] is False and row['exec_gate_released'] is True
    assert row['session_residual_before_cleanup'] == row['session_residual_after_cleanup'] == []
    assert row['identity']['pid'] == row['pid'] > 0 and row['identity']['start_ticks'] > 0
    assert row['identity']['boot_id'] == plan['expected_identity']['boot_id'] and Path(row['identity']['exe']).is_absolute()
    assert row['identity']['sid'] == row['pid'] == row['identity']['pgid']
    assert row['cwd'] == str(REMOTE.parent / 'source')
    assert row['env']['RUSTUP_TOOLCHAIN'] == 'nightly' and row['env']['RUSTC_WRAPPER'] == ''
    assert row['env']['CARGO_TARGET_DIR'] == plan['target_cache'] and row['env']['CARGO_BUILD_JOBS'] == '2'
    assert row['ended_monotonic_ns'] >= row['started_monotonic_ns']
    if previous_end is not None:
        assert row['started_monotonic_ns'] >= previous_end
    previous_end = row['ended_monotonic_ns']
    for stream in ['stdout', 'stderr']:
        actual = pin(local(row[stream]))
        assert actual['sha256'] == row[stream + '_sha256'] and actual['bytes'] == row[stream + '_bytes']
    for side in ['before', 'after']:
        assert load(QA / (name + '_source_' + side + '.json')) == expected
    rows.append({'name': name, 'argv': row['argv'], 'pid': row['pid'], 'start_ticks': row['identity']['start_ticks'],
                 'natural_wait_reap_exit_zero': True, 'completion': pin(completion_path)})
assert rows[2]['argv'] == ['cargo', '+nightly', 'fmt', '--all']
assert rows[3]['argv'] == ['cargo', '+nightly', 'clippy', '--locked', '--all', '--all-targets', '--', '-D', 'warnings']
assert rows[4]['argv'] == ['cargo', '+nightly', 'clippy', '--locked', '--all', '--all-targets', '--features', 'robot-adapter-feetech/real-hw', '--', '-D', 'warnings']
assert load(QA / 'source_before.json') == load(QA / 'source_after.json') == expected
assert len(list(QA.glob('*source*.json'))) == 32
assert (QA / 'cargo_before/stdout.log').read_bytes() == (QA / 'cargo_after/stdout.log').read_bytes()
assert b'-nightly' in (QA / 'cargo_before/stdout.log').read_bytes()
for name in ['rustc_before', 'rustc_after']:
    assert a.parse_rustc_identity((QA / name / 'stdout.log').read_text()) == result['compiler_before']

# 独立读取同一运行器的纯解析函数，原件不改绝对路径或运行输出。
tree = ast.parse((ROOT / 'run_raw_read.py').read_text())
pure = [node for node in tree.body if isinstance(node, ast.FunctionDef) and node.name in {'list_blocks', 'run_blocks', 'parse_allocator_negative'}]
namespace = {'re': re, 'require': a.require}
exec(compile(ast.Module(body=pure, type_ignores=[]), '<pure-parser-only>', 'exec'), namespace)
suites = [('feetech_default', roster['lib_default']), ('feetech_real_hw', roster['lib_real_hw']),
          ('comm_fault_transport', roster['comm_fault_transport']), ('abort_diagnostics', roster['abort_diagnostics'])]
allocator_children = []
for name, wanted in suites:
    listing = namespace['list_blocks']((QA / (name + '_list') / 'stdout.log').read_text())
    actual = namespace['run_blocks']((QA / name / 'stdout.log').read_text())
    assert len(listing) == len(actual) == 1 and len(listing[0]) == len(wanted) and set(listing[0]) == set(wanted)
    assert actual[0]['counts'] == {'passed': len(wanted), 'failed': 0, 'ignored': 0, 'measured': 0, 'filtered_out': 0}
    assert {row['name'] for row in actual[0]['methods']} == set(wanted)
    assert result['tests'][name]['actual_suites'] == actual
    if name in ['feetech_default', 'feetech_real_hw']:
        negative = namespace['parse_allocator_negative']((QA / name / 'stderr.log').read_text(), name)
        assert negative == result['tests'][name]['allocator_negative_child']
        allocator_children.append({'suite': name, **negative})
assert len(roster['raw_read_new_subset']) == 13 and set(roster['raw_read_new_subset']) <= set(roster['lib_default'])
assert set(roster['lib_default']) == set(roster['lib_real_hw']) and len(roster['lib_default']) == 213
assert result['count_policy']['distinct_suite_methods'] == 230
receive = load(ROOT / 'orin-originals/receive_result.json')
assert receive['status'] == 'PASS_RECEIVE_ONLY' and receive['native_git_head'] is None and receive['source_files'] == 597
assert receive['aggregate'] == expected['source_manifest_sha256']
assert receive['archive_sha256'] == pin(ROOT / 'source-inputs.tar.gz')['sha256']
assert receive['source_export_sha256'] == pin(ROOT / 'source_export.json')['sha256']

owners = []
for name in ['ssh_config', 'identity', 'create_remote', 'upload_bootstrap', 'orin_raw_read', 'download_originals', 'post_identity']:
    path = ROOT / (name + '.owner/result.json')
    owner = load(path)
    assert owner['status'] == 'PASS' and owner['reaped'] is True and owner['wait_returncode'] == 0
    assert owner['errors'] == [] and owner['owner_sent_signals'] == [] and owner['received_signals'] == {}
    assert owner['log']['sha256'] == pin(Path(owner['log']['path']))['sha256']
    assert owner['log']['bytes'] == pin(Path(owner['log']['path']))['bytes']
    owners.append({'name': name, 'pid': owner['pid'], 'actual_natural_wait_reap': True, 'receipt': pin(path)})
post = load(ROOT / 'post_identity.owner/result.json')
post_fact = load(ROOT / 'post_identity.owner/child.log')
assert post_fact['status'] == 'PASS_READ_ONLY_IDENTITY_NO_ACTIVE_CARGO'
assert post_fact['identity'] == plan['expected_identity'] and post_fact['active_cargo_compilers'] == []

report = {'status': 'PASS_LOCAL_READBACK_OF_ACTUAL_ORIN_R1', 'native_result': pin(QA / 'result.json'),
          'source_count': 597, 'source_aggregate': expected['source_manifest_sha256'],
          'actual_compiler': result['compiler_before'], 'compiler_and_source_windows': 'PASS',
          'all_32_full_source_snapshots_exact': True, 'actual_native_commands': rows,
          'allocator_negative_children': allocator_children, 'actual_local_external_owners': owners,
          'core_build_cache_returned_no_active_compiler': True, 'post_identity': pin(ROOT / 'post_identity.owner/child.log'),
          'tests': {'lib_default': 213, 'lib_real_hw': 213, 'same_methods_overlap': 213, 'raw_new_subset': 13,
                    'comm_fault_transport': 12, 'abort_diagnostics': 5, 'different_suite_methods': 230, 'ignored': 0},
          'boundary': '限定组件软件验收；非完整workspace/release/RT/H2/USB固件认证/完整B1/实机动作/服务/安装/部署/push',
          'independent_review': 'PENDING_PARENT_ASSIGNMENT', 'main_raw_read_integration': 'NOT_DONE_BY_THIS_AGENT'}
save(ROOT / 'verification_r1.json', report)
files = {}
for path in sorted((ROOT / 'orin-originals').rglob('*')):
    if path.is_file():
        assert not path.is_symlink()
        item = pin(path)
        files[path.relative_to(ROOT).as_posix()] = {key: item[key] for key in ['bytes', 'sha256']}
for name in ['expected_source.json', 'test_roster.json', 'candidate_manifest_r1.json', 'source_export.json', 'source-inputs.tar.gz',
             'run_raw_read.py', 'receive_source.py', 'natural_runner.py', 'artifacts.py', 'host_owner.py', 'execution_plan.json',
             'launch_raw_read.sh', 'identity_read.sh', 'create_remote.sh', 'parser_preflight.json', 'preparation_receipt.json',
             'root_execution_authorization_r1.json', 'verification_r1.json']:
    item = pin(ROOT / name)
    files[name] = {key: item[key] for key in ['bytes', 'sha256']}
for owner in owners:
    for name in ['launch.json', 'result.json', 'child.log']:
        relative = owner['name'] + '.owner/' + name
        item = pin(ROOT / relative)
        files[relative] = {key: item[key] for key in ['bytes', 'sha256']}
index = {'schema': 'WHEEL_RAW_READ_NATIVE_R1_INPUT_AND_ORIGINAL_INDEX', 'files': files,
         'count': len(files), 'aggregate_sha256': hashlib.sha256(canonical(files)).hexdigest(),
         'self_and_summary_excluded_from_index_to_avoid_cycle': True,
         'no_new_combined_tar_or_build_cache_archive': True}
save(ROOT / 'index_r1.json', index)
summary = {'status': 'ACTUAL_ORIN_COMPONENT_SOFTWARE_PASS_INDEPENDENT_REVIEW_PENDING', 'deployable': False,
           'verification': pin(ROOT / 'verification_r1.json'), 'index': pin(ROOT / 'index_r1.json'),
           'native_result': pin(QA / 'result.json'), 'source_count': 597, 'source_aggregate': expected['source_manifest_sha256'],
           'origin': result['origin'], 'actual_compiler': result['compiler_before'],
           'actual_native_owned_children': 15, 'actual_local_external_owners': 7,
           'actual_allocator_negative_children': 2, 'negative_controls_are_not_additional_Rust_methods': True,
           'tests': report['tests'], 'raw_source_changes_against_deadline': ['crates/robot-adapters/feetech/src/bus.rs', 'crates/robot-adapters/feetech/src/bus_raw_read_tests.rs'],
           'main_raw_read_integration': 'NOT_DONE_BY_THIS_AGENT', 'resources': 'RETURNED_AFTER_TRUE_REAP_AND_NO_ACTIVE_CARGO',
           'historical_local_r1_compile_fail_preserved': load(ROOT / 'candidate_manifest_r1.json')['failed_r1_preserved'],
           'old_absolute_native_failures_not_rewritten_or_repackaged': True,
           'boundary': report['boundary']}
save(ROOT / 'summary_r1.json', summary)
print(json.dumps({'summary': pin(ROOT / 'summary_r1.json'), 'verification': pin(ROOT / 'verification_r1.json'),
                  'index': pin(ROOT / 'index_r1.json'), 'indexed_files': len(files), 'status': summary['status']}, ensure_ascii=False))
