"""收口本件必要原件和唯一597源码tar；不编译、不连接Orin、不改源码。"""
import difflib
import gzip
import hashlib
import importlib.util
import io
import json
import shutil
import stat
import subprocess
import tarfile
from pathlib import Path, PurePosixPath

MAIN = Path('/Users/loosqk/repo/rust/robot-system')
EVIDENCE = Path(__file__).parent
WORK = Path('/Users/loosqk/.codex/worktrees/feetech-wheel-raw-read/robot-system')
MAC = WORK / 'target/wheel_raw_read'
NATIVE = EVIDENCE / 'native-r1'
OUT = MAIN / '.verify/feetech_wheel_raw_read_2026-10-08'
OUT.mkdir()


def canonical(value):
    return json.dumps(value, sort_keys=True, separators=(',', ':'), ensure_ascii=False).encode()


def pin(path):
    info = path.lstat()
    assert stat.S_ISREG(info.st_mode) and not path.is_symlink()
    raw = path.read_bytes()
    return {'path': str(path), 'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest(), 'mode': stat.S_IMODE(info.st_mode)}


def load(path):
    return json.loads(path.read_text())


def save(path, value):
    with path.open('x') as stream:
        json.dump(value, stream, ensure_ascii=False, indent=2)
        stream.write('\n')


spec = importlib.util.spec_from_file_location('artifacts', NATIVE / 'artifacts.py')
a = importlib.util.module_from_spec(spec)
spec.loader.exec_module(a)
expected = a.validate_source_manifest(load(NATIVE / 'expected_source.json'))
assert len(expected['files']) == 597 and expected['source_manifest_sha256'] == '5c8c4c049ba57874f550f4dad7a60c47d9c00df4514310c8f980979d3969ec9f'
git_children = []


def git(args):
    child = subprocess.Popen(['git', *args], cwd=MAIN, stdin=subprocess.DEVNULL, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    stdout, stderr = child.communicate()
    assert child.returncode == 0, stderr
    git_children.append({'argv': ['git', *args], 'pid': child.pid, 'exit_code': child.returncode, 'actual_natural_wait_reap': True})
    return stdout


def main_snapshot():
    inventory = git(['ls-files', '-z', '--cached', '--others', '--exclude-standard']).decode().rstrip('\0').split('\0')
    value = a.snapshot_source(MAIN, inventory)
    assert value == expected
    return value


before = main_snapshot()
head = git(['rev-parse', 'HEAD']).decode().strip()
assert head == 'fb390abf1b96177a1f1c48800d158cdaebdf5cfc'
save(EVIDENCE / 'archive_main_source_before_r1.json', before)
main_binding = load(EVIDENCE / 'root_main_quality_binding_r1.json')
integration = load(EVIDENCE / 'root_integration_r1.json')
acceptance = load(EVIDENCE / 'root_acceptance_r1.json')
assert main_binding['status'] == 'PASS_MAIN_POST_FMT_SAME_INPUT_AS_ACTUAL_ORIN_FMT_THEN_TWO_ROOT_CLIPPY'
assert main_binding['source_count'] == 597 and main_binding['source_manifest_sha256'] == expected['source_manifest_sha256']
assert integration['after'] == expected and integration['changed_sources'] == ['crates/robot-adapters/feetech/src/bus.rs', 'crates/robot-adapters/feetech/src/bus_raw_read_tests.rs']
assert acceptance['status'] == 'PASS_SCOPED_SOFTWARE_APPROVED_FOR_MAIN_INTEGRATION'
assert load(EVIDENCE / 'independent_r1/review.json')['blockers'] == []
assert load(EVIDENCE / 'independent_native_r1/review.json')['blockers'] == []
assert load(NATIVE / 'orin-originals/qa/result.json')['status'] == 'PASS'
mac_final = load(MAC / 'local_qa_r3/result.json')
assert mac_final['status'] == 'PASS' and mac_final['source_before_aggregate'] == mac_final['source_after_aggregate'] == expected['source_manifest_sha256']
assert len(mac_final['children']) == 12
assert all(row['exit_code'] == 0 and row['natural_wait_completed'] and row['reaped'] and row['source_same_before_after']
           and row['source_before_aggregate'] == row['source_after_aggregate'] == expected['source_manifest_sha256'] for row in mac_final['children'])
assert load(MAC / 'local_qa_r1/result.json')['status'] == 'FAIL'
assert load(MAC / 'local_qa_r2/result.json')['status'] == 'PASS'

# 文档只记录本阶段与入口；原文备份留target，包内保可逆diff及实际前后SHA。
doc_paths = ['CLAUDE.md', 'docs/CHANGELOG.md', 'docs/10_verification.md', 'team-swe/specs/post_e_comm_fault_hardening.HANDOFF.md']
docs = {}
patch = []
for name in doc_paths:
    old = EVIDENCE / 'doc_before_r1' / name
    new = MAIN / name
    docs[name] = {'before': pin(old), 'after': pin(new)}
    patch.extend(difflib.unified_diff(old.read_text().splitlines(keepends=True), new.read_text().splitlines(keepends=True),
                                   fromfile='a/' + name, tofile='b/' + name))
assert all(value['before']['sha256'] != value['after']['sha256'] for value in docs.values())
with (EVIDENCE / 'doc_update_r1.patch').open('x') as stream:
    stream.write(''.join(patch))
save(EVIDENCE / 'doc_update_r1.json', {'status': 'UPDATED_FOUR_CURRENT_DOCUMENTS_ONLY', 'documents': docs,
     'patch': pin(EVIDENCE / 'doc_update_r1.patch'), 'frozen_design_changed': False, 'compile_inputs_changed': False})

selected = {}


def add(path, member):
    relative = PurePosixPath(member)
    assert not relative.is_absolute() and '..' not in relative.parts and str(relative) == member
    assert member not in selected
    selected[member] = pin(path)


def add_tree(path, prefix, omitted=()):
    for item in sorted(path.rglob('*')):
        if item.is_file() and '__pycache__' not in item.parts and item.name not in omitted:
            add(item, prefix + '/' + item.relative_to(path).as_posix())


for directory in ['local_qa_r1', 'local_qa_r2', 'local_qa_r3', 'freeze_r1']:
    add_tree(MAC / directory, 'mac/' + directory)
for name in ['import_receipt_r1.json', 'baseline_source_r1.json', 'summary_r1.md', 'raw_read_only.diff', 'run_local_qa.py', 'freeze_candidate_r1.py']:
    add(MAC / name, 'mac/' + name)
add_tree(NATIVE, 'native-r1', omitted=('source-inputs.tar.gz',))
for directory in ['independent_r1', 'independent_native_r1', 'main_backup_r1']:
    add_tree(EVIDENCE / directory, 'main-evidence/' + directory)
for name in ['integrate_two.py', 'verify_main_binding.py', 'root_acceptance_r1.json', 'root_integration_r1.json',
             'root_main_quality_binding_r1.json', 'root_native_scope_r1.md', 'prepare_native_r1.py', 'verify_native_r1.py',
             'archive_stage_r1.py', 'doc_update_r1.json', 'doc_update_r1.patch', 'archive_main_source_before_r1.json']:
    add(EVIDENCE / name, 'main-evidence/' + name)
after = main_snapshot()
assert after == before
save(EVIDENCE / 'archive_main_source_after_r1.json', after)
add(EVIDENCE / 'archive_main_source_after_r1.json', 'main-evidence/archive_main_source_after_r1.json')
save(EVIDENCE / 'archive_readback_r1.json', {'status': 'PASS_MAIN_597_BEFORE_AFTER_ARCHIVE_NO_CARGO_SSH', 'head_actual': head,
     'source_aggregate': before['source_manifest_sha256'], 'source_count': 597, 'git_children': git_children})
add(EVIDENCE / 'archive_readback_r1.json', 'main-evidence/archive_readback_r1.json')

# 唯一源码tar在包旁，原件tar不再嵌套它；已提交deadline父阶段仅固定引用，不重封。
source_original = pin(NATIVE / 'source-inputs.tar.gz')
shutil.copyfile(NATIVE / 'source-inputs.tar.gz', OUT / 'source-inputs.tar.gz')
assert pin(OUT / 'source-inputs.tar.gz')['sha256'] == source_original['sha256']
source_members = set()
with tarfile.open(OUT / 'source-inputs.tar.gz', 'r:gz') as tar:
    for member in tar:
        name = member.name
        relative = PurePosixPath(name)
        assert member.isfile() and not member.islnk() and not member.issym()
        assert not relative.is_absolute() and '..' not in relative.parts and str(relative) == name
        assert name not in source_members and name in expected['files']
        item = expected['files'][name]
        raw = tar.extractfile(member).read()
        assert len(raw) == member.size == item['bytes'] and hashlib.sha256(raw).hexdigest() == item['sha256']
        assert member.mode == (0o755 if item['executable'] else 0o644)
        source_members.add(name)
assert source_members == set(expected['files'])
with (OUT / 'original-evidence.tar.gz').open('xb') as stream:
    with gzip.GzipFile(fileobj=stream, mode='wb', filename='', mtime=0) as zipped:
        with tarfile.open(fileobj=zipped, mode='w', format=tarfile.PAX_FORMAT) as tar:
            for name, item in sorted(selected.items()):
                path = Path(item['path'])
                assert pin(path) == item
                raw = path.read_bytes()
                member = tarfile.TarInfo(name)
                member.size = len(raw)
                member.mode = item['mode']
                member.uid = member.gid = member.mtime = 0
                tar.addfile(member, io.BytesIO(raw))
seen = set()
with tarfile.open(OUT / 'original-evidence.tar.gz', 'r:gz') as tar:
    for member in tar:
        assert member.isfile() and not member.islnk() and not member.issym() and member.name in selected and member.name not in seen
        item = selected[member.name]
        raw = tar.extractfile(member).read()
        assert len(raw) == member.size == item['bytes'] and member.mode == item['mode']
        assert hashlib.sha256(raw).hexdigest() == item['sha256']
        assert pin(Path(item['path'])) == item
        seen.add(member.name)
assert seen == set(selected)
assert not any(name.endswith('source-inputs.tar.gz') for name in seen)
assert source_original == pin(NATIVE / 'source-inputs.tar.gz')
index = {'schema': 'FEETECH_WHEEL_RAW_READ_ORIGINAL_INDEX_R1', 'files': selected, 'count': len(selected),
         'aggregate_sha256': hashlib.sha256(canonical(selected)).hexdigest(),
         'source_tar_separate_not_nested_or_duplicated': pin(OUT / 'source-inputs.tar.gz'),
         'source_tar_original': source_original, 'source_tar_member_count': len(source_members),
         'summary_and_self_excluded_no_hash_cycle': True,
         'origin_mapping_boundary': '仅本件所选必要原件；不宣称原件内部所有历史绝对path均是本包闭合引用'}
save(OUT / 'original-evidence.index.json', index)
save(OUT / 'archive-verification.json', {'status': 'PASS_BYTES_SHA_MODE_SAFE_MEMBERS_CURRENT_ORIGINALS',
     'original_count': len(selected), 'original_tar_member_count': len(seen), 'source_tar_member_count': 597,
     'original_bytes_sha_mode_before_after_same': True, 'source_archive_matches_frozen_expected': True,
     'only_one_source_tar_in_this_package': True, 'no_nested_source_tar': True, 'no_parent_deadline_package_repacked': True,
     'self_summary_excluded_from_index': True, 'main_source_before_after': '597/5c8c4c04 exact',
     'tar': pin(OUT / 'original-evidence.tar.gz'), 'index': pin(OUT / 'original-evidence.index.json'),
     'source_tar': pin(OUT / 'source-inputs.tar.gz')})


def archived(path):
    matches = [(member, item) for member, item in selected.items() if item['path'] == str(path)]
    assert len(matches) == 1
    member, item = matches[0]
    return {'archive_member': member, 'bytes': item['bytes'], 'sha256': item['sha256']}


parent = MAIN / '.verify/feetech_absolute_write_2026-10-08/summary.json'
native_result = load(NATIVE / 'orin-originals/qa/result.json')
summary = {'schema': 'FEETECH_WHEEL_RAW_READ_STAGE_ACCEPTANCE_R1', 'status': 'MAIN_INTEGRATED_SCOPED_SOFTWARE_PASS',
           'date': '2026-10-08', 'commit_status': 'PENDING_ROOT_FINAL_REVIEW_AND_COMMIT', 'deployable': False,
           'implemented': '公开raw-by-ID固定缓冲读取和私有测试模块；原完整单租约、状态帧校验与Drop/checkpoint；全部回包合法后一次提交，固定MAX32 u32 staging，原word和尾槽保持',
           'source': {'count': 597, 'aggregate': expected['source_manifest_sha256'], 'main_base_head': head,
                      'candidate_git_head': '66d39b8af6a61cc778371239447d5f8edd4d792d',
                      'origin': '候选HEAD66+冻结六deadline源+本件两源；主树从已提交fb390ab期限阶段精确叠加两源',
                      'native_git_head': None, 'native_kind': 'exported snapshot',
                      'expected_manifest': archived(NATIVE / 'expected_source.json'),
                      'changed_sources': load(MAC / 'freeze_r1/candidate_manifest_r1.json')['changed_against_deadline'],
                      'root_integration': archived(EVIDENCE / 'root_integration_r1.json'),
                      'candidate_manifest': archived(MAC / 'freeze_r1/candidate_manifest_r1.json'),
                      'parent_deadline_phase': pin(parent), 'parent_phase_repacked': False},
           'validation': {'per_platform_distinct_methods': 230, 'lib_default': 213, 'lib_real_hw': 213,
                          'default_real_hw_overlap': 213, 'comm_fault_transport': 12, 'abort_diagnostics': 5,
                          'new_raw_methods': 13, 'new_methods_are_lib_subset': True, 'ignored': 0,
                          'Mac': {'result': archived(MAC / 'local_qa_r3/result.json'), 'owned_children': 12,
                                  'actual_fmt_then_two_feetech_scoped_clippy': True, 'all_natural_wait_reap_exit0': True,
                                  'host': 'aarch64-apple-darwin', 'full_batch_manifest_count': 2,
                                  'per_child_evidence': '保存runner确实计算与比较完整597；result仅持久化聚合和相等字段，没有24份完整快照原件',
                                  'allocator_negative': '没有--nocapture；原负控方法的SIGABRT/8B/wait断言执行通过，nestedPID/子stderr未独立导出'},
                          'Orin': {'result': archived(NATIVE / 'orin-originals/qa/result.json'), 'actual_commands': 15,
                                   'full_source_manifest_count': 32, 'local_external_owners': 7,
                                   'actual_fmt_then_two_root_clippy': True, 'all_natural_wait_reap_exit0': True,
                                   'host': 'aarch64-unknown-linux-gnu', 'allocator_negative_children': [
                                       {'suite': key, **value['allocator_negative_child']} for key, value in native_result['tests'].items()
                                       if 'allocator_negative_child' in value],
                                   'allocator_boundary': '两lib使用--nocapture；合并stderr保真实PID/SIGABRT(core dumped)/8B/wait原行；未单独封子stdout/完整子stderr，显示不证明core文件'},
                          'compiler_commit': '1d81eb4ad9cd207e3e638bd32b17ec4fce8412a6', 'floating_nightly': True,
                          'new_rustup_update_this_stage': False,
                          'dedup': '每平台213+12+5=230；两lib重叠213、13子集、两个负控child不重复累计；不将Mac和Orin相加'},
           'precommit_quality': {'root_binding': archived(EVIDENCE / 'root_main_quality_binding_r1.json'),
                                 'status': main_binding['status'], 'all_main_597_same_as_native': True,
                                 'actual_main_fmt': main_binding['actual_main_fmt'],
                                 'reuse': '本轮Orin实际fmt→默认/real-hw根Clippy同源；main实际fmt后全597相同，不重复Linux门',
                                 'main_fmt_receipt_boundary': '保存root质量回执和session79808实际exit0事实；未提供单独main fmt stdout/stderr，不虚构新增原件'},
           'review': {'independent_static_mac': archived(EVIDENCE / 'independent_r1/review.json'),
                      'independent_native': archived(EVIDENCE / 'independent_native_r1/review.json'),
                      'root_acceptance': archived(EVIDENCE / 'root_acceptance_r1.json'),
                      'original_pending_labels_preserved': True, 'final_package_review': 'PENDING_ROOT_FINAL_REVIEW'},
           'history': {'Mac_r1': {'original_result': archived(MAC / 'local_qa_r1/result.json'), 'status': 'FAIL',
                                 'actual_commands': 4, 'failure': 'Clippy101：三处private Register::new导致E0624；后续8门NOT_RUN',
                                 'recovered_sources': archived(MAC / 'freeze_r1/historical_failure_retention_r1.json'),
                                 'recovery_boundary': '历史两源逆替换恢复并匹配r1已持久化SHA；不是当时额外观测'},
                       'Mac_r2': {'original_result': archived(MAC / 'local_qa_r2/result.json'), 'status': 'PASS',
                                  'source_before': load(MAC / 'local_qa_r2/result.json')['source_before_aggregate'],
                                  'source_after': load(MAC / 'local_qa_r2/result.json')['source_after_aggregate'],
                                  'boundary': 'fmt实际改变输入；保原PASS，但最终源码稳定窗口以新r3为准，不声称r2首尾相同'},
                       'Mac_r3': '模块文档补正后完整新窗口绑定最终597/5c8c；未改变测试阈值、旧read权限或期限算法',
                       'parent_absolute_failures': '父阶段已提交证据原包不重封、不回填'},
           'contract_limits': ['具名现表仅1/2B；4B对同生产private共享核心注入长度oracle，无虚构新寄存器',
                               'raw read仅承诺原transport调用预算，不新增来源绝对READ期限或USB/固件/权限认证',
                               '固定fixture/真实lib AllocDisabler守生产API或同生产核心；foreign backend自行分配错误不由fixture证明noalloc',
                               '未接S0/S1、轮速TX、完整B1或Enable/EEPROM/factory/runtime；旧Position/ArmIK/写算法保持',
                               '无完整workspace/release/RT/H2六配方、新UART/硬件、安装、服务激活、部署、push；无syscalltrace'],
           'hardware_context': {'new_GO': False, 'new_UART': False, 'human_power_cut': '用户已确认两个电机电源切断并保持手臂支撑；实际时刻/独立遥测未测',
                                'old_failures': '头1回程+8、右9停止PV=-50、左腕/右H2原FAIL保持，不推断-50成因',
                                'firmware': '现场FW未读、Phase12未改', 'D15': 'OPEN/DEFERRED'},
           'documents': archived(EVIDENCE / 'doc_update_r1.json'),
           'archive': {'original_evidence': pin(OUT / 'original-evidence.tar.gz'), 'index': pin(OUT / 'original-evidence.index.json'),
                       'verification': pin(OUT / 'archive-verification.json'), 'source_tar': pin(OUT / 'source-inputs.tar.gz'),
                       'original_count': len(selected), 'unique_original_tar_members': len(seen), 'source_member_count': 597,
                       'source_tar_copy_count_in_this_package': 1, 'source_tar_not_nested': True}}
save(OUT / 'summary.json', summary)
print(json.dumps({'summary': pin(OUT / 'summary.json'), 'archive': pin(OUT / 'original-evidence.tar.gz'),
                  'index': pin(OUT / 'original-evidence.index.json'), 'original_count': len(selected),
                  'source_tar': pin(OUT / 'source-inputs.tar.gz'), 'status': summary['status']}, ensure_ascii=False))
