"""仅本机准备597冻结输入和限定Orin软件脚本；不执行SSH或Cargo。"""
import ast
import gzip
import hashlib
import importlib.util
import io
import json
import os
import re
import shutil
import stat
import subprocess
import tarfile
import time
from pathlib import Path

MAIN = Path('/Users/loosqk/repo/rust/robot-system')
WORK = Path('/Users/loosqk/.codex/worktrees/feetech-wheel-raw-read/robot-system')
FROZEN = WORK / 'target/wheel_raw_read/freeze_r1'
OLD = MAIN / 'target/absolute_write_integration_2026-10-08/native-r3'
OUT = Path(__file__).parent / 'native-r1'
BASE = '/home/loosqk/robot-checks/feetech-wheel-raw-read-20261008-r1'
OLD_BASE = '/home/loosqk/robot-checks/feetech-absolute-write-20261008-r3'
AGG = '5c8c4c049ba57874f550f4dad7a60c47d9c00df4514310c8f980979d3969ec9f'
BASELINE_AGG = 'bfe2318fd0bbac6e5f3c34766237ceca634f72331091053b7d2450e5b0ee0f40'
HEAD = '66d39b8af6a61cc778371239447d5f8edd4d792d'
OUT.mkdir()
children = []


def pin(path):
    path = Path(path)
    data = path.read_bytes()
    return {'path': str(path), 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest(), 'mode': stat.S_IMODE(path.stat().st_mode)}


def save(path, value):
    with path.open('x') as stream:
        json.dump(value, stream, ensure_ascii=False, indent=2)
        stream.write('\n')


def git(root, label, args):
    command = ['git', *args]
    started = time.monotonic_ns()
    child = subprocess.Popen(command, cwd=root, stdin=subprocess.DEVNULL, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    stdout, stderr = child.communicate()
    for name, data in [('stdout', stdout), ('stderr', stderr)]:
        with (OUT / (label + '.' + name + '.log')).open('xb') as stream:
            stream.write(data)
    children.append({'name': label, 'argv': command, 'cwd': str(root), 'owned_pid': child.pid,
                     'started_monotonic_ns': started, 'ended_monotonic_ns': time.monotonic_ns(),
                     'exit_code': child.returncode, 'natural_wait_reap': True,
                     'stdout': pin(OUT / (label + '.stdout.log')), 'stderr': pin(OUT / (label + '.stderr.log'))})
    assert child.returncode == 0, (label, stderr)
    return stdout


for original, name in [(OLD / 'artifacts.py', 'artifacts.py'), (OLD / 'natural_runner.py', 'natural_runner.py'),
                       (OLD / 'host_owner.py', 'host_owner.py'), (FROZEN / 'expected_source_r1.json', 'expected_source.json'),
                       (FROZEN / 'test_roster_r1.json', 'test_roster.json'), (FROZEN / 'candidate_manifest_r1.json', 'candidate_manifest_r1.json')]:
    shutil.copy2(original, OUT / name)
    assert pin(original)['sha256'] == pin(OUT / name)['sha256']
spec = importlib.util.spec_from_file_location('artifacts', OUT / 'artifacts.py')
a = importlib.util.module_from_spec(spec)
spec.loader.exec_module(a)
manifest = a.strict_json((OUT / 'candidate_manifest_r1.json').read_text())
expected = a.validate_source_manifest(a.strict_json((OUT / 'expected_source.json').read_text()))
baseline = a.validate_source_manifest(a.strict_json((WORK / 'target/wheel_raw_read/baseline_source_r1.json').read_text()))
roster = a.strict_json((OUT / 'test_roster.json').read_text())
assert len(expected['files']) == 597 and manifest['candidate_source_aggregate'] == expected['source_manifest_sha256'] == AGG
assert len(baseline['files']) == 596 and baseline['source_manifest_sha256'] == BASELINE_AGG
assert len(roster['lib_default']) == len(roster['lib_real_hw']) == 213
assert set(roster['lib_default']) == set(roster['lib_real_hw'])
assert len(roster['raw_read_new_subset']) == 13 and set(roster['raw_read_new_subset']) <= set(roster['lib_default'])
assert len(roster['comm_fault_transport']) == 12 and len(roster['abort_diagnostics']) == 5
assert len({('lib', name) for name in roster['lib_default']} | {(suite, name) for suite in ['comm_fault_transport', 'abort_diagnostics'] for name in roster[suite]}) == 230


def snapshot(root, prefix):
    head = git(root, prefix + '_head', ['rev-parse', 'HEAD']).decode().strip()
    status = git(root, prefix + '_status', ['status', '--porcelain=v1', '--untracked-files=all']).decode()
    raw = git(root, prefix + '_files', ['ls-files', '-z', '--cached', '--others', '--exclude-standard'])
    names = raw.decode().rstrip('\0').split('\0')
    value = a.snapshot_source(root, names)
    save(OUT / (prefix + '_source.json'), value)
    return {'head': head, 'status': status, 'source': value}


before = snapshot(WORK, 'candidate_before')
main_before = snapshot(MAIN, 'main_before')
assert before['head'] == HEAD and before['source'] == expected
assert main_before['source'] == baseline
with (OUT / 'source-inputs.tar.gz').open('xb') as stream:
    with gzip.GzipFile(fileobj=stream, mode='wb', mtime=0, filename='') as zipped:
        with tarfile.open(fileobj=zipped, mode='w', format=tarfile.PAX_FORMAT) as tar:
            for name, item in sorted(expected['files'].items()):
                path = WORK / name
                info = path.lstat()
                assert stat.S_ISREG(info.st_mode) and not path.is_symlink()
                data = path.read_bytes()
                assert len(data) == item['bytes'] and hashlib.sha256(data).hexdigest() == item['sha256']
                member = tarfile.TarInfo(name)
                member.size = len(data)
                member.mode = 0o755 if item['executable'] else 0o644
                member.uid = member.gid = 0
                member.mtime = 0
                tar.addfile(member, io.BytesIO(data))
seen = set()
with tarfile.open(OUT / 'source-inputs.tar.gz', 'r:gz') as tar:
    for member in tar:
        name = member.name
        assert member.isfile() and name in expected['files'] and name not in seen
        assert not Path(name).is_absolute() and '..' not in Path(name).parts and Path(name).as_posix() == name
        item = expected['files'][name]
        assert member.size == item['bytes'] and member.mode == (0o755 if item['executable'] else 0o644)
        data = tar.extractfile(member).read()
        assert len(data) == item['bytes'] and hashlib.sha256(data).hexdigest() == item['sha256']
        seen.add(name)
assert seen == set(expected['files'])
after = snapshot(WORK, 'candidate_after')
main_after = snapshot(MAIN, 'main_after')
assert before == after and main_before == main_after
meta = {'source_manifest': expected,
        'archive': {key: pin(OUT / 'source-inputs.tar.gz')[key] for key in ['sha256', 'bytes']},
        'artifacts_sha256': pin(OUT / 'artifacts.py')['sha256'],
        'files': {name: {**item, 'mode': 0o755 if item['executable'] else 0o644} for name, item in expected['files'].items()},
        'origin': {'main_head_actual': main_before['head'], 'main_inputs': '596/' + BASELINE_AGG,
                   'main_git_status_actual': main_before['status'], 'candidate_git_head_actual': before['head'],
                   'candidate_git_status_actual': before['status'],
                   'candidate_origin': 'HEAD66 + 已冻结六deadline源 + 本次bus/raw-read-test两源；主树仅已整合deadline596',
                   'native_git_head': None, 'source_kind': 'exported snapshot', 'source_count': 597}}
save(OUT / 'source_export.json', meta)
for name in ['identity_read.sh', 'create_remote.sh', 'receive_source.py']:
    code = (OLD / name).read_text().replace(OLD_BASE, BASE)
    with (OUT / name).open('x') as stream:
        stream.write(code)

# 复用旧批次的纯模板与真实child监督，当前名单、计数及输入全部来自本轮冻结候选。
parsed = ast.parse((MAIN / 'target/absolute_write_integration_2026-10-08/prepare_native_r2.py').read_text())
templates = [node.value.value for node in parsed.body if isinstance(node, ast.Assign)
             and any(isinstance(target, ast.Name) and target.id == 'code' for target in node.targets)
             and isinstance(node.value, ast.Constant) and isinstance(node.value.value, str)]
assert len(templates) == 1
code = templates[0]
parser_tree = ast.parse((OLD / 'run_absolute.py').read_text())
pure = [node for node in parser_tree.body if isinstance(node, ast.FunctionDef) and node.name in {'list_blocks', 'run_blocks'}]
parser_code = '\n\n'.join(ast.unparse(node) for node in pure)
parser_code = parser_code.replace("names = [r[0] for r in rows]", "rows = [(n.removesuffix(' - should panic'), status) for n, status in rows]\n        names = [r[0] for r in rows]")
parser_code += r'''

def parse_allocator_negative(raw, name):
    matches = re.findall(r'^分配负控：pid=(\d+)，status=([^\n]+?)，已自然wait/reap，stdout=(\d+)B，stderr=(\d+)B：memory allocation of 8 bytes failed$', raw, re.M)
    require(len(matches) == 1, name + ' 缺唯一真实8B分配负控完成输出')
    pid, status, stdout_bytes, stderr_bytes = matches[0]
    require(int(pid) > 0 and re.fullmatch(r'signal: 6 \(SIGABRT\)( \(core dumped\))?', status) is not None and int(stderr_bytes) > 0, name + ' 负控实际状态不同')
    return {'pid': int(pid), 'raw_status': status, 'signal': 6, 'core_dump_displayed': status.endswith(' (core dumped)'),
            'reaped_by_test_wait_with_output': True, 'stdout_bytes': int(stdout_bytes), 'stderr_bytes': int(stderr_bytes),
            'expected_nonzero_signal_termination': True, 'not_an_additional_Rust_method': True, 'raw_completion_in_stderr': True}
'''
old_negative = code[code.index('        matches = re.findall('):code.index("    result['tests'][name] = record")]
code = code.replace(old_negative, "        record['allocator_negative_child'] = parse_allocator_negative(raw, name)\n")
code = code.replace('Feetech来源期限冻结596', 'Feetech固定缓冲原始读回冻结597')
code = code.replace("'FEETECH_ABSOLUTE_WRITE_NATIVE_QA_R2'", "'FEETECH_WHEEL_RAW_READ_NATIVE_QA_R1'")
code = code.replace('596', '597').replace('两完整200 lib', '两完整213 lib').replace('217不同suite方法', '230不同suite方法')
code = code.replace("wanted = roster['integration'][test]", "wanted = roster[test]")
code = code.replace("'lib_default': 200, 'lib_real_hw_same_methods': 200, 'old_lib': 171, 'new_method_subset': 29", "'lib_default': 213, 'lib_real_hw_same_methods': 213, 'old_lib': 200, 'new_method_subset': 13")
code = code.replace("'distinct_suite_methods': 217", "'distinct_suite_methods': 230")
planned = ['rustc_before', 'cargo_before', 'fmt', 'clippy_default', 'clippy_real_hw', 'feetech_default_list', 'feetech_default',
           'feetech_real_hw_list', 'feetech_real_hw', 'comm_fault_transport_list', 'comm_fault_transport',
           'abort_diagnostics_list', 'abort_diagnostics', 'rustc_after', 'cargo_after']
code = code.replace("before = compiler = cargo = None", 'PLANNED = ' + repr(planned) + '\n\nbefore = compiler = cargo = None')
code = code.replace("    result['receipts'] = runner.receipts", """    result['receipts'] = runner.receipts
    completed_names = [a.strict_json(Path(ref['path']).read_text())['name'] for ref in runner.receipts]
    result['not_run'] = [name for name in PLANNED if name not in completed_names]
    result['planned_command_names'] = PLANNED
    if result['status'] == 'PASS' and completed_names != PLANNED:
        result.update(status='FAIL', completeness_error='真实child回执顺序/数量不同')
    result['all_planned_commands_completed'] = completed_names == PLANNED""")
for key, value in {'REMOTE_BASE': repr(BASE), 'RUNNER_SHA': repr(pin(OUT / 'natural_runner.py')['sha256']),
                   'ARTIFACTS_SHA': repr(pin(OUT / 'artifacts.py')['sha256']), 'ROSTER_SHA': repr(pin(OUT / 'test_roster.json')['sha256']),
                   'MANIFEST_SHA': repr(pin(OUT / 'candidate_manifest_r1.json')['sha256']), 'SOURCE_AGG': repr(AGG), 'PARSER_CODE': parser_code}.items():
    code = code.replace(key, value)
ast.parse(code)
with (OUT / 'run_raw_read.py').open('x') as stream:
    stream.write(code)

# 仅运行无副作用解析器：使用已保留的本机r3日志与合成负控文本，不启动任何Rust/SSH。
namespace = {'re': re, 'require': a.require}
exec(compile(ast.parse(parser_code), '<pure-parser-only>', 'exec'), namespace)
qa = WORK / 'target/wheel_raw_read/local_qa_r3'
run_inputs = []
for label, wanted in [('lib_default', roster['lib_default']), ('lib_real_hw', roster['lib_real_hw']),
                      ('comm_fault_transport', roster['comm_fault_transport']), ('abort_diagnostics', roster['abort_diagnostics'])]:
    path = qa / (label + '.stdout.log')
    blocks = namespace['run_blocks'](path.read_text())
    assert len(blocks) == 1 and blocks[0]['counts'] == {'passed': len(wanted), 'failed': 0, 'ignored': 0, 'measured': 0, 'filtered_out': 0}
    assert {item['name'] for item in blocks[0]['methods']} == set(wanted)
    run_inputs.append(pin(path))
for label, wanted in [('lib_default_list', roster['lib_default']), ('lib_real_hw_list', roster['lib_real_hw'])]:
    path = qa / (label + '.stdout.log')
    blocks = namespace['list_blocks'](path.read_text())
    assert len(blocks) == 1 and set(blocks[0]) == set(wanted)
    run_inputs.append(pin(path))
negative = '分配负控：pid=123，status=signal: 6 (SIGABRT)，已自然wait/reap，stdout=0B，stderr=36B：memory allocation of 8 bytes failed\n'
for raw, core in [(negative, False), (negative.replace(' (SIGABRT)', ' (SIGABRT) (core dumped)'), True)]:
    parsed = namespace['parse_allocator_negative'](raw, '合成解析样本')
    assert parsed['signal'] == 6 and parsed['core_dump_displayed'] == core
rejected = 0
for raw in ['', negative * 2, negative.replace('signal: 6 (SIGABRT)', 'exit status: 0'),
            negative.replace('6 (SIGABRT)', '9 (SIGKILL)'), negative.replace('8 bytes', '16 bytes'),
            negative.replace('pid=123', 'pid=0'), negative.replace('stderr=36B', 'stderr=0B')]:
    try:
        namespace['parse_allocator_negative'](raw, '合成拒绝样本')
    except ValueError:
        rejected += 1
    else:
        raise AssertionError('非法负控误通过')
assert rejected == 7
save(OUT / 'parser_preflight.json', {'status': 'PASS_PURE_PARSER_EXISTING_LOCAL_R3_NOT_NATIVE_EXECUTION',
     'run_and_list_exact': True, 'raw_inputs': run_inputs, 'roster': pin(OUT / 'test_roster.json'),
     'counts': [213, 213, 12, 5], 'distinct_suite_methods': 230, 'negative_synthetic_accepted': 2,
     'negative_synthetic_rejected': rejected, 'Rust_or_SSH_started': 0})

hash_names = ['artifacts.py', 'natural_runner.py', 'expected_source.json', 'source_export.json', 'source-inputs.tar.gz',
              'test_roster.json', 'candidate_manifest_r1.json', 'receive_source.py', 'run_raw_read.py']
launch = 'set -eu\nexport PATH=/home/loosqk/.cargo/bin:/home/loosqk/.local/bin:$PATH\nexport CARGO_HOME=/home/loosqk/robot-checks/viz-orin-a6957cc-20260930-r1/cargo-home\nexport CARGO_NET_OFFLINE=true\nexport RUSTUP_AUTO_INSTALL=0\nexport PYTHONDONTWRITEBYTECODE=1\ncd ' + BASE + '/bootstrap\nsha256sum -c - <<\'SHA_INPUTS\'\n'
launch += '\n'.join(pin(OUT / name)['sha256'] + '  ' + name for name in hash_names)
launch += '\nSHA_INPUTS\nuv run --no-project python receive_source.py\nexec taskset -c 0-3 uv run --no-project python run_raw_read.py\n'
with (OUT / 'launch_raw_read.sh').open('x') as stream:
    stream.write(launch)
save(OUT / 'preparation_receipt.json', {'status': 'PASS_LOCAL_PREPARATION_NOT_NATIVE_QA', 'owned_git_children': children,
     'candidate_source_before_after_equal': True, 'main_source_before_after_equal': True,
     'source_archive_exact_regular_members': len(seen), 'source_archive': pin(OUT / 'source-inputs.tar.gz'),
     'compiler_or_Rust_tests_or_SSH_started': 0, 'main_quality_prior_receipt': pin(MAIN / 'target/absolute_write_integration_2026-10-08/root_main_quality_binding_r1.json'),
     'original_source_and_qa_not_modified': True})
save(OUT / 'execution_plan.json', {
    'status': 'PREPARED_NOT_RUN_AWAITING_ROOT_STATIC_PASS', 'remote_base': BASE,
    'manifest': pin(OUT / 'candidate_manifest_r1.json'), 'source': pin(OUT / 'expected_source.json'),
    'export': pin(OUT / 'source_export.json'), 'source_archive': pin(OUT / 'source-inputs.tar.gz'),
    'runner': pin(OUT / 'natural_runner.py'), 'run_helper': pin(OUT / 'run_raw_read.py'),
    'host_owner': pin(OUT / 'host_owner.py'), 'launch': pin(OUT / 'launch_raw_read.sh'),
    'identity_read': pin(OUT / 'identity_read.sh'), 'create_remote': pin(OUT / 'create_remote.sh'),
    'parser_preflight': pin(OUT / 'parser_preflight.json'), 'preparation': pin(OUT / 'preparation_receipt.json'),
    'origin': meta['origin'], 'commands_in_order': planned, 'planned_external_commands': 15, 'planned_source_windows': 32,
    'budgets_seconds': {'compiler_metadata_each': 60, 'fmt': 300, 'root_clippy_each': 7200, 'test_list_or_run_each': 900},
    'expected_identity': {'hostname': 'ubuntu', 'arch': 'aarch64', 'uid': 1000, 'gid': 1000, 'boot_id': '6cf7ee3e-a3c5-4c91-80bc-4ca924818b53'},
    'expected_compiler_commit': '1d81eb4ad9cd207e3e638bd32b17ec4fce8412a6',
    'reuse_protocol_only_from': str(OLD), 'reuse_prior_expected_counts_or_QA_originals': False,
    'target_cache': '/home/loosqk/robot-checks/xlerobot-velocity-foundation-20261008-r7/build',
    'cache_authorization': 'root已归还绝对写组件cache；实际fresh入口仍拒active cargo/rustc/clippy-driver/rustup',
    'rosters': {'lib_default': 213, 'lib_real_hw_same_methods': 213, 'new_subset': 13,
                'comm_fault_transport': 12, 'abort_diagnostics': 5, 'distinct_suite_methods': 230, 'ignored': 0},
    'allocator_negative': '两完整lib各一个真实8B child SIGABRT6；允许core dumped显示；test自然wait_with_output及stderr原事实；不是新Rust方法',
    'source_and_compiler_before_after_required': True, 'native_git_head': None, 'new_rustup_update': False,
    'strict_ssh_options': ['BatchMode=yes', 'StrictHostKeyChecking=yes', 'ConnectTimeout=15'],
    'no_hardware_release_workspace_service_install_push': True,
})
print(json.dumps({'status': 'PREPARED_NOT_RUN', 'plan': pin(OUT / 'execution_plan.json'),
                  'archive': pin(OUT / 'source-inputs.tar.gz'), 'source_count': 597, 'source_aggregate': AGG,
                  'commands': 15, 'tests': [213, 213, 12, 5], 'distinct_suite_methods': 230, 'SSH_started': 0}, ensure_ascii=False))
