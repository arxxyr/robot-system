"""实际主树格式化后逐项绑定本轮已有Orin质量门，不重跑。"""
import hashlib
import importlib.util
import json
import subprocess
from pathlib import Path

root = Path('/Users/loosqk/repo/rust/robot-system')
area = root / 'target/wheel_raw_read_integration_2026-10-08'
spec = importlib.util.spec_from_file_location('helpers', root / 'scripts/post_e_h2_artifacts.py')
a = importlib.util.module_from_spec(spec)
spec.loader.exec_module(a)
children = []

def call(argv):
    child = subprocess.Popen(argv, cwd=root, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    out, err = child.communicate()
    children.append({'argv': argv, 'pid': child.pid, 'exit_code': child.returncode,
                     'actual_wait_reap': True})
    assert child.returncode == 0, err.decode()
    return out.decode()

names = call(['git', 'ls-files', '-z', '--cached', '--others', '--exclude-standard']).rstrip('\0').split('\0')
source = a.snapshot_source(root, names)
expected = json.loads((area / 'native-r1/expected_source.json').read_text())
assert source == expected
compiler = call(['rustc', '+nightly', '-Vv'])
assert 'commit-hash: 1d81eb4ad9cd207e3e638bd32b17ec4fce8412a6' in compiler
pins = {
    'native-r1/summary_r1.json': 'd0eeeaaae0c7b037cbd44846c86cc231591cbbd0486ac59668c9f1b7f1c362bd',
    'native-r1/verification_r1.json': 'df99c62b95ba40b49150764e57bbace10bf95a369352bff2abdd3592ce037f18',
    'independent_native_r1/review.json': 'f2a26bd85b1ab5eaa85e0a807bb336698b43ff1ce931cdcffbdebeb84aa5b1d5',
}
for path, sha in pins.items():
    assert hashlib.sha256((area / path).read_bytes()).hexdigest() == sha
quality = []
for name in ['fmt', 'clippy_default', 'clippy_real_hw']:
    p = area / 'native-r1/orin-originals/qa' / name / 'completion.json'
    row = json.loads(p.read_text())
    assert row['exit_code'] == 0 and row['reaped'] and not row['budget_exceeded']
    assert not row['signals'] and not row['session_residual_after_cleanup']
    quality.append({'name': name, 'pid': row['pid'], 'argv': row['argv'],
                    'start': row['started_monotonic_ns'], 'end': row['ended_monotonic_ns'],
                    'completion_sha256': hashlib.sha256(p.read_bytes()).hexdigest()})
assert quality[0]['end'] <= quality[1]['start'] < quality[1]['end'] <= quality[2]['start']
receipt = {
    'status': 'PASS_MAIN_POST_FMT_SAME_INPUT_AS_ACTUAL_ORIN_FMT_THEN_TWO_ROOT_CLIPPY',
    'source_count': len(source['files']),
    'source_manifest_sha256': source['source_manifest_sha256'],
    'actual_main_fmt': 'cargo +nightly fmt --all，session79808实际exit0；不是Mac根Clippy',
    'actual_native_quality': quality,
    'quality_reuse': '本轮Orin实际fmt→默认和real-hw根Clippy同597输入；主树未重复运行Linux门',
    'compiler_raw': compiler, 'pins': pins, 'children': children,
    'limits': '未完整workspace/release/RT/H2、新硬件、安装、部署或推送',
}
with (area / 'root_main_quality_binding_r1.json').open('x') as output:
    json.dump(receipt, output, ensure_ascii=False, indent=2)
    output.write('\n')
print(json.dumps({k: receipt[k] for k in ('status', 'source_count', 'source_manifest_sha256')}, ensure_ascii=False))
