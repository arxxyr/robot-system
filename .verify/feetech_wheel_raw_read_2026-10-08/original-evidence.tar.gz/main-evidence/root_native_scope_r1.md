# 固定缓冲原始读回：root 软件验收范围

爸爸，本件推进三轮专用适配器所需的真实原始寄存器读回能力。

- 基线：实际主树期限阶段已提交 `fb390ab`，596 输入聚合 `bfe2318fd0bbac6e5f3c34766237ceca634f72331091053b7d2450e5b0ee0f40`。候选实际 Git HEAD 仍是 `66d39b8`，带六份已冻结期限输入及本件两源，不冒称新的主树提交。
- 冻结：597 输入聚合 `5c8c4c049ba57874f550f4dad7a60c47d9c00df4514310c8f980979d3969ec9f`；仅 bus.rs 和新增私有 bus_raw_read_tests.rs 相对期限基线变动。
- root 静态检查：非空最多32项、ID范围和唯一性、1/2/4字节宽度及调用方全部容量在 lease/IO 前检查；一个原租约覆盖请求及整组响应；所有ID、status、header、checksum、params宽度都通过后一次提交 out。旧 parse_status 与 combine_bytes_le 的精确宽度错误仍生效，第二/第三轮短包或坏包不半提交输出。原始0x8000不做符号解码，4字节仅私有共享core测试，没有虚构具名寄存器。
- 允许：既有严格 SSH 路径、新独立源码目录、已归还热缓存；实际浮动 nightly 编译器身份前后记录，root fmt 后执行默认和 real-hw 根 Clippy，再完整 Feetech 库213/213及 comm12/diag5。两特性相同方法去重，总230；13新增为库子集，不另加。检查固定 fixture 的真实 allocation 守门与SIGABRT/8B负控，所有自有 child 实际 wait/reap。
- 不扩展：仅旧 transport 调用预算，未新增绝对 READ deadline、权限、USB证明或固件合同；本批不运行完整workspace、release、RT、H2六配方，不触UART、现场动作、正式路径、服务、安装或推送。root另行验收后方可整合主树和提交。

独立静态评审并行进行；本授权为已亲核生产函数后的限定软件验证，尚不宣称 Orin 或最终阶段验收通过。任何原 FAIL 保留。
