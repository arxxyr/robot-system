import datetime
import hashlib
import json
import pathlib
import re

ROOT = pathlib.Path('/Users/loosqk/repo/rust/robot-system')
C = pathlib.Path('/Users/loosqk/.codex/worktrees/feetech-wheel-raw-read/robot-system')
D = C / 'target/wheel_raw_read'
OUT = pathlib.Path(__file__).parent

def ref(path):
    p = pathlib.Path(path)
    b = p.read_bytes()
    return {'path': str(p), 'bytes': len(b), 'sha256': hashlib.sha256(b).hexdigest()}

def check(r):
    assert ref(r['path']) == {k:r[k] for k in ['path','bytes','sha256']}, r['path']
    return pathlib.Path(r['path'])

def load(p):
    return json.loads(pathlib.Path(p).read_bytes())

def refs_in(d):
    if isinstance(d,dict):
        if all(k in d for k in ['path','bytes','sha256']):
            yield d
        for v in d.values():
            yield from refs_in(v)
    elif isinstance(d,list):
        for v in d:
            yield from refs_in(v)

mp = D / 'freeze_r1/candidate_manifest_r1.json'
manifest_before = ref(mp)
m = load(mp)
for r in refs_in(m):
    check(r)
expected = load(check(m['expected_source']))
qa = load(check(m['qa']))
roster = load(check(m['test_roster']))
base = load(D / 'baseline_source_r1.json')
assert len(base['files']) == 596 and base['source_manifest_sha256'] == m['baseline_source_aggregate']
assert len(expected['files']) == 597
aggregate = hashlib.sha256(json.dumps(expected['files'],sort_keys=True,separators=(',',':')).encode()).hexdigest()
assert aggregate == expected['source_manifest_sha256'] == m['candidate_source_aggregate'] == '5c8c4c049ba57874f550f4dad7a60c47d9c00df4514310c8f980979d3969ec9f'
changed = [n for n in expected['files'] if base['files'].get(n) != expected['files'][n]]
assert set(changed) == set(m['changed_against_deadline']) and len(changed) == 2
for name, change in m['changed_against_deadline'].items():
    p = check(change['frozen_source'])
    assert p.read_bytes() == (C/name).read_bytes()
    assert ref(C/name)['sha256'] == expected['files'][name]['sha256']
    assert expected['files'][name] == change['new'] and base['files'].get(name) == change['old']
source_before = load(D / 'local_qa_r3/source_before.json')
source_after = load(D / 'local_qa_r3/source_after.json')
assert source_before == source_after == expected
assert qa['status'] == 'PASS' and qa['not_run'] == [] and qa['source_delta_this_run'] == []
assert qa['source_before_aggregate'] == qa['source_after_aggregate'] == aggregate
assert qa['source_count'] == 597 and qa['deadline_other_five_unchanged']
children = qa['children']
assert len(children) == 12 and len({x['owned_pid'] for x in children}) == 12
names = [c['name'] for c in children]
assert names == ['rustc_before','cargo_identity','fmt','clippy_default','clippy_real_hw','lib_default_list','lib_default','lib_real_hw_list','lib_real_hw','comm_fault_transport','abort_diagnostics','rustc_after']
previous_end = 0
rows = []
methods = {}
for child in children:
    assert child['exit_code'] == 0 and child['natural_wait_completed'] and child['reaped']
    assert child['source_before_aggregate'] == child['source_after_aggregate'] == aggregate and child['source_same_before_after']
    assert child['started_ns'] >= previous_end and child['ended_ns'] >= child['started_ns']
    previous_end = child['ended_ns']
    stdout = check(child['stdout']).read_text()
    check(child['stderr'])
    name = child['name']
    if 'test_methods' in child:
        if name.endswith('_list'):
            got = re.findall(r'^(.+): test$',stdout,re.M)
            assert not re.search(r': benchmark$',stdout,re.M)
        else:
            got = re.findall(r'^test ([\w:]+)(?: - should panic)? \.\.\. ok$',stdout,re.M)
            summaries = re.findall(r'^test result: ok\. (\d+) passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in .+$',stdout,re.M)
            assert summaries == [str(len(got))]
        assert got == child['test_methods'] and len(got) == len(set(got))
        methods[name] = sorted(got)
    rows.append({k:child[k] for k in ['name','argv','owned_pid','exit_code','natural_wait_completed','reaped','stdout','stderr']})
for actual, planned in [('lib_default_list','lib_default'),('lib_default','lib_default'),('lib_real_hw_list','lib_real_hw'),('lib_real_hw','lib_real_hw'),('comm_fault_transport','comm_fault_transport'),('abort_diagnostics','abort_diagnostics')]:
    assert methods[actual] == sorted(roster[planned])
assert methods['lib_default'] == methods['lib_real_hw'] and len(methods['lib_default']) == 213
new = sorted(re.findall(r'^fn (\w+)\(', (C/'crates/robot-adapters/feetech/src/bus_raw_read_tests.rs').read_text(),re.M))
new = sorted('bus::raw_read_tests::'+n for n in new if 'bus::raw_read_tests::'+n in roster['raw_read_new_subset'])
assert new == sorted(roster['raw_read_new_subset']) and len(new) == 13
assert set(new) <= set(methods['lib_default'])
assert len(methods['comm_fault_transport']) == 12 and len(methods['abort_diagnostics']) == 5
unique = ['lib::'+n for n in methods['lib_default']] + ['comm_fault_transport::'+n for n in methods['comm_fault_transport']] + ['abort_diagnostics::'+n for n in methods['abort_diagnostics']]
assert len(unique) == len(set(unique)) == roster['unique_binary_method_count'] == 230
rustc = (D/'local_qa_r3/rustc_before.stdout.log').read_bytes()
assert rustc == (D/'local_qa_r3/rustc_after.stdout.log').read_bytes()
assert b'1d81eb4ad9cd207e3e638bd32b17ec4fce8412a6' in rustc and b'host: aarch64-apple-darwin' in rustc
lib = (C/'crates/robot-adapters/feetech/src/lib.rs').read_text()
assert '#[cfg(test)]\n#[global_allocator]\nstatic TEST_ALLOCATOR: assert_no_alloc::AllocDisabler' in lib
guard_name = 'transport::post_e_acceptance::absolute::absolute_production_hot_core_and_bus_paths_run_under_real_allocator_guard'
assert guard_name in methods['lib_default']
history = load(check(m['failed_r1_preserved']))
for r in refs_in(history):
    check(r)
old_fail = load(check(history['actual_result']))
assert old_fail['status'] == 'FAIL' and len(old_fail['not_run']) == 8
assert load(check(m['r2_actual_pass_preserved']))['status'] == 'PASS'
assert ref(mp) == manifest_before

review = {
 'schema':'WHEEL_RAW_READ_INDEPENDENT_REVIEW_R1',
 'status':'PASS_SCOPED_STATIC_AND_MAC_SOFTWARE_PENDING_MAIN_AND_ORIN',
 'created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
 'manifest':manifest_before,'summary':ref(D/'summary_r1.md'),'expected_source':m['expected_source'],'qa':m['qa'],'roster':m['test_roster'],
 'source':{'count':597,'aggregate':aggregate,'baseline_count':596,'baseline_aggregate':m['baseline_source_aggregate'],'only_two_changed_inputs':changed,'changed_frozen_and_live_equal':True,'qa_before_after_full_manifest_equal':True},
 'static':{'preflight':'bus.rs:529-563 count1..32, ID1..253, duplicates, width1/2/4 and all out/TX/RX capacities before lease/I/O','commit':'bus.rs:570-577 fixed32 u32 staged; out[..n] copied once only after every frame header/checksum/ID/status/exact params width validates; tail untouched','raw':'unsigned LE u32; no sign-magnitude conversion, preserves0x8000/0x8001/0xffff and32bit high bits','lease':'bus.rs:565-568 existing one lease request+response; original write/read checkpoints execute on error; Drop returns lease once, rejected lease none','compatibility':'only module doc/new public read API/private core/test module appended; old paths unchanged','authority':'no new authority, USB provenance, firmware claim or source absolute READ deadline; existing optional service behavior retained','four_byte_limit':'current named register table has1/2bytes only;4byte fixture invokes same private production core without inventing public register'},
 'quality':{'fmt_then_two_feetech_scoped_clippy':True,'lib_default':213,'lib_real_hw_same_methods':213,'comm_fault_transport':12,'abort_diagnostics':5,'distinct_suite_qualified_methods':230,'new_raw_subset':13,'ignored':0,'children':12,'owned_natural_wait_reap_exit0':True,'compiler_commit':'1d81eb4ad9cd207e3e638bd32b17ec4fce8412a6','host':'aarch64-apple-darwin','new_rustup_update':False},
 'allocator':{'actual_registered_lib_AllocDisabler':True,'new13_guard_production_api_or_shared_core':True,'fixed_fixture_arrays_and_heap_setup_before_guard':True,'existing_real_guard_negative_method_run_both213':True,'negative_child_raw_boundary':'lib command omits --nocapture; negative SIGABRT/8B assertions and wait_with_output execute within successful method, nested PID/stderr not independently exported; not additional method'},
 'receipts_boundary':'Per-child full597 snapshots are computed and compared by saved runner; only per-child aggregates/equality persisted in result. Full batch first/last manifests independently equal expected; no invented24 full window originals.',
 'history':{'r1_original_compile_FAIL':history['actual_result'],'not_run':8,'restored_historical_sources_not_new_observation':history['source_provenance'],'r2_original_PASS':m['r2_actual_pass_preserved']},
 'blockers':[],
 'limits':['仅冻结候选/macOS限定Feetech软件门；主树整合与Orin/Linux未由本件证明','不是完整workspace/root Clippy/release/硬件/正式健康或部署','不接S0/VelocityTX，不赋予Enable/EEPROM或绝对READ截止','H2/左腕/头部/右轮历史FAIL、D15 OPEN/DEFERRED、deployable=false保持'],
 'own_actions':{'Cargo':False,'SSH':False,'UART':False,'source_mutation':False,'initial_summary_path_misdirected':'freeze_r1/summary_r1.md absent; actual root summary_r1.md verified; own read path issue, not product failure'},
}
OUT.mkdir(parents=True,exist_ok=True)
def save(path,data):
    path.write_text(json.dumps(data,ensure_ascii=False,indent=2)+'\n')
save(OUT/'review.json',review)
save(OUT/'command_matrix.json',rows)
(OUT/'review.md').write_text('爸爸，独立静态与本机软件验收 PASS，无实质阻断。597输入5c8c4c04；仅bus.rs和新增私有测试文件改变。所有形状/容量检查先于租约与IO；32槽固定staging保留无符号原字，整组ID/status/header/checksum/严格宽度均成功才一次提交输出，失败及尾槽不改。\n\n本机实际fmt→两项Feetech限定Clippy、lib213/default与real-hw同名单、集成12+5通过，共230不同suite方法；新增13为213子集。12自有child实际wait/reap退出0，nightly1d81首尾一致。真实注册AllocDisabler直接守新API/共用核心；既有8B负控方法两次执行，但未导出独立负控PID原件。\n\nr1编译FAIL/8个NOT_RUN及恢复历史源码来源原样保留，r2原PASS不改。本件仅候选/macOS软件，不证明主树整合、Orin、完整workspace、绝对READ期限、现场固件、运行健康、权限或硬件。无Cargo/SSH/UART/源码修改。\n')
save(OUT/'index.json',{'status':'PASS','artifacts':[ref(OUT/n) for n in ['review.json','review.md','command_matrix.json','verify_and_write.py']]})
print(json.dumps({'status':review['status'],'review':ref(OUT/'review.json'),'index':ref(OUT/'index.json')},ensure_ascii=False))
