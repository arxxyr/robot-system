爸爸，独立静态与本机软件验收 PASS，无实质阻断。597输入5c8c4c04；仅bus.rs和新增私有测试文件改变。所有形状/容量检查先于租约与IO；32槽固定staging保留无符号原字，整组ID/status/header/checksum/严格宽度均成功才一次提交输出，失败及尾槽不改。

本机实际fmt→两项Feetech限定Clippy、lib213/default与real-hw同名单、集成12+5通过，共230不同suite方法；新增13为213子集。12自有child实际wait/reap退出0，nightly1d81首尾一致。真实注册AllocDisabler直接守新API/共用核心；既有8B负控方法两次执行，但未导出独立负控PID原件。

r1编译FAIL/8个NOT_RUN及恢复历史源码来源原样保留，r2原PASS不改。本件仅候选/macOS软件，不证明主树整合、Orin、完整workspace、绝对READ期限、现场固件、运行健康、权限或硬件。无Cargo/SSH/UART/源码修改。
