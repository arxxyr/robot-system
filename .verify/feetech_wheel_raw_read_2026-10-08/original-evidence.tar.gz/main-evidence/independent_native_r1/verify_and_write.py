import datetime
import hashlib
import json
import pathlib
import re

D=pathlib.Path('/Users/loosqk/repo/rust/robot-system/target/wheel_raw_read_integration_2026-10-08')
P=D/'native-r1';Q=P/'orin-originals/qa';OUT=pathlib.Path(__file__).parent
PINS={'summary_r1.json':(3265,'d0eeeaaae0c7b037cbd44846c86cc231591cbbd0486ac59668c9f1b7f1c362bd'),'index_r1.json':(21856,'b6c56396ab5d07fddb26b28fa5d92beac9d8a3e2f5a0ae0bda2173453742cc45'),'verification_r1.json':(14455,'df99c62b95ba40b49150764e57bbace10bf95a369352bff2abdd3592ce037f18')}

def ref(p):
    p=pathlib.Path(p);b=p.read_bytes()
    return {'path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}

def check(r):
    assert ref(r['path'])=={k:r[k] for k in ['path','bytes','sha256']},r['path']

def load(p):return json.loads(pathlib.Path(p).read_bytes())

pins={n:ref(P/n) for n in PINS}
for n,(size,sha) in PINS.items():assert (pins[n]['bytes'],pins[n]['sha256'])==(size,sha)
s=load(P/'summary_r1.json');v=load(P/'verification_r1.json');idx=load(P/'index_r1.json');r=load(Q/'result.json');expected=load(P/'expected_source.json');roster=load(P/'test_roster.json')
assert len(idx['files'])==idx['count']==133
for n,row in idx['files'].items():
    rel=pathlib.PurePosixPath(n);assert not rel.is_absolute() and '..' not in rel.parts
    assert {k:ref(P/n)[k] for k in ['bytes','sha256']}==row,n
assert hashlib.sha256(json.dumps(idx['files'],sort_keys=True,separators=(',',':')).encode()).hexdigest()==idx['aggregate_sha256']
check(s['native_result']);check(s['verification']);check(s['index']);check(s['historical_local_r1_compile_fail_preserved'])
assert r['status']=='PASS' and r['not_run']==[] and r['all_planned_commands_completed'] and r['interrupted_signal'] is None
assert not r['deployable'] and not s['deployable']
assert len(expected['files'])==597
agg=hashlib.sha256(json.dumps(expected['files'],sort_keys=True,separators=(',',':')).encode()).hexdigest()
assert agg==expected['source_manifest_sha256']==r['source_aggregate']==s['source_aggregate']=='5c8c4c049ba57874f550f4dad7a60c47d9c00df4514310c8f980979d3969ec9f'
source_paths=sorted(Q.glob('*source*.json'))
assert len(source_paths)==32
for p in source_paths:assert load(p)==expected,p
names=r['planned_command_names']
assert names==['rustc_before','cargo_before','fmt','clippy_default','clippy_real_hw','feetech_default_list','feetech_default','feetech_real_hw_list','feetech_real_hw','comm_fault_transport_list','comm_fault_transport','abort_diagnostics_list','abort_diagnostics','rustc_after','cargo_after']
assert len(r['receipts'])==len(names)==len(v['actual_native_commands'])==15
rows=[];prev=0
for name,receipt,stated in zip(names,r['receipts'],v['actual_native_commands']):
    folder=Q/name;c=load(folder/'completion.json');launch=load(folder/'launch.json')
    assert pathlib.PurePosixPath(receipt['path']).parent.name==name and receipt['sha256']==ref(folder/'completion.json')['sha256']
    check(stated['completion']);assert stated['name']==name and stated['pid']==c['pid'] and stated['argv']==c['argv']
    for key in ['name','argv','cwd','env','pid','identity','started_monotonic_ns','deadline_monotonic_ns','bootstrap_argv','bootstrap_sha256']:
        assert c[key]==launch[key],(name,key)
    assert c['name']==name and c['exit_code']==0 and c['reaped'] and c['signals']==[] and c['exec_gate_released']
    assert not c['budget_exceeded'] and c['ended_monotonic_ns']<=c['deadline_monotonic_ns']
    assert c['session_residual_before_cleanup']==c['session_residual_after_cleanup']==[]
    assert c['identity']['pid']==c['pid']==c['identity']['pgid']==c['identity']['sid']
    assert c['identity_phase']=='bootstrap' and c['argv_semantics']=='收到父进程 GO 后同 PID exec 的目标命令'
    assert c['started_monotonic_ns']>=prev;prev=c['ended_monotonic_ns']
    for stream in ['stdout','stderr']:
        rr=ref(folder/(stream+'.log'))
        assert (rr['bytes'],rr['sha256'])==(c[stream+'_bytes'],c[stream+'_sha256'])
    rows.append({'name':name,'argv':c['argv'],'pid':c['pid'],'start_ticks':c['identity']['start_ticks'],'exit_code':0,'natural_reap':True,'completion':ref(folder/'completion.json'),'launch':ref(folder/'launch.json'),'stdout':ref(folder/'stdout.log'),'stderr':ref(folder/'stderr.log'),'source_before':ref(Q/(name+'_source_before.json')),'source_after':ref(Q/(name+'_source_after.json'))})
assert len({x['pid'] for x in rows})==15
assert rows[2]['argv']==['cargo','+nightly','fmt','--all']
assert rows[3]['argv']==['cargo','+nightly','clippy','--locked','--all','--all-targets','--','-D','warnings']
assert rows[4]['argv']==['cargo','+nightly','clippy','--locked','--all','--all-targets','--features','robot-adapter-feetech/real-hw','--','-D','warnings']
compiler=(Q/'rustc_before/stdout.log').read_bytes()
assert compiler==(Q/'rustc_after/stdout.log').read_bytes()
assert (Q/'cargo_before/stdout.log').read_bytes()==(Q/'cargo_after/stdout.log').read_bytes()
assert b'1d81eb4ad9cd207e3e638bd32b17ec4fce8412a6' in compiler and b'host: aarch64-unknown-linux-gnu' in compiler
assert not r['new_rustup_update']
methods={};negative=[]
for native,planned,count in [('feetech_default','lib_default',213),('feetech_real_hw','lib_real_hw',213),('comm_fault_transport','comm_fault_transport',12),('abort_diagnostics','abort_diagnostics',5)]:
    listing=(Q/(native+'_list')/'stdout.log').read_text()
    listed=re.findall(r'^(.+): test$',listing,re.M)
    assert not re.search(r': benchmark$',listing,re.M)
    log=(Q/native/'stdout.log').read_text()
    ran=re.findall(r'^test ([\w:]+)(?: - should panic)? \.\.\. ok$',log,re.M)
    assert len(ran)==len(set(ran))==len(listed)==len(set(listed))==count
    assert sorted(ran)==sorted(listed)==sorted(roster[planned])
    assert listed==r['tests'][native+'_list']['actual_list']
    suite=r['tests'][native]['actual_suites'];assert len(suite)==1
    assert ran==[x['name'] for x in suite[0]['methods']] and all(x['raw_status']=='ok' for x in suite[0]['methods'])
    assert suite[0]['counts']=={'passed':count,'failed':0,'ignored':0,'measured':0,'filtered_out':0}
    assert re.findall(r'^test result: ok\. (\d+) passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in .+$',log,re.M)==[str(count)]
    methods[native]=sorted(ran)
    if native.startswith('feetech_'):
        argv=load(Q/native/'completion.json')['argv'];assert '--nocapture' in argv
        stderr=(Q/native/'stderr.log').read_text()
        match=re.findall(r'分配负控：pid=(\d+)，status=(signal: 6 \(SIGABRT\) \(core dumped\))，已自然wait/reap，stdout=(\d+)B，stderr=(\d+)B：memory allocation of (\d+) bytes failed',stderr)
        assert len(match)==1
        pid,status,stdout,err,size=match[0];assert (int(stdout),int(err),int(size))==(16,114,8)
        fact=r['tests'][native]['allocator_negative_child'];assert fact['pid']==int(pid) and fact['raw_status']==status and fact['reaped_by_test_wait_with_output']
        negative.append({'suite':native,'pid':int(pid),'status':status,'allocation_bytes':8,'stdout_bytes':16,'stderr_bytes':114,'wait_reap_recorded_by_test':True,'raw_combined_stderr':ref(Q/native/'stderr.log')})
assert methods['feetech_default']==methods['feetech_real_hw']
assert len(roster['raw_read_new_subset'])==13 and set(roster['raw_read_new_subset'])<=set(methods['feetech_default'])
unique=['lib::'+n for n in methods['feetech_default']]+['comm_fault_transport::'+n for n in methods['comm_fault_transport']]+['abort_diagnostics::'+n for n in methods['abort_diagnostics']]
assert len(unique)==len(set(unique))==230
owners=[]
for fact in v['actual_local_external_owners']:
    check(fact['receipt']);owner=load(fact['receipt']['path'])
    assert owner['phase']=='REAPED' and owner['reaped'] and owner['wait_returncode']==0
    assert owner['owner_sent_signals']==[] and owner['errors']==[] and owner['pid']==fact['pid']
    check(owner['log']);owners.append({'name':fact['name'],'pid':owner['pid'],'owner_pid':owner['owner_pid'],'wait_returncode':0,'reaped':True,'remote_state':owner['remote_state'],'ref':fact['receipt']})
assert len(owners)==7
assert {n:ref(P/n) for n in PINS}==pins
review={'schema':'WHEEL_RAW_READ_INDEPENDENT_NATIVE_REVIEW_R1','status':'PASS_SCOPED_ORIN_SOFTWARE_NO_BLOCKER_PENDING_MAIN_BINDING','created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'final_refs':pins,'native_result':ref(Q/'result.json'),'original_index_133_bytes_sha_checked':True,'source':{'count':597,'aggregate':agg,'full_original_snapshots':32,'all_expected_manifest_equal':True,'native_git_head':None,'kind':'exported snapshot'},'quality':{'actual_order':'fmt→default root Clippy→real-hw root Clippy→lists/tests','default_lib':213,'real_hw_same_lib':213,'comm_fault_transport':12,'abort_diagnostics':5,'distinct_suite_methods':230,'new13_are_lib_subset':True,'ignored':0,'native_direct_commands_natural_exit0_reap':15,'local_external_owners_natural_exit0_reap':7},'compiler':{'commit_hash':'1d81eb4ad9cd207e3e638bd32b17ec4fce8412a6','host':'aarch64-unknown-linux-gnu','rustc_cargo_before_after_raw_equal':True,'new_rustup_update':False},'allocator_negative_controls':negative,'negative_boundaries':'两lib明确--nocapture；合并stderr保真实PID/SIGABRT(core dumped)/8B/wait完成行。子stdout与完整子stderr未独立导出；core dumped显示不证明core文件；两负控不计Rust方法。','owners':owners,'historical_local_r1_FAIL_ref':s['historical_local_r1_compile_fail_preserved'],'prior_static_local_review':ref(D/'independent_r1/review.json'),'blockers':[],'limits':['仅冻结原始读组件同源Orin软件；主树整合/提交由后续main绑定另验','非完整workspace/release/RT/H2/完整B1/现场FW/USB认证/新运行健康或硬件','不赋予权限/Enable/绝对READ期限，D15 OPEN/DEFERRED及deployable=false保持','本独审无Cargo/SSH/UART/源码修改，原Mac r1FAIL/NOT_RUN与当前summary的PENDING历史不回填']}
OUT.mkdir(parents=True,exist_ok=True)
def save(p,d):p.write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n')
save(OUT/'review.json',review);save(OUT/'command_matrix.json',{'commands':rows,'full_source_snapshots':[ref(p) for p in source_paths],'suite_qualified_methods':unique})
(OUT/'review.md').write_text('爸爸，Orin原始读组件定向独审 PASS，无阻断。133件索引原字节/SHA、15实际命令及其launch/completion/stdout/stderr均实核；实际fmt→两根Clippy通过，自然wait/reap退出0，无预算超限/发信号/残留会话。\n\n597输入5c8c4c04，32份完整原件快照均等expected；nightly1d81及cargo首尾原字节一致。默认/real-hw各213同名单只计一次，集成12+5，共230不同suite方法；新增13为库子集，0ignored。两lib明确nocapture，真实负控PID518003/518497、8B SIGABRT及test wait完成行保留；子stdout/完整stderr没有独立原件，core dumped不证明core文件。七本机外部owner亦自然回收。\n\n原Mac r1编译FAIL和未执行项不回填。本件仅同源Orin组件软件，不证明主树绑定、完整workspace、release、绝对READ期限、现场FW、权限、运行健康、硬件或部署；无新Cargo/SSH/UART/源码写。\n')
save(OUT/'index.json',{'status':'PASS','artifacts':[ref(OUT/n) for n in ['review.json','review.md','command_matrix.json','verify_and_write.py']]})
print(json.dumps({'review':ref(OUT/'review.json'),'index':ref(OUT/'index.json')},ensure_ascii=False))
