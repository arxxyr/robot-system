# 固定缓冲原始读回候选

爸爸，隔离工作树基线66d39b8；先精确导入冻结deadline六源，全596=bfe2318f匹配，再只增加bus原始读API/共享私有核心/模块说明与一个私有测试文件。当前597输入聚合 `5c8c4c049ba57874f550f4dad7a60c47d9c00df4514310c8f980979d3969ec9f`，主树66仍clean。

`sync_read_by_id_raw_into`在租约和IO前检查非空/最多32/1..253/唯一IDs、1/2/4宽度及out/TX/RX容量；固定32×u32 staging，同一次真实PeriodicRead租约覆盖请求+整组响应，原ID/status/checksum/长度校验全成功后一次提交out前n槽。保负零0x8000原word，后轮错误/短IO保全out，尾槽不动。旧读/写/权限/绝对写核心不改。

本机最终r3：fmt、默认/real-hw两项限定crate Clippy均0；默认lib213、real-hw lib213（全部重叠213）、通信故障12、诊断5全部通过，0ignored。共有230不同suite方法；13个新增raw方法是213子集，不另累计。12个自然owned child实际wait/reap退出0，逐child完整597输入前后相同，两次真实nightly rustc为1d81。r2实际PASS保留；r1私有Register构造误用导致Clippy101、后8未执行的原FAIL及实际源码SHA保留。两份历史源由限定逆替换恢复并逐字匹配持久化SHA，注明恢复来源，不伪作历史额外观测。

具名寄存器表仅1/2字节；4字节正负边界守同生产私有核心，不新增虚构寄存器。AllocDisabler直接守生产API/核心，夹具为固定capture数组，所有heap资源guard外构造。

证据入口：`freeze_r1/candidate_manifest_r1.json`、`freeze_r1/expected_source_r1.json`、`freeze_r1/test_roster_r1.json`、`local_qa_r3/result.json`、`raw_read_only.diff`。相对deadline仅bus和新test两文件；依赖的另外五源逐字不变。主树整合和Linux/Orin仍待root；没有SSH/UART/firmware/EEPROM/factory/runtime/commit/push/部署，不宣称来源绝对read期限或USB/固件/Enable证据。
