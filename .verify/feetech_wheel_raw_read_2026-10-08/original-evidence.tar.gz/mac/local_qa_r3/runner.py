import hashlib
import json
import re
import subprocess
import sys
import time
from pathlib import Path

root = Path(__file__).resolve().parents[2]
folder = root / "target/wheel_raw_read"
run = folder / sys.argv[1]
run.mkdir(exist_ok=False)
(run / "runner.py").write_bytes(Path(__file__).read_bytes())
baseline = json.loads((folder / "baseline_source_r1.json").read_text())
source_names = sorted([*baseline["files"], "crates/robot-adapters/feetech/src/bus_raw_read_tests.rs"])


def source_snapshot():
    files = {}
    for name in source_names:
        path = root / name
        data = path.read_bytes()
        files[name] = {
            "sha256": hashlib.sha256(data).hexdigest(),
            "bytes": len(data),
            "executable": bool(path.stat().st_mode & 0o111),
        }
    digest = hashlib.sha256(json.dumps(files, sort_keys=True, separators=(",", ":")).encode()).hexdigest()
    return {"domains": baseline["domains"], "files": files, "source_manifest_sha256": digest}


def save(name, data):
    (run / name).write_text(json.dumps(data, ensure_ascii=False, indent=2) + "\n")


before = source_snapshot()
save("source_before.json", before)
commands = [
    ("rustc_before", ["rustc", "-Vv"]),
    ("cargo_identity", ["cargo", "-V"]),
    ("fmt", ["cargo", "fmt", "--all"]),
    ("clippy_default", ["cargo", "clippy", "--locked", "-p", "robot-adapter-feetech", "--all-targets", "--", "-D", "warnings"]),
    ("clippy_real_hw", ["cargo", "clippy", "--locked", "-p", "robot-adapter-feetech", "--features", "real-hw", "--all-targets", "--", "-D", "warnings"]),
    ("lib_default_list", ["cargo", "test", "--locked", "-p", "robot-adapter-feetech", "--lib", "--", "--list"]),
    ("lib_default", ["cargo", "test", "--locked", "-p", "robot-adapter-feetech", "--lib"]),
    ("lib_real_hw_list", ["cargo", "test", "--locked", "-p", "robot-adapter-feetech", "--features", "real-hw", "--lib", "--", "--list"]),
    ("lib_real_hw", ["cargo", "test", "--locked", "-p", "robot-adapter-feetech", "--features", "real-hw", "--lib"]),
    ("comm_fault_transport", ["cargo", "test", "--locked", "-p", "robot-adapter-feetech", "--test", "comm_fault_transport"]),
    ("abort_diagnostics", ["cargo", "test", "--locked", "-p", "robot-adapter-feetech", "--test", "abort_diagnostics"]),
    ("rustc_after", ["rustc", "-Vv"]),
]
result = {"schema": "WHEEL_RAW_READ_LOCAL_QA_R1", "status": "RUNNING", "scope": "Mac限定Feetech；无SSH/UART/main修改/commit", "new_rustup_update_this_batch": False, "children": [], "not_run": []}
save("result.json", result)
for index, (name, command) in enumerate(commands):
    print("START", name, flush=True)
    item = {"name": name, "argv": command, "cwd": str(root), "started_ns": time.time_ns()}
    source_before_child = source_snapshot()
    item["source_before_aggregate"] = source_before_child["source_manifest_sha256"]
    start = time.monotonic_ns()
    with (run / f"{name}.stdout.log").open("wb") as out, (run / f"{name}.stderr.log").open("wb") as err:
        child = subprocess.Popen(command, cwd=root, stdin=subprocess.DEVNULL, stdout=out, stderr=err)
        item["owned_pid"] = child.pid
        item["exit_code"] = child.wait()
    item["ended_ns"] = time.time_ns()
    item["elapsed_ns"] = time.monotonic_ns() - start
    item["natural_wait_completed"] = True
    item["reaped"] = child.returncode is not None
    source_after_child = source_snapshot()
    item["source_after_aggregate"] = source_after_child["source_manifest_sha256"]
    item["source_same_before_after"] = source_before_child == source_after_child
    for stream in ["stdout", "stderr"]:
        path = run / f"{name}.{stream}.log"
        raw = path.read_bytes()
        item[stream] = {"path": str(path), "bytes": len(raw), "sha256": hashlib.sha256(raw).hexdigest()}
    stdout = (run / f"{name}.stdout.log").read_text(errors="replace")
    if name.endswith("_list"):
        item["test_methods"] = re.findall(r"^(.+): test$", stdout, re.MULTILINE)
    elif name in ["lib_default", "lib_real_hw", "comm_fault_transport", "abort_diagnostics"]:
        item["test_methods"] = re.findall(r"^test ([\w:]+)(?: - should panic)? \.\.\. ok$", stdout, re.MULTILINE)
        item["summary_lines"] = [line for line in stdout.splitlines() if line.startswith("test result:")]
    result["children"].append(item)
    save("result.json", result)
    print("END", name, item["exit_code"], flush=True)
    if item["exit_code"] != 0:
        result["status"] = "FAIL"
        result["not_run"] = [rest[0] for rest in commands[index + 1:]]
        break
else:
    result["status"] = "PASS"
after = source_snapshot()
save("source_after.json", after)
result["source_before_aggregate"] = before["source_manifest_sha256"]
result["source_after_aggregate"] = after["source_manifest_sha256"]
result["source_count"] = len(source_names)
result["source_delta_this_run"] = [name for name in source_names if before["files"][name] != after["files"][name]]
result["deadline_other_five_unchanged"] = all(after["files"][name] == baseline["files"][name] for name in ["crates/robot-adapters/feetech/src/transport.rs", "crates/robot-adapters/feetech/src/error.rs", "crates/robot-adapters/feetech/src/diagnostic.rs", "crates/robot-adapters/feetech/src/lib.rs", "crates/robot-adapters/feetech/src/post_e_transport_acceptance.rs"])
save("result.json", result)
print(result["status"], "children", len(result["children"]), "source", after["source_manifest_sha256"], flush=True)
sys.exit(0 if result["status"] == "PASS" else 1)
