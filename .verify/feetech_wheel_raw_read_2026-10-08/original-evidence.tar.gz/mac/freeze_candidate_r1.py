import hashlib
import json
import re
import shutil
import subprocess
from pathlib import Path

root = Path(__file__).resolve().parents[2]
folder = root / "target/wheel_raw_read"
freeze = folder / "freeze_r1"
freeze.mkdir(exist_ok=False)
run = folder / "local_qa_r3"
qa = json.loads((run / "result.json").read_text())
before = json.loads((run / "source_before.json").read_text())
source = json.loads((run / "source_after.json").read_text())
baseline = json.loads((folder / "baseline_source_r1.json").read_text())
assert qa["status"] == "PASS" and len(qa["children"]) == 12
assert before == source and all(child["source_same_before_after"] for child in qa["children"])
assert all(child["exit_code"] == 0 and child["natural_wait_completed"] and child["reaped"] for child in qa["children"])
for rel, pin in source["files"].items():
    path = root / rel
    data = path.read_bytes()
    assert len(data) == pin["bytes"] and hashlib.sha256(data).hexdigest() == pin["sha256"], rel
    assert bool(path.stat().st_mode & 0o111) == pin["executable"], rel
changes = [name for name in source["files"] if name not in baseline["files"] or source["files"][name] != baseline["files"][name]]
assert changes == ["crates/robot-adapters/feetech/src/bus.rs", "crates/robot-adapters/feetech/src/bus_raw_read_tests.rs"]
for rel in changes:
    path = freeze / "source" / rel
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_bytes((root / rel).read_bytes())
(freeze / "expected_source_r1.json").write_text(json.dumps(source, ensure_ascii=False, indent=2) + "\n")


def identity(path):
    data = path.read_bytes()
    return {"path": str(path), "bytes": len(data), "sha256": hashlib.sha256(data).hexdigest()}


children = {child["name"]: child for child in qa["children"]}
default = children["lib_default"]["test_methods"]
real_hw = children["lib_real_hw"]["test_methods"]
assert set(default) == set(children["lib_default_list"]["test_methods"])
assert set(real_hw) == set(children["lib_real_hw_list"]["test_methods"])
assert set(default) == set(real_hw) and len(default) == len(set(default)) == 213
new = sorted(name for name in default if name.startswith("bus::raw_read_tests::"))
assert len(new) == 13
roster = {
    "lib_default": sorted(default),
    "lib_real_hw": sorted(real_hw),
    "raw_read_new_subset": new,
    "comm_fault_transport": sorted(children["comm_fault_transport"]["test_methods"]),
    "abort_diagnostics": sorted(children["abort_diagnostics"]["test_methods"]),
    "unique_binary_method_count": len(default) + len(children["comm_fault_transport"]["test_methods"]) + len(children["abort_diagnostics"]["test_methods"]),
    "default_real_hw_overlap": len(set(default) & set(real_hw)),
    "new_methods_are_lib_subset_not_added_again": True,
}
assert roster["unique_binary_method_count"] == 230
assert len(roster["comm_fault_transport"]) == 12 and len(roster["abort_diagnostics"]) == 5
(freeze / "test_roster_r1.json").write_text(json.dumps(roster, ensure_ascii=False, indent=2) + "\n")
compiler_before = Path(children["rustc_before"]["stdout"]["path"]).read_bytes()
compiler_after = Path(children["rustc_after"]["stdout"]["path"]).read_bytes()
assert compiler_before == compiler_after and b"1d81eb4ad9cd207e3e638bd32b17ec4fce8412a6" in compiler_after

receipts = []
for name, checkout in [("candidate", root), ("main", Path('/Users/loosqk/repo/rust/robot-system'))]:
    for operation, args in [("head", ["rev-parse", "HEAD"]), ("status", ["status", "--porcelain=v1"])]:
        child = subprocess.Popen(["git", *args], cwd=checkout, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        stdout, stderr = child.communicate()
        assert child.returncode == 0
        receipts.append({"checkout": name, "operation": operation, "owned_pid": child.pid, "exit_code": child.returncode, "natural_wait_and_reap": True, "stdout": stdout.decode(), "stderr": stderr.decode()})
assert receipts[0]["stdout"].strip() == "66d39b8af6a61cc778371239447d5f8edd4d792d"
assert receipts[2]["stdout"].strip() == receipts[0]["stdout"].strip() and receipts[3]["stdout"] == ""
(freeze / "git_readback_r1.json").write_text(json.dumps(receipts, ensure_ascii=False, indent=2) + "\n")
failed = json.loads((folder / "local_qa_r1/result.json").read_text())
assert failed["status"] == "FAIL" and failed["children"][-1]["exit_code"] == 101
history = {
    "status": "ORIGINAL_R1_COMPILE_FAILURE_PRESERVED",
    "actual_result": identity(folder / "local_qa_r1/result.json"),
    "source_provenance": "历史两源由当前原样bus与三处测试Register构造逆替换恢复，逐字匹配r1已持久化SHA；这是恢复记录，不冒作当时另一次观测",
    "historical_sources": {},
}
for rel in changes:
    path = folder / "local_qa_r1/historical_failed_source" / Path(rel).name
    data = path.read_bytes()
    pin = json.loads((folder / "local_qa_r1/source_after.json").read_text())["files"][rel]
    assert hashlib.sha256(data).hexdigest() == pin["sha256"] and len(data) == pin["bytes"]
    history["historical_sources"][rel] = identity(path)
(freeze / "historical_failure_retention_r1.json").write_text(json.dumps(history, ensure_ascii=False, indent=2) + "\n")
manifest = {
    "schema": "FEETECH_FIXED_BUFFER_RAW_READ_CANDIDATE_R1",
    "status": "FROZEN_LOCAL_SCOPED_SOFTWARE_PASS_ROOT_REVIEW_PENDING",
    "git_head": receipts[0]["stdout"].strip(),
    "main_readback_clean": True,
    "dependency_deadline_manifest": identity(Path('/Users/loosqk/.codex/worktrees/feetech-absolute-write/robot-system/target/absolute_write/freeze_r1/candidate_manifest_r1.json')),
    "import_receipt": identity(folder / "import_receipt_r1.json"),
    "baseline_source_count": 596,
    "baseline_source_aggregate": baseline["source_manifest_sha256"],
    "candidate_source_count": len(source["files"]),
    "candidate_source_aggregate": source["source_manifest_sha256"],
    "changed_against_deadline": {rel: {"old": baseline["files"].get(rel), "new": source["files"][rel], "frozen_source": identity(freeze / "source" / rel)} for rel in changes},
    "other_595_deadline_input_files_exactly_unchanged": True,
    "original_deadline_other_five_sources_exactly_unchanged": qa["deadline_other_five_unchanged"],
    "expected_source": identity(freeze / "expected_source_r1.json"),
    "test_roster": identity(freeze / "test_roster_r1.json"),
    "qa": identity(run / "result.json"),
    "compiler_raw": compiler_after.decode(),
    "owned_qa_children": 12,
    "all_children_natural_wait_reap_exit_zero": True,
    "per_child_full_597_source_before_after_same": True,
    "lib_default": 213,
    "lib_real_hw": 213,
    "default_real_hw_overlap": 213,
    "comm_fault_transport": 12,
    "abort_diagnostics": 5,
    "different_suite_methods": 230,
    "raw_read_new_methods": 13,
    "new_methods_are_213_subset": True,
    "failed_r1_preserved": identity(freeze / "historical_failure_retention_r1.json"),
    "r2_actual_pass_preserved": identity(folder / "local_qa_r2/result.json"),
    "r3_reason": "补正模块文档的signed接口范围后，用新实际完整窗口绑定最终源码；不新增测试语义/样本/预算",
    "claim_boundary": ["仅macOS专项；未Linux/Orin验收", "具名现表仅1/2B；4B是同生产私有共享核心oracle，无新增虚构寄存器", "固定缓冲原始read仅承诺旧transport调用预算，不认证来源绝对read截止或USB/固件/Enable", "未主树整合/commit/push/SSH/UART/硬件/部署"],
}
(freeze / "candidate_manifest_r1.json").write_text(json.dumps(manifest, ensure_ascii=False, indent=2) + "\n")
print(json.dumps(identity(freeze / "candidate_manifest_r1.json"), ensure_ascii=False))
print("FROZEN", len(source["files"]), source["source_manifest_sha256"], "DIFFERENT_METHODS", 230, "RAW_SUBSET", 13)
