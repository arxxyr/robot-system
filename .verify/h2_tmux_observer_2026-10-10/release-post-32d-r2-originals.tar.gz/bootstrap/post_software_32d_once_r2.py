"""复用既有 Runner 和 post_release 的短 mock/tonic；仅本次32d纯软件验收。"""
import importlib.util
import json
import os
from pathlib import Path
import signal
import sys
from types import SimpleNamespace

base = Path('/home/loosqk/robot-checks/h2-exit-observation-20261009-r1')
source, release, out = base / 'source', base / 'release-32d-r2', base / 'post-software-32d-r2'
evidence = base / 'mock-ac12-32d-r2'
target = Path('/home/loosqk/robot-checks/xlerobot-velocity-foundation-20261008-r7/build')
formal = Path('/home/loosqk/repo/robot/robot-system')
head = 'a96c34ae26b56fc9e8d2deef17c3b829c3d87d0d'
modules = []
for name, path in [('artifacts', source / 'scripts/post_e_h2_artifacts.py'),
                   ('release_runner', Path('/home/loosqk/robot-checks/h2-right-ready-20261009-r1/bootstrap/run_release_v2.py')),
                   ('post_checks', Path('/home/loosqk/robot-checks/h2-trace-owner-v2-20260930-r1/bootstrap/post_release_checks.py'))]:
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    modules.append(module)
a, r, p = modules
a.require(a.sha256(Path(r.__file__)) == 'd6b20da28de8d5ae077a93cb2fb5ba7f27a66b8145df9e7e91951cb14ac0b12b', '既有Runner身份不同')
a.require(a.sha256(Path(a.__file__)) == 'bd2b3f7bb8527cd9ecec73894171638e9cf378656b89e284a585c3baa37b8731', '产品校验模块不同')
a.require(a.sha256(Path(p.__file__)) == '4f567265b93687411324811363ab4d79a1730ff5a0d41bb745a37942c385449e', '原 post_release 模块不同')
sys.path.insert(0, str(source / 'scripts'))
import run_post_e_h2 as driver
def interrupted(signum, _frame):
    r.INTERRUPTED = signum
for sig in (signal.SIGTERM, signal.SIGINT, signal.SIGHUP):
    signal.signal(sig, interrupted)
a.require(not out.exists() and not evidence.exists(), '单次 mock 输出不得复用')
out.mkdir()
r.save(out / 'owner.json', r.proc_entry(os.getpid()))
runner = r.Runner(SimpleNamespace(source=source, target=target, out=out, build_head=head), a)
runner.env['CARGO_HOME'] = '/home/loosqk/robot-checks/viz-orin-a6957cc-20260930-r1/cargo-home'
proxy = {key: 'http://10.0.1.80:10808' for key in ('http_proxy', 'https_proxy', 'HTTP_PROXY', 'HTTPS_PROXY')}
runner.env.update(proxy)
runner.shown.update(proxy)
runner.shown['CARGO_HOME'] = runner.env['CARGO_HOME']
result = {'status': 'FAIL', 'deployable': False, 'started_at': r.utc(),
          'scope': '仅新32d短mock AC-12四组各2及tonic6测试9场景、正式状态读回；无UART/现场参数/GO/部署/服务操作',
          'script_sha256': a.sha256(Path(__file__)), 'proxy_runtime_overrides': proxy, 'cargo_home': runner.env['CARGO_HOME'],
          'build_head': head, 'post_release_sha256': a.sha256(Path(p.__file__))}
manifests, before, initial = {}, None, None
installed = {name: formal / 'target/release' / name for name in a.INSTALLED_NAMES}
def identities():
    frozen = {}
    for kind, manifest in manifests.items():
        a.validate_artifact_set(manifest, source_manifest=before, expected_kind=kind, expected_head=head)
        for name, artifact in manifest['artifacts'].items():
            frozen[kind + '/' + name] = a.elf_identity(artifact['path'])
    return {'frozen': frozen, 'formal': a.validate_target_isolation(target, installed)['installed'],
            'manifests': {kind: a.sha256(release / (kind + '.json')) for kind in manifests}}
def services(label):
    _, row = runner.command(label + '_services', ['systemctl', 'show', *driver.UNITS, '-p', 'Id', '-p', 'ActiveState', '-p', 'SubState', '-p', 'MainPID'])
    output = Path(row['stdout']).read_text()
    rows = [dict(line.split('=', 1) for line in block.splitlines()) for block in output.strip().split('\n\n')]
    a.require(len(rows) == 6 and {row['Id'] for row in rows} == set(driver.UNITS)
              and all(row['ActiveState'] == 'inactive' and row['SubState'] == 'dead' and row['MainPID'] == '0' for row in rows),
              '六个正式服务未保持停止')
    return rows

def processes():
    binaries = [Path(item['path']) for manifest in manifests.values() for item in manifest['artifacts'].values()] + list(installed.values())
    return driver.process_snapshot(-1, evidence, binaries)
try:
    prior = a.strict_json((release / 'result.json').read_text())
    a.require(prior['status'] == 'PASS' and prior['source_after'] == prior['isolation_after'] == 'PASS', '原 release 失败')
    a.require(prior['runner_sha256'] == a.sha256(Path(r.__file__)) and prior['artifacts_module_sha256'] == a.sha256(source / 'scripts/post_e_h2_artifacts.py'), '复用模块不同')
    before = runner.source('source_before')
    a.require(len(before['files']) == 597 and before['source_manifest_sha256'] == '5970c9bed0ab02f99b47d88d47eb3718c6a748155ca4fafd5c18050a68ec6cf7' and before == a.strict_json((release / 'source_before.json').read_text()), '597 输入或冻结源不同')
    result['source_manifest_sha256'] = before['source_manifest_sha256']
    manifests = {kind: a.read_pinned_json(prior['artifacts'][kind]) for kind in ('production', 'measurement')}
    initial = identities()
    a.require(len(initial['frozen']) == 7, '不是本次七件')
    r.save(out / 'identities_before.json', initial)
    result['formal_before'] = services('formal_before')
    process_before = processes()
    r.save(out / 'process_before.json', process_before)
    a.require(process_before['clean'], 'mock 前有控制进程或未知进程')
    result['rustc_before'], rustc = runner.command('rustc_before', ['rustc', '-vV'])
    compiler = a.parse_rustc_identity(Path(rustc['stdout']).read_text())
    a.require(compiler == manifests['production']['rustc_identity'] == manifests['measurement']['rustc_identity'], '32d 编译器与新七件不同')
    measurement = manifests['measurement']
    result['mock_receipt'], _ = runner.command('run_mock_ac12', [measurement['artifacts']['comm_fault_e2e']['path'], '--phase', 'mock', '--case', 'AC-12', '--bin-dir', measurement['artifact_directory'], '--evidence-dir', str(evidence)], 300)
    report = a.strict_json((evidence / 'report.json').read_text())
    result['mock'] = p.validate_mock(report, measurement, evidence)
    result['mock_report_sha256'] = a.sha256(evidence / 'report.json')
    result['loopback_receipt'], loopback = runner.command('final_stop_transport', ['cargo', 'test', '--locked', '-p', 'robot-tests',
        '--no-default-features', '--features', 'comm-fault-rpc', '--test', 'final_stop_transport',
        '--', '--ignored', '--test-threads=1', '--nocapture'], 7200)
    scenes = p.validate_loopback(Path(loopback['stdout']).read_text())
    r.save(out / 'loopback_scenes.json', scenes)
    result['loopback'] = {'tests': 6, 'scenes': 9, 'all_servers_joined': True}
    result['rustc_after'], after = runner.command('rustc_after', ['rustc', '-vV'])
    a.require(a.parse_rustc_identity(Path(after['stdout']).read_text()) == compiler, 'mock 前后编译器不同')
    result.update(status='PASS', rustc_identity=compiler)
except BaseException as error:
    result['error'] = repr(error)
finally:
    for label, action in [('source_after', lambda: runner.source('source_after')), ('identities_after', identities), ('process_after', processes)]:
        try:
            value = action()
            if label == 'source_after':
                a.require(before is not None and value == before, 'mock 前后编译源不同')
            else:
                r.save(out / (label + '.json'), value)
                a.require(value == initial if label == 'identities_after' else value['clean'], '七件/正式变化或 mock 控制残留')
            result[label] = 'PASS'
        except BaseException as error:
            result.update(status='FAIL')
            result[label] = repr(error)
    try:
        result['formal_after'] = services('formal_after')
        a.require(result['formal_after'] == result.get('formal_before'), '六正式服务前后不同')
        a.require(a.sha256(Path(__file__)) == result['script_sha256']
                  and a.sha256(Path(p.__file__)) == result['post_release_sha256']
                  and a.sha256(Path(r.__file__)) == 'd6b20da28de8d5ae077a93cb2fb5ba7f27a66b8145df9e7e91951cb14ac0b12b'
                  and a.sha256(Path(a.__file__)) == 'bd2b3f7bb8527cd9ecec73894171638e9cf378656b89e284a585c3baa37b8731', '软件脚本或复用模块前后不同')
    except BaseException as error:
        result.update(status='FAIL', formal_or_metadata_error=repr(error))
    result['finished_at'] = r.utc()
    result['receipts'] = runner.receipts
    r.save(out / 'result.json', result)
    print(json.dumps(result, ensure_ascii=False), flush=True)
raise SystemExit(0 if result['status'] == 'PASS' else 1)
