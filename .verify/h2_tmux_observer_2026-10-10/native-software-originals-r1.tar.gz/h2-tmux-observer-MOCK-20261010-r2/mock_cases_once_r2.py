"""固定五类无害 tmux 动态场景及注册接缝；只清理本次自有 dead pane。"""

import errno
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import time

ROOT = Path(__file__).resolve().parent
OUT = ROOT / "mock-r2"
SESSION = "robot-h2-observer-MOCK-20261010-r2"
ORIGINAL_BASE = "/home/loosqk/robot-checks/h2-exit-observation-20261009-r1"
TEMPLATE = (ROOT / "tmux_h2_observer_event_once_r1.sh").read_text()
OUT.mkdir()
COMMANDS = []
OBSERVERS = []
BASES = []


def save(path, data):
    with path.open("x") as stream:
        json.dump(data, stream, ensure_ascii=False, indent=2)
        stream.write("\n")


def command(argv):
    # 软件夹具的每个直接 child 都自然 wait；无信号/超时 kill。
    child = subprocess.Popen(argv, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    stdout, stderr = child.communicate()
    row = {"argv": argv, "pid": child.pid, "wait_returncode": child.returncode,
           "naturally_reaped": True, "stdout": stdout.decode(), "stderr": stderr.decode(),
           "sent_signals": []}
    COMMANDS.append(row)
    assert child.returncode == 0, row
    return row["stdout"].strip()


def until(check):
    # 仅软件测试装配用有界等待；不进入待验证 observer/H2 逻辑。
    limit = time.monotonic() + 15
    while True:
        value = check()
        if value:
            return value
        assert time.monotonic() < limit, "mock 装配超时，保留原件"
        time.sleep(0.01)


def make_case(name, status=0, seam=False):
    base = OUT / name
    (base / "bootstrap/control-v2").mkdir(parents=True)
    BASES.append(base)
    os.mkfifo(base / "finish.fifo")
    (base / "exit-status.txt").write_text(str(status))
    launch = base / "bootstrap/control-v2/h2_launch_r1.sh"
    launch.write_text(
        "#!/bin/bash\nset -eu\n"
        'tmux set-option -w -t "$TMUX_PANE" remain-on-exit on\n'
        f"printf 'launch\\n' >> {base}/launch-count.txt\n"
        f"exec {sys.executable} {ROOT}/mock_driver.py {base}\n")
    script = TEMPLATE.replace(ORIGINAL_BASE, str(base)).replace(
        "robot-h2-20261009-proxy-r1", SESSION).replace(
        "right-h2-a96-event-once", "MOCK-" + name).replace(
        "P7_H2_RUN_V1", "MOCK_H2_RUN_V1").replace(
        "a96c34ae26b56fc9e8d2deef17c3b829c3d87d0d", "MOCK-A96-NO-HARDWARE")
    if seam:
        os.mkfifo(base / "observer-register.fifo")
        # 明示仅测试副本：将真正 wait 注册延迟到 driver 已退出之后。
        script = script.replace('  tmux wait-for "$channel"',
                                f'  printf ready > {base}/before-wait.txt\n'
                                f'  read -r permit < {base}/observer-register.fifo\n'
                                '  test "$permit" = G\n  tmux wait-for "$channel"')
    (base / "observer-MOCK.sh").write_text(script)
    return base


def observe(base, only=False):
    label = "observe-" + str(sum(row[0] == base for row in OBSERVERS))
    log = (base / (label + ".log")).open("xb")
    argv = ["/bin/bash", str(base / "observer-MOCK.sh")]
    env = dict(os.environ, H2_OBSERVE_ONLY="1" if only else "0")
    child = subprocess.Popen(argv, env=env, stdout=log, stderr=subprocess.STDOUT,
                             start_new_session=True)
    row = {"argv": argv, "pid": child.pid, "observe_only": only, "sent_signals": []}
    OBSERVERS.append((base, child, log, row))
    save(base / (label + ".launch.json"), row)
    return child


def record(base):
    path = base / "bootstrap/tmux-hardware-event-r1/pane.txt"
    until(path.is_file)
    fields = path.read_text().split()
    assert len(fields) == 3
    return fields


def wait_started(base, child):
    hooks = base / f"bootstrap/tmux-hardware-event-r1/observer-{child.pid}.hooks-after"
    until(hooks.is_file)
    channel = (hooks.parent / f"observer-{child.pid}.channel").read_text().strip()

    def waiting():
        if child.poll() is not None:
            return False
        for entry in Path("/proc").iterdir():
            if not entry.name.isdigit():
                continue
            try:
                fields = (entry / "stat").read_text().rsplit(") ", 1)[1].split()
                if int(fields[1]) != child.pid:
                    continue
                argv = (entry / "cmdline").read_bytes().split(b"\0")
            except FileNotFoundError:
                continue
            if argv[:3] == [b"tmux", b"wait-for", channel.encode()]:
                return {"waiter_pid": int(entry.name), "ppid": child.pid,
                        "start_ticks": int(fields[19]), "argv": [s.decode() for s in argv if s]}
        return False

    row = until(waiting)
    save(base / f"waiter-{child.pid}.json", dict(row, channel=channel))
    return channel


def release(base):
    until((base / "ready.json").is_file)
    if not (base / "released.txt").exists():
        with (base / "finish.fifo").open("wb", buffering=0) as stream:
            stream.write(b"G")
        (base / "released.txt").write_text("本次仅释放自有 mock driver\n")


def terminal(base):
    pane, pid, window = record(base)
    state = until(lambda: (value if (value := command([
        "tmux", "display-message", "-p", "-t", pane,
        "#{pane_id} #{pane_pid} #{pane_dead} #{pane_dead_status}"])).split()[2] == "1" else None))
    assert state.split()[:2] == [pane, pid]
    return state


def reaped(child, expected):
    code = child.wait()
    assert code == expected, (child.pid, code, expected)
    try:
        os.waitpid(child.pid, os.WNOHANG)
    except ChildProcessError as error:
        assert error.errno == errno.ECHILD
    else:
        raise AssertionError("observer child 未确认真实回收")
    for base, owned, log, row in OBSERVERS:
        if owned is child:
            log.close()
            row.update(wait_returncode=code, naturally_reaped=True,
                       waitpid_after_reap_errno=errno.ECHILD)
            save(base / (log.name.split("/")[-1].replace(".log", ".result.json")), row)
            break


result = {"schema": "TMUX_OBSERVER_MOCK_ONCE_V1", "status": "FAIL", "no_hardware": True,
          "template_sha256": hashlib.sha256((ROOT / "tmux_h2_observer_event_once_r1.sh").read_bytes()).hexdigest(),
          "cases": []}
try:
    result["tmux_version"] = command(["tmux", "-V"])
    bootstrap = make_case("bootstrap")
    command(["tmux", "new-session", "-d", "-s", SESSION, "-n", "MOCK-bootstrap",
             f"exec /bin/bash {bootstrap}/bootstrap/control-v2/h2_launch_r1.sh"])
    until((bootstrap / "ready.json").is_file)
    bootstrap_pane = command(["tmux", "display-message", "-p", "-t", SESSION,
                              "#{pane_id} #{pane_pid} #{window_id}"])
    (bootstrap / "bootstrap/tmux-hardware-event-r1").mkdir()
    (bootstrap / "bootstrap/tmux-hardware-event-r1/pane.txt").write_text(bootstrap_pane + "\n")

    for name, code in (("exit0", 0), ("exit1", 1)):
        base = make_case(name, code)
        child = observe(base)
        wait_started(base, child)
        release(base)
        reaped(child, code)
        result["cases"].append({"name": name, "status": "PASS", "terminal": terminal(base)})

    base = make_case("exit-before-reconnect")
    pane_output = command(["tmux", "new-window", "-d", "-t", SESSION, "-n", "MOCK-exit-before",
                           "-P", "-F", "#{pane_id} #{pane_pid} #{window_id}",
                           f"exec /bin/bash {base}/bootstrap/control-v2/h2_launch_r1.sh"])
    rec = base / "bootstrap/tmux-hardware-event-r1"
    rec.mkdir()
    (rec / "pane.txt").write_text(pane_output + "\n")
    release(base)
    terminal(base)
    child = observe(base, only=True)
    reaped(child, 0)
    result["cases"].append({"name": "exit-before-reconnect", "status": "PASS", "terminal": terminal(base)})

    base = make_case("two-observers")
    first = observe(base)
    first_channel = wait_started(base, first)
    second = observe(base, only=True)
    second_channel = wait_started(base, second)
    assert first_channel != second_channel
    release(base)
    reaped(first, 0)
    reaped(second, 0)
    result["cases"].append({"name": "two-observers", "status": "PASS", "terminal": terminal(base)})

    base = make_case("early-and-wrong-notification")
    child = observe(base)
    channel = wait_started(base, child)
    command(["tmux", "wait-for", "-S", channel + ".WRONG"])
    # 同一个真实 wait-for child 仍活，错 channel 不可唤醒。
    until(lambda: child.poll() is None)
    time.sleep(0.1)
    assert child.poll() is None
    command(["tmux", "wait-for", "-S", channel])
    reaped(child, 2)
    # 此时 driver 仍活，没有终态；拒绝码 2 不伪装成 driver 的自然 FAIL。
    pane, pid, _ = record(base)
    still_live = command(["tmux", "display-message", "-p", "-t", pane,
                          "#{pane_id} #{pane_pid} #{pane_dead}"])
    assert still_live.split() == [pane, pid, "0"]
    duplicate = observe(base)
    reaped(duplicate, 1)
    release(base)
    terminal(base)
    resumed = observe(base, only=True)
    reaped(resumed, 0)
    result["cases"].append({"name": "early-and-wrong-notification", "status": "PASS",
                            "live_after_rejection": still_live, "terminal": terminal(base)})

    base = make_case("exit-before-wait-registration", seam=True)
    child = observe(base)
    until((base / "before-wait.txt").is_file)
    release(base)
    terminal(base)
    with (base / "observer-register.fifo").open("w") as stream:
        stream.write("G\n")
    reaped(child, 0)
    result["cases"].append({"name": "exit-before-wait-registration", "status": "PASS", "terminal": terminal(base)})

    for base in BASES:
        assert (base / "launch-count.txt").read_text().splitlines() == ["launch"]
        result.setdefault("launch_counts", {})[base.name] = 1
    result["status"] = "PASS"
except BaseException as error:
    result["error"] = repr(error)
    raise
finally:
    # 只释放自有软件 driver；没有自动重跑，没有信号终止或用户 session 清理。
    for base in BASES:
        if (base / "bootstrap/tmux-hardware-event-r1/pane.txt").is_file():
            until((base / "ready.json").is_file)
            release(base)
    for base, child, log, row in OBSERVERS:
        if not row.get("naturally_reaped"):
            reaped(child, child.wait())
    panes = command(["tmux", "list-panes", "-s", "-t", SESSION, "-F",
                     "#{pane_id} #{pane_dead} #{pane_pid} #{pane_dead_status}"])
    until(lambda: all(line.split()[1] == "1" for line in command([
        "tmux", "list-panes", "-s", "-t", SESSION, "-F", "#{pane_id} #{pane_dead}"]).splitlines()))
    panes = command(["tmux", "list-panes", "-s", "-t", SESSION, "-F",
                     "#{pane_id} #{pane_dead} #{pane_pid} #{pane_dead_status}"])
    result["dead_panes_before_own_cleanup"] = panes.splitlines()
    for line in panes.splitlines():
        pane, dead, _, _ = line.split()
        assert dead == "1"
        command(["tmux", "kill-pane", "-t", pane])
    result["commands"] = COMMANDS
    result["observers"] = [row for _, _, _, row in OBSERVERS]
    save(OUT / "result.json", result)
    print(json.dumps({"status": result["status"], "cases": result["cases"],
                      "result": str(OUT / "result.json")}, ensure_ascii=False), flush=True)
