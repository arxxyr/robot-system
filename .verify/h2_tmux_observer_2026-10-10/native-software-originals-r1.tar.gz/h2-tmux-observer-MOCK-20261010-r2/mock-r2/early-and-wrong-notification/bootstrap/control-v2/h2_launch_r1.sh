#!/bin/bash
set -eu
tmux set-option -w -t "$TMUX_PANE" remain-on-exit on
printf 'launch\n' >> /home/loosqk/robot-checks/h2-tmux-observer-MOCK-20261010-r2/mock-r2/early-and-wrong-notification/launch-count.txt
exec /home/loosqk/.local/share/uv/python/cpython-3.12-linux-aarch64-gnu/bin/python3.12 /home/loosqk/robot-checks/h2-tmux-observer-MOCK-20261010-r2/mock_driver.py /home/loosqk/robot-checks/h2-tmux-observer-MOCK-20261010-r2/mock-r2/early-and-wrong-notification
