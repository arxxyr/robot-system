#!/bin/bash
set -eu
tmux set-option -w -t "$TMUX_PANE" remain-on-exit on
exec > /home/loosqk/robot-checks/h2-tmux-observer-MOCK-20261010-r1/software-owner.log 2>&1
exec /home/loosqk/.local/share/uv/python/cpython-3.12-linux-aarch64-gnu/bin/python3.12 /home/loosqk/robot-checks/h2-tmux-observer-MOCK-20261010-r1/mock_cases_once.py
