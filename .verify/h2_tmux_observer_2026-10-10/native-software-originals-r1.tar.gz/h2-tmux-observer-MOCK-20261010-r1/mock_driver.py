"""仅供 tmux 观察副本的软件夹具；不导入机器人模块、不访问 UART。"""

import json
import os
from pathlib import Path
import subprocess
import sys
import time

base = Path(sys.argv[1])
child = subprocess.Popen(["/bin/true"])
code = child.wait()
try:
    os.waitpid(child.pid, os.WNOHANG)
except ChildProcessError as error:
    wait_error = error.errno
else:
    raise AssertionError("自有 mock child 未确认回收")
(base / "ready.json").write_text(json.dumps({
    "schema": "MOCK_DRIVER_READY_V1", "pid": os.getpid(),
    "mock_child_pid": child.pid, "mock_child_wait_returncode": code,
    "mock_child_reaped": True, "waitpid_after_reap_errno": wait_error,
}))
with (base / "finish.fifo").open("rb", buffering=0) as stream:
    assert stream.read(1) == b"G"
status = int((base / "exit-status.txt").read_text())
(base / "right-h2-run-01").mkdir()
(base / "right-h2-run-01/run.json").write_text(json.dumps({
    "schema": "MOCK_H2_RUN_V1", "side": "right",
    "expected_head": "MOCK-A96-NO-HARDWARE", "supervisor_pid": os.getpid(),
    "status": "PASS" if status == 0 else "FAIL", "finished_ns": time.time_ns(),
    "tool_pid": child.pid, "tool_naturally_reaped": True, "tool_exit": code,
    "no_hardware": True,
}))
raise SystemExit(status)
