#!/bin/bash
set -eu
export PYTHONDONTWRITEBYTECODE=1
tmux set-option -w -t "$TMUX_PANE" remain-on-exit on
exec /home/loosqk/.local/share/uv/python/cpython-3.12.13-linux-aarch64-gnu/bin/python3 /home/loosqk/robot-checks/position-return-20261010-r1/software-facts-r1/scripts/run_hardware_maintenance.py --bindings /home/loosqk/robot-checks/position-return-20261010-r1/head-phase-r3/maintenance_bindings_head_r3.json --position-target head-2 --output /home/loosqk/robot-checks/position-return-20261010-r1/head-phase-r3/head2-baseline-r3 --run-id head2-baseline-r3 --artifact-root /home/loosqk/robot-checks/position-return-20261010-r1 --execute --approval /home/loosqk/robot-checks/position-return-20261010-r1/head-phase-r3/head2-baseline-r3.go.json > /home/loosqk/robot-checks/position-return-20261010-r1/head-phase-r3/head2-launch-r3/driver.log 2>&1
