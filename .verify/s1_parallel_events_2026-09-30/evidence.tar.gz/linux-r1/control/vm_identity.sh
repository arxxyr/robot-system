set -eu
hostname
id -un
uname -m
cat /proc/sys/kernel/random/boot_id
pwd
printf 'HOME_DIR=%s\n' "$HOME"
ls -d /home/loosqk.guest/robot-checks/* 2>/dev/null
command -v python3
command -v uv || true
