set -eu
BASE=/home/loosqk.guest/robot-checks/s1-parallel-events-20260930-r1
cat "$BASE/control/fmt.owner/child.log"
cat "$BASE/control/nightly_update.owner/child.log"
cat "$BASE/control/rustc_before.owner/child.log"
cat "$BASE/control/cargo_before.owner/child.log"
