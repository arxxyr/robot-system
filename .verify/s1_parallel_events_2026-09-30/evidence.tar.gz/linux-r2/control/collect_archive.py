"""仅收集本次 Lima r1/r2 原件和 589 项输入；不改源码，不包含 Git 或 Cargo 缓存。"""

import hashlib
import importlib.util
import io
import json
import os
from pathlib import Path
import socket
import stat
import sys
import tarfile
from types import SimpleNamespace

sys.dont_write_bytecode = True
ROOT = Path("/home/loosqk.guest/robot-checks")
BASES = [ROOT / ("s1-parallel-events-20260930-r" + str(number)) for number in (1, 2)]
OUTPUT = ROOT / "s1-parallel-events-20260930-native-r1.tar.gz"
INDEX = ROOT / "s1-parallel-events-20260930-native-r1.index.json"
POST = BASES[1] / "postchecks.json"
AGGREGATE = "72ac7a50c9aeddaa0ac47f21543f3c21e3f05a2c72e7b7e3108246b2d6e4cc02"


def require(condition, message):
    if not condition:
        raise ValueError(message)


def raw(path):
    require(path == path.resolve() and path.is_absolute(), "原件必须规范绝对路径")
    meta = path.lstat()
    require(stat.S_ISREG(meta.st_mode) and meta.st_nlink == 1, "不是独立普通文件：" + str(path))
    return path.read_bytes()


def digest(content):
    return hashlib.sha256(content).hexdigest()


def module(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    result = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(result)
    return result


require(socket.gethostname() == "lima-robot-viz-check" and os.getuid() == 501, "Lima 身份不符")
require(not OUTPUT.exists() and not INDEX.exists() and not POST.exists(), "输出必须全新")
completed = [json.loads(raw(base / "result.json")) for base in BASES]
require(completed[0]["status"] == "FAIL" and completed[1]["status"] == "PASS", "r1 原 FAIL / r2 原 PASS 不符")
for result, base in zip(completed, BASES):
    for command in result["commands"]:
        receipt = command["receipt"]
        path = Path(receipt["path"])
        data = raw(path)
        require(path.is_relative_to(base / "control") and digest(data) == receipt["sha256"], "命令原回执改变")
        row = json.loads(data)
        require(row["reaped"] is True and row["phase"] == "REAPED" and row["owner_sent_signals"] == []
                and row["received_signals"] == {} and row["errors"] == [], "命令缺真实自然回收")
        require(row["wait_returncode"] == command["exit_code"], "真实退出码不符")
        log = row["log"]
        content = raw(Path(log["path"]))
        require(len(content) == log["bytes"] and digest(content) == log["sha256"], "原日志改变")

control = BASES[1] / "control"
require(digest(raw(control / "owner.py")) == "96d1c8ed14fa94e62cbfcb0ea28ff60f628bdcf0d76cf3796d968602ce14938a", "owner 改变")
owner = module("s1_collector_owner", control / "owner.py")
os.chdir(BASES[1] / "source")
fresh = {}
for name, argv in (("inventory", ["git", "ls-files", "-z"]), ("head", ["git", "rev-parse", "HEAD"]),
                   ("status", ["git", "status", "--porcelain=v1", "--untracked-files=all"])):
    code = owner.run(SimpleNamespace(label="collector_" + name, command=argv, observe_seconds=5.0, input=None))
    require(code == 0, "fresh Git 查询失败")
    fresh[name] = raw(control / ("collector_" + name + ".owner/child.log"))
require(fresh["head"].decode().strip() == completed[1]["head"], "fresh HEAD 改变")
require(fresh["status"] == b" M crates/robot-s1/src/events_drain/runtime.rs\n", "fresh Git 修改范围改变")
inventory = fresh["inventory"].decode().rstrip("\0").split("\0")
artifacts = module("s1_collector_contract", BASES[1] / "source/scripts/post_e_h2_artifacts.py")
source = artifacts.snapshot_source(BASES[1] / "source", inventory)
require(len(source["files"]) == 589 and source["source_manifest_sha256"] == AGGREGATE
        and source == json.loads(raw(BASES[1] / "source_before.json"))
        and source == json.loads(raw(BASES[1] / "source_after.json")), "fresh 589 输入与原前后不符")

sessions = {json.loads(raw(Path(command["receipt"]["path"])))["child_session_id"]
            for result in completed for command in result["commands"]}
remaining = []
for entry in Path("/proc").iterdir():
    if not entry.name.isdigit():
        continue
    try:
        fields = (entry / "stat").read_text().rsplit(") ", 1)[1].split()
        sid = int(fields[3])
        if sid in sessions:
            remaining.append({"pid": int(entry.name), "sid": sid, "start_ticks": int(fields[19]), "state": fields[0]})
    except FileNotFoundError:
        pass
require(not remaining, "本次命令会话仍有进程")
post = {"status": "PASS", "fresh_source": source, "fresh_git_head": fresh["head"].decode().strip(),
        "fresh_git_status": fresh["status"].decode(), "owned_sessions_remaining": remaining,
        "session_count": len(sessions), "identity": completed[1]["identity"]}
with POST.open("x") as stream:
    json.dump(post, stream, ensure_ascii=False, indent=2)
    stream.write("\n")

files = {}
for number, base in enumerate(BASES, 1):
    paths = [base / name for name in ("result.json", "source_before.json", "source_after.json")]
    paths.extend(path for path in (base / "control").rglob("*") if path.is_file())
    if number == 2:
        paths.append(POST)
    for path in paths:
        name = "r" + str(number) + "/" + str(path.relative_to(base))
        require(name not in files, "归档路径重复")
        files[name] = raw(path)
for name, item in source["files"].items():
    data = raw(BASES[1] / "source" / name)
    require(digest(data) == item["sha256"] and len(data) == item["bytes"], "打包时源码改变")
    files["candidate-source-inputs/" + name] = data
index = {"schema": "S1_LINUX_NATIVE_ARCHIVE_INDEX_V1", "files": {
    name: {"sha256": digest(data), "bytes": len(data)} for name, data in sorted(files.items())}}
index_raw = (json.dumps(index, ensure_ascii=False, sort_keys=True, indent=2) + "\n").encode()
with INDEX.open("xb") as stream:
    stream.write(index_raw)
with tarfile.open(OUTPUT, "x:gz") as archive:
    for name, data in sorted({**files, "index.json": index_raw}.items()):
        item = tarfile.TarInfo(name)
        item.size = len(data)
        item.mode = 0o644
        archive.addfile(item, io.BytesIO(data))
require(all(digest(raw(BASES[1] / "source" / name)) == item["sha256"] for name, item in source["files"].items()),
        "归档后源码改变")
print(json.dumps({"status": "PASS", "archive": {"path": str(OUTPUT), "sha256": digest(raw(OUTPUT)),
                                               "bytes": OUTPUT.stat().st_size},
                  "index": {"path": str(INDEX), "sha256": digest(index_raw), "bytes": len(index_raw)},
                  "files": len(files), "source_files": 589, "source_manifest_sha256": AGGREGATE,
                  "s1_tests": completed[1]["s1_lib_default_parallel"], "original_r1_fail_preserved": True}, ensure_ascii=False))
