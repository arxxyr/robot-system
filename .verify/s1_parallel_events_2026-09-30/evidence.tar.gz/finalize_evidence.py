#!/usr/bin/env python3
"""仅整理当前隔离候选的本地证据，不启动测试或修改源码。"""
import hashlib
import json
import subprocess
import sys
from pathlib import Path

sys.dont_write_bytecode = True
root = Path(__file__).resolve().parents[2]
base = Path(__file__).resolve().parent
sys.path.insert(0, str(root / "scripts"))
import post_e_h2_artifacts as artifacts


def reference(path):
    data = path.read_bytes()
    return {"path": str(path), "sha256": hashlib.sha256(data).hexdigest(), "bytes": len(data)}


def write_new(path, value):
    with path.open("x") as stream:
        json.dump(value, stream, ensure_ascii=False, indent=2, allow_nan=False)
        stream.write("\n")


def git(*args):
    return subprocess.check_output(["git", *args], cwd=root)


head = git("rev-parse", "HEAD").decode().strip()
assert head == "4a8e171f27bf18625973aa4f3a6097e9b9fbed18"
modified = git("diff", "--name-only").decode().splitlines()
runtime_name = "crates/robot-s1/src/events_drain/runtime.rs"
assert modified == [runtime_name]
assert git("status", "--porcelain=v1", "--untracked-files=all").decode() == " M " + runtime_name + "\n"
candidate = artifacts.snapshot_source(root, git("ls-files", "-z").decode().rstrip("\0").split("\0"))
assert len(candidate["files"]) == 589
assert candidate["source_manifest_sha256"] == "72ac7a50c9aeddaa0ac47f21543f3c21e3f05a2c72e7b7e3108246b2d6e4cc02"
extracted = base / "linux-r2/native-extracted"
before = artifacts.strict_json((extracted / "r2/source_before.json").read_text())
after = artifacts.strict_json((extracted / "r2/source_after.json").read_text())
assert candidate == before == after

# 从 Git HEAD 逐文件读取全部编译域，避免仅用单文件替换推定基线。
tree = {}
for row in git("ls-tree", "-r", "-z", head).split(b"\0"):
    if not row:
        continue
    meta, name = row.split(b"\t", 1)
    mode, kind, oid = meta.decode().split()
    tree[name.decode()] = {"mode": mode, "kind": kind, "oid": oid}
names = sorted(candidate["files"])
assert all(tree[name]["kind"] == "blob" for name in names)
proc = subprocess.Popen(["git", "cat-file", "--batch"], cwd=root,
                        stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
raw, stderr = proc.communicate("".join(tree[name]["oid"] + "\n" for name in names).encode())
assert proc.returncode == 0 and stderr == b""
baseline_files = {}
offset = 0
runtime_baseline = None
for name in names:
    end = raw.index(b"\n", offset)
    oid, kind, length = raw[offset:end].decode().split()
    size = int(length)
    assert oid == tree[name]["oid"] and kind == "blob"
    data = raw[end + 1:end + 1 + size]
    assert len(data) == size and raw[end + 1 + size:end + 2 + size] == b"\n"
    offset = end + 2 + size
    baseline_files[name] = {"sha256": hashlib.sha256(data).hexdigest(), "bytes": size,
                            "executable": tree[name]["mode"] == "100755"}
    if name == runtime_name:
        runtime_baseline = data
assert offset == len(raw)
baseline_digest = hashlib.sha256(artifacts.canonical(baseline_files)).hexdigest()
assert baseline_digest == "c03888074cbd4005837bc0291aafdf72fff4a59f473d75f52298b1da42182a96"
differences = [name for name in names if baseline_files[name] != candidate["files"][name]]
assert differences == [runtime_name]
current_runtime = (root / runtime_name).read_bytes()
assert hashlib.sha256(current_runtime).hexdigest() == "f0aaae567e7100ed903acef64504c038ce9f0cda6cd5b394ab8539afecbd0a40"
marker = b"#[cfg(test)]\nmod tests {"
baseline_offset = runtime_baseline.index(marker)
candidate_offset = current_runtime.index(marker)
assert baseline_offset == candidate_offset == 25621
assert runtime_baseline[:baseline_offset] == current_runtime[:candidate_offset]
comparison = {
    "status": "PASS", "head": head, "baseline_read_from": "git cat-file --batch：全部 589 个 HEAD blob",
    "baseline_manifest_sha256": baseline_digest,
    "candidate_manifest_sha256": candidate["source_manifest_sha256"],
    "source_files": 589, "unchanged_files": 588,
    "differences": [{"path": runtime_name, "baseline": baseline_files[runtime_name],
                     "candidate": candidate["files"][runtime_name]}],
    "production_prefix_unchanged": True, "production_prefix_bytes": baseline_offset,
    "production_prefix_sha256": hashlib.sha256(current_runtime[:candidate_offset]).hexdigest(),
    "local_candidate_equal_linux_before_after": True,
    "git_batch_exit_code": proc.returncode, "git_batch_reaped": True,
    "scope": "仅 cfg(test) 测试模块；生产代码前缀字节一致"
}
write_new(base / "source_comparison.json", comparison)

old_bytes = (base / "summary.json").read_bytes()
old = artifacts.strict_json(old_bytes.decode())
with (base / "mac_summary_before_linux.json").open("xb") as stream:
    stream.write(old_bytes)
result = artifacts.strict_json((extracted / "r2/result.json").read_text())
postchecks = artifacts.strict_json((extracted / "r2/postchecks-r2.json").read_text())
verification = artifacts.strict_json((base / "linux-r2/native_archive_verification.json").read_text())
assert result["status"] == postchecks["status"] == verification["status"] == "PASS"
assert result["s1_lib_default_parallel"]["passed"] == 287
assert result["rust_test_threads_present"] is False
assert result["compiler_before_after_equal"] and result["source_before_after_equal"]
assert postchecks["owned_sessions_remaining"] == []
linux_checks = []
for label in ["nightly_update", "nightly_components", "fmt", "clippy_all", "s1_lib_default_parallel"]:
    receipt_dir = extracted / "r2/control" / (label + ".owner")
    receipt = artifacts.strict_json((receipt_dir / "result.json").read_text())
    command = next(row for row in result["commands"] if row["name"] == label)
    assert command["exit_code"] == 0 and command["reaped"] is True
    linux_checks.append({"name": label, "argv": command["argv"], "exit": 0, "reaped": True,
                         "receipt": reference(receipt_dir / "result.json"),
                         "log": reference(receipt_dir / "child.log")})
old["status"] = "SOFTWARE_CANDIDATE_PASS_PENDING_ROOT_ACCEPTANCE"
old["checks_platform"] = "macOS；Linux 完整门见 linux_validation"
old["linux_default_parallel"] = result["s1_lib_default_parallel"]
old["source_comparison"] = reference(base / "source_comparison.json")
old["linux_validation"] = {
    "status": "PASS", "environment": "隔离 Lima robot-viz-check；没有 robot/Orin SSH 或硬件访问",
    "vm_identity": result["identity"], "compiler": "1.101.0-nightly / 5c543b0b8c73c7b72bc8284ced4fb22ead15734d / aarch64-unknown-linux-gnu",
    "cargo": "1.101.0-nightly (3d7cf6e93 2026-09-25)",
    "checks": linux_checks, "full_s1_lib_default_parallel": result["s1_lib_default_parallel"],
    "source_before_after_equal": True, "compiler_before_after_equal": True,
    "same_source_589": candidate["source_manifest_sha256"],
    "original_r1_fmt_failure_preserved": reference(extracted / "r1/control/fmt.owner/child.log"),
    "original_r1_fmt_failure_exit": 1,
    "r1_not_run": ["root Clippy", "S1 lib"],
    "r2_software_result": reference(extracted / "r2/result.json"),
    "postchecks": reference(extracted / "r2/postchecks-r2.json"),
    "native_archive": reference(base / "linux-r2/native-evidence.tar.gz"),
    "native_index": reference(base / "linux-r2/native-evidence.index.json"),
    "native_archive_verification": reference(base / "linux-r2/native_archive_verification.json"),
    "actual_vm_waits": verification["vm_wait_count"],
    "owned_sessions_remaining_at_postcheck": [],
    "vm_last_observed_state": "Running；测试命令均已真实回收"
}
old["independent_static_review"] = reference(base / "static_review.json")
old["historical_failure_root_cause"] = "OPEN_UNCONFIRMED；受控连接窗口机制已复现，不回填历史归因"
old["historical_s49_failure"] = reference(Path("/Users/loosqk/repo/rust/robot-system/target/post_e_h2_rt/s49/delayed_ack_20260929/orin/test_final_affected.log"))
old["parent_integration"] = "候选冻结；root 验收、合并与提交另行处理；没有自动 merge/commit/push"
old["verification_boundary"] = "未跑完整 workspace test；完整 S1 lib 默认并行、根 all-targets Clippy 已跑。Mac all-targets 既有 handler lint 保持 FAIL。硬件 H2/D15 不由本报告外推。"
(base / "summary.json").write_text(json.dumps(old, ensure_ascii=False, indent=2, allow_nan=False) + "\n")
(base / "README.md").write_text(
    "# S1 并行事件夹具候选\n\n"
    "仅调整 `runtime.rs` 的 cfg(test) 夹具：独立 Node/端口 RAII、发送前刷新订阅连接，并用同 topic 双订阅者验证同一终态的投递与未连接遗漏。生产前缀 25621 字节一致，20ms/2s 预算和默认并行不变。\n\n"
    "Mac 定向默认并行 15 项及 S1 lib Clippy 通过；隔离 Linux 更新浮动 nightly 5c543b0b8 后，fmt、根 Clippy all/all-targets 和完整 S1 lib 默认并行 287 项通过，0 failed/ignored。589 个输入前后一致，35 份 VM 命令回执真实 wait/reap。\n\n"
    "入口：`summary.json`；逐文件基线比较：`source_comparison.json`；原生证据包：`linux-r2/native-evidence.tar.gz` 和对应 index；已校验解包：`linux-r2/native-extracted`。\n\n"
    "首次 Linux 缺 rustfmt 的 FAIL 和 Mac 既有 all-targets handler lint FAIL 均保留。历史两次超时的具体根因仍 OPEN_UNCONFIRMED；本报告不宣称完整 workspace 测试或 H2 硬件通过。候选冻结，无主树源码修改、robot/Orin SSH、硬件访问、合并、提交或推送。\n"
)
print(json.dumps({"summary": reference(base / "summary.json"), "comparison": reference(base / "source_comparison.json"),
                  "readme": reference(base / "README.md"), "source": reference(root / runtime_name)}, ensure_ascii=False, indent=2))
