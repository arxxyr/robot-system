#!/usr/bin/env python3
"""隔离 Orin 软件验收辅具；只管理本轮自有命令，不访问设备或正式服务。"""

import argparse
import datetime
import hashlib
import json
import os
from pathlib import Path
import platform
import re
import signal
import subprocess
import time


INTERRUPTED = None


def utc():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()


def sha(path):
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def save(path, value):
    # 每份回执只写一次；失败重跑必须使用新的证据目录。
    with path.open("x", encoding="utf-8") as stream:
        json.dump(value, stream, ensure_ascii=False, indent=2)
        stream.write("\n")


def verify_source(root, expected_manifest_sha):
    manifest = root / "source_manifest.json"
    actual_manifest_sha = sha(manifest)
    rows = json.loads(manifest.read_text())["files"]
    mismatches, allowed, seen = [], [], set()
    for row in rows:
        relative = Path(row["path"])
        if relative.is_absolute() or ".." in relative.parts or str(relative) in seen:
            raise ValueError("源码清单含非法或重复路径")
        seen.add(str(relative))
        path = root / relative
        try:
            actual = ({"link": str(path.readlink())} if path.is_symlink()
                      else {"bytes": path.stat().st_size, "sha256": sha(path)})
            expected = {key: value for key, value in row.items() if key != "path"}
            if actual != expected:
                item = {"path": str(relative), "expected": expected, "actual": actual}
                (allowed if str(relative) == "CLAUDE.md" else mismatches).append(item)
        except OSError as error:
            mismatches.append({"path": str(relative), "error": str(error)})
    return {
        "source_matches": not mismatches and actual_manifest_sha == expected_manifest_sha,
        "files": len(rows), "manifest_sha256": actual_manifest_sha,
        "expected_manifest_sha256": expected_manifest_sha,
        "mismatches": mismatches, "allowed_claude_drift": allowed,
        "scope": "仅逐项核清单文件；CLAUDE.md 内容差异记录但不替代产品源码身份",
    }


def process_entry(pid):
    try:
        directory = Path("/proc") / str(pid)
        fields = (directory / "stat").read_text().rsplit(") ", 1)[1].split()
        return {"pid": int(pid), "ppid": int(fields[1]), "pgid": int(fields[2]),
                "sid": int(fields[3]), "state": fields[0], "start_ticks": int(fields[19])}
    except (OSError, ValueError, IndexError):
        return None


def processes():
    return [entry for path in Path("/proc").iterdir() if path.name.isdigit()
            if (entry := process_entry(path.name)) is not None]


def session_members(sid):
    return [entry for entry in processes() if entry["sid"] == sid]


def signal_session(sid, sig, actions):
    # 测试会另建 process group，因此从本轮新 session 枚举其子组。
    # 不按命令名、全局路径或其他 session 发送信号；不收养孤儿进程。
    groups = sorted({entry["pgid"] for entry in session_members(sid)})
    for pgid in groups:
        event = {"sid": sid, "pgid": pgid, "signal": sig.name, "utc": utc()}
        try:
            os.killpg(pgid, sig)
            event["sent"] = True
        except ProcessLookupError:
            event["sent"] = False
            event["reason"] = "group_already_gone"
        except OSError as error:
            event["sent"] = False
            event["error"] = str(error)
        actions.append(event)


def stop_session(process, actions):
    signal_session(process.pid, signal.SIGTERM, actions)
    until = time.monotonic() + 5
    while time.monotonic() < until:
        process.poll()
        if not session_members(process.pid):
            break
        time.sleep(0.1)
    if session_members(process.pid):
        signal_session(process.pid, signal.SIGKILL, actions)
    try:
        code = process.wait(timeout=5)
        reaped = True
    except subprocess.TimeoutExpired:
        # D 状态可能不响应 KILL；明确 FAIL，不作无限 wait 或解决成功的承诺。
        code, reaped = None, False
    until = time.monotonic() + 2
    while session_members(process.pid) and time.monotonic() < until:
        time.sleep(0.1)
    return code, reaped


def run_command(root, evidence, env, label, command, timeout, expected_tests=None):
    log = evidence / (label + ".log")
    started, start = utc(), time.monotonic_ns()
    process, code, error = None, None, None
    timed_out, reaped, actions, residual_before = False, False, [], []
    print(json.dumps({"label": label, "command": command, "started_utc": started}), flush=True)
    with log.open("xb") as output:
        try:
            process = subprocess.Popen(command, cwd=root, env=env, stdout=output,
                                       stderr=subprocess.STDOUT, start_new_session=True)
            deadline = start + timeout * 1_000_000_000
            while code is None and INTERRUPTED is None:
                remaining = (deadline - time.monotonic_ns()) / 1e9
                if remaining <= 0:
                    timed_out = True
                    break
                try:
                    code = process.wait(timeout=min(0.5, remaining))
                    reaped = True
                except subprocess.TimeoutExpired:
                    pass
            residual_before = session_members(process.pid)
            if timed_out or INTERRUPTED is not None or residual_before:
                code, reaped = stop_session(process, actions)
        except Exception as caught:
            error = f"{type(caught).__name__}: {caught}"
            if process is not None:
                code, reaped = stop_session(process, actions)
    residual_after = session_members(process.pid) if process else []
    summary = None
    if expected_tests is not None:
        text = log.read_text(errors="replace")
        summaries = re.findall(r"test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored;", text)
        summary = [tuple(map(int, item)) for item in summaries]
        if summary != [expected_tests]:
            error = f"实际测试计数不匹配：expected={expected_tests}, actual={summary}"
    passed = (code == 0 and reaped and not timed_out and INTERRUPTED is None
              and not error and not residual_before and not residual_after)
    receipt = {
        "label": label, "command": command, "cwd": str(root),
        "pid": process.pid if process else None, "session_id": process.pid if process else None,
        "wait_returncode": code, "reaped": reaped, "reaped_scope": "仅 Popen 直接 child 的实际 wait",
        "started_utc": started, "finished_utc": utc(), "elapsed_ns": time.monotonic_ns() - start,
        "timeout_seconds": timeout, "timed_out": timed_out, "interrupted_signal": INTERRUPTED,
        "status": "PASS" if passed else "FAIL", "error": error, "test_summary": summary,
        "log": str(log), "log_sha256": sha(log), "log_bytes": log.stat().st_size,
        "cleanup_signals": actions, "session_residual_before_cleanup": residual_before,
        "session_residual_after_cleanup": residual_after,
    }
    save(evidence / (label + ".json"), receipt)
    print(json.dumps(receipt, ensure_ascii=False), flush=True)
    if not passed:
        raise RuntimeError(f"检查失败：{label}；原始回执已保存")
    return receipt


def cargo_artifact(evidence, receipt, target, name, is_test, binding_name=None):
    matches = []
    for line in Path(receipt["log"]).read_text(errors="replace").splitlines():
        try:
            message = json.loads(line)
        except json.JSONDecodeError:
            continue
        if (message.get("reason") == "compiler-artifact" and message.get("executable")
                and message["target"]["name"] == name
                and message["profile"]["test"] == is_test):
            matches.append(message)
    if len(matches) != 1:
        raise RuntimeError(f"Cargo 未给出唯一真实 executable：{name}, matches={len(matches)}")
    artifact = matches[0]
    executable = Path(artifact["executable"]).resolve(strict=True)
    executable.relative_to(target)
    if artifact["profile"]["opt_level"] != "3" or not os.access(executable, os.X_OK):
        raise RuntimeError("实际 executable 不是预期优化可执行产物")
    save(evidence / ((binding_name or receipt["label"] + "_artifact") + ".json"), {
        "build_receipt": receipt["label"] + ".json", "cargo_artifact": artifact,
        "path": str(executable), "sha256": sha(executable), "bytes": executable.stat().st_size,
    })
    return executable


def scan_paths(roots):
    ancestors, current = {os.getpid()}, os.getppid()
    while current not in ancestors and current > 0:
        ancestors.add(current)
        entry = process_entry(current)
        current = entry["ppid"] if entry else 0
    matches = []
    for entry in processes():
        if entry["pid"] in ancestors:
            continue
        directory = Path("/proc") / str(entry["pid"])
        try:
            args = (directory / "cmdline").read_bytes().decode(errors="replace").split("\0")
        except OSError:
            args = []
        for field in ("cwd", "exe"):
            try:
                entry[field] = str((directory / field).readlink())
            except OSError:
                entry[field] = None
        values = args + [entry.get("cwd") or "", entry.get("exe") or ""]
        if any(value == str(root) or str(root) + "/" in value for root in roots for value in values):
            entry["argv"] = args
            matches.append(entry)
    return {"utc": utc(), "roots": [str(root) for root in roots],
            "excluded_self_and_ancestors": sorted(ancestors), "matches": matches,
            "scope": "只读核本轮路径相关进程；空扫描不是逐后代 wait 证明，不据此杀其他 session"}


def clean_environment(args, artifacts):
    env = os.environ.copy()
    exact = {"RUSTFLAGS", "RUSTDOCFLAGS", "CARGO_ENCODED_RUSTFLAGS", "CARGO_ENCODED_RUSTDOCFLAGS",
             "RUSTC", "RUSTDOC", "RUSTC_BOOTSTRAP", "RUST_TEST_THREADS", "LD_PRELOAD"}
    removed = []
    for key in list(env):
        if key in exact or key.startswith(("ROBOT_", "CARGO_PROFILE_", "CARGO_TARGET_", "CARGO_BUILD_")):
            removed.append(key)
            del env[key]
    overrides = {"RUSTUP_TOOLCHAIN": args.toolchain, "RUSTC_WRAPPER": "",
                 "RUSTC_WORKSPACE_WRAPPER": "", "CARGO_TARGET_DIR": str(args.target),
                 "CARGO_BUILD_JOBS": str(args.jobs), "ROBOT_VIZ_TEST_ARTIFACTS": str(artifacts),
                 "NO_COLOR": "1", "CARGO_TERM_COLOR": "never"}
    env.update(overrides)
    return env, {"removed_keys": sorted(removed), "overrides": overrides}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--evidence", type=Path, required=True)
    parser.add_argument("--target", type=Path, required=True)
    parser.add_argument("--toolchain", default="nightly")
    parser.add_argument("--jobs", type=int, default=2)
    args = parser.parse_args()
    if platform.system() != "Linux" or platform.machine() not in ("aarch64", "arm64"):
        parser.error("本辅具仅允许在已确认身份的 Linux ARM64 隔离源码目录使用")
    if args.jobs < 1:
        parser.error("jobs 必须为正数")
    root, args.evidence, args.target = Path.cwd().resolve(), args.evidence.resolve(), args.target.resolve()
    roots = (root, args.evidence, args.target)
    if any(a == b or a in b.parents for a in roots for b in roots if a is not b):
        parser.error("源码、证据、Cargo target 必须为互不包含的独立目录")
    args.evidence.mkdir(parents=True, exist_ok=True)
    if any(args.evidence.iterdir()):
        parser.error("拒绝覆盖非空证据目录")
    args.target.mkdir(parents=True, exist_ok=True)
    manifest_sha = sha(root / "source_manifest.json")
    env, environment = clean_environment(args, args.evidence / "artifacts")
    save(args.evidence / "environment.json", environment)
    report = {"started_utc": utc(), "status": "FAIL", "cwd": str(root), "target": str(args.target),
              "toolchain": args.toolchain,
              "manifest_sha256": manifest_sha, "commands": [], "error": None,
              "script_sha256": sha(Path(__file__).resolve()), "hardware_actions": False}
    cargo = ["cargo", "+" + args.toolchain]

    def execute(label, command, timeout, expected=None):
        report["commands"].append(label + ".json")
        receipt = run_command(root, args.evidence, env, label, command, timeout, expected)
        return receipt

    try:
        before = verify_source(root, manifest_sha)
        save(args.evidence / "source_before.json", before)
        scan = scan_paths(roots)
        save(args.evidence / "processes_before.json", scan)
        if not before["source_matches"] or scan["matches"]:
            raise RuntimeError("前置源码或本轮路径进程边界不干净；未启动 Cargo")
        execute("01_fmt", cargo + ["fmt", "--all"], 600)
        after_fmt = verify_source(root, manifest_sha)
        save(args.evidence / "source_after_fmt.json", after_fmt)
        if not after_fmt["source_matches"]:
            raise RuntimeError("实际 fmt 改变了清单源码")
        execute("02_clippy", cargo + ["clippy", "--locked", "--all", "--all-targets", "--", "-D", "warnings"], 7200)
        for label, package, selector, name, extra, expected in [
            ("03_viz_units", "robot-viz", ["--lib"], "robot_viz", [], (17, 0, 0)),
            ("04_observer_mirror", "robot-transport", ["--test", "observer_mirror"], "observer_mirror", [], (9, 0, 1)),
            ("05_observer_roundtrip", "robot-viz", ["--test", "observer_roundtrip"], "observer_roundtrip", ["--ignored"], (6, 0, 0)),
        ]:
            built = execute(label + "_build", cargo + ["test", "--locked", "--profile", "release-tools", "-p", package]
                            + selector + ["--no-run", "--message-format=json"], 7200)
            executable = cargo_artifact(args.evidence, built, args.target, name, True)
            if label == "05_observer_roundtrip":
                # no-run 同时构建夹具真正调用的桥；不能用后面的独立 build 冒充其身份。
                bridge = cargo_artifact(args.evidence, built, args.target, "robot-viz", False,
                                        "05_integration_bridge_before")
                integration = {"path": str(bridge), "sha256": sha(bridge),
                               "bytes": bridge.stat().st_size, "profile": "release-tools",
                               "cargo_binding": "05_integration_bridge_before.json"}
                report["integration_bridge"] = integration
                try:
                    execute(label, [str(executable)] + extra + ["--test-threads=1", "--nocapture"], 600, expected)
                finally:
                    # 测试失败也保留身份后验；哈希变化不能作为同一桥的验收结果。
                    checked = {"path": str(bridge), "before_sha256": integration["sha256"],
                               "checked_utc": utc(), "unchanged": False}
                    try:
                        checked["after_sha256"] = sha(bridge)
                        checked["unchanged"] = checked["after_sha256"] == integration["sha256"]
                    except OSError as error:
                        checked["error"] = str(error)
                    save(args.evidence / "05_integration_bridge_after.json", checked)
                    if not checked["unchanged"]:
                        raise RuntimeError("六项集成运行前后 bridge 产物身份不一致")
            else:
                execute(label, [str(executable)] + extra + ["--test-threads=1", "--nocapture"], 600, expected)
        built = execute("06_viz_build", cargo + ["build", "--locked", "--profile", "release-tools", "-p", "robot-viz", "--message-format=json"], 7200)
        binary = cargo_artifact(args.evidence, built, args.target, "robot-viz", False)
        with binary.open("rb") as stream:
            header = stream.read(20)
        if header[:6] != b"\x7fELF\x02\x01" or int.from_bytes(header[18:20], "little") != 183:
            raise RuntimeError("实际优化二进制不是原生 ELF64 little-endian AArch64")
        report["binary"] = {"path": str(binary), "sha256": sha(binary), "bytes": binary.stat().st_size,
                            "format": "ELF64 little-endian AArch64", "profile": "release-tools"}
        report["standalone_bridge"] = report["binary"]
        comparison = {"integration_bridge": report["integration_bridge"],
                      "standalone_bridge": report["standalone_bridge"],
                      "same_sha256": report["integration_bridge"]["sha256"] == report["binary"]["sha256"],
                      "scope": "两次 Cargo 构建分别绑定；不同 SHA 时六项测试仅证明 integration_bridge"}
        save(args.evidence / "06_bridge_identity_comparison.json", comparison)
        report["bridge_identities_match"] = comparison["same_sha256"]
        execute("07_viz_help", [str(binary), "--help"], 30)
        report["status"] = "PASS"
    except Exception as error:
        report["error"] = f"{type(error).__name__}: {error}"
    finally:
        try:
            after = verify_source(root, manifest_sha)
            save(args.evidence / "source_after.json", after)
            scan = scan_paths(roots)
            save(args.evidence / "processes_after.json", scan)
            if not after["source_matches"] or scan["matches"]:
                report["status"] = "FAIL"
                report["final_boundary_error"] = "源码变化或本轮路径仍有相关进程"
        except Exception as error:
            report["status"] = "FAIL"
            report["final_boundary_error"] = str(error)
        report["finished_utc"] = utc()
        report["interrupted_signal"] = INTERRUPTED
        if INTERRUPTED is not None:
            report["status"] = "FAIL"
        save(args.evidence / "run_report.json", report)
    print(json.dumps(report, ensure_ascii=False), flush=True)
    return 0 if report["status"] == "PASS" else 1


if __name__ == "__main__":
    def interrupted(signum, _frame):
        global INTERRUPTED
        INTERRUPTED = signal.Signals(signum).name

    signal.signal(signal.SIGINT, interrupted)
    signal.signal(signal.SIGTERM, interrupted)
    raise SystemExit(main())
