#!/usr/bin/env python3
"""复用已编译六项夹具验收最终 standalone 桥；不运行 Cargo，不覆盖旧证据。"""

import argparse
import importlib.util
import json
import os
from pathlib import Path
import signal
import sys
from types import SimpleNamespace


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--base", type=Path, required=True)
    args = parser.parse_args()
    base = args.base.resolve(strict=True)
    source, target, previous = base / "source", base / "build", base / "evidence"
    if Path.cwd().resolve() != source:
        parser.error("必须从本轮隔离 source 目录执行")
    evidence = previous / "standalone_final"
    evidence.mkdir(exist_ok=False)
    with (evidence / "final_standalone.py").open("xb") as output:
        output.write(Path(__file__).read_bytes())
    # 直接加载本轮已验收 runner；禁写 __pycache，不引入第二套监督逻辑。
    sys.dont_write_bytecode = True
    spec = importlib.util.spec_from_file_location("native_runner", base / "run_native.py")
    runner = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(runner)

    def interrupted(signum, _frame):
        runner.INTERRUPTED = signal.Signals(signum).name

    signal.signal(signal.SIGINT, interrupted)
    signal.signal(signal.SIGTERM, interrupted)
    summary = {"started_utc": runner.utc(), "status": "FAIL", "error": None,
               "scope": "原 05 test executable 补验最终 standalone_bridge；不运行 Cargo",
               "script_sha256": runner.sha(Path(__file__).resolve()), "hardware_actions": False}
    expected_manifest = None
    bound_paths = {}
    before = None
    roots = (source, target, previous)

    def read(name):
        return json.loads((previous / name).read_text())

    def bound_path(name, raw):
        path = Path(raw)
        if path.is_symlink():
            raise RuntimeError(f"{name} 不能是符号链接")
        path = path.resolve(strict=True)
        path.relative_to(target)
        if not path.is_file() or not os.access(path, os.X_OK):
            raise RuntimeError(f"{name} 不是实际可执行文件")
        return path

    def identities():
        return {name: {"path": str(path), "sha256": runner.sha(path), "bytes": path.stat().st_size}
                for name, path in bound_paths.items()}

    try:
        original = read("run_report.json")
        if original.get("status") != "PASS" or not original.get("finished_utc"):
            raise RuntimeError("原生 pipeline 尚未真实 PASS 并结束")
        if runner.sha(base / "run_native.py") != original["script_sha256"]:
            raise RuntimeError("复用 runner 与原 pipeline 的脚本身份不一致")
        expected_manifest = original["manifest_sha256"]
        test_binding = read("05_observer_roundtrip_build_artifact.json")
        bridge_binding = read("05_integration_bridge_before.json")
        bridge_after = read("05_integration_bridge_after.json")
        standalone = original["standalone_bridge"]
        if (test_binding["cargo_artifact"]["target"]["name"] != "observer_roundtrip"
                or test_binding["cargo_artifact"]["profile"]["test"] is not True
                or bridge_binding["cargo_artifact"]["target"]["name"] != "robot-viz"
                or bridge_binding["cargo_artifact"]["profile"]["test"] is not False
                or bridge_after.get("unchanged") is not True):
            raise RuntimeError("原 05 Cargo 产物及运行后验绑定不完整")
        test_exe = bound_path("test_executable", test_binding["path"])
        bridge = bound_path("standalone_bridge", standalone["path"])
        if (bridge != bound_path("原 05 bridge", bridge_binding["path"])
                or bridge != bound_path("原 05 Cargo bridge", bridge_binding["cargo_artifact"]["executable"])
                or test_exe != bound_path("原 05 Cargo test", test_binding["cargo_artifact"]["executable"])):
            raise RuntimeError("最终桥/夹具路径与原 05 编译绑定不一致")
        bound_paths = {"test_executable": test_exe, "standalone_bridge": bridge}
        before = identities()
        runner.save(evidence / "identities_before.json", before)
        if (before["test_executable"]["sha256"] != test_binding["sha256"]
                or before["standalone_bridge"]["sha256"] != standalone["sha256"]):
            raise RuntimeError("当前 executable SHA 与指定原夹具/最终 standalone 身份不一致")
        summary["expected_standalone_sha256"] = standalone["sha256"]
        summary["original_integration_sha256"] = bridge_binding["sha256"]
        checked = runner.verify_source(source, expected_manifest)
        runner.save(evidence / "source_before.json", checked)
        processes = runner.scan_paths(roots)
        runner.save(evidence / "processes_before.json", processes)
        if not checked["source_matches"] or processes["matches"]:
            raise RuntimeError("补验前源码或本轮进程边界不干净")
        options = SimpleNamespace(toolchain="nightly", target=target, jobs=2)
        env, environment = runner.clean_environment(options, evidence / "artifacts")
        runner.save(evidence / "environment.json", environment)
        if runner.INTERRUPTED is not None:
            raise RuntimeError("收到终止信号，不启动夹具")
        receipt = runner.run_command(
            source, evidence, env, "standalone_roundtrip",
            [str(test_exe), "--ignored", "--test-threads=1", "--nocapture"], 600, (6, 0, 0))
        summary["test_receipt"] = "standalone_roundtrip.json"
        summary["test_pid"] = receipt["pid"]
        summary["reaped"] = receipt["reaped"]
        summary["status"] = "PASS"
    except Exception as error:
        summary["error"] = f"{type(error).__name__}: {error}"
    finally:
        # 失败同样写终态证据；两份 executable 都必须保持同一 SHA。
        errors = []
        try:
            after = identities()
            runner.save(evidence / "identities_after.json", after)
            if before is None or after != before:
                errors.append("桥或夹具运行前后身份变化/前置身份缺失")
        except Exception as error:
            errors.append(f"产物后验失败：{error}")
        try:
            checked = runner.verify_source(source, expected_manifest)
            runner.save(evidence / "source_after.json", checked)
            if not checked["source_matches"]:
                errors.append("源码后验不匹配")
            processes = runner.scan_paths(roots)
            runner.save(evidence / "processes_after.json", processes)
            if processes["matches"]:
                errors.append("本轮路径仍有相关进程")
        except Exception as error:
            errors.append(f"源码/进程后验失败：{error}")
        summary["final_boundary_errors"] = errors
        summary["interrupted_signal"] = runner.INTERRUPTED
        if errors or runner.INTERRUPTED is not None:
            summary["status"] = "FAIL"
        summary["finished_utc"] = runner.utc()
        runner.save(evidence / "summary.json", summary)
    print(json.dumps(summary, ensure_ascii=False), flush=True)
    return 0 if summary["status"] == "PASS" else 1


if __name__ == "__main__":
    raise SystemExit(main())
