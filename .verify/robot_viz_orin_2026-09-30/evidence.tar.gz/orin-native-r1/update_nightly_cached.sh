set -eu
export PATH=/home/loosqk/.cargo/bin:/home/loosqk/.local/bin:$PATH
cd /home/loosqk/robot-checks/viz-orin-a6957cc-20260930-r1
cd toolchain-evidence
uv run --no-project python gate.py latest_nightly_cached_update -- timeout --signal=TERM --kill-after=30s 1800s rustup update nightly --no-self-update
uv run --no-project python gate.py latest_nightly_cached_rustc -- rustc +nightly -Vv
uv run --no-project python gate.py latest_nightly_cached_cargo -- cargo +nightly -V
uv run --no-project python gate.py latest_nightly_cached_clippy -- cargo +nightly clippy -V
rustup default
