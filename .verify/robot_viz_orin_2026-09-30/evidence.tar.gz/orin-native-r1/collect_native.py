#!/usr/bin/env python3
"""只读采集已结束的本轮证据，向 stdout 流式输出 tar.gz；不启动任何检查。"""

import argparse
import datetime
import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import stat
import sys
import tarfile
import io


def utc():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()


def safe_path(base, name):
    relative = PurePosixPath(name)
    if relative.is_absolute() or not relative.parts or any(part in (".", "..") for part in relative.parts):
        raise ValueError(f"拒绝非法归档路径：{name!r}")
    current = base
    for part in relative.parts:
        current = current / part
        if current.is_symlink():
            raise ValueError(f"拒绝符号链接：{relative}")
    return current


def regular_files(base, name, suffixes=None):
    path = safe_path(base, name)
    if not path.exists():
        return []
    mode = path.lstat().st_mode
    if stat.S_ISREG(mode):
        return [name] if suffixes is None or path.suffix in suffixes else []
    if not stat.S_ISDIR(mode):
        raise ValueError(f"拒绝非普通文件：{name}")
    result = []
    for child in sorted(path.iterdir()):
        result.extend(regular_files(base, f"{name}/{child.name}", suffixes))
    return result


def fingerprint(info):
    return (info.st_dev, info.st_ino, info.st_size, info.st_mtime_ns)


def open_regular(path):
    # 不跟随最终分量的链接；上层目录也由 safe_path 逐项核对。
    stream = os.fdopen(os.open(path, os.O_RDONLY | os.O_NOFOLLOW), "rb")
    if not stat.S_ISREG(os.fstat(stream.fileno()).st_mode):
        stream.close()
        raise ValueError(f"采集时路径不再是普通文件：{path}")
    return stream


class HashReader:
    def __init__(self, stream):
        self.stream = stream
        self.digest = hashlib.sha256()
        self.bytes = 0

    def read(self, size):
        data = self.stream.read(size)
        self.digest.update(data)
        self.bytes += len(data)
        return data


def add_file(archive, base, name):
    path = safe_path(base, name)
    with open_regular(path) as stream:
        before = os.fstat(stream.fileno())
        info = tarfile.TarInfo(name)
        info.size = before.st_size
        info.mode = stat.S_IMODE(before.st_mode) & 0o777
        info.mtime = int(before.st_mtime)
        reader = HashReader(stream)
        archive.addfile(info, reader)
        if reader.bytes != before.st_size or fingerprint(before) != fingerprint(os.fstat(stream.fileno())):
            raise RuntimeError(f"采集期间文件发生变化：{name}")
        return {"path": name, "bytes": reader.bytes, "sha256": reader.digest.hexdigest()}


def add_json(archive, name, value):
    data = (json.dumps(value, ensure_ascii=False, indent=2) + "\n").encode()
    info = tarfile.TarInfo(name)
    info.size, info.mode = len(data), 0o644
    archive.addfile(info, io.BytesIO(data))
    return {"path": name, "bytes": len(data), "sha256": hashlib.sha256(data).hexdigest()}


def binary_readback(base):
    name = "build/release-tools/robot-viz"
    path = safe_path(base, name)
    result = {"path": name, "readback_utc": utc(), "included_binary_body": False, "exists": path.exists()}
    if not path.exists():
        return result
    with open_regular(path) as stream:
        before = os.fstat(stream.fileno())
        reader = HashReader(stream)
        header = reader.read(20)
        while reader.read(1024 * 1024):
            pass
        if fingerprint(before) != fingerprint(os.fstat(stream.fileno())):
            raise RuntimeError("优化二进制在读回期间发生变化")
        elf = len(header) == 20 and header[:4] == b"\x7fELF"
        endian = {1: "little", 2: "big"}.get(header[5]) if elf else None
        result.update({"sha256": reader.digest.hexdigest(), "bytes": reader.bytes,
                       "mode": oct(stat.S_IMODE(before.st_mode)), "header_hex": header.hex(),
                       "elf_magic": elf, "elf_class": header[4] if elf else None,
                       "elf_endian": endian,
                       "elf_machine": int.from_bytes(header[18:20], endian) if endian else None,
                       "native_aarch64_elf64_le": elf and header[4:6] == b"\x02\x01"
                       and int.from_bytes(header[18:20], "little") == 183})
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--base", type=Path, required=True)
    args = parser.parse_args()
    if args.base.is_symlink():
        parser.error("BASE 不得是符号链接")
    base = args.base.resolve(strict=True)
    report_path = safe_path(base, "evidence/run_report.json")
    with open_regular(report_path) as stream:
        report = json.load(stream)
    if report.get("status") not in ("PASS", "FAIL") or not report.get("finished_utc"):
        raise RuntimeError("run_report.json 尚未结束；拒绝收集中途证据")
    names = regular_files(base, "evidence")
    names += regular_files(base, "toolchain-evidence", {".json", ".log", ".py"})
    for name in ("cargo_cache_verified.json", "toolchain_cache_seeded.json", "nightly-before-version.txt",
                 "run_native.py", "source/source_manifest.json"):
        names += regular_files(base, name)
    names = sorted(set(names))
    identity = binary_readback(base)
    index = {"collected_utc": utc(), "run_status": report["status"],
             "run_finished_utc": report["finished_utc"], "files": [],
             "scope": "逐项 SHA 对应实际归档字节；index.json 不索引自身。仅收既有证据，未复跑验收或正式状态检查。"}
    # 手工加入普通文件项，不使用递归 add，不允许链接、绝对路径或 ../ 条目。
    # 输出出错将以非零退出，接收端必须保留失败状态，不能仅凭部分压缩包存在判成功。
    with tarfile.open(fileobj=sys.stdout.buffer, mode="w|gz", format=tarfile.PAX_FORMAT) as archive:
        for name in names:
            index["files"].append(add_file(archive, base, name))
        index["files"].append(add_json(archive, "optimized_binary_readback.json", identity))
        add_json(archive, "index.json", index)
    print(f"已采集 {len(index['files'])} 项；run_status={report['status']}；二进制本体留在 Orin", file=sys.stderr)


if __name__ == "__main__":
    main()
