set -eu
cd /home/loosqk/robot-checks/viz-orin-a6957cc-20260930-r1
test ! -e nightly-before
cp -a --reflink=auto /home/loosqk/.rustup/toolchains/nightly-aarch64-unknown-linux-gnu nightly-before
/home/loosqk/.cargo/bin/rustup run nightly rustc -Vv > nightly-before-version.txt
sha256sum nightly-before/bin/rustc nightly-before/bin/cargo
cmp /home/loosqk/.rustup/toolchains/nightly-aarch64-unknown-linux-gnu/bin/rustc nightly-before/bin/rustc
cmp /home/loosqk/.rustup/toolchains/nightly-aarch64-unknown-linux-gnu/bin/cargo nightly-before/bin/cargo
ps -p 383121,383133 -o pid,ppid,pgid,sid,etimes,stat,args || true
