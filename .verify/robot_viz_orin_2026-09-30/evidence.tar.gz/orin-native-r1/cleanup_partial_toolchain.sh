set -eu
export PATH=/home/loosqk/.cargo/bin:/home/loosqk/.local/bin:$PATH
rustup default
rustup toolchain list
rustup toolchain uninstall nightly-2026-09-29
rustup default
rustup toolchain list
rustc +nightly -Vv
