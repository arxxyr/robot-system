set -eu
cd /home/loosqk/robot-checks/viz-orin-a6957cc-20260930-r1
printf '%s\n' 'cfb3f8908fc436f1cc5faa1572cbea4f362ab9c19985202dc36a723587eba12c  source.tar.gz' | sha256sum -c -
test ! -e source/source_manifest.json
tar xzf source.tar.gz -C source
cd source
/home/loosqk/.local/bin/uv run --no-project python verify_source.py
ps -p 383121,383133 -o pid,ppid,pgid,sid,etimes,stat,args || true
