"""冻结本次验收原件；大体积可重下载缓存仅记录校验和。"""
import hashlib,io,json,tarfile
from pathlib import Path
root=Path(__file__).resolve().parent
out=root.parents[2]/'.verify'/'robot_viz_orin_2026-09-30'
# root 位于 repo/target/robot_viz_20260929/orin-native-r1。
assert (out.parent.parent/'Cargo.toml').is_file()
out.mkdir(exist_ok=True)
archive=out/'evidence.tar.gz'
assert not archive.exists()
exclude={'cargo-cache.tar.gz','summary.json'}
files=[p for p in root.iterdir() if p.is_file() and p.name not in exclude]
files.extend(p for p in (root/'toolchain-cache').iterdir() if p.suffix=='.txt')
rows=[]
with tarfile.open(archive,'w:gz') as tar:
    for path in sorted(files):
        assert not path.is_symlink()
        data=path.read_bytes(); name=str(path.relative_to(root))
        item=tarfile.TarInfo('orin-native-r1/'+name); item.size=len(data); item.mode=0o644
        tar.addfile(item,io.BytesIO(data))
        rows.append({'path':item.name,'sha256':hashlib.sha256(data).hexdigest(),'bytes':len(data)})
    index={'scope':'原始本机回执、源码快照与远端原件包；缓存本体和二进制本体在校验记录所指位置保留','files':rows}
    data=(json.dumps(index,ensure_ascii=False,indent=2)+'\n').encode()
    item=tarfile.TarInfo('index.json'); item.size=len(data); item.mode=0o644
    tar.addfile(item,io.BytesIO(data))
with tarfile.open(archive,'r:gz') as tar:
    assert len(tar.getmembers())==len(rows)+1
    for row in rows:
        data=tar.extractfile(row['path']).read()
        assert len(data)==row['bytes'] and hashlib.sha256(data).hexdigest()==row['sha256']
result={'archive':'evidence.tar.gz','sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'bytes':archive.stat().st_size,'indexed_files':len(rows),'verified':True,'exclusions':['cargo-cache.tar.gz','toolchain-cache component bodies','remote/ extracted duplicate','Orin build and toolchain backup bodies'],'files':rows}
(out/'archive.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({k:v for k,v in result.items() if k!='files'},ensure_ascii=False))
