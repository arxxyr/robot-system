set -eu
cd /home/loosqk/robot-checks/viz-orin-a6957cc-20260930-r1
/home/loosqk/.local/bin/uv run --no-project python - <<'INNER'
import hashlib,json,tarfile
from pathlib import Path
root=Path.cwd()
index=root/'cargo-cache-index.json'
assert hashlib.sha256(index.read_bytes()).hexdigest()=='23850705cddf31cf13919093992b583968f1696b3102a6c50a57e44bff2d40fe'
data=json.loads(index.read_text())
archive=root/'cargo-cache.tar.gz'
assert hashlib.sha256(archive.read_bytes()).hexdigest()==data['archive']['sha256']
assert archive.stat().st_size==data['archive']['bytes']
assert hashlib.sha256((root/'source/Cargo.lock').read_bytes()).hexdigest()==data['cargo_lock_sha256']
rows={r['path']:r for r in data['files']}
dest=root/'cargo-home'
dest.mkdir(exist_ok=False)
with tarfile.open(archive,'r:gz') as tar:
    members=tar.getmembers()
    names=[m.name for m in members]
    assert len(names)==len(set(names))==len(rows) and set(names)==set(rows)
    for member in members:
        relative=Path(member.name)
        assert member.isfile() and not relative.is_absolute() and '..' not in relative.parts
        content=tar.extractfile(member).read()
        row=rows[member.name]
        assert len(content)==row['bytes'] and hashlib.sha256(content).hexdigest()==row['sha256'],member.name
        path=dest/relative
        path.parent.mkdir(parents=True,exist_ok=True)
        with path.open('xb') as f: f.write(content)
    for name,row in rows.items():
        path=dest/name
        assert path.stat().st_size==row['bytes'] and hashlib.sha256(path.read_bytes()).hexdigest()==row['sha256'],name
receipt={'status':'PASS','files':len(rows),'cargo_home':str(dest),'archive_sha256':data['archive']['sha256'],'cargo_lock_sha256':data['cargo_lock_sha256'],'readback_all_matched':True,'global_cache_modified':False,'cargo_executed':False}
(root/'cargo_cache_verified.json').write_text(json.dumps(receipt,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(receipt,ensure_ascii=False))
INNER
