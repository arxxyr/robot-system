#!/bin/sh
# 只复跑已编译的六项夹具，不触发 Cargo、设备或正式服务。
set -eu
BASE=/home/loosqk/robot-checks/viz-orin-a6957cc-20260930-r1
export PATH=/home/loosqk/.cargo/bin:/home/loosqk/.local/bin:$PATH
export CARGO_HOME="$BASE/cargo-home"
export CARGO_NET_OFFLINE=true
cd "$BASE"
printf '%s\n' '0ddf53d5c9a507f374771e5f77717899931b37dc199371d6205f22d06a933287  final_standalone.py' | sha256sum -c -
cd "$BASE/source"
exec uv run --no-project python ../final_standalone.py --base "$BASE"
