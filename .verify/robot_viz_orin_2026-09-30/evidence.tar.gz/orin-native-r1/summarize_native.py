"""从已结束回执派生验收摘要，保留不同桥身份与历史失败边界。"""
import hashlib,json,shutil
from pathlib import Path
root=Path(__file__).resolve().parent
repo=root.parents[2]
out=repo/'.verify/robot_viz_orin_2026-09-30'
out.mkdir(exist_ok=True)
def read(relative): return json.loads((root/relative).read_text())
def digest(path): return hashlib.sha256(path.read_bytes()).hexdigest()
def bound(path): return {'path':str(path.relative_to(root)), 'sha256':digest(path), 'bytes':path.stat().st_size}
report=read('remote/evidence/run_report.json')
final=read('remote/evidence/standalone_final/summary.json')
assert report['status']==final['status']=='PASS'
commands=[]
for name in report['commands']:
    receipt=read('remote/evidence/'+name)
    log=root/'remote/evidence'/Path(receipt['log']).name
    assert receipt['status']=='PASS' and receipt['wait_returncode']==0 and receipt['reaped'] and not receipt['timed_out']
    assert receipt['log_sha256']==digest(log) and receipt['log_bytes']==log.stat().st_size
    commands.append({'receipt':'remote/evidence/'+name, **{k:receipt[k] for k in ['label','command','test_summary','wait_returncode','reaped','elapsed_ns','log_sha256']}})
last=read('remote/evidence/standalone_final/standalone_roundtrip.json')
assert last['status']=='PASS' and last['test_summary']==[[6,0,0]]
assert last['log_sha256']==digest(root/'remote/evidence/standalone_final/standalone_roundtrip.log')
identities=read('remote/evidence/standalone_final/identities_before.json')
assert identities==read('remote/evidence/standalone_final/identities_after.json')
assert identities['standalone_bridge']['sha256']==report['standalone_bridge']['sha256']
assert read('remote/optimized_binary_readback.json')['sha256']==report['standalone_bridge']['sha256']
for name in ['source_before.json','source_after_fmt.json','source_after.json','standalone_final/source_before.json','standalone_final/source_after.json']:
    row=read('remote/evidence/'+name)
    assert row['source_matches'] and row['files']==620 and not row['allowed_claude_drift']
for name in ['processes_before.json','processes_after.json','standalone_final/processes_before.json','standalone_final/processes_after.json']:
    assert not read('remote/evidence/'+name)['matches']
manifest=read('source_manifest.json')
local_differences=[]
for row in manifest['files']:
    path=repo/row['path']; actual={'link':str(path.readlink())} if path.is_symlink() else {'sha256':digest(path),'bytes':path.stat().st_size}
    expected={k:v for k,v in row.items() if k!='path'}
    if actual!=expected: local_differences.append({'path':row['path'],'before':expected,'after':actual})
assert all(row['path']=='CLAUDE.md' for row in local_differences)
review=read('native_independent_review.json')
assert review['status']=='PASS',review
formal=read('formal_state_comparison.json'); assert formal['status']=='PASS'
rrd_check=read('final_rrd_verify.json')
assert rrd_check['wait_returncode']==0 and rrd_check['reaped'] and not rrd_check['timed_out']
assert rrd_check['log_sha256']==digest(root/'final_rrd_verify.log')
assert '1 file verified without error.' in (root/'final_rrd_verify.log').read_text()
normal_dirs=list((root/'remote/evidence/standalone_final/artifacts').glob('viz_all_*'))
assert len(normal_dirs)==1
rrd=normal_dirs[0]/'observation.rrd'; normal=json.loads((normal_dirs[0]/'report.json').read_text())
assert normal['frames_logged']==1000 and len(normal['per_schema'])==10 and normal['publisher_instances_seen']==11
assert normal['frames_rejected']==normal['observer_dropped']==normal['observer_sequence_gaps']==0
shutil.copyfile(rrd,out/'example.rrd')
result={
 'status':'SOFTWARE_ACCEPTED','date_utc':'2026-09-30','base_commit':manifest['base_commit'],
 'scope':'Orin aarch64 上以最新浮动 nightly 验收独立 Rerun 观测桥；仅软件夹具，不正式安装或触发硬件动作',
 'toolchain':{'channel':'nightly','channel_date_utc':'2026-09-30','rustc':'1.101.0-nightly','commit':'5c543b0b8c73c7b72bc8284ced4fb22ead15734d','host':'aarch64-unknown-linux-gnu','manifest':bound(root/'nightly-channel.toml'),'readback':'remote_snapshot_final.log','backup':'/home/loosqk/robot-checks/viz-orin-a6957cc-20260930-r1/nightly-before','policy':'默认浮动最新 nightly；本轮记录实际日期与提交仅用于溯源，没有 pin 项目'},
 'source':{'files':620,'manifest':bound(root/'source_manifest.json'),'archive':bound(root/'source.tar.gz'),'remote_before_after_match':True,'host_document_only_differences':local_differences},
 'gates':commands,'distinct_tests_passed':32,'ignored_child_fixtures':1,
 'standalone_final':{'scope':'不同 Cargo 构建的桥 SHA 不同，另用原测试程序对最终桥复跑同一组6项；不计为6项新增测试','receipt':last,'identities':identities,'original_integration_bridge':report['integration_bridge'],'standalone_bridge':report['standalone_bridge'],'source_and_process_postchecks':'PASS'},
 'recording':{'file':'example.rrd','sha256':digest(rrd),'bytes':rrd.stat().st_size,'original':str(rrd.relative_to(root)),'official_verify':rrd_check,'normal_report':normal,'scope':'1000帧、10类与11实例均为本轮软件夹具；本轮 SIGINT 测试0帧，仅证明生命周期，不复用历史80帧证据'},
 'formal_state':formal,'native_archive':read('native_collect.json'),'independent_review':bound(root/'native_independent_review.json'),
 'preserved_nonpass':[
  {'receipt':'remote_before.json','fact':'首次固定日期工具链探测触发自动下载，90秒外层超时；真实SSH wait255，保留原FAIL'},
  {'receipt':'toolchain_readback.json','fact':'外层exit0但内容为安装缺失错误，不计成功'},
  {'receipt':'update_latest_nightly.json','fact':'首次浮动latest在线更新慢，精确中断自有rustup；实际wait-2，随后校验官方缓存并另次更新通过'},
  {'receipt':'preparation.json','fact':'历史PREPARED_NOT_RUN和日期工具链计划，仅准备，不冒充本轮验收结果'}
 ],
 'boundaries':['本輪未重跑完整 workspace 测试或托管 CI；根 Clippy 全仓通过与17+9+6定向测试分别记账','软件发布者与媒体夹具，不证明机器人实时传感器画面；本轮仅官方文件校验，真实Viewer GUI证据来自9月29日阶段','观测镜像有损；首连接饥饿和多发布者公平性限制保留','原S1并行超时根因、Feetech读早退/过期tick问题未关闭','右H2仍整体FAIL；D15 OPEN；deployable=false；物理电源/支撑状态未由本轮核实','正式源仍ca14f0e，四安装件未变，六正式服务停止；未更新生产发布者','仅本地阶段提交，不push'],
 'evidence':'evidence.tar.gz（外层索引archive.json；原生原件位于orin-native-r1/native_evidence.tar.gz，内含118项索引）',
 'next_step':'按独立部署与现场授权流程验证真实机器人发布者的观测，再继续通信硬件门及D15；当前软件PASS不关闭硬件条件'
}
(out/'summary.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'status':result['status'],'distinct_tests_passed':32,'standalone_final':last['test_summary'],'rrd_sha256':digest(rrd),'rrd_bytes':rrd.stat().st_size,'local_differences':[r['path'] for r in local_differences]},ensure_ascii=False))
