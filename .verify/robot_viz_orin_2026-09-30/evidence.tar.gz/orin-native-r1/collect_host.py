"""拉回终态原生证据并核验每项归档字节；拒绝覆盖既有结果。"""
import datetime,hashlib,json,os,signal,subprocess,tarfile,time
from pathlib import Path
root=Path(__file__).resolve().parent
archive=root/'native_evidence.tar.gz'; err=root/'native_collect.stderr.log'
assert not archive.exists() and not err.exists() and not (root/'remote').exists()
remote="set -eu; cd /home/loosqk/robot-checks/viz-orin-a6957cc-20260930-r1; printf '%s\\n' '1ee63bd3c17493b32c9b205944453d4b852eae69da7c682b8c55153013753212  collect_native.py' | sha256sum -c - >&2; exec /home/loosqk/.local/bin/uv run --no-project python collect_native.py --base /home/loosqk/robot-checks/viz-orin-a6957cc-20260930-r1"
command=['ssh','-o','BatchMode=yes','-o','StrictHostKeyChecking=yes','-o','ConnectTimeout=15','robot',remote]
start=datetime.datetime.now(datetime.timezone.utc).isoformat(); mono=time.monotonic_ns(); timed_out=False
with archive.open('xb') as out,err.open('xb') as errors:
    child=subprocess.Popen(command,stdout=out,stderr=errors,start_new_session=True)
    try: code=child.wait(timeout=180)
    except subprocess.TimeoutExpired:
        timed_out=True; os.killpg(child.pid,signal.SIGTERM)
        try: code=child.wait(timeout=10)
        except subprocess.TimeoutExpired:
            os.killpg(child.pid,signal.SIGKILL); code=child.wait()
receipt={'command':command,'pid':child.pid,'wait_returncode':code,'reaped':True,'timed_out':timed_out,'started_utc':start,'finished_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'elapsed_ns':time.monotonic_ns()-mono,'archive_sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'archive_bytes':archive.stat().st_size,'stderr_sha256':hashlib.sha256(err.read_bytes()).hexdigest(),'verified':False}
try:
    assert code==0 and not timed_out,receipt
    with tarfile.open(archive,'r:gz') as tar:
        index=json.load(tar.extractfile('index.json')); rows=index['files']
        members=tar.getmembers(); names=[m.name for m in members]
        assert len(names)==len(set(names)) and set(names)=={r['path'] for r in rows}|{'index.json'}
        for member in members:
            assert member.isfile() and not Path(member.name).is_absolute() and '..' not in Path(member.name).parts
        for row in rows:
            data=tar.extractfile(row['path']).read()
            assert len(data)==row['bytes'] and hashlib.sha256(data).hexdigest()==row['sha256'],row['path']
        tar.extractall(root/'remote',filter='data')
    receipt.update({'verified':True,'indexed_files':len(rows),'run_status':index['run_status']})
finally:
    (root/'native_collect.json').write_text(json.dumps(receipt,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(receipt,ensure_ascii=False))
