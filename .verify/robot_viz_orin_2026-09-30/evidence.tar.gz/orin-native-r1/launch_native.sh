set -eu
export PATH=/home/loosqk/.cargo/bin:/home/loosqk/.local/bin:$PATH
export CARGO_HOME=/home/loosqk/robot-checks/viz-orin-a6957cc-20260930-r1/cargo-home
export CARGO_NET_OFFLINE=true
export CARGO_REGISTRIES_CRATES_IO_PROTOCOL=sparse
cd /home/loosqk/robot-checks/viz-orin-a6957cc-20260930-r1
printf '%s\n' '6dac61458089673325527fe8d6a0ab557b345ff34d7a0b6a8eb5d838138d403c  run_native.py' | sha256sum -c -
cd source
exec uv run --no-project python ../run_native.py --evidence ../evidence --target ../build --toolchain nightly --jobs 2
