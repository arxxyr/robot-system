"""比较本轮隔离软件验证前后的正式服务与安装件，不推断物理状态。"""
import hashlib,json,re
from pathlib import Path
root=Path(__file__).resolve().parent
head='ca14f0e6cf6df8ecc6baaaa8dff2dddb64abbd0a'
rows={}
for label in ['remote_snapshot_before','remote_snapshot_final']:
    receipt=json.loads((root/(label+'.json')).read_text())
    raw=(root/(label+'.log')).read_bytes()
    assert receipt['wait_returncode']==0 and receipt['reaped'] and not receipt['timed_out']
    assert receipt['log_sha256']==hashlib.sha256(raw).hexdigest() and receipt['log_bytes']==len(raw)
    content=raw.decode(); tail=content.split(head+'\n',1)[1].strip()
    assert tail.startswith('MainPID=0\n')
    assert tail.count('MainPID=0')==6 and tail.count('ActiveState=inactive')==6 and tail.count('SubState=dead')==6
    hashes=re.findall(r'^([a-f0-9]{64})  (/home/loosqk/repo/robot/robot-system/target/release/\S+)$',tail,re.M)
    assert len(hashes)==4
    assert tail.splitlines()[-1].endswith('/robot_rpc_gateway')
    rows[label]={'log_sha256':receipt['log_sha256'],'finished_utc':receipt['finished_utc'],'formal_tail':tail,'installed':dict((p,h) for h,p in hashes)}
assert rows['remote_snapshot_before']['formal_tail']==rows['remote_snapshot_final']['formal_tail']
result={'status':'PASS','formal_repository_head':head,'formal_repository_clean':True,'services_inactive_mainpid_zero':6,'installed_binary_hashes_unchanged':True,'control_processes_found':False,'snapshots':rows,'scope':'只读软件状态；不推断物理电源、断扭、支撑或无人值守安全'}
(root/'formal_state_comparison.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({k:v for k,v in result.items() if k!='snapshots'},ensure_ascii=False))
