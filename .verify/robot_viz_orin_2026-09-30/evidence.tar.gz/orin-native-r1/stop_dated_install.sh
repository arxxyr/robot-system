set -eu
/home/loosqk/.local/bin/uv run --no-project python - <<'INNER'
import json,os,signal,time
from pathlib import Path
pid=383133
p=Path('/proc')/str(pid)
result={'pid':pid,'target':'本轮自动触发的日期工具链补装','signal_sent':False,'direct_child_wait_claim':False}
if p.exists():
    cmd=(p/'cmdline').read_bytes().split(b'\0')
    assert cmd[:3]==[b'rustc',b'+nightly-2026-09-29',b'-Vv'],cmd
    result['observed_cmd']=[x.decode() for x in cmd if x]
    os.kill(pid,signal.SIGTERM)
    result['signal_sent']=True
    end=time.monotonic()+30
    while p.exists() and time.monotonic()<end:
        state=(p/'stat').read_text().split(') ',1)[1].split()[0]
        if state=='Z': break
        time.sleep(.2)
    result['still_present']=p.exists()
    if p.exists():
        result['state']=(p/'stat').read_text().split(') ',1)[1].split()[0]
        assert result['state']=='Z',result
print(json.dumps(result,ensure_ascii=False))
INNER
export PATH=/home/loosqk/.cargo/bin:$PATH
rustup update --help
