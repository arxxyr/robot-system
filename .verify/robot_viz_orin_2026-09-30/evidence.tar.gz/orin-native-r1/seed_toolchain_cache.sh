set -eu
cd /home/loosqk/robot-checks/viz-orin-a6957cc-20260930-r1
/home/loosqk/.local/bin/uv run --no-project python - <<'INNER'
import hashlib,json,os,signal,time
from pathlib import Path
pid=383665
proc=Path('/proc')/str(pid)
result={'target_pid':pid,'purpose':'用已核官方组件缓存恢复本轮 latest nightly 更新','signal_sent':False}
if proc.exists():
    argv=(proc/'cmdline').read_bytes().split(b'\0')
    assert argv[:4]==[b'rustup',b'update',b'nightly',b'--no-self-update'],argv
    os.kill(pid,signal.SIGINT)
    result['signal_sent']=True
    deadline=time.monotonic()+30
    while proc.exists() and time.monotonic()<deadline: time.sleep(.2)
    assert not proc.exists(),'更新进程仍在，不修改其缓存'
rows=[]
for checksum in ['d0803b0d16476484305f330fd53ab73c14c25377858228cb9bbaa69358c2cb88','7aa0c39246039e6dd3f2fff65e21eed5cce885cfff53c0103a70db7d0ae92a38']:
    source=Path.cwd()/checksum
    data=source.read_bytes()
    assert hashlib.sha256(data).hexdigest()==checksum
    target=Path('/home/loosqk/.rustup/downloads')/checksum
    existed=target.exists()
    if not existed:
        with target.open('xb') as f: f.write(data)
    assert hashlib.sha256(target.read_bytes()).hexdigest()==checksum
    rows.append({'sha256':checksum,'bytes':len(data),'target':str(target),'already_present':existed,'readback':True})
result['components']=rows
result['old_process_absent']=not proc.exists()
Path('toolchain_cache_seeded.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(result,ensure_ascii=False))
INNER
