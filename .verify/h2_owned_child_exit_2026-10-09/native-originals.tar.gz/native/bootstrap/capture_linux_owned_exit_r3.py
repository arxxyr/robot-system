"""仅复跑完整合同中的同一个 Linux 方法，记录真实 probe/wait 原字段；不增加测试计数。"""
import copy,json,os,sys,unittest
from pathlib import Path
sys.dont_write_bytecode=True
source=Path('/home/loosqk/robot-checks/h2-exit-observation-20261009-r1/source')
sys.path.insert(0,str(source/'scripts/tests'))
import test_run_post_e_h2 as tests
receipts=[];waits=[]
original_observe=tests.driver.RealBackend.observe
original_waitpid=os.waitpid
def observe(self,child,journal):
 value=original_observe(self,child,journal)
 receipts.append({'actual_child_pid':child.pid,'actual_child_returncode':child.returncode,'receipt':copy.deepcopy(journal.state['owned_child_exit_observation'])})
 return value
def waitpid(pid,options):
 row={'pid':pid,'options':options};waits.append(row)
 try:
  value=original_waitpid(pid,options);row['returned']=list(value);return value
 except BaseException as error:row['exception_type']=type(error).__name__;row['exception']=repr(error);raise
case=tests.OwnedChildExitTests('test_linux_real_exe_enoent_then_owned_wait_and_no_second_waitable_child')
with tests.patch.object(tests.driver.RealBackend,'observe',observe),tests.patch.object(os,'waitpid',waitpid):
 result=unittest.TextTestRunner(verbosity=2).run(unittest.TestSuite([case]))
passed=result.wasSuccessful() and result.testsRun==1 and not result.skipped and len(receipts)==1 and receipts[0]['actual_child_returncode']==0 and any(x.get('exception_type')=='ChildProcessError' for x in waits)
record={'status':'PASS' if passed else 'FAIL','scope':'同一个既有 Linux 方法再次执行并记录原字段，不作为第二个不同方法累计','tests_run':result.testsRun,'skipped':result.skipped,'observations':receipts,'actual_waitpid_calls':waits,'no_uart':True}
out=Path('/home/loosqk/robot-checks/h2-exit-observation-20261009-r1/qa-r3/linux-owned-exit-real.json')
with out.open('x') as stream:json.dump(record,stream,ensure_ascii=False,indent=2);stream.write('\n')
print(json.dumps(record,ensure_ascii=False),flush=True)
raise SystemExit(0 if passed else 1)
