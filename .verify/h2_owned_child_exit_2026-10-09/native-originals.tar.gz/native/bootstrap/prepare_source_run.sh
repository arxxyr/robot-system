#!/bin/bash
# 网络不稳时只在同一 tmux pane 观察本次独立源准备。
set -u
umask 077
export PATH=/home/loosqk/.cargo/bin:/home/loosqk/.local/bin:$PATH
export PYTHONDONTWRITEBYTECODE=1
b=/home/loosqk/robot-checks/h2-exit-observation-20261009-r1
tmux set-option -w -t "$TMUX_PANE" remain-on-exit on
python_path=$(uv python find 3.12)
"$python_path" "$b/bootstrap/prepare_source_once.py" > "$b/bootstrap/prepare-source-owner.log" 2>&1
code=$?
printf '%s\n' "$code" > "$b/bootstrap/prepare-source-owner.exit"
exit "$code"
