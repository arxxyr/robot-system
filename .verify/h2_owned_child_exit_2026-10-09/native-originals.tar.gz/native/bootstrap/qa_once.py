"""本轮退出观察窄修复软件门；复用既有 Runner，不执行控制或硬件。"""
import importlib.util,json,os,re,signal
from pathlib import Path
from types import SimpleNamespace
base=Path('/home/loosqk/robot-checks/h2-exit-observation-20261009-r1');source=base/'source';out=base/'qa-r1'
expected={'scripts/run_post_e_h2.py':'3b69527eb66115a3770b96ab55aa06d99716270399bb5cf2b0d84c1c9c51b9ae','scripts/tests/test_run_post_e_h2.py':'28c9beee78f800b0d5c8b667144162875ff1924c76b81bf3a6893513de8dd119'}
modules=[]
for name,path in [('artifacts',source/'scripts/post_e_h2_artifacts.py'),('release_runner',Path('/home/loosqk/robot-checks/h2-right-ready-20261009-r1/bootstrap/run_release_v2.py'))]:
 spec=importlib.util.spec_from_file_location(name,path);module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module);modules.append(module)
a,r=modules
a.require(a.sha256(Path(r.__file__))=='d6b20da28de8d5ae077a93cb2fb5ba7f27a66b8145df9e7e91951cb14ac0b12b' and a.sha256(Path(a.__file__))=='bd2b3f7bb8527cd9ecec73894171638e9cf378656b89e284a585c3baa37b8731','既有模块身份改变')
def interrupted(signum,frame):r.INTERRUPTED=signum
for sig in (signal.SIGTERM,signal.SIGINT,signal.SIGHUP):signal.signal(sig,interrupted)
out.mkdir();r.save(out/'owner.json',r.proc_entry(os.getpid()))
runner=r.Runner(SimpleNamespace(source=source,target=Path('/home/loosqk/robot-checks/xlerobot-velocity-foundation-20261008-r7/build'),out=out),a)
runner.env['CARGO_HOME']='/home/loosqk/robot-checks/viz-orin-a6957cc-20260930-r1/cargo-home'
proxy={name:'http://10.0.1.80:10808' for name in ('http_proxy','https_proxy','HTTP_PROXY','HTTPS_PROXY')};runner.env.update(proxy)
result={'status':'FAIL','scope':'原597 Rust源上的两份自有Python overlay；nightly更新/fmt/根Clippy/完整Python及同一Linux方法实证，无硬件/release/全Rustworkspace测试','proxy_runtime_overrides':proxy,'expected_overlays':expected}
def snapshot(label):
 _,h=runner.command(label+'_head',['git','rev-parse','HEAD']);_,s=runner.command(label+'_status',['git','status','--porcelain=v1','--untracked-files=all']);_,f=runner.command(label+'_files',['git','ls-files','-z','--cached','--others','--exclude-standard'])
 head=Path(h['stdout']).read_text().strip();dirty=Path(s['stdout']).read_text();compiled=a.snapshot_source(source,Path(f['stdout']).read_text().rstrip('\0').split('\0'));overlays={name:{'sha256':a.sha256(source/name),'bytes':(source/name).stat().st_size} for name in expected}
 a.require(head=='aa03ca51a819fee45c9ffe029e0ee11fb535a6e7' and set(dirty.splitlines())=={' M '+name for name in expected} and len(compiled['files'])==597 and compiled['source_manifest_sha256']=='5970c9bed0ab02f99b47d88d47eb3718c6a748155ca4fafd5c18050a68ec6cf7' and all(overlays[n]['sha256']==expected[n] for n in expected),'源码/overlay身份不符')
 value={'head':head,'porcelain':dirty,'compiled_source':compiled,'overlays':overlays};r.save(out/(label+'.json'),value);return value
before=None;compiler=None
try:
 before=snapshot('source_before')
 runner.command('nightly_update',['rustup','update','nightly'],7200)
 _,v=runner.command('rustc_before',['rustc','-vV']);compiler=a.parse_rustc_identity(Path(v['stdout']).read_text());result['rustc_identity']=compiler
 runner.command('cargo_version',['cargo','-V'])
 runner.command('fmt',['cargo','fmt','--all'],300)
 runner.command('clippy',['cargo','clippy','--all','--all-targets','--','-D','warnings'],7200)
 _,t=runner.command('python_contracts',['uv','run','--no-project','python','-m','unittest','discover','-s','scripts/tests','-p','test_*.py','-v'],300)
 text=Path(t['stderr']).read_text();m=re.search(r'Ran (\d+) tests in ',text);a.require(m is not None and text.rstrip().endswith('OK') and re.search(r'test_linux_real_exe_enoent_then_owned_wait_and_no_second_waitable_child .*\.\.\. ok',text) is not None,'完整Python或Linux方法未通过/被skip')
 result['python_unique_methods']=int(m.group(1));result['linux_in_full_contract']='PASS_NOT_SKIPPED'
 runner.command('linux_owned_exit_capture',['uv','run','--no-project','python',str(base/'bootstrap/capture_linux_owned_exit.py')],300)
 result['status']='PASS'
except BaseException as error:result['error']=repr(error)
finally:
 try:a.require(before is not None and snapshot('source_after')==before,'源与两脚本前后不同');result['source_after']='PASS'
 except BaseException as error:result.update(status='FAIL',source_after=repr(error))
 try:
  _,v=runner.command('rustc_after',['rustc','-vV']);a.require(compiler is not None and a.parse_rustc_identity(Path(v['stdout']).read_text())==compiler,'编译器前后不同');result['compiler_after']='PASS'
 except BaseException as error:result.update(status='FAIL',compiler_after=repr(error))
 result['receipts']=runner.receipts;r.save(out/'result.json',result);print(json.dumps(result,ensure_ascii=False),flush=True)
raise SystemExit(0 if result['status']=='PASS' else 1)
