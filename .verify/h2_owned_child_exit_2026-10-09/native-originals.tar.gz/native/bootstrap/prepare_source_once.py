"""本轮软件 QA 独立源准备；复用既有 Runner，不执行构建或硬件。"""
import importlib.util,json,os
from pathlib import Path
from types import SimpleNamespace
base=Path('/home/loosqk/robot-checks/h2-exit-observation-20261009-r1')
source=base/'source';out=base/'prepare-source-r1'
modules=[]
for name,path in [('artifacts',Path('/home/loosqk/robot-checks/h2-right-ready-20261009-r2/source/scripts/post_e_h2_artifacts.py')),('release_runner',Path('/home/loosqk/robot-checks/h2-right-ready-20261009-r1/bootstrap/run_release_v2.py'))]:
 spec=importlib.util.spec_from_file_location(name,path);module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module);modules.append(module)
a,r=modules
a.require(a.sha256(Path(r.__file__))=='d6b20da28de8d5ae077a93cb2fb5ba7f27a66b8145df9e7e91951cb14ac0b12b' and a.sha256(Path(a.__file__))=='bd2b3f7bb8527cd9ecec73894171638e9cf378656b89e284a585c3baa37b8731','既有模块身份不同')
a.require(not source.exists(),'独立源码目录已存在')
out.mkdir();r.save(out/'owner.json',r.proc_entry(os.getpid()))
runner=r.Runner(SimpleNamespace(source=base,target=Path('/home/loosqk/robot-checks/xlerobot-velocity-foundation-20261008-r7/build'),out=out),a)
result={'status':'FAIL','scope':'仅 origin 独立 clone 与当前 aa03 clean/597 身份；无 overlay/Cargo/UART/控制产物执行'}
try:
 runner.command('clone',['git','clone','--single-branch','--branch','feat/post-e-comm-fault-hardening','ssh://git@git.yang.cafe:20080/loosqk/robot-system.git',str(source)],7200)
 runner.options.source=source
 _,h=runner.command('head',['git','-C',str(source),'rev-parse','HEAD']);_,s=runner.command('status',['git','-C',str(source),'status','--porcelain=v1','--untracked-files=all']);_,f=runner.command('files',['git','-C',str(source),'ls-files','-z','--cached','--others','--exclude-standard'])
 head=Path(h['stdout']).read_text().strip();dirty=Path(s['stdout']).read_text();names=Path(f['stdout']).read_text().rstrip('\0').split('\0');snapshot=a.snapshot_source(source,names)
 a.require(head=='aa03ca51a819fee45c9ffe029e0ee11fb535a6e7' and dirty=='' and len(snapshot['files'])==597 and snapshot['source_manifest_sha256']=='5970c9bed0ab02f99b47d88d47eb3718c6a748155ca4fafd5c18050a68ec6cf7','独立源基线不符')
 r.save(out/'source.json',snapshot);result.update(status='PASS',head=head,clean=True,source_manifest_sha256=snapshot['source_manifest_sha256'])
except BaseException as error:result['error']=repr(error)
result['receipts']=runner.receipts;r.save(out/'result.json',result);print(json.dumps(result,ensure_ascii=False),flush=True)
raise SystemExit(0 if result['status']=='PASS' else 1)
