#!/bin/bash
# 同一 tmux pane 顺序执行本次已授权软件门。
set -u
umask 077
export PATH=/home/loosqk/.cargo/bin:/home/loosqk/.local/bin:$PATH
export PYTHONDONTWRITEBYTECODE=1
b=/home/loosqk/robot-checks/h2-exit-observation-20261009-r1
tmux set-option -w -t "$TMUX_PANE" remain-on-exit on
python_path=$(uv python find 3.12)
"$python_path" "$b/bootstrap/qa_python_r3.py" > "$b/bootstrap/qa-r3-owner.log" 2>&1
code=$?
printf '%s\n' "$code" > "$b/bootstrap/qa-r3-owner.exit"
exit "$code"
