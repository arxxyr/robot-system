#!/bin/bash
# 爸爸，仅取回本轮终态原件，不打开UART、不执行控制工具、不更改保护。
set -eu
exec /bin/tar -C /home/loosqk/robot-checks/position-return-20261010-r1 -cf - baseline-control-r1 left-wrist-baseline-r1 left-wrist-baseline-r1.driver.log left-wrist-baseline-r1.go.json left-wrist-baseline-r1.go.json.consumed maintenance_bindings_current_r1.json left-wrist-baseline-r1.plan-only.json software-facts-r1/scripts/run_hardware_maintenance.py
