# 本轮固定74次原帧只读；复用既有RealExecutor，不写寄存器，不运动，不重试。
import fcntl, hashlib, importlib.util, json, os, signal, stat, sys, time
from pathlib import Path
sys.dont_write_bytecode=True
BASE=Path('/home/loosqk/robot-checks/position-return-20261010-r1/readonly-r1')
C=json.loads((BASE/'config.json').read_bytes())
OUT=BASE/'evidence'
OUT.mkdir()
SOURCE=Path('/home/loosqk/robot-checks/h2-exit-observation-20261009-r1/source/scripts/run_hardware_maintenance.py')
SOURCE_SHA='dc12de3b2f00f506213c47441f4cceec2f4d534e308e87a65e98167aaaabacfa'
meta={'Torque_Enable':(40,1),'Model_Number':(3,2),'Firmware_Major_Version':(0,1),'Firmware_Minor_Version':(1,1),'Operating_Mode':(33,1),'Phase':(18,1),'P_Coefficient':(21,1),'D_Coefficient':(22,1),'I_Coefficient':(23,1),'CW_Dead_Zone':(26,1),'CCW_Dead_Zone':(27,1),'Goal_Position':(42,2),'Present_Position':(56,2),'Goal_Velocity':(46,2),'Present_Velocity':(58,2),'Lock':(55,1),'Min_Position_Limit':(9,2),'Max_Position_Limit':(11,2),'Homing_Offset':(31,2)}
result={'status':'RUNNING','pid':os.getpid(),'started_ns':time.time_ns(),'nonuart_snapshot_reference':{k:v for k,v in C.items() if k.startswith('nonuart_snapshot_')},'field_confirmation':C['field_confirmation'],'readouts':[],'register_writes':0,'motion_commands':0,'errors':[],'source':{'path':str(SOURCE),'sha256':SOURCE_SHA},'tool':C['files']['read_raw_13c97115']}
locks=[]; io=None

def require(value,text):
 if not value:raise ValueError(text)

def identities():
 require(Path('/proc/sys/kernel/random/boot_id').read_text().strip()==C['boot_id'],'boot变化')
 files={}
 for name,ref in C['files'].items():
  p=Path(ref['path']);s=p.lstat();raw=p.read_bytes()
  row={'path':str(p),'sha256':hashlib.sha256(raw).hexdigest(),'bytes':len(raw),'uid':s.st_uid,'gid':s.st_gid,'mode':stat.S_IMODE(s.st_mode),'device':s.st_dev,'inode':s.st_ino,'mtime_ns':s.st_mtime_ns,'ctime_ns':s.st_ctime_ns,'elf_machine':int.from_bytes(raw[18:20],'little')}
  require(stat.S_ISREG(s.st_mode) and row==ref,'ELF身份变化:'+name); files[name]=row
 for side,ref in C['devices'].items():
  p=Path(ref['device']);s=p.stat();ls=p.lstat()
  require(stat.S_ISCHR(s.st_mode) and stat.S_ISLNK(ls.st_mode) and str(p.resolve())==ref['resolved'] and s.st_rdev==ref['rdev'] and s.st_ino==ref['device_inode'] and ls.st_ino==ref['link_inode'],'USB身份变化:'+side)
 require(hashlib.sha256(SOURCE.read_bytes()).hexdigest()==SOURCE_SHA,'既有Executor源码变化')
 return {'boot_id':C['boot_id'],'files':files,'devices':C['devices']}

def protection():
 rows={}
 for side in ('left','right'):
  for name in ('rx_trust.lock','estop_latch.lock','rx_trust_marker','rx_trust_marker.bak','estop_latch','estop_latch.bak'):
   p=Path('/var/lib/robot/xlerobot_'+side)/name
   if not p.exists():
    require(not p.is_symlink(),'保护符号链接');rows[str(p)]={'exists':False};continue
   fd=os.open(p,os.O_RDONLY|os.O_NOFOLLOW)
   with os.fdopen(fd,'rb') as f:s=os.fstat(f.fileno());raw=f.read()
   require(stat.S_ISREG(s.st_mode),'保护文件类型')
   rows[str(p)]={'exists':True,'sha256':hashlib.sha256(raw).hexdigest(),'bytes':len(raw),'uid':s.st_uid,'gid':s.st_gid,'mode':stat.S_IMODE(s.st_mode),'inode':s.st_ino,'raw_hex':raw.hex()}
 return rows

try:
 result['identity_before']=identities()
 spec=importlib.util.spec_from_file_location('maintenance_readonly_existing',SOURCE);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
 io=m.RealExecutor(C['files']['read_raw_13c97115'],OUT)
 for sig in (signal.SIGINT,signal.SIGTERM,signal.SIGHUP,signal.SIGQUIT):signal.signal(sig,io.mark_signal)
 result['protection_before']=protection()
 for side in ('left','right'):
  for name in ('rx_trust.lock','estop_latch.lock'):
   fd=os.open('/var/lib/robot/xlerobot_'+side+'/'+name,os.O_RDONLY|os.O_NOFOLLOW);locks.append(fd);fcntl.flock(fd,fcntl.LOCK_EX|fcntl.LOCK_NB)
 rows=[(side,motor,'Torque_Enable') for side,count in (('left',8),('right',9)) for motor in range(1,count+1)]
 rows += [('left',motor,reg) for motor in (5,7,8) for reg in C['registers']]
 require(len(rows)==74 and len(C['registers'])==19,'固定74项集合错误')
 for seq,(side,motor,reg) in enumerate(rows,1):
  m.verify_ref(C['files']['read_raw_13c97115'],executable=True)
  device=C['devices'][side]['device'];argv=[C['files']['read_raw_13c97115']['path'],device,str(motor),'read-raw',reg]
  text=io.command(argv);require(len(text.splitlines())==1,'结果行数错误');j=m.strict_json(text);addr,width=meta[reg]
  keys={'operation','serial_device','motor_id','register','requested_register_address','width','raw_unsigned','tx','rx'}
  require(set(j)==keys and (j['operation'],j['serial_device'],j['motor_id'],j['register'],j['requested_register_address'],j['width'])==('sync_read',device,motor,reg,addr,width),'JSON身份不一致')
  tx=[255,255,254,5,130,addr,width,motor];tx.append((~sum(tx[2:]))&255);rx=j['rx'];raw=j['raw_unsigned']
  require(type(raw) is int and j['tx']==tx and type(rx) is list and all(type(v) is int and 0<=v<=255 for v in rx) and len(rx)==6+width and rx[:5]==[255,255,motor,width+2,0] and (sum(rx[2:])&255)==255 and int.from_bytes(bytes(rx[5:5+width]),'little')==raw,'原帧校验错误')
  result['readouts'].append({'seq':seq,'side':side,'motor_id':motor,'register':reg,'raw':j,'command_sequence':io.sequence})
  print(json.dumps({'seq':seq,'side':side,'motor_id':motor,'register':reg,'raw_unsigned':raw},ensure_ascii=False),flush=True)
  require(reg!='Torque_Enable' or raw==0,'TE非零，停止后续读取，请现场立即断电')
  require(reg!='Model_Number' or raw==777,'目标型号不是777')
  require(reg!='Operating_Mode' or raw==0,'位置目标不是模式0')
  require(reg not in ('Present_Velocity','Goal_Velocity') or raw==0,'目标速度非零，停止后续读取，请现场立即断电')
 require(len(result['readouts'])==74,'输出不足74项')
except BaseException as error:
 result['errors'].append(repr(error));print('爸爸，只读批次失败，停止后续UART，不自动重试：'+repr(error),flush=True)
finally:
 for name,fn in (('identity_after',identities),('protection_after',protection)):
  try:result[name]=fn()
  except BaseException as error:result['errors'].append(name+':'+repr(error))
 if result.get('protection_before')!=result.get('protection_after'):result['errors'].append('保护文件前后变化')
 for fd in reversed(locks):os.close(fd)
 if io is not None:
  result['commands']=io.commands;result['received_signal']=io.interrupted;result['evidence_errors']=io.evidence_errors;io.journal.close()
  if io.interrupted or io.evidence_errors:result['errors'].append('收到信号/证据错误')
 result['finished_ns']=time.time_ns();result['status']='FAIL' if result['errors'] else 'PASS_READONLY_74'
 with (BASE/'result.json.tmp').open('x') as f:json.dump(result,f,ensure_ascii=False,indent=2);f.write('\n');f.flush();os.fsync(f.fileno())
 (BASE/'result.json.tmp').rename(BASE/'result.json')
 print(json.dumps({'terminal':True,'status':result['status'],'readouts':len(result['readouts']),'child_count':len(result.get('commands',[])),'errors':result['errors']},ensure_ascii=False),flush=True)
sys.exit(1 if result['errors'] else 0)
