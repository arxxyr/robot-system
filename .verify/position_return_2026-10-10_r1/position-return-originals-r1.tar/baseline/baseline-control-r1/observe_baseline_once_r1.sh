#!/bin/bash
# 爸爸，本轮root精确GO批准唯一左腕baseline；只观察同一pane，自然退出后保留原FAIL。
# SSH 等待同一 pane 的退出通知，通知后仍只读核验真实终态。
set -euC
umask 077
export PATH=/home/loosqk/.cargo/bin:/home/loosqk/.local/bin:$PATH
base=/home/loosqk/robot-checks/position-return-20261010-r1
launch="$base/baseline-control-r1/launch_baseline_r1.sh"
record="$base/baseline-control-r1/event-once"
# 断线后显式选 1，只观察已有 pane；旧 SSH 255 原件仍保留。
case "${BASELINE_OBSERVE_ONLY:-0}" in
  0)
    test -f "$launch"
    test ! -e "$base/left-wrist-baseline-r1"
    test ! -e "$base/left-wrist-baseline-r1.driver.log"
    mkdir "$record"
    # 只核继承hook文本，不执行或复制其命令；有pane-died行为则拒绝遮住。
    tmux show-hooks -g > "$record/inherited-global-hooks"
    tmux show-hooks -gw > "$record/inherited-global-window-hooks"
    tmux show-hooks -t robot-h2-20261009-proxy-r1 > "$record/inherited-session-hooks"
    if /usr/bin/grep -E '^pane-died(\[| )' "$record"/inherited-*-hooks; then exit 2; fi
    tmux new-window -d -t robot-h2-20261009-proxy-r1 -n left-wrist-baseline-20261010-r1 -P \
      -F '#{pane_id} #{pane_pid} #{window_id}' "exec /bin/bash $launch" > "$record/pane.txt"
    ;;
  1) test -s "$record/pane.txt" ;;
  *) exit 2 ;;
esac
read -r pane driver_pid window < "$record/pane.txt"
case "$pane" in %[0-9]*) ;; *) exit 2;; esac
case "$driver_pid" in ''|*[!0-9]*) exit 2;; esac
# 同一服务器的 pane_id 不复用；同一记录目录的 observer PID 文件不覆盖。
# 每个观察者有自己的 indexed hook/channel，续接不覆盖旧 waiter。
observer=$$
channel="leftwrist.pane.${pane#%}.driver.$driver_pid.observer.$observer"
hook="pane-died[$observer]"
printf '%s\n' "$channel" > "$record/observer-$observer.channel"
before_hooks=$(tmux show-hooks -p -t "$pane")
printf '%s\n' "$before_hooks" > "$record/observer-$observer.hooks-before"
while read -r hook_name hook_command; do
  if [ "$hook_name" = "$hook" ]; then exit 2; fi
done <<< "$before_hooks"
cleanup_hook() {
  tmux set-hook -pu -t "$pane" "$hook"
}
trap cleanup_hook EXIT
tmux set-hook -p -t "$pane" "$hook" "wait-for -S $channel"
tmux show-hooks -p -t "$pane" > "$record/observer-$observer.hooks-after"
observe() {
  state=$(tmux display-message -p -t "$pane" '#{pane_id} #{pane_pid} #{pane_dead} #{pane_dead_status}')
  printf '%s\n' "$state" >> "$record/observer-$observer.log"
  read -r observed_pane observed_pid dead status <<< "$state"
  test "$observed_pane" = "$pane"
  test "$observed_pid" = "$driver_pid"
}
# 挂钩后查询：先退出的 pane 直接核验；查询到存活后的退出由 channel 留存通知。
observe
if [ "$dead" = 0 ]; then
  tmux wait-for "$channel"
  observe
fi
# 提前或错误通知不能变成 PASS，也不再次等待/启动。
if [ "$dead" != 1 ]; then exit 2; fi
printf '%s\n' "$state" > "$record/observer-$observer.terminal"
    case "$status" in 0|1) ;; *) exit 2;; esac
    "/home/loosqk/.local/share/uv/python/cpython-3.12.13-linux-aarch64-gnu/bin/python3" - "$base/left-wrist-baseline-r1/run.json" "$driver_pid" "$status" "$base/baseline-control-r1/terminal.json" <<'PY_END'
import hashlib,json,sys,time
from pathlib import Path
run_path=Path(sys.argv[1]);raw=run_path.read_bytes();run=json.loads(raw)
status=int(sys.argv[3]);pid=int(sys.argv[2])
assert run['schema']=='MAINTENANCE_RUN_V2'
assert run['plan']['script_sha256']=='d97e0da9b792d048681053054296de66e7f3ef37cf392852784587b51a8b1d41'
assert run['plan']['position_targets']==[['left',5,'left_arm_wrist_roll']]
assert run['go']['plan_sha256']=='0fa57c69ca03207265b31911616bd8f6012d2fef56084143bd0ec958ae49db28'
assert status==(0 if run['result']=='PASS' else 1)
commands=run['commands']
for row in commands:
    argv=row['argv']
    if len(argv)>3 and argv[3]=='write':
        assert argv[1]=='/dev/serial/by-id/usb-1a86_USB_Single_Serial_5A7C121427-if00' and argv[2]=='5'
        assert argv[4] in ('Goal_Position','Torque_Enable')
summary={'status':'OBSERVED_REAL_TERMINAL','driver_pid':pid,'pane_exit_status':status,
    'driver_result':run['result'],'run_sha256':hashlib.sha256(raw).hexdigest(),'run_bytes':len(raw),
    'probes':run.get('probes'),'stop_verification':run.get('stop_verification'),
    'position_verification':run.get('position_verification'),'identity_verification':run.get('identity_verification'),
    'commands':len(commands),'all_command_children_reaped':all(r.get('reaped') is True for r in commands),
    'all_command_signals_sent_empty':all(r.get('signals_sent')==[] for r in commands),
    'manual_power_cut_required':run.get('manual_power_cut_required'),'observed_ns':time.time_ns()}
with Path(sys.argv[4]).open('x') as f:json.dump(summary,f,ensure_ascii=False,indent=2);f.write('\n')
print(json.dumps(summary,ensure_ascii=False),flush=True)
PY_END
exit "$status"
