#!/bin/bash
# 爸爸，只由本轮一次observer启动；本体exec，保留真实pane PID。
set -euC
umask 077
export PYTHONDONTWRITEBYTECODE=1
tmux set-option -w -t "$TMUX_PANE" remain-on-exit on
exec > /home/loosqk/robot-checks/position-return-20261010-r1/left-wrist-baseline-r1.driver.log 2>&1
exec /home/loosqk/.local/share/uv/python/cpython-3.12.13-linux-aarch64-gnu/bin/python3 /home/loosqk/robot-checks/position-return-20261010-r1/software-facts-r1/scripts/run_hardware_maintenance.py --bindings /home/loosqk/robot-checks/position-return-20261010-r1/maintenance_bindings_current_r1.json --output /home/loosqk/robot-checks/position-return-20261010-r1/left-wrist-baseline-r1 --run-id left-wrist-baseline-r1 --artifact-root /home/loosqk/robot-checks/position-return-20261010-r1 --position-target left-wrist --approval /home/loosqk/robot-checks/position-return-20261010-r1/left-wrist-baseline-r1.go.json --execute
