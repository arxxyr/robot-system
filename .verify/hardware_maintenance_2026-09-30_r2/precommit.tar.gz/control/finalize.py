"""只整理本次软件提交前门；不编辑主仓或旧包。"""
import hashlib,importlib.util,io,json,stat,subprocess,sys,tarfile
from pathlib import Path,PurePosixPath
sys.dont_write_bytecode=True
ROOT=Path.cwd();BASE=ROOT/'target/h2-hardware-stage-gate-r1';OUT=BASE/'native-extracted';OUT.mkdir()
def sha(b):return hashlib.sha256(b).hexdigest()
def ref(p):
    b=p.read_bytes();return {'path':str(p),'sha256':sha(b),'bytes':len(b)}
def save(p,v):
    with p.open('x') as s:json.dump(v,s,ensure_ascii=False,indent=2,allow_nan=False);s.write('\n')
collector=json.loads((BASE/'control/collect_guest.owner/child.log').read_text());archive=BASE/'native.tar.gz';idx=BASE/'native.index.json';raw=idx.read_bytes();index=json.loads(raw)
assert ref(archive)['sha256']==collector['archive']['sha256'] and ref(archive)['bytes']==collector['archive']['bytes'];assert ref(idx)['sha256']==collector['index']['sha256'] and len(raw)==collector['index']['bytes'];seen=set()
with tarfile.open(archive,'r:gz') as tar:
    for item in tar:
        name=item.name;p=PurePosixPath(name);assert item.isfile() and name not in seen and not p.is_absolute() and '..' not in p.parts and str(p)==name;seen.add(name);b=tar.extractfile(item).read()
        if name=='index.json':assert b==raw;entry={'executable':False}
        else:
            entry=index['files'][name];assert sha(b)==entry['sha256'] and len(b)==entry['bytes']
        assert bool(item.mode&stat.S_IXUSR)==entry['executable'];dst=OUT/name;dst.parent.mkdir(parents=True,exist_ok=True)
        with dst.open('xb') as s:s.write(b)
        dst.chmod(0o755 if entry['executable'] else 0o644)
assert seen==set(index['files'])|{'index.json'}
r=json.loads((OUT/'result.json').read_text());before=json.loads((OUT/'source_before.json').read_text());after=json.loads((OUT/'source_after.json').read_text());assert r['status']=='PASS' and r['source_before_after_equal'] and r['compiler_before_after_equal'] and before==after
receipts=[]
for p in sorted(BASE.rglob('*.owner/result.json')):
    v=json.loads(p.read_text());assert v['phase']=='REAPED' and v['reaped'] and v['wait_returncode']==0 and v['owner_sent_signals']==[] and v['received_signals']=={} and v['errors']==[];b=(p.parent/'child.log').read_bytes();assert len(b)==v['log']['bytes'] and sha(b)==v['log']['sha256'];receipts.append({'path':str(p.relative_to(BASE)),'owner_pid':v['owner_pid'],'child_pid':v['pid'],'wait_returncode':0,'reaped':True})
assert len(receipts)==18
main=Path('/Users/loosqk/repo/rust/robot-system');spec=importlib.util.spec_from_file_location('stage_bind_inputs',ROOT/'scripts/post_e_h2_artifacts.py');a=importlib.util.module_from_spec(spec);spec.loader.exec_module(a)
main_head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=main).decode().strip();main_names=subprocess.check_output(['git','ls-files','-z'],cwd=main).decode().rstrip('\0').split('\0');main_source=a.snapshot_source(main,main_names);assert main_source==before
save(BASE/'main_source_readonly_binding.json',{'head':main_head,'source':main_source,'scope':'只读主树编译域绑定，未编辑主仓/docs'})
summary={'schema':'H2_HARDWARE_STAGE_COMMIT_SOFTWARE_GATE_V1','status':'PASS','scope':'本次硬件证据/文档阶段提交前新执行的软件门；同R4源码，无主仓/docs修改、全仓测试、SSH robot/Orin、UART或提交/推送。','main_head_readonly_binding':main_head,'same_main_guest_source':True,'source_files':589,'aggregate':before['source_manifest_sha256'],'sla_sha256':r['sla']['sha256'],'sla_bytes':r['sla']['bytes'],'identity':r['identity'],'actual_current_execution':['rustup update nightly --no-self-update','cargo fmt --all','cargo clippy --locked --offline --all --all-targets -- -D warnings'],'rustc':(OUT/'control/rustc_before.owner/child.log').read_text(),'cargo':(OUT/'control/cargo_before.owner/child.log').read_text(),'compiler_and_source_before_after_equal':True,'result':ref(OUT/'result.json'),'fmt_receipt':ref(OUT/'control/fmt.owner/result.json'),'fmt_log':ref(OUT/'control/fmt.owner/child.log'),'root_clippy_receipt':ref(OUT/'control/root_clippy.owner/result.json'),'root_clippy_log':ref(OUT/'control/root_clippy.owner/child.log'),'native_archive':ref(archive),'native_index':ref(idx),'native_files':len(index['files']),'native_members':len(seen),'native_hash_bytes_mode_verified':True,'guest_owned_waits':14,'outer_owned_waits':4,'total_owned_waits':18,'receipts':receipts,'owned_sessions_remaining':[],'hardware_boundary':'不代表硬件PASS；root告知的维护run02整体FAIL保持，不改原run或硬件状态。','deployable':False}
save(BASE/'summary.json',summary)
paths=[p for p in BASE.rglob('*') if p.is_file() and 'native-extracted' not in p.parts];entries={}
for p in sorted(paths):
    b=p.read_bytes();entries[str(p.relative_to(BASE))]={'sha256':sha(b),'bytes':len(b),'executable':bool(p.stat().st_mode&stat.S_IXUSR)}
outer_index={'schema':'H2_HARDWARE_STAGE_SOFTWARE_GATE_OUTER_V1','files':entries};raw_index=(json.dumps(outer_index,sort_keys=True,ensure_ascii=False,indent=2)+'\n').encode();pack=ROOT/'target/h2-hardware-stage-gate-r1.tar.gz';packidx=ROOT/'target/h2-hardware-stage-gate-r1.index.json'
with packidx.open('xb') as s:s.write(raw_index)
with tarfile.open(pack,'x:gz') as tar:
    for name,entry in entries.items():
        b=(BASE/name).read_bytes();assert sha(b)==entry['sha256'];item=tarfile.TarInfo(name);item.size=len(b);item.mode=0o755 if entry['executable'] else 0o644;tar.addfile(item,io.BytesIO(b))
    item=tarfile.TarInfo('outer-index.json');item.size=len(raw_index);item.mode=0o644;tar.addfile(item,io.BytesIO(raw_index))
seen=set()
with tarfile.open(pack,'r:gz') as tar:
    for item in tar:
        assert item.isfile() and item.name not in seen;seen.add(item.name);b=tar.extractfile(item).read()
        if item.name=='outer-index.json':assert b==raw_index
        else:
            entry=entries[item.name];assert sha(b)==entry['sha256'] and len(b)==entry['bytes'] and bool(item.mode&stat.S_IXUSR)==entry['executable']
assert seen==set(entries)|{'outer-index.json'}
verification={'status':'PASS','archive':ref(pack),'index':ref(packidx),'files':len(entries),'members':len(seen),'sha_bytes_mode_verified':True,'summary':ref(BASE/'summary.json')};save(BASE/'outer_archive_verification.json',verification);print(json.dumps(verification,ensure_ascii=False,indent=2))
