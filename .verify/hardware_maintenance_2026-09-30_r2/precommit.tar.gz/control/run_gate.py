"""硬件证据文档阶段提交前的同源Linux软件门；不访问硬件或改主树。"""
import hashlib,importlib.util,json,os,platform,socket,sys
from pathlib import Path
from types import SimpleNamespace
sys.dont_write_bytecode=True
ROOT=Path('/home/loosqk.guest/robot-checks/h2-trace-owner-20260930-r4');SOURCE=ROOT/'source';OUT=ROOT/'hardware-stage-commit-gate-r1';CONTROL=OUT/'control';CACHE=Path('/home/loosqk.guest/robot-checks/build')
AGG='83048e983bb7a13c2f75ae23e593ec301f129b10b412db8f4f80176ca434f62f';SLA='167dc63b2a274b53d9c53fe72c811d242d8ca96d5f031e1bf0ea9981cbd78e18'
def require(ok,message):
    if not ok:raise ValueError(message)
def identity(path):
    b=path.read_bytes();return {'path':str(path),'sha256':hashlib.sha256(b).hexdigest(),'bytes':len(b)}
def save(path,value):
    with path.open('x') as stream:json.dump(value,stream,ensure_ascii=False,indent=2,allow_nan=False);stream.write('\n')
def module(name,path):
    spec=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);return m
require(platform.system()=='Linux' and platform.machine()=='aarch64' and socket.gethostname()=='lima-robot-viz-check' and os.getuid()==501,'Lima身份不符')
require(identity(CONTROL/'owner.py')['sha256']=='96d1c8ed14fa94e62cbfcb0ea28ff60f628bdcf0d76cf3796d968602ce14938a','owner身份不符')
os.chdir(SOURCE);owner=module('stage_gate_owner',CONTROL/'owner.py');a=module('stage_gate_contract',SOURCE/'scripts/post_e_h2_artifacts.py');os.environ['PATH']='/home/loosqk.guest/.cargo/bin:/home/loosqk.guest/.local/bin:'+os.environ['PATH'];env,shown,removed=a.fixed_build_environment(CACHE);os.environ.clear();os.environ.update(env)
result={'status':'RUNNING','scope':'本次硬件证据文档阶段提交前独立fmt/根Clippy；纯Lima软件，无UART/Orin/主树修改，不代表硬件通过。','identity':{'hostname':socket.gethostname(),'machine':platform.machine(),'uid':os.getuid(),'boot_id':Path('/proc/sys/kernel/random/boot_id').read_text().strip()},'commands':[],'environment':shown,'removed_environment_keys':removed,'deployable':False}
def command(name,argv):
    rc=owner.run(SimpleNamespace(label=name,command=argv,observe_seconds=5,input=None));p=CONTROL/(name+'.owner/result.json');r=json.loads(p.read_text());result['commands'].append({'name':name,'argv':argv,'receipt':identity(p),'exit_code':rc,'reaped':r['reaped']})
    require(rc==0 and r['reaped'] and r['wait_returncode']==0 and r['phase']=='REAPED' and r['owner_sent_signals']==[] and r['received_signals']=={} and r['errors']==[],'命令未自然成功完成:'+name);return (p.parent/'child.log').read_bytes()
before=None;names=None
try:
    names=command('inventory_before',['git','ls-files','-z']).decode().rstrip('\0').split('\0');before=a.snapshot_source(SOURCE,names);save(OUT/'source_before.json',before)
    require(len(before['files'])==589 and before['source_manifest_sha256']==AGG and identity(SOURCE/'crates/robot-tests/src/comm_fault/sla.rs')['sha256']==SLA,'快照不符')
    head=command('head_before',['git','rev-parse','HEAD']);status=command('status_before',['git','status','--porcelain=v1','--untracked-files=all'])
    require(head.decode().strip()=='4a8e171f27bf18625973aa4f3a6097e9b9fbed18' and status==b' M crates/robot-s1/src/events_drain/runtime.rs\n M crates/robot-tests/src/comm_fault/sla.rs\n','快照Git状态变化')
    command('nightly_update',['rustup','update','nightly','--no-self-update']);rustc=command('rustc_before',['rustc','-Vv']);cargo=command('cargo_before',['cargo','-V'])
    require(b'commit-hash: 5c543b0b8c73c7b72bc8284ced4fb22ead15734d' in rustc and rustc==(ROOT/'control/rustc_before.owner/child.log').read_bytes(),'编译器已变，需要重新评估软件证据')
    command('fmt',['cargo','fmt','--all']);require(a.snapshot_source(SOURCE,names)==before,'fmt改变源身份')
    command('root_clippy',['cargo','clippy','--locked','--offline','--all','--all-targets','--','-D','warnings'])
    require(command('rustc_after',['rustc','-Vv'])==rustc and command('cargo_after',['cargo','-V'])==cargo,'编译器窗口变化');result['compiler_before_after_equal']=True
    after_names=command('inventory_after',['git','ls-files','-z']).decode().rstrip('\0').split('\0');require(after_names==names,'inventory变化')
    require(command('head_after',['git','rev-parse','HEAD'])==head and command('status_after',['git','status','--porcelain=v1','--untracked-files=all'])==status,'Git状态变化')
    command('diff_check',['git','diff','--check']);result.update(status='PASS',source_files=589,source_manifest_sha256=AGG,sla=identity(SOURCE/'crates/robot-tests/src/comm_fault/sla.rs'))
except BaseException as error:result.update(status='FAIL',error=repr(error))
finally:
    if names is not None:
        after=a.snapshot_source(SOURCE,names);save(OUT/'source_after.json',after);result['source_before_after_equal']=before==after
        if before!=after:result['status']='FAIL'
    save(OUT/'result.json',result)
print(json.dumps(result,ensure_ascii=False),flush=True);raise SystemExit(0 if result['status']=='PASS' else 1)
