"""收集提交前小包；不改变冻结r4包和源码。"""
import hashlib,io,json,os,socket,stat,tarfile
from pathlib import Path
ROOT=Path('/home/loosqk.guest/robot-checks');OUT=ROOT/'h2-trace-owner-20260930-r4/hardware-stage-commit-gate-r1';ARCHIVE=ROOT/'h2-hardware-stage-commit-gate-r1.tar.gz';INDEX=ROOT/'h2-hardware-stage-commit-gate-r1.index.json'
def require(ok,msg):
    if not ok:raise ValueError(msg)
def digest(data):return hashlib.sha256(data).hexdigest()
require(socket.gethostname()=='lima-robot-viz-check' and os.getuid()==501,'身份错')
r=json.loads((OUT/'result.json').read_text());require(r['status']=='PASS' and r['source_before_after_equal'] and r['compiler_before_after_equal'],'提交前原件未PASS')
sessions=[]
for command in r['commands']:
    p=Path(command['receipt']['path']);raw=p.read_bytes();require(digest(raw)==command['receipt']['sha256'] and len(raw)==command['receipt']['bytes'],'原件变化');row=json.loads(raw);require(row['reaped'] and row['phase']=='REAPED' and row['wait_returncode']==0 and row['owner_sent_signals']==[] and row['received_signals']=={} and row['errors']==[],'回收不真实');sessions.append(row['child_session_id']);b=(p.parent/'child.log').read_bytes();require(digest(b)==row['log']['sha256'] and len(b)==row['log']['bytes'],'日志变化')
remaining=[]
for p in Path('/proc').iterdir():
    if not p.name.isdigit():continue
    try:
        fields=(p/'stat').read_text().rsplit(') ',1)[1].split()
        if int(fields[3]) in sessions:remaining.append({'pid':int(p.name),'sid':int(fields[3]),'state':fields[0]})
    except FileNotFoundError:pass
require(remaining==[],'原会话有进程')
with (OUT/'owned_sessions_after.json').open('x') as s:json.dump({'status':'PASS','sessions':sessions,'remaining':remaining},s,indent=2);s.write('\n')
files={}
for p in sorted(OUT.rglob('*')):
    if not p.is_file():continue
    require(p.resolve()==p and stat.S_ISREG(p.lstat().st_mode),'原件不是普通文件');b=p.read_bytes();files[str(p.relative_to(OUT))]={'sha256':digest(b),'bytes':len(b),'executable':bool(p.stat().st_mode&stat.S_IXUSR)}
index={'schema':'H2_HARDWARE_STAGE_SOFTWARE_GATE_NATIVE_V1','files':files};raw=(json.dumps(index,sort_keys=True,ensure_ascii=False,indent=2)+'\n').encode()
with INDEX.open('xb') as s:s.write(raw)
with tarfile.open(ARCHIVE,'x:gz') as tar:
    for name,item in files.items():
        b=(OUT/name).read_bytes();require(digest(b)==item['sha256'] and len(b)==item['bytes'],'打包期间变化');meta=tarfile.TarInfo(name);meta.size=len(b);meta.mode=0o755 if item['executable'] else 0o644;tar.addfile(meta,io.BytesIO(b))
    meta=tarfile.TarInfo('index.json');meta.size=len(raw);meta.mode=0o644;tar.addfile(meta,io.BytesIO(raw))
print(json.dumps({'status':'PASS','archive':{'path':str(ARCHIVE),'sha256':digest(ARCHIVE.read_bytes()),'bytes':ARCHIVE.stat().st_size},'index':{'path':str(INDEX),'sha256':digest(raw),'bytes':len(raw)},'files':len(files),'waits':len(sessions),'sessions_remaining':remaining},ensure_ascii=False))
