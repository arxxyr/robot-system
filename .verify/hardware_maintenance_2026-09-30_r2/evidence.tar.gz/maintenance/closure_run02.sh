set -eu
export PATH=/home/loosqk/.cargo/bin:/home/loosqk/.local/bin:$PATH
cd /home/loosqk/robot-checks/hardware-verify-20260930-r2/maintenance
MAINTENANCE_PYTHON="$(uv python find 3.12)"
exec taskset -c 0-3 "$MAINTENANCE_PYTHON" - <<'END_PY'
import hashlib,importlib.util,json,os,sys
from pathlib import Path
sys.dont_write_bytecode=True
assert hashlib.sha256(Path('run_maintenance.py').read_bytes()).hexdigest()=='791079cfc1abfa5eab72d8acfbf6be78146423e7d7dfd2b0c7e759158600f048'
import run_maintenance as m
bindings=m.strict_json(Path('bindings.json').read_text())
output=Path('/home/loosqk/robot-checks/hardware-verify-20260930-r2/closure-run02'); output.mkdir(mode=0o750,exist_ok=False)
report={'schema':'MAINTENANCE_INDEPENDENT_CLOSURE_V1','status':'FAIL','UART_reads':0,'UART_writes':0,'hardware_actions':0,'physical_power':'USER_CONFIRMATION_PENDING'}
io=m.RealExecutor(bindings['tool'],output); io.process_snapshots=[]
try:
 assert os.uname().machine=='aarch64' and os.uname().nodename==bindings['host']['hostname'] and os.getuid()==os.geteuid()==1000
 assert Path('/proc/sys/kernel/random/boot_id').read_text().strip()==bindings['host']['boot_id']
 m.protected_and_refs(bindings)
 m.verify_ref(bindings['proc_helper'])
 spec=importlib.util.spec_from_file_location('proc_helper',bindings['proc_helper']['path']); helper=importlib.util.module_from_spec(spec); spec.loader.exec_module(helper)
 m.idle(io,bindings,helper)
 for side in m.SERIALS:
  m.usb_identity(io,side,bindings['usb'][side])
  for name in ('rx_trust.lock','estop_latch.lock'):
   for prefix in ([],['sudo','-n']):
    assert io.command(prefix+['fuser',bindings['protection'][side][name]['path']],allowed=(1,))==''
 assert not Path('/proc/432008').exists(), 'run02真实runner PID仍存在，保留未结束'
 assert not Path('/proc/431920').exists(), 'run01 uv父壳PID仍存在'
 formal='/home/loosqk/repo/robot/robot-system'
 assert io.command(['git','-C',formal,'rev-parse','HEAD']).strip()=='ca14f0e6cf6df8ecc6baaaa8dff2dddb64abbd0a'
 assert io.command(['git','-C',formal,'status','--porcelain=v1','--untracked-files=all'])==''
 original=m.strict_json(Path('/home/loosqk/robot-checks/hardware-verify-20260930-r2/run-02/run.json').read_text())
 assert not original['child_active'] and not original['after_errors'] and len(original['after'])==17
 assert all(row['Torque_Enable']==row['Present_Velocity']==row['Goal_Velocity']==0 for row in original['after'].values())
 assert all(row['reaped'] and row['exit_code']==0 and not row['signals_sent'] for row in original['commands'])
 report.update(status='PASS',original_run_result=original['result'],original_final_readback='17电机三个停止寄存器均0；原件采样证据，不冒充独立重读或物理断电',original_run_sha256=hashlib.sha256(Path('/home/loosqk/robot-checks/hardware-verify-20260930-r2/run-02/run.json').read_bytes()).hexdigest(),runner_pid_absent=432008,formal_HEAD='ca14f0e6cf6df8ecc6baaaa8dff2dddb64abbd0a',formal_clean=True,refs_unchanged=True,protection_unchanged=True)
except BaseException as error:
 report['error']=repr(error)
finally:
 report.update(commands=io.commands,process_snapshots=io.process_snapshots,child_active=io.child is not None,evidence_errors=io.evidence_errors)
 m.write_new(output/'closure.json',report); io.journal.close()
 print(json.dumps({key:value for key,value in report.items() if key not in ('commands','process_snapshots')},ensure_ascii=False),flush=True)
sys.exit(0 if report['status']=='PASS' else 1)
END_PY
