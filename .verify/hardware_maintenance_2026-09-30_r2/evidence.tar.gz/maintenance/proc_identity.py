# 爸爸，既有只读PID身份门的局部副本；仅本轮维护使用，不启动控制程序。

import os
import hashlib
import json
import subprocess
from pathlib import Path

def require(value, reason):
    if not value:
        raise ValueError(reason)

PROC_PROBE_CODE = r'''
import json
import os
import sys

def _read_at(directory, name, limit):
    descriptor = os.open(name, os.O_RDONLY | os.O_CLOEXEC | os.O_NOFOLLOW, dir_fd=directory)
    try:
        data = bytearray()
        while len(data) <= limit:
            part = os.read(descriptor, min(8192, limit + 1 - len(data)))
            if not part:
                return bytes(data)
            data.extend(part)
        raise ValueError("proc字段超过读取上限")
    finally:
        os.close(descriptor)

def _stat_at(directory, pid):
    raw = _read_at(directory, "stat", 8192).decode()
    opening, closing = raw.find("("), raw.rfind(")")
    if opening < 1 or closing <= opening or int(raw[:opening].strip()) != pid:
        raise ValueError("proc stat PID格式错误")
    fields = raw[closing + 2:].split()
    start = int(fields[19])
    if start < 0:
        raise ValueError("proc start_ticks不能为负")
    return {"pid": pid, "start_ticks": start, "pgid": int(fields[2]), "state": fields[0]}

def _uids_at(directory):
    rows = [line.split()[1:] for line in _read_at(directory, "status", 65536).decode().splitlines()
            if line.startswith("Uid:")]
    if len(rows) != 1 or len(rows[0]) != 4:
        raise ValueError("proc Uid字段不完整")
    values = [int(value) for value in rows[0]]
    if any(value < 0 for value in values):
        raise ValueError("proc Uid无效")
    return values

def _boot(root):
    with open(root + "/sys/kernel/random/boot_id", encoding="ascii") as stream:
        value = stream.read(128).strip()
    if len(value) != 36 or any(c not in "0123456789abcdef-" for c in value):
        raise ValueError("proc boot_id格式错误")
    return value

def _stable(left, right):
    return all(left[key] == right[key] for key in ("pid", "start_ticks", "boot_id", "pgid", "uids"))

def _proc_probe(pid, expected=None, details=True, root="/proc"):
    result = {"pid": pid}
    directory = None
    try:
        directory = os.open(root + "/" + str(pid), os.O_RDONLY | os.O_DIRECTORY | os.O_CLOEXEC | os.O_NOFOLLOW)
        before = _stat_at(directory, pid)
        before.update(boot_id=_boot(root), uids=_uids_at(directory))
        result["before"] = before
        if expected is not None and not _stable(before, expected):
            return dict(result, status="replaced")
        identity = dict(before)
        if details:
            identity["argv"] = _read_at(directory, "cmdline", 65536).rstrip(b"\0").decode().split("\0")
            identity["exe"] = None if before["state"] == "Z" else os.readlink("exe", dir_fd=directory)
            identity["zombie"] = before["state"] == "Z"
        after = _stat_at(directory, pid)
        after.update(boot_id=_boot(root), uids=_uids_at(directory))
        result["after"] = after
        if not _stable(before, after):
            return dict(result, status="replaced")
        return dict(result, status="observed", identity=identity)
    except FileNotFoundError as error:
        # exe缺失不等于PID退出；只在同一dirfd的stat也消失时报告vanished。
        if directory is not None:
            try:
                result["remaining_stat"] = _stat_at(directory, pid)
            except FileNotFoundError:
                return dict(result, status="vanished", error=repr(error))
            except Exception as recheck_error:
                return dict(result, status="unreadable", error=repr(recheck_error))
            return dict(result, status="unreadable", error=repr(error))
        return dict(result, status="vanished", error=repr(error))
    except PermissionError as error:
        return dict(result, status="permission", error=repr(error))
    except (OSError, ValueError, KeyError, IndexError, UnicodeError) as error:
        return dict(result, status="unreadable", error=repr(error))
    finally:
        if directory is not None:
            os.close(directory)

def _probe_main():
    text = sys.stdin.read(131073)
    if len(text) > 131072:
        raise ValueError("PID批次输入过大")
    request = json.loads(text)
    if set(request) != {"schema", "candidates"} or request["schema"] != "P7_PROC_PROBE_V1":
        raise ValueError("PID探针请求格式错误")
    candidates = request["candidates"]
    if not isinstance(candidates, list) or not 1 <= len(candidates) <= 256:
        raise ValueError("PID批次超限")
    pids = set()
    for expected in candidates:
        if set(expected) != {"pid", "start_ticks", "boot_id", "pgid", "state", "uids"}:
            raise ValueError("PID身份字段错误")
        pid = expected["pid"]
        if type(pid) is not int or pid <= 0 or pid in pids:
            raise ValueError("PID无效或重复")
        if type(expected["start_ticks"]) is not int or expected["start_ticks"] < 0:
            raise ValueError("start_ticks无效")
        if type(expected["pgid"]) is not int or expected["pgid"] < 0:
            raise ValueError("PGID无效")
        if not isinstance(expected["uids"], list) or len(expected["uids"]) != 4 or any(type(u) is not int or u < 0 for u in expected["uids"]):
            raise ValueError("Uid无效")
        if not isinstance(expected["state"], str) or len(expected["state"]) != 1 or not isinstance(expected["boot_id"], str):
            raise ValueError("PID状态/boot错误")
        pids.add(pid)
    print(json.dumps({"schema": "P7_PROC_PROBE_V1", "reader_euid": os.geteuid(), "boot_id": _boot("/proc"),
                      "rows": [_proc_probe(row["pid"], row) for row in candidates]}, ensure_ascii=False))

if __name__ == "__main__":
    _probe_main()
'''

_PROC_READER = {"__name__": "p7_fixed_proc_reader"}

exec(PROC_PROBE_CODE, _PROC_READER)

def read_process(pid, expected=None, details=True, proc=Path("/proc")):
    return _PROC_READER["_proc_probe"](pid, expected, details, str(proc))

def process_snapshot(pgid, output, binaries, proc=Path("/proc"), *, probe_runner=None, reader=None):
    """普通身份先读；只为已绑定身份的EACCES候选提权核实，不忽略未知。"""
    related, unreadable, vanished, denied, candidates = [], [], [], [], []
    read = reader or read_process
    binary_names = {str(path) for path in binaries}

    def classify(row):
        identity = row["identity"]
        arguments = identity["argv"]
        if (identity["pgid"] == pgid or str(output) in arguments or identity["exe"] in binary_names
                or any(argument in binary_names for argument in arguments)
                or any(Path(argument).name in {'s0_daemon','s1_daemon','robot_rpc_gateway','xlerobot_deploy',
                       'supervised_demo','comm_fault_e2e','feetech_poke','post_e_shutdown'} for argument in arguments)):
            related.append(identity)

    for path in proc.iterdir():
        if not path.name.isdigit() or int(path.name) == os.getpid():
            continue
        pid = int(path.name)
        basic = read(pid, details=False, proc=proc)
        if basic["status"] == "vanished":
            vanished.append(basic)
            continue
        if basic["status"] != "observed":
            unreadable.append(basic)
            continue
        identity = basic["identity"]
        if identity["pgid"] != pgid and os.getuid() not in identity["uids"]:
            continue
        row = read(pid, expected=identity, proc=proc)
        if row["status"] == "observed":
            classify(row)
        elif row["status"] == "permission":
            denied.append(row)
            candidates.append(identity)
        elif row["status"] == "vanished":
            vanished.append(row)
        else:
            unreadable.append(row)
    probe = None
    if candidates:
        try:
            require(len(candidates) <= 256, "拒读PID数量超过有限批次")
            # 临时proc夹具不会意外访问宿主机sudo；测试必须显式提供后端。
            require(proc == Path("/proc") or probe_runner is not None, "非真实proc需要显式只读探针夹具")
            probe = (probe_runner or privileged_process_probe)(candidates)
            require(isinstance(probe, dict) and not probe.get("error") and probe.get("exit_code") == 0, "只读PID探针失败")
            response = probe["response"]
            require(isinstance(response, dict) and response["schema"] == "P7_PROC_PROBE_V1" and response["reader_euid"] == 0
                    and all(response["boot_id"] == row["boot_id"] for row in candidates), "探针格式/权限/boot错误")
            rows = response["rows"]
            require(isinstance(rows, list) and all(isinstance(r, dict) for r in rows)
                    and len(rows) == len(candidates) and [r["pid"] for r in rows] == [r["pid"] for r in candidates], "探针PID批次不对应")
            for expected, row in zip(candidates, rows):
                status = row["status"]
                if status == "observed":
                    require(isinstance(row.get("identity"), dict) and isinstance(row.get("before"), dict)
                            and isinstance(row.get("after"), dict), "探针缺完整身份记录")
                    require(_PROC_READER["_stable"](expected, row["before"])
                            and _PROC_READER["_stable"](expected, row["after"])
                            and _PROC_READER["_stable"](expected, row["identity"]), "探针PID/start/boot身份不对应")
                    require(isinstance(row["identity"]["argv"], list)
                            and all(isinstance(a, str) for a in row["identity"]["argv"])
                            and (isinstance(row["identity"]["exe"], str) and row["identity"]["exe"].startswith("/")
                                 or row["identity"]["exe"] is None and row["identity"].get("zombie") is True and row["identity"]["state"] == "Z"), "探针exe/argv不完整")
                    classify(row)
                elif status == "vanished":
                    require("before" not in row or _PROC_READER["_stable"](expected, row["before"]), "消失回执身份不符")
                    vanished.append({"expected": expected, "probe": row})
                else:
                    unreadable.append({"expected": expected, "probe": row})
        except (OSError, ValueError, KeyError, TypeError, IndexError, subprocess.SubprocessError) as error:
            unreadable.extend({"pid": row["pid"], "expected": row, "error": repr(error)} for row in candidates)
    return {"related": related, "unreadable": unreadable, "vanished": vanished,
            "ordinary_denied": denied, "privileged_probe": probe, "clean": not related and not unreadable}
