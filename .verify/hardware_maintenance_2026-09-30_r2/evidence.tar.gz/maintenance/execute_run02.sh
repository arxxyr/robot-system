set -eu
export PATH=/home/loosqk/.cargo/bin:/home/loosqk/.local/bin:$PATH
cd /home/loosqk/robot-checks/hardware-verify-20260930-r2/maintenance
MAINTENANCE_PYTHON="$(uv python find 3.12)"
"$MAINTENANCE_PYTHON" - <<'END_PY'
import base64,hashlib,json,os
from pathlib import Path
assert os.uname().machine=='aarch64' and os.getuid()==os.geteuid()==1000
assert Path('/proc/sys/kernel/random/boot_id').read_text().strip()=='6cf7ee3e-a3c5-4c91-80bc-4ca924818b53'
assert hashlib.sha256(Path('run_maintenance.py').read_bytes()).hexdigest()=='791079cfc1abfa5eab72d8acfbf6be78146423e7d7dfd2b0c7e759158600f048'
import run_maintenance as m
plan=m.make_plan(m.strict_json(Path('bindings.json').read_text()),'/home/loosqk/robot-checks/hardware-verify-20260930-r2/run-02','hardware-r2-run-02')
raw=base64.b64decode('ewogICJzY2hlbWEiOiAiTUFJTlRFTkFOQ0VfR09fVjEiLAogICJpc3N1ZWRfYnkiOiAicm9vdCIsCiAgInBsYW5fc2hhMjU2IjogImQ4MTAxZjRlYWFlY2Q1NjI3NTVmMTE2YjY4ZGY3OTkzYmY4NmNjYzViMWUxZmE0YjRiZDE4MDExNzcxYzRhNDkiLAogICJpc3N1ZWRfYXRfbnMiOiAxNzkwODAyNjg3NTYzNTU0MDAwLAogICJleHBpcmVzX2F0X25zIjogMTc5MDgwMzU4NzU2MzU1NDAwMCwKICAiaG9zdCI6IHsKICAgICJob3N0bmFtZSI6ICJ1YnVudHUiLAogICAgInVpZCI6IDEwMDAsCiAgICAiZ2lkIjogMTAwMCwKICAgICJib290X2lkIjogIjZjZjdlZTNlLWEzYzUtNGM5MS04MGJjLTRjYTkyNDgxOGI1MyIKICB9LAogICJzb3VyY2UiOiAi55So5oi35pys5qyh5piO56Gu5Zue5aSN4oCc5YWo6YOo5bey6YeN5paw5bCx57uq77yM5Y+v5oyB57ut55yL5oqk4oCd77yM56Gu6K6k5pat55S15aSN5L2NL1VTQuOAgeWPjOiHguepuui9veaUr+aSkeOAgea0u+WKqOWMuuepuuaXt+OAgeWcsOmdouW6leebmOS4juaMgee7reeci+aKpOeri+WNs+S6uuW3peWIh+eUte+8m+maj+WQjuimgeaxguW6leebmOaMieeFp1hMZVJvYm905qih5byP44CC5bey5pyJ55u05o6l5o6I5p2D5oyB57ut5pyJ5pWI44CCIiwKICAicGh5c2ljYWwiOiB7CiAgICAibGVmdCI6IHsKICAgICAgIm1vdG9yX3Bvd2VyX2N5Y2xlIjogdHJ1ZSwKICAgICAgInVzYl9yZXBsdWciOiB0cnVlLAogICAgICAic3VwcG9ydGVkIjogdHJ1ZSwKICAgICAgInVubG9hZGVkIjogdHJ1ZSwKICAgICAgImFyZWFfY2xlYXIiOiB0cnVlLAogICAgICAiYmFzZV9vbl9ncm91bmRfd2l0aF9zcGFjZSI6IHRydWUsCiAgICAgICJjb250aW51b3VzX3ByZXNlbmNlX3VudGlsX2NsZWFudXAiOiB0cnVlLAogICAgICAiaW1tZWRpYXRlX3Bvd2VyX2N1dCI6IHRydWUsCiAgICAgICJjb25maXJtZWRfYXRfbnMiOiAxNzkwNzk5NTc1MDAwMDAwMDAwLAogICAgICAiY29uZmlybWVkX2F0X3NlbWFudGljcyI6ICLnlKjmiLfmnKzmrKHlhajpg6jlsLHnu6rnrZTlpI3kuYvliY3lt7Lop4LmtYvnmoRVVEPkuIvnlYzvvIzkuI3lhpLlhYXnsr7noa7nrZTlpI3ml7bpl7QiCiAgICB9LAogICAgInJpZ2h0IjogewogICAgICAibW90b3JfcG93ZXJfY3ljbGUiOiB0cnVlLAogICAgICAidXNiX3JlcGx1ZyI6IHRydWUsCiAgICAgICJzdXBwb3J0ZWQiOiB0cnVlLAogICAgICAidW5sb2FkZWQiOiB0cnVlLAogICAgICAiYXJlYV9jbGVhciI6IHRydWUsCiAgICAgICJiYXNlX29uX2dyb3VuZF93aXRoX3NwYWNlIjogdHJ1ZSwKICAgICAgImNvbnRpbnVvdXNfcHJlc2VuY2VfdW50aWxfY2xlYW51cCI6IHRydWUsCiAgICAgICJpbW1lZGlhdGVfcG93ZXJfY3V0IjogdHJ1ZSwKICAgICAgImNvbmZpcm1lZF9hdF9ucyI6IDE3OTA3OTk1NzUwMDAwMDAwMDAsCiAgICAgICJjb25maXJtZWRfYXRfc2VtYW50aWNzIjogIueUqOaIt+acrOasoeWFqOmDqOWwsee7quetlOWkjeS5i+WJjeW3suingua1i+eahFVUQ+S4i+eVjO+8jOS4jeWGkuWFheeyvuehruetlOWkjeaXtumXtCIKICAgIH0KICB9Cn0K',validate=True)
assert hashlib.sha256(raw).hexdigest()=='07ce480553b781daab73c6b6f5b98065824749bdbeabcb04d82e1e5a46deded2'
assert m.digest(plan)==json.loads(raw)['plan_sha256']
with Path('root-go-run02.json').open('xb') as f: f.write(raw)
assert Path('root-go-run02.json').read_bytes()==raw
m.write_new(Path('plan_remote_run02.json'),{'result':'PLAN_ONLY','actions_started':0,'plan_sha256':m.digest(plan),'plan':plan})
print(json.dumps({'GO_sha256':hashlib.sha256(raw).hexdigest(),'plan_sha256':m.digest(plan),'hardware_actions_before_entry':0}),flush=True)
END_PY
exec taskset -c 0-3 "$MAINTENANCE_PYTHON" run_maintenance.py --bindings bindings.json --output /home/loosqk/robot-checks/hardware-verify-20260930-r2/run-02 --run-id hardware-r2-run-02 --execute --approval /home/loosqk/robot-checks/hardware-verify-20260930-r2/maintenance/root-go-run02.json
