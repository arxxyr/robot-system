set -eu
set -C
export PATH=/home/loosqk/.cargo/bin:/home/loosqk/.local/bin:$PATH
cd /home/loosqk/robot-checks/hardware-verify-20260930-r2/maintenance
uv run --no-project --python 3.12 python -m unittest -v test_maintenance > selftest_remote_r4.stdout 2> selftest_remote_r4.stderr
uv run --no-project --python 3.12 python run_maintenance.py --bindings bindings.json --output /home/loosqk/robot-checks/hardware-verify-20260930-r2/run-01 --run-id hardware-r2-run-01 > plan_remote_r4.json
cat plan_remote_r4.json
