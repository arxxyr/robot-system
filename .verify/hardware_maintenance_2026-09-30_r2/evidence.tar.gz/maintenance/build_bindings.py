"""爸爸，读取本机既有原件构造绑定；不连接Orin，不写硬件，不生成GO。"""
import argparse
import hashlib
import json
from pathlib import Path

def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--prep',type=Path,required=True)
    parser.add_argument('--output',type=Path,required=True)
    args=parser.parse_args()
    prep=args.prep
    rawpath=prep/'probe_r2.owner/child.log'
    raw=rawpath.read_bytes()
    assert hashlib.sha256(raw).hexdigest()=='40305db5481d550c19e0c2217becddc42d907bf0ae399ac3a7fbb24b2357b105'
    r=json.loads(raw)
    upraw=(prep/'upstream_verification.json').read_bytes(); up=json.loads(upraw)
    calroot=prep/'upstream_extracted_r2/dimensional-applications/calibration'
    for ref in up['files']:
        local=prep/'upstream_extracted_r2/dimensional-applications'/ref['path'].split('/dimensional-applications/',1)[1]
        data=local.read_bytes()
        assert len(data)==ref['bytes'] and hashlib.sha256(data).hexdigest()==ref['sha256']
    l=json.loads((calroot/'left_arm.json').read_text())
    rr=json.loads((calroot/'right_arm.json').read_text())
    h=json.loads((calroot/'head.json').read_text())
    helper=Path(__file__).with_name('proc_identity.py'); data=helper.read_bytes()
    helper_ref={'path':'/home/loosqk/robot-checks/hardware-verify-20260930-r2/maintenance/proc_identity.py',
                'sha256':hashlib.sha256(data).hexdigest(),'bytes':len(data)}
    usb={}
    for side,d in r['before']['devices'].items():
        fields=dict(line.split('=',1) for line in d['udev_command']['stdout'].splitlines() if '=' in line)
        usb[side]={k:d[k] for k in ('device','resolved','rdev','mode','uid','gid')}
        usb[side].update(serial=fields['ID_SERIAL_SHORT'],devpath=fields['DEVPATH'],usec_initialized=fields['USEC_INITIALIZED'])
    bindings={'schema':'MAINTENANCE_BINDINGS_V1',
              'host':{'hostname':r['identity']['hostname'],'uid':1000,'gid':1000,'boot_id':r['identity']['boot_id']},
              'tool':r['before']['elf'],'usb':usb,'protection':r['before']['protection'],
              'refs':list(r['before']['formal']['files'].values())+up['files']+[helper_ref],
              'proc_helper':helper_ref,
              'binary_paths':[v['path'] for k,v in r['before']['formal']['files'].items() if k.startswith('installed:')]+[r['before']['elf']['path']],
              'calibrations':{'left_arm_wrist_roll':l['left_arm_wrist_roll'],'right_arm_wrist_roll':rr['right_arm_wrist_roll'],**h},
              'origin':{'readback_sha256':'3775fae57273b44ddb2ce98b6c266e4acffc4f4df693c562de0d69aa506d700e',
                        'upstream_index_sha256':hashlib.sha256(upraw).hexdigest(),
                        'hardware_authorization':'none; root must issue current GO for exact plan'}}
    with args.output.open('x') as f:json.dump(bindings,f,ensure_ascii=False,indent=2);f.write('\n')
    print(hashlib.sha256(args.output.read_bytes()).hexdigest())

if __name__=='__main__':main()
