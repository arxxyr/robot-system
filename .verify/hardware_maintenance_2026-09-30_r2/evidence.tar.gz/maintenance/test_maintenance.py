"""爸爸，维护收尾确定性测试；只用假寄存器及自有短命子进程，不访问硬件。"""
import contextlib
import copy
import io
import json
from pathlib import Path
import signal
import subprocess
import sys
import tempfile
import threading
import unittest
from unittest.mock import patch

import run_maintenance as m

PLAN = {'position_delta_raw':24,'minimum_excursion_raw':12,'return_tolerance_raw':4,
        'position_wait_ms':800,'base_raw':[20,-20],'pulse_target_ms':150,
        'nonzero_window_fail_ns':1_000_000_000,'observed_velocity_raw_max':40,
        'observed_wheel_delta_raw_min':3,'observed_wheel_delta_raw_max':64}
CALI = {'id':5,'range_min':73,'range_max':3864}


class FakeIO:
    def __init__(self, fail_at=None, *, stuck=False, velocity=None, delta=None, step=None):
        self.t=0; self.normal=0; self.fail_at=fail_at; self.stuck=stuck
        self.velocity=velocity; self.delta=delta; self.calls=[]; self.fail_cleanup=set()
        self.position=1000; self.goal=1000; self.torque=0; self.goal_velocity=0
        self.mode=0; self.drift=0; self.slow=False
        self.step=step

    def now(self): return self.t
    def check(self): pass

    def checkpoint(self, cleanup):
        if not cleanup:
            self.normal+=1
            if self.normal==self.fail_at:
                raise RuntimeError('注入：动作已生效而回执/控制点失败')

    def sleep(self, seconds, cleanup=False):
        self.calls.append(('sleep',seconds,cleanup))
        self.t+=int(seconds*1e9)
        if not cleanup and self.slow and seconds==0.15: self.t+=1_000_000_000
        if not cleanup and seconds==0.05 and self.t==70_000_000: self.position+=self.drift
        if cleanup and 'sleep' in self.fail_cleanup: raise RuntimeError('cleanup sleep失败')
        self.checkpoint(cleanup)

    def poke(self, side, motor, action, register, value=None, cleanup=False):
        self.calls.append((side,motor,action,register,value,cleanup))
        # 先实施真实副作用，再注入ACK/wait错误，验证不确定写也必定停机。
        if action=='write':
            if register=='Torque_Enable': self.torque=value
            elif register=='Goal_Position': self.goal=value
            elif register=='Goal_Velocity': self.goal_velocity=value
            else: raise AssertionError('禁止的维护写')
        if cleanup and register in self.fail_cleanup: raise RuntimeError('cleanup寄存器失败')
        self.checkpoint(cleanup)
        if action=='write': return None
        if register=='Operating_Mode': return self.mode
        if register=='Torque_Enable': return self.torque
        if register=='Goal_Position': return self.goal
        if register=='Goal_Velocity': return self.goal_velocity
        if register=='Present_Velocity':
            return (self.velocity if self.velocity is not None else self.goal_velocity) if self.torque else 0
        if register=='Present_Position':
            if self.torque and not self.stuck:
                if self.mode==0:
                    difference=self.goal-self.position
                    self.position+=difference if self.step is None else max(-self.step,min(self.step,difference))
                elif self.goal_velocity:
                    self.position=(self.position+(self.delta if self.delta is not None else (6 if self.goal_velocity>0 else -6)))%4096
            return self.position
        raise AssertionError(register)


class ProbeTests(unittest.TestCase):
    def quiet(self): return contextlib.redirect_stdout(io.StringIO())

    def test_position_and_wheel_positive(self):
        a=FakeIO(); e=m.ProbeEngine(a,PLAN)
        e.position('left',5,'left_arm_wrist_roll',CALI)
        self.assertEqual(e.rows[0]['status'],'PASS'); self.assertEqual((a.torque,a.position,a.goal),(0,1000,1000))
        a=FakeIO(); a.mode=1; e=m.ProbeEngine(a,PLAN); e.wheel(8)
        self.assertEqual(e.rows[0]['status'],'PASS'); self.assertEqual((a.torque,a.goal_velocity),(0,0))
        self.assertEqual([p['delta_raw'] for p in e.rows[0]['pulses']],[6,-6])
        self.assertTrue(all(p['zero_write_confirmed'] for p in e.rows[0]['pulses']))

    def test_every_position_action_point_stops_after_applied_write(self):
        baseline=FakeIO(step=8); m.ProbeEngine(baseline,PLAN).position('left',5,'wrist',CALI)
        cases=0
        for index in range(1,baseline.normal+1):
            a=FakeIO(index,step=8); e=m.ProbeEngine(a,PLAN)
            with self.subTest(index=index),self.quiet(),self.assertRaises(ValueError):
                e.position('left',5,'wrist',CALI)
            self.assertEqual(a.torque,0)
            self.assertIn(('left',5,'write','Torque_Enable',0,True),a.calls)
            self.assertEqual(e.rows[0]['status'],'FAIL'); cases+=1
        self.assertEqual(cases,baseline.normal)

    def test_normal_multiread_outward_and_return_movement(self):
        a=FakeIO(step=8); e=m.ProbeEngine(a,PLAN)
        e.position('left',5,'wrist',CALI)
        self.assertEqual([s['position_raw'] for s in e.rows[0]['outward']],[1008,1016,1024])
        self.assertEqual([s['position_raw'] for s in e.rows[0]['return']],[1016,1008,1000])
        self.assertEqual(e.rows[0]['status'],'PASS'); self.assertEqual(a.torque,0)

    def test_every_wheel_action_point_zero_then_off_after_applied_write(self):
        baseline=FakeIO(); baseline.mode=1; m.ProbeEngine(baseline,PLAN).wheel(8)
        for index in range(1,baseline.normal+1):
            a=FakeIO(index); a.mode=1; e=m.ProbeEngine(a,PLAN)
            with self.subTest(index=index),self.quiet(),self.assertRaises(ValueError): e.wheel(8)
            self.assertEqual((a.torque,a.goal_velocity),(0,0))
            self.assertIn(('right',8,'write','Goal_Velocity',0,True),a.calls)
            self.assertIn(('right',8,'write','Torque_Enable',0,True),a.calls)
            self.assertEqual(e.rows[0]['status'],'FAIL')

    def test_cleanup_errors_never_skip_independent_torqueoff(self):
        for failure in ('Goal_Velocity','Torque_Enable','Present_Velocity','sleep'):
            a=FakeIO(); a.mode=1; a.fail_cleanup={failure}; e=m.ProbeEngine(a,PLAN)
            with self.subTest(failure=failure),self.quiet(),self.assertRaises(ValueError): e.wheel(8)
            self.assertIn(('right',8,'write','Torque_Enable',0,True),a.calls)
            self.assertTrue(e.manual_cut)
            self.assertEqual(e.rows[0]['status'],'FAIL')

    def test_zero_position_motion_fails(self):
        a=FakeIO(stuck=True); e=m.ProbeEngine(a,PLAN)
        with self.quiet(),self.assertRaises(ValueError): e.position('left',5,'wrist',CALI)
        self.assertEqual(a.torque,0); self.assertEqual(e.rows[0]['status'],'FAIL')

    def test_wheel_observed_velocity_and_delta_limits_fail_and_stop(self):
        for velocity,delta in [(0,None),(1000,None),(-20,None),(None,0),(None,2),(None,-6),(None,65)]:
            a=FakeIO(velocity=velocity,delta=delta); a.mode=1; e=m.ProbeEngine(a,PLAN)
            with self.subTest(velocity=velocity,delta=delta),self.quiet(),self.assertRaises(ValueError): e.wheel(8)
            self.assertEqual((a.torque,a.goal_velocity),(0,0))
            self.assertEqual(len(e.rows[0]['pulses']),1)

    def test_modular_encoder_both_wrap_directions(self):
        for start,sign in [(4093,20),(2,-20)]:
            a=FakeIO(); a.mode=1; a.torque=1; a.position=start; e=m.ProbeEngine(a,PLAN)
            pulse=e.pulse(8,sign)
            self.assertEqual(pulse['status'],'PASS'); self.assertEqual(pulse['delta_raw'],6 if sign>0 else -6)

    def test_long_actual_nonzero_window_fails_not_sleep_claim(self):
        a=FakeIO(); a.mode=1; a.slow=True; e=m.ProbeEngine(a,PLAN)
        with self.quiet(),self.assertRaises(ValueError): e.wheel(8)
        self.assertGreater(e.rows[0]['pulses'][0]['nonzero_window_ns'],1_000_000_000)
        self.assertEqual((a.torque,a.goal_velocity),(0,0))

    def test_mode_calibration_and_anchor_drift_refuse_enable(self):
        for mode,cali,drift in [(1,CALI,0),(0,{**CALI,'id':6},0),(0,{**CALI,'range_max':1010},0),(0,CALI,5)]:
            a=FakeIO(); a.mode=mode; a.drift=drift; e=m.ProbeEngine(a,PLAN)
            with self.subTest(mode=mode,cali=cali,drift=drift),self.quiet(),self.assertRaises(ValueError): e.position('left',5,'wrist',cali)
            self.assertNotIn(('left',5,'write','Torque_Enable',1,False),a.calls)

    def test_failure_prevents_next_motor(self):
        a=FakeIO(fail_at=10); e=m.ProbeEngine(a,PLAN)
        with self.quiet(),self.assertRaises(ValueError):
            e.position('left',5,'wrist',CALI)
            e.wheel(8)
        self.assertEqual(len(e.rows),1)

    def test_final_snapshot_rejects_unexpected_changes_and_unsafe_readback(self):
        rows={}
        for side in m.SERIALS:
            for motor in range(1,9 if side=='left' else 10):
                rows[f'{side}:{motor}']={r:0 for r in m.REGS}
                rows[f'{side}:{motor}']['Operating_Mode']=1 if side=='right' and motor>=7 else 0
                rows[f'{side}:{motor}']['Present_Position']=1000
        m.validate_snapshot(rows)
        for reg,value in [('Torque_Enable',1),('Goal_Velocity',20),('Present_Velocity',2),('Goal_Position',1),('Present_Position',1005),('Operating_Mode',1)]:
            changed=copy.deepcopy(rows); changed['left:1'][reg]=value
            with self.subTest(reg=reg),self.assertRaises(ValueError): m.validate_snapshot(changed,rows)


class OwnerTests(unittest.TestCase):
    def make_io(self,d): return m.RealExecutor({'path':'/not-hardware/fake'},Path(d))

    def test_actual_child_signal_request_wait_and_reap_without_kill(self):
        with tempfile.TemporaryDirectory() as d:
            e=self.make_io(d); timer=threading.Timer(.02,e.mark_signal,args=(signal.SIGHUP,None)); timer.start()
            with self.assertRaises(ValueError): e.command([sys.executable,'-c','import time;time.sleep(.08);print("ok")'])
            timer.join(); self.assertIsNone(e.child)
            self.assertTrue(e.commands[0]['reaped']); self.assertEqual(e.commands[0]['signals_sent'],[])
            self.assertEqual(e.command([sys.executable,'-c','print("stop")'],cleanup=True),'stop\n')
            e.journal.close()

    def test_wait_exception_keeps_actual_child_then_allows_cleanup(self):
        real_popen=subprocess.Popen
        class WaitOnce:
            def __init__(self,*args,**kwargs): self.raw=real_popen(*args,**kwargs); self.pid=self.raw.pid; self.fail=True
            def wait(self,timeout):
                if self.fail: self.fail=False; raise OSError('真实child已启动后wait注入错误')
                return self.raw.wait(timeout=timeout)
        with tempfile.TemporaryDirectory() as d,patch.object(m.subprocess,'Popen',WaitOnce):
            e=self.make_io(d)
            with self.assertRaises(ValueError): e.command([sys.executable,'-c','print("ok")'])
            self.assertIsNone(e.child); self.assertTrue(e.commands[0]['reaped'])
            self.assertTrue(e.commands[0]['owner_errors'])
            with self.assertRaises(ValueError): e.command([sys.executable,'-c','print("cleanup")'],cleanup=True)
            self.assertTrue(e.commands[1]['reaped']); e.journal.close()

    def test_stderr_and_evidence_failure_are_sticky_after_reap(self):
        with tempfile.TemporaryDirectory() as d:
            e=self.make_io(d)
            with self.assertRaises(ValueError): e.command([sys.executable,'-c','import sys;print("error",file=sys.stderr)'])
            self.assertIsNone(e.child); self.assertTrue(e.commands[0]['reaped'])
            e.journal.close()
            with self.assertRaises(ValueError): e.command([sys.executable,'-c','print("stopped")'],cleanup=True)
            self.assertTrue(e.commands[1]['reaped']); self.assertIsNone(e.child)

    def test_default_plan_only_never_spawns(self):
        with patch.object(m.subprocess,'Popen',side_effect=AssertionError('PLAN_ONLY不许启动child')),contextlib.redirect_stdout(io.StringIO()) as output:
            self.assertEqual(m.main([]),0)
        self.assertEqual(json.loads(output.getvalue())['actions_started'],0)

    def test_actual_cli_default_plan_only_exit_zero(self):
        child=subprocess.Popen([sys.executable,str(Path(m.__file__))],stdout=subprocess.PIPE,stderr=subprocess.PIPE)
        out,err=child.communicate()
        self.assertEqual(child.wait(),0); self.assertEqual(err,b'')
        self.assertEqual(json.loads(out)['actions_started'],0)

    def test_go_rejects_wrong_plan_missing_facts_and_expiration(self):
        plan={'bindings':{'host':{'boot_id':'test'}}}
        go={'schema':'MAINTENANCE_GO_V1','issued_by':'root','plan_sha256':m.digest(plan),
            'issued_at_ns':100,'expires_at_ns':1000,'host':plan['bindings']['host'],'source':'当次用户现场答复',
            'physical':{s:{**{f:True for f in m.FACTS},'confirmed_at_ns':100} for s in m.SERIALS}}
        m.validate_go(go,plan,200)
        for change in ('digest','facts','expire'):
            bad=copy.deepcopy(go)
            if change=='digest':bad['plan_sha256']='0'*64
            if change=='facts':bad['physical']['left']['supported']=False
            if change=='expire':bad['expires_at_ns']=150
            with self.subTest(change=change),self.assertRaises(ValueError):m.validate_go(bad,plan,200)

    def test_strict_poke_stdout_rejects_extra_lines(self):
        with tempfile.TemporaryDirectory() as d:
            e=self.make_io(d)
            with patch.object(m,'verify_ref'),patch.object(e,'command',return_value='extra\nread Goal_Velocity@8 = -20\n'):
                with self.assertRaises(ValueError):e.poke('right',8,'read','Goal_Velocity')
            with patch.object(m,'verify_ref'),patch.object(e,'command',return_value='read Goal_Velocity@8 = -20\n'):
                self.assertEqual(e.poke('right',8,'read','Goal_Velocity'),-20)
            e.journal.close()


if __name__=='__main__': unittest.main(verbosity=2)
