set -eu
export PATH=/home/loosqk/.cargo/bin:/home/loosqk/.local/bin:$PATH
PROBE_PYTHON="$(uv python find 3.12)"
exec taskset -c 0-3 "$PROBE_PYTHON" - <<'END_PY'
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import re
import signal
import stat
import struct
import subprocess
import sys
import time
sys.dont_write_bytecode=True
BASE=Path('/home/loosqk/robot-checks/h2-serial-recovery-20260930-r1')
ROOT=BASE/'source'
FORMAL=Path('/home/loosqk/repo/robot/robot-system')
ELF=BASE/'readback-tool-r1/feetech_poke'
ELF_SHA='f2014ee4008311e7a8725235a39f0d1b3913391f17cbd977b7441f120539114b'
result={'schema':'HARDWARE_READ_ONLY_PREP_R2_V1','read_only':True,'status':'RUNNING','started_ns':time.time_ns(),'commands':[],'checks':[],'reads':[],'errors':[],'received_signals':[],'hardware_writes':0,'physical_facts_source':'root received current user confirmation; not inferred by software'}
stop=False
def require(value,message):
 if not value: raise ValueError(message)
def handler(signum,frame):
 global stop
 stop=True
 result['received_signals'].append({'name':signal.Signals(signum).name,'at_ns':time.time_ns()})
for sig in (signal.SIGINT,signal.SIGTERM,signal.SIGHUP,signal.SIGQUIT): signal.signal(sig,handler)
def command(argv,code=0,input_raw=None):
 require(not stop,'已收到停止信号，不启动后续命令')
 row={'argv':[str(a) for a in argv],'started_ns':time.time_ns(),'pid':None,'reaped':False,'signals_sent':[]}
 result['commands'].append(row)
 child=subprocess.Popen(row['argv'],stdin=subprocess.PIPE if input_raw is not None else subprocess.DEVNULL,stdout=subprocess.PIPE,stderr=subprocess.PIPE,start_new_session=True,env={**os.environ,'GIT_OPTIONAL_LOCKS':'0','LC_ALL':'C'})
 row['pid']=child.pid
 # communicate 不设置总超时；它持有当前 child 并完成真实 wait，不发信号。
 stdout,stderr=child.communicate(input_raw)
 row.update(exit_code=child.returncode,reaped=True,finished_ns=time.time_ns(),child_end_class='EXIT_STATUS' if child.returncode>=0 else 'SIGNAL',stdout=stdout.decode(errors='replace'),stderr=stderr.decode(errors='replace'),stdout_sha256=hashlib.sha256(stdout).hexdigest(),stderr_sha256=hashlib.sha256(stderr).hexdigest(),stdout_bytes=len(stdout),stderr_bytes=len(stderr))
 require(child.returncode==code and stderr==b'','只读命令失败：'+repr(row))
 return row,stdout
def read_regular(path):
 require(path.is_absolute() and path==path.resolve(),'非规范文件路径')
 before=path.lstat()
 require(stat.S_ISREG(before.st_mode) and before.st_nlink==1,'非独占普通文件')
 fd=os.open(path,os.O_RDONLY|os.O_NOFOLLOW|os.O_CLOEXEC)
 try:
  opened=os.fstat(fd)
  require((before.st_dev,before.st_ino)==(opened.st_dev,opened.st_ino),'文件身份变化')
  with os.fdopen(fd,'rb',closefd=False) as stream: raw=stream.read()
  after=os.fstat(fd)
  require((opened.st_size,opened.st_mtime_ns,opened.st_ctime_ns)==(after.st_size,after.st_mtime_ns,after.st_ctime_ns),'读取期间文件变化')
 finally: os.close(fd)
 return raw
def pin(path,sha):
 raw=read_regular(path); require(hashlib.sha256(raw).hexdigest()==sha,'SHA变化：'+str(path)); return json.loads(raw)
def check(name,fn):
 row={'name':name,'status':'FAIL','started_ns':time.time_ns()}; result['checks'].append(row)
 row['value']=fn(); row.update(status='PASS',finished_ns=time.time_ns()); return row['value']
def elf_identity():
 raw=read_regular(ELF)
 require(hashlib.sha256(raw).hexdigest()==ELF_SHA and len(raw)==1469904 and raw[:6]==b'\x7fELF\x02\x01' and struct.unpack_from('<H',raw,18)[0]==183 and os.access(ELF,os.X_OK),'冻结READ ELF身份变化')
 return {'path':str(ELF),'sha256':ELF_SHA,'bytes':len(raw),'elf_machine':183}
try:
 require(os.uname().machine=='aarch64' and os.getuid()==os.geteuid()==1000,'Orin架构/运行身份错误')
 result['identity']={'hostname':os.uname().nodename,'uid':os.getuid(),'euid':os.geteuid(),'machine':os.uname().machine,'boot_id':Path('/proc/sys/kernel/random/boot_id').read_text().strip(),'python':sys.version}
 helper=BASE/'bootstrap/s52-control-helper-r1/prelaunch_go.py'
 require(hashlib.sha256(read_regular(helper)).hexdigest()=='8121c8e8454d5a06dfa1f828ca85417917a0cdcd756d222717af89adf1024b77','既验helper身份改变')
 sys.path.insert(0,str(helper.parent))
 from prelaunch_go import tracked_driver,reference
 # 已冻结旧source只作只读门实现来源；不使用新SLA开发候选。
 driver,hashes=tracked_driver(ROOT/'scripts/run_post_e_h2.py',ROOT,'4a8e171f27bf18625973aa4f3a6097e9b9fbed18')
 result['driver_helpers']=hashes
 inputs=pin(BASE/'bootstrap/s52-right-inputs-r1.json','541d7f463948cfb5393dbf1a8fe20be648c6e550f014caa4245d4b446dbcbff7')
 manifests={kind:reference(inputs[kind]) for kind in ('production','measurement','installed')}
 binaries=[Path(r['path']) for kind in ('production','measurement') for r in manifests[kind]['artifacts'].values()]
 binaries += [Path(r['path']) for n,r in manifests['installed']['files'].items() if n.startswith('installed:')]
 binaries.append(ELF)
 def proc_probe(candidates):
  request={'schema':'P7_PROC_PROBE_V1','candidates':candidates}
  row,raw=command(['sudo','-n','/usr/bin/python3','-I','-S','-c',driver.PROC_PROBE_CODE],input_raw=json.dumps(request).encode())
  return {'argv_prefix':row['argv'][:6],'request':request,'started_ns':row['started_ns'],'finished_ns':row['finished_ns'],'exit_code':row['exit_code'],'stdout':row['stdout'],'stderr':row['stderr'],'response':json.loads(raw)}
 def formal():
  head=command(['git','-C',str(FORMAL),'rev-parse','HEAD'])[1].decode().strip()
  status=command(['git','-C',str(FORMAL),'status','--porcelain=v1','--untracked-files=all'])[1].decode()
  require(head=='ca14f0e6cf6df8ecc6baaaa8dff2dddb64abbd0a' and status=='','正式ca14/clean变化')
  files={}
  for name,expected in manifests['installed']['files'].items():
   path=Path(expected['path']); raw=read_regular(path); m=path.stat()
   files[name]={'path':str(path),'sha256':hashlib.sha256(raw).hexdigest(),'bytes':len(raw),'uid':m.st_uid,'gid':m.st_gid,'mode':stat.S_IMODE(m.st_mode)}
   require(files[name]['sha256']==expected['sha256'] and files[name]['bytes']==expected['bytes'],'正式文件变化：'+name)
  return {'head':head,'status_porcelain':status,'files':files}
 def services():
  row,raw=command(['systemctl','show',*driver.UNITS,'--property=Id,LoadState,ActiveState,SubState,MainPID'])
  return driver.validate_services(raw.decode())
 def processes():
  snap=driver.process_snapshot(-1,BASE/'right-h2-run-01',binaries,probe_runner=proc_probe)
  require(snap['clean'],'控制/READ进程残留或身份不可读'); return snap
 def device(side):
  profile=driver.arm_profile(side)
  row,raw=command(['udevadm','info','--query=property','--name',profile.device]); lines=raw.decode().splitlines()
  for key,value in {'ID_VENDOR_ID':'1a86','ID_MODEL_ID':'55d3','ID_SERIAL_SHORT':profile.usb_serial,'ID_USB_DRIVER':'cdc_acm'}.items(): require([l for l in lines if l.startswith(key+'=')]==[key+'='+value],'USB身份错误')
  m=Path(profile.device).stat(); require(stat.S_ISCHR(m.st_mode) and os.access(profile.device,os.R_OK|os.W_OK),'USB类型/权限错误')
  return {'device':profile.device,'resolved':str(Path(profile.device).resolve()),'rdev':m.st_rdev,'mode':stat.S_IMODE(m.st_mode),'uid':m.st_uid,'gid':m.st_gid,'udev_command':row}
 def holder(path,elevated):
  require(path.exists(),'持有者路径缺失：'+str(path))
  row,raw=command((['sudo','-n'] if elevated else [])+['fuser',str(path)],1)
  require(raw==b'','串口/锁有持有者'); return row
 def protection():
  states={}
  for side in ('left','right'):
   trust=driver.arm_profile(side).trust; states[side]={}
   for name in ('rx_trust_marker','rx_trust_marker.bak','estop_latch','estop_latch.bak','rx_trust.lock','estop_latch.lock'):
    path=trust/name
    if not path.exists(): states[side][name]={'missing':True}; continue
    raw=read_regular(path); m=path.stat(); require(len(raw)<=4096,'保护文件尺寸异常')
    states[side][name]={'path':str(path),'hex':raw.hex(),'sha256':hashlib.sha256(raw).hexdigest(),'bytes':len(raw),'mode':stat.S_IMODE(m.st_mode),'uid':m.st_uid,'gid':m.st_gid,'inode':m.st_ino}
  return states
 def guard(epoch):
  value={'formal':check(epoch+'_formal',formal),'services':check(epoch+'_services',services),'processes':check(epoch+'_processes',processes),'protection':check(epoch+'_protection',protection),'elf':check(epoch+'_elf',elf_identity),'devices':{},'holders':[]}
  for side in ('left','right'):
   profile=driver.arm_profile(side); value['devices'][side]=check(epoch+'_'+side+'_device',lambda side=side:device(side))
   for path in (Path(profile.device),profile.trust/'rx_trust.lock',profile.trust/'estop_latch.lock'):
    for elevated in (False,True): value['holders'].append(check(epoch+'_'+side+'_'+path.name+('_sudo' if elevated else ''),lambda path=path,elevated=elevated:holder(path,elevated)))
  return value
 before=guard('before'); result['before']=before
 registers=('Operating_Mode','Torque_Enable','Present_Velocity','Present_Position','Goal_Position','Goal_Velocity')
 for side,count in (('left',8),('right',9)):
  for motor in range(1,count+1):
   values={}
   for register in registers:
    require(not stop,'停止后续READ'); elf_identity()
    argv=[str(ELF),driver.arm_profile(side).device,str(motor),'read',register]
    row,raw=command(argv)
    match=re.fullmatch(r'read '+register+'@'+str(motor)+r' = (-?\d+)\n',raw.decode())
    require(match is not None,'READ输出不精确')
    value=int(match.group(1)); values[register]=value
    result['reads'].append({'index':len(result['reads'])+1,'side':side,'motor_id':motor,'register':register,'value':value,'pid':row['pid'],'exit_code':row['exit_code'],'reaped':row['reaped'],'started_ns':row['started_ns'],'finished_ns':row['finished_ns'],'stdout_sha256':row['stdout_sha256']})
   require(values['Operating_Mode']==(1 if side=='right' and motor>=7 else 0),'电机实际Operating_Mode不符合拟用路径')
   require(values['Torque_Enable']==0 and values['Present_Velocity']==0,'只读基线扭矩/速度非零；拒绝后续READ')
 after=guard('after'); result['after']=after
 require(before['formal']==after['formal'] and before['services']==after['services'] and before['protection']==after['protection'] and before['elf']==after['elf'],'前后正式/服务/保护/ELF变化')
 for side in ('left','right'):
  require({k:v for k,v in before['devices'][side].items() if k!='udev_command'}=={k:v for k,v in after['devices'][side].items() if k!='udev_command'},'USB前后身份变化')
 require(len(result['reads'])==102 and not stop,'READ未完整或收信号')
 result['status']='PASS'
except BaseException as error:
 result['status']='FAIL'; result['errors'].append({'error':repr(error),'at_ns':time.time_ns()})
result.update(finished_ns=time.time_ns(),completed=len(result['reads']),limits=['仅寄存器采样与只读检查；不证明连续静止、主动运动或D15闭环','本探针不修改保护文件、不调用enable/clear/write、不启动控制服务'])
print(json.dumps(result,ensure_ascii=False,allow_nan=False),flush=True)
raise SystemExit(0 if result['status']=='PASS' else 1)
END_PY
