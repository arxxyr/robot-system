set -eu
exec /usr/bin/python3 -I -S - <<'END_PY'
import base64,hashlib,json,os,stat,subprocess,time
from pathlib import Path
result={'schema':'XLEROBOT_UPSTREAM_READ_ONLY_R1','read_only':True,'status':'FAIL','started_ns':time.time_ns(),'commands':[],'files':[],'missing_roots':[]}
def cmd(argv):
 row={'argv':argv,'started_ns':time.time_ns(),'signals_sent':[]}
 p=subprocess.Popen(argv,stdin=subprocess.DEVNULL,stdout=subprocess.PIPE,stderr=subprocess.PIPE,start_new_session=True,env={**os.environ,'GIT_OPTIONAL_LOCKS':'0'})
 out,err=p.communicate();row.update(pid=p.pid,reaped=True,exit_code=p.returncode,stdout=out.decode(errors='replace'),stderr=err.decode(errors='replace'),finished_ns=time.time_ns()); result['commands'].append(row)
 if p.returncode!=0: raise ValueError('只读源码枚举失败')
 return out
try:
 result['identity']={'hostname':os.uname().nodename,'uid':os.getuid(),'boot_id':Path('/proc/sys/kernel/random/boot_id').read_text().strip()}
 for root in (Path('/home/loosqk/repo/dimensional-applications'),Path('/home/loosqk/repo/XLeRobot'),Path('/home/loosqk/repo/robot/XLeRobot')):
  if not root.is_dir(): result['missing_roots'].append(str(root)); continue
  # 远端没有rg；退回限定仓库的os.walk，只读且不跟随目录符号链接。
  names=[]
  for current,dirs,files in os.walk(root,followlinks=False):
   dirs[:]=[d for d in dirs if d not in ('.git','.venv','node_modules','target','__pycache__') and not (Path(current)/d).is_symlink()]
   names.extend(str(Path(current)/name) for name in files)
   if len(names)>50000: raise ValueError('限定枚举超过50000文件')
  selected=[]
  for name in names:
   p=Path(name); rel=p.relative_to(root).as_posix()
   relevant=('xlerobot_dimos' in rel and (p.name in ('bus2_base.py','config.py','units.py') or '/feetech_io/' in rel and p.suffix=='.py')) or (rel.startswith('calibration/') and p.suffix=='.json') or ('XLeRobot' in str(root) and p.suffix=='.py' and ('base' in p.name.lower() or 'omni' in p.name.lower()))
   if relevant: selected.append(p)
  if len(selected)>48: raise ValueError('限定源码集合超过48')
  for p in sorted(selected):
   m=p.lstat()
   if not stat.S_ISREG(m.st_mode) or m.st_size>524288: raise ValueError('源码非普通文件或过大')
   raw=p.read_bytes(); after=p.stat()
   if (m.st_size,m.st_mtime_ns,m.st_ctime_ns)!=(after.st_size,after.st_mtime_ns,after.st_ctime_ns): raise ValueError('读取期间源码变化')
   result['files'].append({'path':str(p),'sha256':hashlib.sha256(raw).hexdigest(),'bytes':len(raw),'mode':stat.S_IMODE(m.st_mode),'content_base64':base64.b64encode(raw).decode()})
 result['status']='PASS' if result['files'] else 'FAIL'
except Exception as e:result['error']=repr(e)
result['finished_ns']=time.time_ns();print(json.dumps(result),flush=True)
raise SystemExit(0 if result['status']=='PASS' else 1)
END_PY
