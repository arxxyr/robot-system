#!/bin/bash
set -eu
export PYTHONDONTWRITEBYTECODE=1
tmux set-option -w -t "$TMUX_PANE" remain-on-exit on
exec /home/loosqk/.local/share/uv/python/cpython-3.12.13-linux-aarch64-gnu/bin/python3 /home/loosqk/robot-checks/position-return-20261010-r1/normal-read-r4/normal_read_capture_r4.py --config /home/loosqk/robot-checks/position-return-20261010-r1/normal-read-r4/config.live.json --execute > /home/loosqk/robot-checks/position-return-20261010-r1/normal-read-r4/launch-record-r4/driver.log 2>&1
