#!/bin/bash
# 本轮软件质量观察副本；无UART/GO/服务动作。
# SSH 等待同一 pane 的退出通知，通知后仍只读核验真实终态。
set -euC
umask 077
export PATH=/home/loosqk/.cargo/bin:/home/loosqk/.local/bin:$PATH
base=/home/loosqk/robot-checks/position-return-20261010-r1
record="$base/normal-read-r4/launch-record-r4b/observer-event-r4b"
mkdir "$record"
printf '%s\n' '%51 619231 @51' > "$record/pane.txt"
read -r pane driver_pid window < "$record/pane.txt"
case "$pane" in %[0-9]*) ;; *) exit 2;; esac
case "$driver_pid" in ''|*[!0-9]*) exit 2;; esac
# 同一服务器的 pane_id 不复用；同一记录目录的 observer PID 文件不覆盖。
# 每个观察者有自己的 indexed hook/channel，续接不覆盖旧 waiter。
observer=$$
channel="quality.pane.${pane#%}.driver.$driver_pid.observer.$observer"
hook="pane-died[$observer]"
printf '%s\n' "$channel" > "$record/observer-$observer.channel"
before_hooks=$(tmux show-hooks -p -t "$pane")
printf '%s\n' "$before_hooks" > "$record/observer-$observer.hooks-before"
while read -r hook_name hook_command; do
  if [ "$hook_name" = "$hook" ]; then exit 2; fi
done <<< "$before_hooks"
cleanup_hook() {
  tmux set-hook -pu -t "$pane" "$hook"
}
trap cleanup_hook EXIT
tmux set-hook -p -t "$pane" "$hook" "wait-for -S $channel"
tmux show-hooks -p -t "$pane" > "$record/observer-$observer.hooks-after"
observe() {
  state=$(tmux display-message -p -t "$pane" '#{pane_id} #{pane_pid} #{pane_dead} #{pane_dead_status}')
  printf '%s\n' "$state" >> "$record/observer-$observer.log"
  read -r observed_pane observed_pid dead status <<< "$state"
  test "$observed_pane" = "$pane"
  test "$observed_pid" = "$driver_pid"
}
# 挂钩后查询：先退出的 pane 直接核验；查询到存活后的退出由 channel 留存通知。
observe
if [ "$dead" = 0 ]; then
  tmux wait-for "$channel"
  observe
fi
# 提前或错误通知不能变成 PASS，也不再次等待/启动。
if [ "$dead" != 1 ]; then exit 2; fi
printf '%s\n' "$state" > "$record/observer-$observer.terminal"
    case "$status" in 0|1|2) ;; *) exit 2;; esac
    /home/loosqk/.local/share/uv/python/cpython-3.12.13-linux-aarch64-gnu/bin/python3 - "$base/normal-read-r4/evidence-r4b/run.json" "$driver_pid" "$status" <<'PYREMOTE'
import hashlib,json,sys
from pathlib import Path
p=Path(sys.argv[1]);status=int(sys.argv[3])
if not p.exists():
 print(json.dumps({'status':'NORMAL_READ_R4B_ENTRY_TERMINAL','pane_pid':int(sys.argv[2]),'pane_exit':status,'run_exists':False},ensure_ascii=False),flush=True)
else:
 raw=p.read_bytes();j=json.loads(raw)
 assert j['pid']==int(sys.argv[2]) and status==(0 if j['status']=='PASS_NORMAL_READ_CAPTURE_2' else 1)
 print(json.dumps({'status':'NORMAL_READ_R4B_REAL_TERMINAL','pane_pid':int(sys.argv[2]),'pane_exit':status,'result_status':j['status'],'result_sha256':hashlib.sha256(raw).hexdigest(),'result_bytes':len(raw),'errors':j['errors'],'readouts':j['readouts'],'nonuart_post':j.get('nonuart_post'),'manual_power_cut_requested':j['manual_power_cut_requested'],'child_count':len(j['commands']),'unreaped':[v['sequence'] for v in j['commands'] if v['reaped'] is not True],'child_active':j['child_active'],'evidence_errors':j['evidence_errors'],'received_signal':j['received_signal'],'register_writes':j['register_writes'],'motion_commands':j['motion_commands'],'stop_verification':j['stop_verification'],'child_scope':j['child_scope']},ensure_ascii=False),flush=True)
 if j['manual_power_cut_requested']:print('爸爸，请现场立即切断两个电机电源并保持支撑；禁止后续UART。',flush=True)

PYREMOTE
exit "$status"
