#!/bin/bash
set -eu
export PYTHONDONTWRITEBYTECODE=1
tmux set-option -w -t "$TMUX_PANE" remain-on-exit on
exec /home/loosqk/.local/share/uv/python/cpython-3.12.13-linux-aarch64-gnu/bin/python3 /home/loosqk/robot-checks/position-return-20261010-r1/strace-install-r2/prepare_strace_job_r2.py > /home/loosqk/robot-checks/position-return-20261010-r1/strace-install-r2/driver.log 2>&1
