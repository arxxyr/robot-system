import hashlib,json,os,re,subprocess,time
from pathlib import Path
root=Path('/home/loosqk/robot-checks/position-return-20261010-r1/strace-install-r2')
rows=[];result={'schema':'STRACE_SCOPED_TOOL_PREPARATION_V1','uart_operations':0,'commands':rows,'status':'PENDING','uid':os.getuid(),'euid':os.geteuid(),'started_ns':time.time_ns()}
def command(name,argv,accepted=(0,)):
 start=time.time_ns();child=subprocess.Popen(argv,stdin=subprocess.DEVNULL,stdout=subprocess.PIPE,stderr=subprocess.PIPE,env=dict(os.environ,LC_ALL='C',LANG='C'))
 out,err=child.communicate();code=child.wait()
 for suffix,data in [('stdout',out),('stderr',err)]:
  with (root/(name+'.'+suffix)).open('xb') as f:f.write(data)
 row={'name':name,'argv':argv,'pid':child.pid,'started_ns':start,'finished_ns':time.time_ns(),'exit_code':code,'wait_returncode':code,'reaped':True,'signals_sent':[],'stdout_sha256':hashlib.sha256(out).hexdigest(),'stderr_sha256':hashlib.sha256(err).hexdigest(),'stdout_bytes':len(out),'stderr_bytes':len(err)};rows.append(row)
 with (root/(name+'.receipt.json')).open('x') as f:json.dump(row,f,indent=2);f.write('\n')
 if code not in accepted:raise RuntimeError(name+' exit '+str(code))
 return code,out,err
try:
 raw=Path('/etc/os-release').read_bytes()
 with (root/'os-release').open('xb') as f:f.write(raw)
 release={key:value.strip('"') for key,value in (line.split('=',1) for line in raw.decode().splitlines() if '=' in line)}
 result['os_release']=release;result['absolute_strace_before']={'exists':Path('/usr/bin/strace').exists(),'executable':os.access('/usr/bin/strace',os.X_OK)}
 command('path-before',['bash','-c','command -v strace'],(0,1))
 dpkg_code,dpkg_out,_=command('dpkg-before',['dpkg-query','-W','-f','${db:Status-Status}\t${Version}\n','strace'],(0,1))
 result['package_before']=dpkg_out.decode();result['dpkg_before_exit']=dpkg_code
 if not os.access('/usr/bin/strace',os.X_OK):
  if release.get('ID')!='ubuntu' or not os.access('/usr/bin/apt-get',os.X_OK):raise RuntimeError('NOT_UBUNTU_APT')
  sudo_code,_,_=command('sudo-capability',['sudo','-n','true'],(0,1))
  if sudo_code!=0:raise RuntimeError('SUDO_NONINTERACTIVE_UNAVAILABLE')
  prefix=['sudo','-n','apt-get','-o','Acquire::http::Proxy=http://10.0.1.80:10808','-o','Acquire::https::Proxy=http://10.0.1.80:10808']
  simulate=prefix+['-s','--no-upgrade','--no-install-recommends','install','strace']
  code,out,err=command('simulate-r1',simulate,(0,100))
  if code!=0:
   text=(out+err).decode()
   if not any(term in text for term in ('Unable to locate package strace','Package strace has no installation candidate')):raise RuntimeError('SIMULATION_FAILURE_NOT_MISSING_CANDIDATE')
   command('index-update',prefix+['update'])
   code,out,err=command('simulate-after-index',simulate)
  text=(out+err).decode();inst=[line.split()[1] for line in text.splitlines() if line.startswith('Inst ')];conf=[line.split()[1] for line in text.splitlines() if line.startswith('Conf ')];remove=[line for line in text.splitlines() if line.startswith('Remv ')]
  summary=re.search(r'(\d+) upgraded, (\d+) newly installed, (\d+) to remove and (\d+) not upgraded',text)
  assert code==0 and inst==['strace'] and conf==['strace'] and not remove and summary and summary.group(1)=='0' and summary.group(2)=='1' and summary.group(3)=='0', 'SIMULATION_OUTSIDE_STRACE_ONLY'
  result['accepted_simulation']={'install':inst,'configure':conf,'remove':remove,'summary':summary.group(0)}
  command('install',prefix+['-y','--no-upgrade','--no-install-recommends','install','strace'])
 assert os.access('/usr/bin/strace',os.X_OK),'STRACE_NOT_EXECUTABLE_AFTER'
 command('dpkg-after',['dpkg-query','-W','-f','${db:Status-Status}\t${Version}\n','strace'])
 command('version',['/usr/bin/strace','-V'])
 command('true-trace',['/usr/bin/strace','-ttt','-xx','-s','256','-yy','-e','trace=openat,close,read,write,ioctl','-o',str(root/'true.trace'),'/usr/bin/true'])
 trace=(root/'true.trace').read_bytes();assert not re.search(rb'/dev/(tty|serial|pts|console)',trace),'TRUE_TRACE_CONTAINS_TTY'
 data=Path('/usr/bin/strace').read_bytes();result['strace_binary']={'path':'/usr/bin/strace','sha256':hashlib.sha256(data).hexdigest(),'bytes':len(data)}
 result['true_trace']={'sha256':hashlib.sha256(trace).hexdigest(),'bytes':len(trace),'tty_paths_found':False,'tested_program':'/usr/bin/true','ordinary_uid':os.getuid()}
 result['status']='PASS_STRACE_ONLY_INSTALL_AND_TRUE_PTRACE'
except BaseException as error:
 result['status']='FAIL_OR_BLOCKED';result['error']=repr(error)
finally:
 result['finished_ns']=time.time_ns()
 raw=(json.dumps(result,ensure_ascii=False,indent=2)+'\n').encode()
 with (root/'result.json').open('xb') as f:f.write(raw)
 print(json.dumps({'status':result['status'],'error':result.get('error'),'result_sha256':hashlib.sha256(raw).hexdigest(),'commands':len(rows)},ensure_ascii=False),flush=True)
raise SystemExit(0 if result['status'].startswith('PASS_') else 1)
