#!/bin/bash
# 爸爸，保持stdin连接tmux的PTY，只有本轮全部pins绑定后才执行；正文/只读候选入口保持。
set -eu
export PYTHONDONTWRITEBYTECODE=1
exec /home/loosqk/.local/share/uv/python/cpython-3.12.13-linux-aarch64-gnu/bin/python3 -c 'import os,subprocess
FIELD_STAMP=1791870170000000000
FIELD_EXPECTED=('"'"'4454145c392d430a99b0b31b796fab4ece625528438f11cfcffbb7fd6e0d0892'"'"', 1645)
GO_EXPECTED=('"'"'387d11aa8aeda953b774ee25cc8ac3779cd920a94929afc18c1e49d4c079da3d'"'"', 1782)
BINDING_EXPECTED=('"'"'ac4c13d8c2c0d61216f8414ee141f7f8744f84a97d413d71c4a2ba91b624b669'"'"', 30529)
PLAN_EXPECTED=('"'"'034a118fb85677bf204a1428385bc83820d7ee6b13577df1044de98117449735'"'"', 38653)
PLAN_CANONICAL_SHA='"'"'bfd13186961ca75be190caa1c9ba8ae50ff843c3f9f35d8329e6fb0ca2ad1bfc'"'"'
NATIVE_PREPARATION_EXPECTED=('"'"'a929d202c53bd918ea8d3221a5ff1c9e9694be1d80b41ac5d7e69492887f44ea'"'"', 4809)
assert type(FIELD_STAMP) is int and FIELD_STAMP>0 and all(v is not None for v in (FIELD_EXPECTED,GO_EXPECTED,BINDING_EXPECTED,PLAN_EXPECTED,NATIVE_PREPARATION_EXPECTED)) and type(PLAN_CANONICAL_SHA) is str and len(PLAN_CANONICAL_SHA)==64, '"'"'爸爸，只读反馈launcher未绑定本轮现场/GO/软件准备，零I/O拒绝。'"'"'
log=os.open('"'"'/home/loosqk/robot-checks/base-feedback-diagnostic-r2/base-feedback-diagnostic-launch-r2/driver.log'"'"',os.O_WRONLY|os.O_CREAT|os.O_EXCL,0o600)
os.dup2(log,1);os.dup2(log,2);os.close(log)
subprocess.run(['"'"'tmux'"'"','"'"'set-option'"'"','"'"'-p'"'"','"'"'-t'"'"',os.environ['"'"'TMUX_PANE'"'"'],'"'"'remain-on-exit'"'"','"'"'on'"'"'],check=True)
os.execv('"'"'/home/loosqk/.local/share/uv/python/cpython-3.12.13-linux-aarch64-gnu/bin/python3'"'"',['"'"'/home/loosqk/.local/share/uv/python/cpython-3.12.13-linux-aarch64-gnu/bin/python3'"'"','"'"'/home/loosqk/robot-checks/base-feedback-r2-software-20261013/candidate/base_feedback_diagnostic_r2.py'"'"','"'"'--raw-helper'"'"','"'"'/home/loosqk/robot-checks/base-feedback-r2-software-20261013/candidate/fixtures/raw_right9_from_r14_r2.py'"'"','"'"'--maintenance'"'"','"'"'/home/loosqk/robot-checks/position-return-20261010-r1/software-facts-r1/scripts/run_hardware_maintenance.py'"'"','"'"'--bindings'"'"','"'"'/home/loosqk/robot-checks/base-feedback-diagnostic-r2/maintenance_bindings_base_feedback_diagnostic_r2.json'"'"','"'"'--output'"'"','"'"'/home/loosqk/robot-checks/base-feedback-diagnostic-r2/base-feedback-diagnostic-r2'"'"','"'"'--artifact-root'"'"','"'"'/home/loosqk/robot-checks/base-feedback-diagnostic-r2'"'"','"'"'--execute'"'"','"'"'--approval'"'"','"'"'/home/loosqk/robot-checks/base-feedback-diagnostic-r2/base-feedback-diagnostic-r2.go.json'"'"'])'
