#!/bin/bash
# 爸爸，独立launcher也必须由已核starter填全部本轮pins；纯草稿零I/O拒绝。
set -eu
export PYTHONDONTWRITEBYTECODE=1
exec /home/loosqk/.local/share/uv/python/cpython-3.12.13-linux-aarch64-gnu/bin/python3 - <<'PYLAUNCH'
import os,subprocess
FIELD_STAMP=1791782992615353000
FIELD_EXPECTED=('d76689d74a5ceeff127af556d3182f255d73d07b959a37113be8d7296017f9d8', 1766)
GO_EXPECTED=('f883e3bd423dc9256fbfe230c5fe74e731f63b12e020c9f0e9c79819f0baedc5', 1781)
BINDING_EXPECTED=('347a65dbfe0b3d553f7df06b413507b1491c073ced8a283f498bf7a81f51be86', 30051)
PLAN_EXPECTED=('28f7bf60eab714204110aad93e5734c750c30ae451e212aab9db8765db41d9fd', 38231)
PLAN_CANONICAL_SHA='aa66be3595a28b645d328fd16018a80478c7f671c0ddc51d0d3b435a8900c454'
NATIVE_PREPARATION_EXPECTED=('166d327b5e50615f3329e135447a24cc1f62ce6cfcfc14752cf7e3f30b873ff1', 5112)
assert type(FIELD_STAMP) is int and FIELD_STAMP>0 and all(v is not None for v in (FIELD_EXPECTED,GO_EXPECTED,BINDING_EXPECTED,PLAN_EXPECTED,NATIVE_PREPARATION_EXPECTED)) and type(PLAN_CANONICAL_SHA) is str and len(PLAN_CANONICAL_SHA)==64, '爸爸，零目标launcher未绑定本轮现场/GO/软件准备，零I/O拒绝。'
log=os.open('/home/loosqk/robot-checks/position-return-20261010-r1/base-zero-diagnostic-r1/base-zero-diagnostic-launch-r3/driver.log',os.O_WRONLY|os.O_CREAT|os.O_EXCL,0o600)
os.dup2(log,1);os.dup2(log,2);os.close(log)
subprocess.run(['tmux','set-option','-p','-t',os.environ['TMUX_PANE'],'remain-on-exit','on'],check=True)
os.execv('/home/loosqk/.local/share/uv/python/cpython-3.12.13-linux-aarch64-gnu/bin/python3',['/home/loosqk/.local/share/uv/python/cpython-3.12.13-linux-aarch64-gnu/bin/python3','/home/loosqk/robot-checks/position-return-20261010-r1/base-zero-diagnostic-r1/base_zero_diagnostic_r1.py','--raw-helper','/home/loosqk/robot-checks/position-return-20261010-r1/base-zero-diagnostic-r1/helpers/raw_right9_from_r14_r1.py','--maintenance','/home/loosqk/robot-checks/position-return-20261010-r1/software-facts-r1/scripts/run_hardware_maintenance.py','--bindings','/home/loosqk/robot-checks/position-return-20261010-r1/base-zero-diagnostic-r1/maintenance_bindings_base_zero_diagnostic_r3.json','--output','/home/loosqk/robot-checks/position-return-20261010-r1/base-zero-diagnostic-r1/base-zero-diagnostic-r3','--artifact-root','/home/loosqk/robot-checks/position-return-20261010-r1','--execute','--approval','/home/loosqk/robot-checks/position-return-20261010-r1/base-zero-diagnostic-r1/base-zero-diagnostic-r3.go.json'])
PYLAUNCH
