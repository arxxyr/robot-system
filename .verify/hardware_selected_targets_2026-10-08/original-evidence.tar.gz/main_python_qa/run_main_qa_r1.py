"""主树两文件合同顺序QA；仅Python/零动作CLI，真实持有自有child至wait回收。"""
import ast
import datetime
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import signal
import stat
import subprocess
import sys
import time

ROOT=Path('/Users/loosqk/repo/rust/robot-system')
BASE=ROOT/'target/hardware_selected_targets'
RUN=BASE/'main_qa_r1'
RUN.mkdir()
SOURCES={'scripts/run_hardware_maintenance.py':'caf87b36f0689b4e40fb8fade0f4577ef0a6ff691732c157a10ed620b9a6d4f4','scripts/tests/test_hardware_maintenance.py':'0c817f14a3b56cb84b0f0453d6d8e74eeaeedc1d044dfd9f047f253e67fce25b'}
def sha(raw):return hashlib.sha256(raw).hexdigest()
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def write(p,v):
 with p.open('x') as f:json.dump(v,f,ensure_ascii=False,indent=2);f.write('\n')
def ref(p):
 raw=p.read_bytes();return {'path':str(p),'sha256':sha(raw),'bytes':len(raw)}
def snapshot():
 result={}
 for n in SOURCES:
  p=ROOT/n;raw=p.read_bytes();info=p.lstat()
  if not stat.S_ISREG(info.st_mode) or p.is_symlink():raise ValueError('源必须普通文件')
  result[n]={'sha256':sha(raw),'bytes':len(raw),'mode':stat.S_IMODE(info.st_mode)}
 return result
RECEIVED=[]
def interrupted(n,_frame):RECEIVED.append(n)
for sig in (signal.SIGINT,signal.SIGTERM,signal.SIGHUP):signal.signal(sig,interrupted)
uv=shutil.which('uv')
if not uv:raise RuntimeError('缺少uv')
methods=sorted(n.name+'.'+f.name for n in ast.parse((ROOT/'scripts/tests/test_hardware_maintenance.py').read_text()).body if isinstance(n,ast.ClassDef) for f in n.body if isinstance(f,ast.FunctionDef) and f.name.startswith('test_'))
independent=json.loads((BASE/'independent_code_review_r1.json').read_bytes())
new_subset=independent['methods']['new_subset']
report={'schema':'HARDWARE_SELECTED_TARGETS_MAIN_QA_R1','status':'FAIL','started_at':now(),'runner':ref(Path(__file__)),'root_integration':ref(BASE/'root_integration_r1.json'),'python_executable':sys.executable,'python_version':sys.version,'commands':[],'source_before':snapshot(),'methods':{'actual_roster':methods,'whole_file':len(methods),'original_retained':sorted(set(methods)-set(new_subset)),'new_subset':new_subset,'new_are_subset_of_40':set(new_subset)<=set(methods)},'hardware_execution':'NOT_RUN','UART':'NOT_RUN','motion_GO':'NOT_ISSUED','cargo':'NOT_RUN_PURE_PYTHON','scope':'主树最终两源顺序本机合同门；不累计worktree或r1/r2重复测试；不是Orin或实际运动'}
write(RUN/'source_before.json',report['source_before'])
def command(name,args,expected):
 if RECEIVED:raise ValueError('收到信号，停止下一命令')
 before=snapshot()
 if before!=report['source_before']:raise ValueError('启动前源漂移，停止QA')
 folder=RUN/name;folder.mkdir()
 argv=[uv,'run','--no-project','python','-B',*args]
 env={**os.environ,'PYTHONDONTWRITEBYTECODE':'1','UV_NO_PROGRESS':'1'}
 row={'name':name,'argv':argv,'cwd':str(ROOT),'recorded_environment':{'PYTHONDONTWRITEBYTECODE':'1','UV_NO_PROGRESS':'1'},'started_at':now(),'started_monotonic_ns':time.monotonic_ns(),'owner_pid':os.getpid(),'expected_exit_code':expected,'budget_seconds':60,'pid':None,'wait_returncode':None,'reaped':False,'signals_sent':[],'received_signals':[],'identity_phase':'SPAWN_RETURNED_PID;完整OS启动身份未捕获，不伪造','status':'RUNNING'}
 with (folder/'stdout.log').open('xb') as out,(folder/'stderr.log').open('xb') as err:
  child=subprocess.Popen(argv,cwd=ROOT,env=env,stdout=out,stderr=err,start_new_session=True)
  row['pid']=child.pid;row['child_session_id']=child.pid
  write(folder/'launch.json',row)
  budget_exceeded=False
  while True:
   try:code=child.wait(timeout=1);break
   except subprocess.TimeoutExpired:
    if time.monotonic_ns()-row['started_monotonic_ns']>60*10**9:budget_exceeded=True
  ended=time.monotonic_ns()
  row.update(wait_returncode=code,reaped=True,ended_monotonic_ns=ended,elapsed_ns=ended-row['started_monotonic_ns'],finished_at=now(),budget_exceeded=budget_exceeded,received_signals=list(RECEIVED),status='PASS' if code==expected and not budget_exceeded and not RECEIVED else 'FAIL')
 row['stdout']=ref(folder/'stdout.log');row['stderr']=ref(folder/'stderr.log')
 row['source_after']=snapshot()
 if row['source_after']!=report['source_before']:row['status']='FAIL';row['source_error']='源发生漂移'
 write(folder/'completion.json',row);report['commands'].append(row)
 if row['status']!='PASS':raise ValueError('实际命令失败：'+name)
 return (folder/'stdout.log').read_bytes(),(folder/'stderr.log').read_bytes()
try:
 if not all(report['source_before'][n]['sha256']==s for n,s in SOURCES.items()):raise ValueError('当前两源非已批准SHA')
 if len(methods)!=40 or len(new_subset)!=5 or len(report['methods']['original_retained'])!=35:raise ValueError('方法名册计数不符')
 out,err=command('tests',['-m','unittest','discover','-s','scripts/tests','-p','test_hardware_maintenance.py','-v'],0)
 observed=sorted(m.group(2)+'.'+m.group(1) for m in re.finditer(r'^(test_\w+) \(test_hardware_maintenance\.(\w+)\.test_\w+\) \.\.\. ok$',err.decode(),re.M))
 if observed!=methods or re.search(r'Ran 40 tests in [\d.]+s\n\nOK\n$',err.decode()) is None:raise ValueError('实际unittest方法或最终40通过不符')
 report['methods']['executed_roster']=observed
 out,err=command('default_plan_only',['scripts/run_hardware_maintenance.py'],0)
 default=json.loads(out)
 if default['result']!='PLAN_ONLY' or default['actions_started']!=0 or default['position_targets']!=[['left',5,'left_arm_wrist_roll'],['right',5,'right_arm_wrist_roll'],['left',7,'head_motor_1'],['left',8,'head_motor_2']]:raise ValueError('默认零动作/原顺序不符')
 out,err=command('selected_plan_only',['scripts/run_hardware_maintenance.py','--position-target','right-wrist','--position-target','head-1','--position-target','head-2'],0)
 selected=json.loads(out)
 if selected['result']!='PLAN_ONLY' or selected['actions_started']!=0 or selected['position_targets']!=[['right',5,'right_arm_wrist_roll'],['left',7,'head_motor_1'],['left',8,'head_motor_2']]:raise ValueError('所选三目标零动作/原顺序不符')
 out,err=command('duplicate_cli_rejected',['scripts/run_hardware_maintenance.py','--position-target','head-1','--position-target','head-1'],2)
 if out or '位置目标重复，禁止开串口' not in err.decode():raise ValueError('重复CLI未严格前置拒绝')
 out,err=command('unknown_cli_rejected',['scripts/run_hardware_maintenance.py','--position-target','unknown'],2)
 if out or 'invalid choice' not in err.decode():raise ValueError('未知CLI未严格前置拒绝')
 report.update(status='PASS',default_response=default,selected_response=selected,direct_QA_children=5,tests={'passed':40,'failed':0,'errors':0,'skipped':0,'new_methods':5,'new_subset_not_extra_count':True})
except BaseException as error:
 report['error']=repr(error)
finally:
 report['source_after']=snapshot();report['source_unchanged']=report['source_before']==report['source_after']
 if not report['source_unchanged']:report['status']='FAIL';report['source_drift']=True
 report['finished_at']=now();report['received_signals']=list(RECEIVED)
 write(RUN/'source_after.json',report['source_after']);write(BASE/'main_qa_r1.json',report)
print(json.dumps({'status':report['status'],'commands_started':len(report['commands']),'test_methods':len(methods),'source_unchanged':report['source_unchanged'],'error':report.get('error'),'report':ref(BASE/'main_qa_r1.json')},ensure_ascii=False))
raise SystemExit(0 if report['status']=='PASS' else 1)
