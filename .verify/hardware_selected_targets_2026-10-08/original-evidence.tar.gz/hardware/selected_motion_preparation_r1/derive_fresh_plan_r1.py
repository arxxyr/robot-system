"""爸爸，仅在本机核对只读原件并派生绑定与计划；不连接硬件、不生成 GO。"""
import hashlib
import importlib.util
import json
from pathlib import Path

ROOT = Path('/Users/loosqk/repo/rust/robot-system')
BASE = ROOT / 'target/hardware_readonly_2026-10-08/selected_motion_preparation_r1'
SCRIPT = ROOT / 'scripts/run_hardware_maintenance.py'
RAW_SHA = '4283fccee1477ea27b4bcf9ae0cc26e6813bb115dcf813398e3e2aa9788d8239'
SCRIPT_SHA = 'caf87b36f0689b4e40fb8fade0f4577ef0a6ff691732c157a10ed620b9a6d4f4'
PREP_SHA = '7840e626f0a33da21a29068d5e1e75cb4f7ea1a6696176156fe529adf74a8c11'
PROC_PATH = '/home/loosqk/robot-checks/hardware-verify-20260930-r2/maintenance/proc_identity.py'
REMOTE_ROOT = '/home/loosqk/robot-checks/hardware-selected-targets-20261008-r1'


def require(value, reason):
    if not value:
        raise ValueError(reason)


def sha(data):
    return hashlib.sha256(data).hexdigest()


def strict_json(data):
    def pairs(values):
        out = {}
        for key, value in values:
            require(key not in out, '重复 JSON 字段')
            out[key] = value
        return out
    return json.loads(data, object_pairs_hook=pairs,
                      parse_constant=lambda value: (_ for _ in ()).throw(ValueError(value)))


def reference(path):
    data = path.read_bytes()
    return {'path': str(path), 'sha256': sha(data), 'bytes': len(data)}


def write_new(path, value):
    with path.open('x') as output:
        json.dump(value, output, ensure_ascii=False, indent=2)
        output.write('\n')


def main():
    raw_path = BASE / 'fresh_prepare_r1.owner/child.log'
    raw = raw_path.read_bytes()
    require(sha(raw) == RAW_SHA and len(raw) == 431662, 'fresh 原件身份改变')
    report = strict_json(raw)
    owner_path = BASE / 'fresh_prepare_r1.owner/result.json'
    owner = strict_json(owner_path.read_bytes())
    require(owner['phase'] == 'REAPED' and owner['status'] == 'PASS'
            and owner['wait_returncode'] == 0 and owner['reaped'] is True
            and owner['owner_sent_signals'] == [] and owner['received_signals'] == {}
            and owner['errors'] == [] and owner['log'] == reference(raw_path), 'owner 回执不完整')
    require(owner['remote_state'] == 'NOT_VERIFIED', '不得回填 owner 对远端的宣称')
    require(owner['input'] == reference(BASE / 'prepare_fresh_r1.sh')
            and owner['input']['sha256'] == PREP_SHA
            and owner['elapsed_ns'] <= 600_000_000_000, '输入或外层观察预算改变')
    require(report['schema'] == 'SELECTED_MAINTENANCE_NONUART_PREPARATION_R1_V1'
            and report['status'] == 'PASS' and report['errors'] == []
            and report['received_signals'] == [] and report['reads'] == []
            and report['hardware_writes'] == 0 and report['locks'] == []
            and report['expected_requested_register_outputs'] == 0
            and report['elapsed_ns'] <= 600_000_000_000, '非 UART 原件结果或预算不符')
    require(len(report['commands']) == 51 and len(report['checks']) == 205
            and len({row['pid'] for row in report['commands']}) == 51
            and all(row['status'] == 'PASS' for row in report['checks']), 'child/check 覆盖不符')
    for row in report['commands']:
        require(row['reaped'] is True and row['signals_sent'] == []
                and row['communicate_errors'] == []
                and row['wait_returncode'] == row['exit_code']
                and row['exit_code'] in (0, 1) and row['elapsed_ns'] <= 2_000_000_000
                and row['child_end_class'] == 'EXIT_STATUS', 'child 未真正回收或越预算')
        require(row['argv'][0] in ('git', 'systemctl', 'sudo', 'fuser', 'udevadm')
                and not any(arg.endswith('/feetech_poke') for arg in row['argv']), '越界工具调用')
        for channel in ('stdout', 'stderr'):
            data = row[channel].encode()
            require(sha(data) == row[channel + '_sha256']
                    and len(data) == row[channel + '_bytes'], 'child 原输出不一致')
    before, after = report['before'], report['after']
    for key in ('identity', 'formal', 'services', 'protection', 'elf'):
        require(before[key] == after[key], '前后快照变化：' + key)
    require(before['formal']['valid'] is True
            and before['formal']['head'] == 'ca14f0e6cf6df8ecc6baaaa8dff2dddb64abbd0a'
            and before['formal']['status_porcelain'] == ''
            and len(before['formal']['files']) == 14, '正式安装身份不符')
    for epoch in (before, after):
        require(epoch['processes']['clean'] is True and not epoch['processes']['related']
                and not epoch['processes']['unreadable']
                and len(epoch['holders']) == 12
                and all(row['stdout'] == row['stderr'] == '' and row['exit_code'] == 1
                        for row in epoch['holders']), '进程/占用门不符')
    require(report['fixed_refs_before'] == report['fixed_refs_after']
            and report['old_services_before'] == report['old_services_after'], '固定引用或旧服务变化')
    refs = report['fixed_refs_before']['refs']
    require(report['fixed_refs_before']['valid'] is True and len(refs) == 30
            and all(row['valid'] is True for row in refs.values()), '固定引用不完整')
    for row in before['formal']['files'].values():
        require(refs[row['path']] == {k: v for k, v in row.items() if k != 'expected'},
                '正式引用实际元数据投影不一致')
    require(before['services']['valid'] is True and len(before['services']['units']) == 6
            and report['old_services_before']['valid'] is True
            and len(report['old_services_before']['units']) == 5, '服务集合不完整')
    usb = {}
    for side in ('left', 'right'):
        b, a = before['devices'][side], after['devices'][side]
        require({k: v for k, v in b.items() if k != 'udev_command'}
                == {k: v for k, v in a.items() if k != 'udev_command'}, 'USB 类型或映射变化')
        fields = dict(line.split('=', 1) for line in b['udev_command']['stdout'].splitlines())
        fields_after = dict(line.split('=', 1) for line in a['udev_command']['stdout'].splitlines())
        require(all(fields[k] == fields_after[k] for k in ('ID_SERIAL_SHORT', 'DEVPATH', 'USEC_INITIALIZED')),
                'USB 枚举代次变化')
        usb[side] = {k: v for k, v in b.items() if k != 'udev_command'}
        usb[side].update(serial=fields['ID_SERIAL_SHORT'], devpath=fields['DEVPATH'],
                         usec_initialized=fields['USEC_INITIALIZED'])
    tool = before['elf']
    require(tool['sha256'] == 'f2014ee4008311e7a8725235a39f0d1b3913391f17cbd977b7441f120539114b'
            and tool['bytes'] == 1469904 and tool['elf_machine'] == 183 and tool['mode'] & 0o111,
            '位置维护工具身份错误')
    calibrations = {}
    calibration_sources = {}
    for side, motor, name, file_name in (
            ('left', 5, 'left_arm_wrist_roll', 'left_arm'),
            ('right', 5, 'right_arm_wrist_roll', 'right_arm'),
            ('left', 7, 'head_motor_1', 'head'), ('left', 8, 'head_motor_2', 'head')):
        path = f'/home/loosqk/repo/dimensional-applications/calibration/{file_name}.json'
        value = refs[path]['calibration_json'][name]
        require(set(value) == {'id', 'drive_mode', 'homing_offset', 'range_min', 'range_max'}
                and all(type(v) is int for v in value.values()) and value['id'] == motor
                and value['drive_mode'] == 0 and 0 <= value['range_min'] < value['range_max'] <= 4095,
                '校准值不符合固定位置目标')
        calibrations[name] = value
        calibration_sources[name] = {'path': path, 'sha256': refs[path]['sha256'], 'side': side, 'motor': motor}
    identity = before['identity']
    require(identity['hostname'] == 'ubuntu' and identity['machine'] == 'aarch64'
            and identity['uid'] == identity['euid'] == identity['gid'] == identity['egid'] == 1000
            and identity['boot_id'] == '6cf7ee3e-a3c5-4c91-80bc-4ca924818b53', '主机身份不符')
    script_pin = reference(SCRIPT)
    require(script_pin['sha256'] == SCRIPT_SHA and script_pin['bytes'] == 50013, '候选源码改变')
    bindings = {
        'schema': 'MAINTENANCE_BINDINGS_V1',
        'host': {k: identity[k] for k in ('hostname', 'uid', 'gid', 'boot_id')},
        'tool': tool, 'usb': usb,
        'protection': {side: {k: v for k, v in before['protection'][side].items() if k != 'directory'}
                       for side in ('left', 'right')},
        'refs': [{k: v for k, v in row.items() if k != 'calibration_json'} for row in refs.values()],
        'proc_helper': refs[PROC_PATH],
        'binary_paths': [row['path'] for row in before['formal']['files'].values()
                         if '/target/release/' in row['path']] + [tool['path']],
        'calibrations': calibrations,
        'origin': {'fresh_non_uart_raw': reference(raw_path), 'fresh_owner': reference(owner_path),
                   'fresh_prepare_script': reference(BASE / 'prepare_fresh_r1.sh'),
                   'read_sampling_raw': reference(ROOT / 'target/hardware_readonly_2026-10-08/read_r1.owner/child.log'),
                   'calibration_sources': calibration_sources,
                   'all_metadata_source': '本次 fresh before；after 逐项相同；不沿用旧 USB 枚举或保护时间',
                   'hardware_authorization': 'none; 仅 PLAN_ONLY，root 决定本轮具体运动 GO',
                   'position_tool_basis': 'f201 历史位置维护 ELF；本次重新核本体，未调用，不是 B0 替代件'},
    }
    spec = importlib.util.spec_from_file_location('maintenance_frozen_plan', SCRIPT)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    plan = module.make_plan(bindings, REMOTE_ROOT + '/right-head-run-01', 'right-head-run-01',
                            REMOTE_ROOT, ['right-wrist', 'head-1', 'head-2'])
    expected = [('right', 5, 'right_arm_wrist_roll'), ('left', 7, 'head_motor_1'), ('left', 8, 'head_motor_2')]
    require(module.position_targets_from_plan(plan) == expected
            and len(plan['bindings']['refs']) == 30
            and all(row['decision'] == 'DEFERRED' for row in plan['base_targets']), '计划范围错误')
    require(reference(SCRIPT) == script_pin, '本机派生期间源码变化')
    bindings_path, plan_path = BASE / 'maintenance_bindings_fresh_r1.json', BASE / 'right_head_plan_r1.json'
    write_new(bindings_path, bindings)
    write_new(plan_path, plan)
    validation = {
        'schema': 'SELECTED_MAINTENANCE_FRESH_PLAN_VALIDATION_R1_V1', 'status': 'PASS',
        'plan_only': True, 'go_created': False, 'hardware_launches': 0, 'uart_requests': 0,
        'source': script_pin, 'fresh_raw': reference(raw_path), 'owner': reference(owner_path),
        'owner_remote_state': owner['remote_state'], 'remote_report_status': report['status'],
        'remote_child_count': 51, 'checks': 205, 'all_remote_children_reaped': True,
        'remote_elapsed_ns': report['elapsed_ns'], 'owner_elapsed_ns': owner['elapsed_ns'],
        'max_remote_child_elapsed_ns': max(row['elapsed_ns'] for row in report['commands']),
        'fixed_ref_count': 30, 'calibration_file_count': 4, 'upstream_reference_file_count': 11,
        'new_units': before['services']['units'], 'old_units': report['old_services_before']['units'],
        'formal_head': before['formal']['head'], 'formal_status_porcelain': before['formal']['status_porcelain'],
        'formal_four': {k: v for k, v in before['formal']['files'].items() if k.startswith('installed:')},
        'selected_names': ['right-wrist', 'head-1', 'head-2'], 'position_targets': plan['position_targets'],
        'bindings': reference(bindings_path), 'plan_file': reference(plan_path),
        'canonical_plan_sha256': module.digest(plan),
        'artifact_root_observation': report['artifact_root_observation'],
        'remaining': ['远端阶段目录尚未创建；不冒称具备执行文件/GO',
                      '当次最终同源 Orin 40 项软件 QA 尚待 root 授权执行',
                      'root 审核当前具体计划并决定单次运动 GO；此文件不授予动作'],
        'limits': ['左腕旧 FAIL 不重试或被新结果覆盖', '底盘 DEFERRED，无 wheel/pulse 动作',
                   'H2 整体 FAIL、D15 OPEN/DEFERRED、deployable=false 保持',
                   '+24/±4/800ms/32 与全 17 电机×3 停止字段和非目标后验保持'],
    }
    write_new(BASE / 'fresh_plan_validation_r1.json', validation)
    manifest = {'schema': 'SELECTED_MAINTENANCE_LOCAL_DERIVED_MANIFEST_R1_V1', 'status': 'PLAN_ONLY',
                'files': [reference(BASE / name) for name in ('derive_fresh_plan_r1.py',
                          'maintenance_bindings_fresh_r1.json', 'right_head_plan_r1.json',
                          'fresh_plan_validation_r1.json')],
                'canonical_plan_sha256': module.digest(plan), 'go_created': False}
    write_new(BASE / 'derived_manifest_r1.json', manifest)
    print(json.dumps({'status': 'PLAN_ONLY', 'validation': reference(BASE / 'fresh_plan_validation_r1.json'),
                      'manifest': reference(BASE / 'derived_manifest_r1.json'),
                      'canonical_plan_sha256': module.digest(plan)}, ensure_ascii=False, indent=2))


if __name__ == '__main__':
    main()
