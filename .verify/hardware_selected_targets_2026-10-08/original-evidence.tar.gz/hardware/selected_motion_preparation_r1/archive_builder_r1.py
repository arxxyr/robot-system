"""爸爸，本机封存本轮独立证据；不访问远端、不修改原件或源码。"""
import gzip
import hashlib
import io
import json
from pathlib import Path
import stat
import tarfile

ROOT = Path('/Users/loosqk/repo/rust/robot-system')
WORKTREE = Path('/Users/loosqk/.codex/worktrees/hardware-selected-targets/robot-system')
OUTPUT = ROOT / '.verify/hardware_selected_targets_2026-10-08'


def require(value, message):
    if not value:
        raise ValueError(message)


def sha(data):
    return hashlib.sha256(data).hexdigest()


def write_new(path, value):
    with path.open('x') as output:
        json.dump(value, output, ensure_ascii=False, indent=2, allow_nan=False)
        output.write('\n')


def file_bytes(path):
    before = path.lstat()
    require(stat.S_ISREG(before.st_mode) and before.st_nlink == 1, '证据非独立普通文件：' + str(path))
    raw = path.read_bytes()
    after = path.lstat()
    require((before.st_dev, before.st_ino, before.st_size, before.st_mtime_ns, before.st_ctime_ns)
            == (after.st_dev, after.st_ino, after.st_size, after.st_mtime_ns, after.st_ctime_ns), '取样期间原件变化')
    return raw, before


def main():
    inputs = {}
    groups = [
        (ROOT / 'target/hardware_readonly_2026-10-08', 'hardware'),
        (ROOT / 'target/hardware_selected_targets', 'main_python_qa'),
        (WORKTREE / 'target/hardware_selected_targets', 'worktree_python_qa'),
        (ROOT / 'target/feetech_firmware_contract_2026-10-08', 'manufacturer_research'),
        (ROOT / 'target/xlerobot_b1_firmware_contract_20261008', 'b1_r2_design'),
    ]
    for directory, prefix in groups:
        require(directory.is_dir(), '必要证据目录缺失：' + str(directory))
        for path in sorted(directory.rglob('*')):
            require(not path.is_symlink(), '证据符号链接拒绝：' + str(path))
            if path.is_file() and '__pycache__' not in path.parts:
                inputs[prefix + '/' + path.relative_to(directory).as_posix()] = path
    for name in ('scripts/run_hardware_maintenance.py', 'scripts/tests/test_hardware_maintenance.py',
                 'scripts/tests/fixtures/hardware_maintenance_run02_return_error.json'):
        inputs['source/' + name] = ROOT / name
    inputs['historical_references/maintenance_bindings_20260930_r2.json'] = (
        ROOT / 'target/hardware_verify_20260930_r2/maintenance/final_maintenance_bindings.json')
    inputs['historical_references/readonly_probe_20260930_r2.sh'] = (
        ROOT / 'target/hardware_verify_20260930_r2/read_only_prep/probe_r2.sh')
    stored, index = {}, []
    for name, path in sorted(inputs.items()):
        require(not name.startswith('/') and '..' not in Path(name).parts, 'tar 路径越界')
        raw, metadata = file_bytes(path)
        stored[name] = raw
        index.append({'archive_path': name, 'source_path': str(path), 'sha256': sha(raw), 'bytes': len(raw),
                      'source_mode': stat.S_IMODE(metadata.st_mode)})
    pins = {row['archive_path']: row for row in index}
    require(pins['source/scripts/run_hardware_maintenance.py']['sha256']
            == 'caf87b36f0689b4e40fb8fade0f4577ef0a6ff691732c157a10ed620b9a6d4f4', '最终维护源码变化')
    require(pins['source/scripts/tests/test_hardware_maintenance.py']['sha256']
            == '0c817f14a3b56cb84b0f0453d6d8e74eeaeedc1d044dfd9f047f253e67fce25b', '最终测试源码变化')
    require(pins['source/scripts/tests/fixtures/hardware_maintenance_run02_return_error.json']['sha256']
            == 'a7bfa3fbfc3f3039be9db68973348ba4db156b74f807e57a01eecda8dfd27948', '旧失败夹具变化')
    prep = 'hardware/selected_motion_preparation_r1/'
    actual = json.loads(stored[prep + 'derived_motion_r1/run.json'])
    require(actual['result'] == 'NEEDS_MANUAL_POWER_CUT' and actual['manual_power_cut_required'] is True,
            '不得改写实际动作原结果')
    require(len(actual['commands']) == 359 and all(row['reaped'] for row in actual['commands']), '真实回收原件不完整')
    OUTPUT.mkdir()
    archive = OUTPUT / 'original-evidence.tar.gz'
    with archive.open('xb') as output:
        with gzip.GzipFile(fileobj=output, mode='wb', mtime=0, filename='') as compressed:
            with tarfile.open(fileobj=compressed, mode='w', format=tarfile.PAX_FORMAT) as tar:
                for row in index:
                    info = tarfile.TarInfo(row['archive_path'])
                    info.size, info.mode, info.mtime = row['bytes'], row['source_mode'], 0
                    info.uid = info.gid = 0
                    tar.addfile(info, io.BytesIO(stored[row['archive_path']]))
    archive_raw = archive.read_bytes()
    aggregate = sha(''.join(row['archive_path'] + '\0' + row['sha256'] + '\0' + str(row['bytes']) + '\n'
                            for row in index).encode())
    index_value = {'schema': 'HARDWARE_SELECTED_TARGETS_ORIGINAL_INDEX_R1_V1', 'file_count': len(index),
                   'aggregate_sha256': aggregate, 'archive_sha256': sha(archive_raw),
                   'archive_bytes': len(archive_raw), 'files': index}
    write_new(OUTPUT / 'original-evidence.index.json', index_value)
    verified = []
    with tarfile.open(archive, mode='r:gz') as tar:
        members = tar.getmembers()
        require(len(members) == len(index) and len({m.name for m in members}) == len(index), 'tar 重复/数量不符')
        require({m.name for m in members} == set(stored), 'tar/index 非精确闭包')
        for member in members:
            require(member.isfile() and not member.name.startswith('/') and '..' not in Path(member.name).parts,
                    'tar 成员越界或不是普通文件')
            raw = tar.extractfile(member).read()
            pin = pins[member.name]
            require(sha(raw) == pin['sha256'] and len(raw) == pin['bytes'], 'tar 原件校验失败')
            verified.append(member.name)
    for row in index:
        raw, _ = file_bytes(Path(row['source_path']))
        require(sha(raw) == row['sha256'] and len(raw) == row['bytes'], '封存期间源原件发生变化')
    write_new(OUTPUT / 'archive-verification.json', {
        'schema': 'HARDWARE_SELECTED_TARGETS_ARCHIVE_VERIFICATION_R1_V1', 'status': 'PASS',
        'file_count': len(verified), 'exact_member_closure': True, 'each_sha_and_bytes_match': True,
        'source_originals_before_after_same': True, 'no_remote_operations': True,
        'archive_sha256': sha(archive_raw), 'archive_bytes': len(archive_raw),
        'aggregate_sha256': aggregate, 'scope': '仅证据封存验证；不是硬件通过'})
    summary = {
        'schema': 'HARDWARE_SELECTED_TARGETS_STAGE_SUMMARY_R1_V1', 'date': '2026-10-08',
        'archive_status': 'PASS', 'overall_hardware_result': 'NEEDS_MANUAL_POWER_CUT',
        'physical_power_cut': 'PENDING；若收到异步答复则另追加回执，不修改本次原报告',
        'software_change': '可重复选择固定位置目标；缺省保持原四项，实际计划仅right-wrist→head-1→head-2',
        'source_pins': {name: pins['source/' + name] for name in (
            'scripts/run_hardware_maintenance.py', 'scripts/tests/test_hardware_maintenance.py',
            'scripts/tests/fixtures/hardware_maintenance_run02_return_error.json')},
        'software_validation': {'local_unique_methods': 40, 'new_method_subset': 5,
                                'main_actual_commands': 5, 'native_r3_unique_methods': 40,
                                'native_r3_actual_commands': 5, 'not_summed_across_repeated_runs': True},
        'independent_read_sample': {'status': 'PASS', 'unique_register_requests': 170,
                                    'owned_children_real_reap': 211, 'checks': 130,
                                    'read_log': pins['hardware/read_r1.owner/child.log'],
                                    'limitations': '包含连接握手额外只读帧；170不称全部wire帧；不覆盖后续动作STOP失败'},
        'fresh_non_uart': {'status': 'PASS', 'children': 51, 'checks': 205, 'fixed_refs': 30,
                           'uart_requests': 0, 'log': pins[prep + 'fresh_prepare_r1.owner/child.log']},
        'preserved_preparation_failures': [
            {'stage': 'native_upload_owner_entry_fail_r1', 'result': 'FAIL exit2, SSH0，误用参数名'},
            {'stage': 'native_upload_r1.owner', 'result': 'NOT_LAUNCHED FAIL，输入未用绝对路径，SSH0'},
            {'stage': 'native_upload_r2.owner', 'result': 'FAIL，封装参数签名错误；文件已上传、QA child0'},
            {'stage': 'native_resume_r2.owner', 'result': 'FAIL，40项34ok/6ERROR，漏原有fixture；未继续CLI'},
            {'stage': 'native_fixture_resume_r3.owner', 'result': 'PASS，原件未回填前轮FAIL'},
        ],
        'selected_plan': {'canonical_sha256': 'a8ae2757e95acaca9524b2f1646fdfed4552c679c7df10f71d52f61369cb2f77',
                          'go': pins[prep + 'root_motion_go_conditional_r1.json'],
                          'root_final_release': pins[prep + 'root_final_launch_release_r1.json'],
                          'independent_plan_review': pins[prep + 'independent_right_head_plan_r1.json']},
        'actual_motion': {'right_wrist': 'PASS 875→895（目标899）→879；终值878/goal875',
                          'head_1': 'FAIL 2634→2655（目标2658）→2642；回程+8超±4/800ms',
                          'head_2': 'NOT_RUN，头1失败后停止', 'left_wrist': 'NOT_RUN，原FAIL保留',
                          'base': 'DEFERRED，主动写0', 'stop': 'FAIL：17×3中50整数零，right9 Present_Velocity=-50',
                          'stop_raw_interpretation': '不推定来源/单位/实际轮转动；UART原字节未捕获',
                          'cleanup': '右5/左7断扭完整ACK与exit0、cleanup_errors=[]，不替代STOP失败',
                          'driver_children': 359, 'wrapper_children': 52, 'all_true_wait_reap': True,
                          'driver_exit_code': 1, 'ssh_exit_code': 1, 'signals_sent': [], 'retries': 0,
                          'log': pins[prep + 'motion_selected_r1.owner/child.log'],
                          'exact_run_original': pins[prep + 'derived_motion_r1/run.json'],
                          'exact_command_journal': pins[prep + 'derived_motion_r1/commands.jsonl']},
        'independent_non_uart_postflight': {'status': 'PASS', 'checks': 216, 'new_services': '六项inactive/dead/MainPID0',
                                           'control_processes': '无相关残留；普通/特权proc复核',
                                           'locks': '四锁普通/特权共8次fuser空exit1，driver已真实退出，字节/身份未变',
                                           'formal': 'ca14 clean，四正式产物SHA不变', 'protection': 'Dirty/LATCHED保持',
                                           'usb_and_fixed_refs': '双USB本轮枚举与30refs/五stage文件首尾相同'},
        'hardware_safety_stop': pins[prep + 'root_hardware_session_stop_r1.json'],
        'manufacturer_research': {'status': 'PRIMARY_CONTRACT_FOUND_DEVICE_FIRMWARE_BINDING_PENDING',
                                  'review': pins['manufacturer_research/review.json'],
                                  'limits': '版本181/下载时间是厂家文档身份，不是现场固件；Phase12与zero语义合同继续拒base动作'},
        'b1_r2_plan': {'status': 'DESIGN_R2_SCOPE_APPROVED_IMPLEMENTATION_TO_FOLLOW_SEPARATE_CANDIDATE',
                       'plan': pins['b1_r2_design/plan.json'],
                       'limits': '计划/数值模型不是Rust候选验收或硬件动作；本包不收其它独立候选构建'},
        'readonly_triage': pins[prep + 'derived_motion_r1/readonly_triage_r1.json'],
        'historical_status_unchanged': ['右H2整体FAIL', '左腕历史FAIL', 'D15 OPEN/DEFERRED', 'deployable=false'],
        'not_done': ['本次head2或底盘主动动作', 'Phase/EEPROM/PID/模式修改', 'S0/S1头部/底盘接入',
                     '右H2硬件复测', 'D15闭环', '新正式安装/部署/push', '人工断电实际时刻确认'],
        'archive': {'path': str(archive), 'sha256': sha(archive_raw), 'bytes': len(archive_raw),
                    'file_count': len(index), 'aggregate_sha256': aggregate},
        'archive_closure_limit': '逐文件清单与tar精确闭包；历史远端ELF/每个命令stdout本体只保既验身份和回执，不宣称全部复制到本机',
    }
    write_new(OUTPUT / 'summary.json', summary)
    print(json.dumps({'archive_sha256': sha(archive_raw), 'archive_bytes': len(archive_raw),
                      'file_count': len(index), 'aggregate_sha256': aggregate,
                      'summary_sha256': sha((OUTPUT / 'summary.json').read_bytes())}, ensure_ascii=False, indent=2))


if __name__ == '__main__':
    main()
