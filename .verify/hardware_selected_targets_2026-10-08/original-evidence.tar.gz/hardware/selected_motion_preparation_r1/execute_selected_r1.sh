set -eu
export PATH=/home/loosqk/.cargo/bin:/home/loosqk/.local/bin:$PATH
PROBE_PYTHON="/home/loosqk/.local/share/uv/python/cpython-3.12.13-linux-aarch64-gnu/bin/python3"
exec taskset -c 0-3 "$PROBE_PYTHON" - <<'END_PY'
import fcntl
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import re
import signal
import stat
import struct
import subprocess
import sys
import threading
import time
sys.dont_write_bytecode = True
BASE = Path('/home/loosqk/robot-checks/h2-serial-recovery-20260930-r1')
ROOT = BASE / 'source'
FORMAL = Path('/home/loosqk/repo/robot/robot-system')
ELF = Path('/home/loosqk/robot-checks/h2-serial-recovery-20260930-r1/readback-tool-r1/feetech_poke')
ELF_SHA = 'f2014ee4008311e7a8725235a39f0d1b3913391f17cbd977b7441f120539114b'
EXPECTED_BOOT = '6cf7ee3e-a3c5-4c91-80bc-4ca924818b53'
FORMAL_FILES = {'config:left': {'path': '/etc/robot/xlerobot_left_arm.toml', 'sha256': '720979785a149f8f25a9a48f5bab10202e32f6e312a998267c4ce3c20d4a6194', 'bytes': 2161, 'uid': 0, 'gid': 0, 'mode': 420}, 'config:right': {'path': '/etc/robot/xlerobot_right_arm.toml', 'sha256': 'ce46c7b1317811ce7cb267db3863624462823c58518cd5e044df4dbc54fd3992', 'bytes': 1589, 'uid': 0, 'gid': 0, 'mode': 420}, 'config:roles': {'path': '/etc/robot/rpc_roles.toml', 'sha256': '6b989264dccf599d22a83808226f049f05481fe57e2eb04519bbcfc3dab3278f', 'bytes': 3434, 'uid': 0, 'gid': 0, 'mode': 420}, 'installed:robot_rpc_gateway': {'path': '/home/loosqk/repo/robot/robot-system/target/release/robot_rpc_gateway', 'sha256': '9e8d029c30472bcd5371b6ae1fb6e4f98446086f420c567d11891dab81cc8d78', 'bytes': 5883280, 'uid': 1000, 'gid': 1000, 'mode': 509}, 'installed:s0_daemon': {'path': '/home/loosqk/repo/robot/robot-system/target/release/s0_daemon', 'sha256': '461aec751fc5a41a24ab4dcc3778ca1e88783c4c96467254419f7bf13d1fde7f', 'bytes': 3968152, 'uid': 1000, 'gid': 1000, 'mode': 509}, 'installed:s1_daemon': {'path': '/home/loosqk/repo/robot/robot-system/target/release/s1_daemon', 'sha256': '1c9037443f9786f09631705bd8800bc5f85333a45c7e9b08d6fcfaf26738de93', 'bytes': 4033312, 'uid': 1000, 'gid': 1000, 'mode': 509}, 'installed:xlerobot_deploy': {'path': '/home/loosqk/repo/robot/robot-system/target/release/xlerobot_deploy', 'sha256': '7d0cfa3da22610e9a34749d1fbb0d081239a728ed1a30cb9836e01c909dff5c3', 'bytes': 1818776, 'uid': 1000, 'gid': 1000, 'mode': 509}, 'discovered:/etc/systemd/system/xlerobot-s0-left-arm.service': {'path': '/etc/systemd/system/xlerobot-s0-left-arm.service', 'sha256': '842e732b55677567e914e2ad6862ccf561ef5b39c2bbe8647c42e2fef50332db', 'bytes': 5247, 'uid': 0, 'gid': 0, 'mode': 420}, 'discovered:/etc/systemd/system/xlerobot-s0-right-arm.service': {'path': '/etc/systemd/system/xlerobot-s0-right-arm.service', 'sha256': '08d3b928d9206b7cc282efdad174ef1f4e66f61971f3d09f4e651a1f70c3e579', 'bytes': 5259, 'uid': 0, 'gid': 0, 'mode': 420}, 'discovered:/etc/systemd/system/xlerobot-s1-left.service': {'path': '/etc/systemd/system/xlerobot-s1-left.service', 'sha256': 'e8ceafd7540f6a78076ad7f7d51845a2df005f9e84998120e70e273dec62b0b2', 'bytes': 1830, 'uid': 0, 'gid': 0, 'mode': 420}, 'discovered:/etc/systemd/system/xlerobot-s1-right.service': {'path': '/etc/systemd/system/xlerobot-s1-right.service', 'sha256': 'faa3d9dbe85e721f383ec2e6a81a153aa136c4397c44603f64d421ba3125575f', 'bytes': 1839, 'uid': 0, 'gid': 0, 'mode': 420}, 'discovered:/etc/systemd/system/xlerobot-gateway-left.service': {'path': '/etc/systemd/system/xlerobot-gateway-left.service', 'sha256': '1b0afa5c17a2be42b6b5286f2e3707471be1aa37390f65017fecc07c19839ea7', 'bytes': 2117, 'uid': 0, 'gid': 0, 'mode': 420}, 'discovered:/etc/systemd/system/xlerobot-gateway-right.service': {'path': '/etc/systemd/system/xlerobot-gateway-right.service', 'sha256': '1233ce1571c626af494f87b26a9e084117fc6b8761ce6e39b24fae377502bd71', 'bytes': 2125, 'uid': 0, 'gid': 0, 'mode': 420}, 'discovered:/etc/systemd/system/xlerobot-handoff.service': {'path': '/etc/systemd/system/xlerobot-handoff.service', 'sha256': '4cce48f85d40642bab7c7646e06be38f37e3412bcc51031b29737b5527e03ace', 'bytes': 3367, 'uid': 0, 'gid': 0, 'mode': 420}}
REGISTERS = ('Model_Number', 'Operating_Mode', 'Torque_Enable', 'Present_Velocity', 'Goal_Velocity', 'Present_Position', 'Goal_Position', 'Phase', 'CW_Dead_Zone', 'CCW_Dead_Zone')
STOP_REGISTERS = frozenset(('Torque_Enable', 'Present_Velocity', 'Goal_Velocity'))
PROFILES = {
    side: {'device': '/dev/serial/by-id/usb-1a86_USB_Single_Serial_' + serial + '-if00',
           'serial': serial, 'trust': Path('/var/lib/robot/xlerobot_' + side), 'count': count}
    for side, serial, count in (('left', '5A7C121427', 8), ('right', '5A7C122340', 9))
}
UNITS = tuple('xlerobot-' + role + '-' + side + ('-arm' if role == 's0' else '') + '.service'
              for role in ('gateway', 's1', 's0') for side in ('left', 'right'))
HELPER_SHA = '8121c8e8454d5a06dfa1f828ca85417917a0cdcd756d222717af89adf1024b77'
DRIVER_SHAS = {
    'run_post_e_h2.py': '1a679114cf9f6a719e4369486214a71280b35efbea46f69cb9fa5c53710b1c13',
    'post_e_h2_report.py': 'bd35923146c3841ec5f4547b85b99494abbd93970cb1b805ce0fb7692b368387',
    'post_e_h2_artifacts.py': 'bd2b3f7bb8527cd9ecec73894171638e9cf378656b89e284a585c3baa37b8731',
}
result = {'schema': 'SELECTED_MAINTENANCE_NONUART_PREPARATION_R1_V1', 'read_only': True, 'status': 'RUNNING',
          'started_ns': time.time_ns(), 'started_monotonic_ns': time.monotonic_ns(),
          'commands': [], 'checks': [], 'reads': [], 'errors': [], 'received_signals': [],
          'locks': [], 'hardware_writes': 0, 'expected_requested_register_outputs': 0,
          'extra_read_only_handshake_frames': '本次不调用poke/connect，不打开UART，无握手帧',
          'budget': {'whole_python_seconds': 600, 'owned_child_seconds': 2, 'signals_sent': []},
          'read_tool_basis': '历史 f201 位置维护工具；本次只核本体，不调用工具或串口',
          'physical_facts_source': 'root 已收到本轮用户全部重新就绪答复；不推定人工动作时间'}
stop = False
driver = None
binaries = [ELF]
locks = []
children = []

def require(value, message):
    if not value:
        raise ValueError(message)

def note_error(phase, error):
    result['errors'].append({'phase': phase, 'error': repr(error), 'at_ns': time.time_ns()})

def handler(signum, frame):
    global stop
    stop = True
    result['received_signals'].append({'name': signal.Signals(signum).name, 'at_ns': time.time_ns()})

def within_budget():
    return time.monotonic_ns() - result['started_monotonic_ns'] <= 600_000_000_000


def collect_owned_child(child, input_raw, row):
    # 无 timeout/kill。communicate 异常后仅接管同一个 child 的管道并真实 wait，不重启命令。
    stdout, stderr = b'', b''
    row['communicate_errors'] = []
    try:
        stdout, stderr = child.communicate(input_raw)
    except BaseException as error:
        row['communicate_errors'].append(repr(error))
        if child.stdin is not None and not child.stdin.closed:
            try:
                child.stdin.close()
            except BaseException as close_error:
                row['communicate_errors'].append(repr(close_error))
        values = {}
        def drain(name, stream):
            try:
                values[name] = b'' if stream is None or stream.closed else stream.read()
            except BaseException as drain_error:
                values[name] = b''
                row['communicate_errors'].append(repr(drain_error))
        drains = [threading.Thread(target=drain, args=(name, stream))
                  for name, stream in (('stdout', child.stdout), ('stderr', child.stderr))]
        for thread in drains:
            thread.start()
        while True:
            try:
                child.wait()
                break
            except BaseException as wait_error:
                row['communicate_errors'].append(repr(wait_error))
        for thread in drains:
            while True:
                try:
                    thread.join()
                    break
                except BaseException as join_error:
                    row['communicate_errors'].append(repr(join_error))
        stdout, stderr = values['stdout'], values['stderr']
    finally:
        while True:
            try:
                row['wait_returncode'] = child.wait()
                row['reaped'] = True
                break
            except BaseException as wait_error:
                row['communicate_errors'].append(repr(wait_error))
    for stream in (child.stdin, child.stdout, child.stderr):
        if stream is not None and not stream.closed:
            try:
                stream.close()
            except BaseException as close_error:
                row['communicate_errors'].append(repr(close_error))
    return stdout, stderr

def command(argv, code=0, input_raw=None, cleanup=False):
    argv = [str(a) for a in argv]
    require(allowed_command(argv), '非批准只读命令：' + repr(argv))
    if not cleanup:
        require(not stop and within_budget(), '已停止/已超过600秒，拒绝后续命令')
    row = {'argv': argv, 'started_ns': time.time_ns(), 'started_monotonic_ns': time.monotonic_ns(),
           'pid': None, 'reaped': False, 'signals_sent': [], 'cleanup': cleanup}
    result['commands'].append(row)
    child = subprocess.Popen(argv, stdin=subprocess.PIPE if input_raw is not None else subprocess.DEVNULL,
                             stdout=subprocess.PIPE, stderr=subprocess.PIPE, start_new_session=True,
                             env={**os.environ, 'GIT_OPTIONAL_LOCKS': '0', 'LC_ALL': 'C'})
    row['pid'] = child.pid
    children.append((child, row))
    stdout, stderr = collect_owned_child(child, input_raw, row)
    elapsed = time.monotonic_ns() - row['started_monotonic_ns']
    row.update(exit_code=child.returncode, finished_ns=time.time_ns(), elapsed_ns=elapsed,
               child_end_class='EXIT_STATUS' if child.returncode >= 0 else 'SIGNAL',
               stdout=stdout.decode(errors='replace'), stderr=stderr.decode(errors='replace'),
               stdout_sha256=hashlib.sha256(stdout).hexdigest(), stderr_sha256=hashlib.sha256(stderr).hexdigest(),
               stdout_bytes=len(stdout), stderr_bytes=len(stderr))
    require(not row['communicate_errors'], 'communicate异常已接管并回收：' + repr(row))
    require(elapsed <= 2_000_000_000, '自有child超2秒预算，已真实wait/reap；不启动后续READ')
    require(child.returncode == code and stderr == b'', '只读命令失败：' + repr(row))
    return row, stdout

def read_regular(path, allow_hardlink=False):
    require(path.is_absolute() and path == path.resolve(), '非规范文件路径')
    before = path.lstat()
    require(stat.S_ISREG(before.st_mode) and (allow_hardlink or before.st_nlink == 1), '非批准普通文件：' + str(path))
    fd = os.open(path, os.O_RDONLY | os.O_NOFOLLOW | os.O_CLOEXEC)
    try:
        opened = os.fstat(fd)
        require((before.st_dev, before.st_ino) == (opened.st_dev, opened.st_ino), '文件身份变化')
        with os.fdopen(fd, 'rb', closefd=False) as stream:
            raw = stream.read()
        after = os.fstat(fd)
        require((opened.st_size, opened.st_mtime_ns, opened.st_ctime_ns) ==
                (after.st_size, after.st_mtime_ns, after.st_ctime_ns), '读取期间文件变化')
    finally:
        os.close(fd)
    return raw, opened

def pin(path, digest):
    raw, _ = read_regular(path)
    require(hashlib.sha256(raw).hexdigest() == digest, 'SHA变化：' + str(path))
    return json.loads(raw)

def check(name, fn, exhaustive=False):
    row = {'name': name, 'status': 'FAIL', 'started_ns': time.time_ns()}
    result['checks'].append(row)
    try:
        row['value'] = fn()
        require(not isinstance(row['value'], dict) or row['value'].get('valid') is not False, '逐项检查有失败，保留完整结果')
        row['status'] = 'PASS'
        return row['value']
    except BaseException as error:
        row['error'] = repr(error)
        note_error(name, error)
        if not exhaustive:
            raise
    finally:
        row['finished_ns'] = time.time_ns()

def identity():
    value = {'hostname': os.uname().nodename, 'uid': os.getuid(), 'euid': os.geteuid(),
             'gid': os.getgid(), 'egid': os.getegid(), 'machine': os.uname().machine,
             'boot_id': Path('/proc/sys/kernel/random/boot_id').read_text().strip(), 'python': sys.version,
             'python_executable': sys.executable}
    require(value['hostname'] == 'ubuntu' and value['machine'] == 'aarch64'
            and value['uid'] == value['euid'] == value['gid'] == value['egid'] == 1000
            and value['boot_id'] == EXPECTED_BOOT, 'Orin主机/boot/运行身份错误')
    return value

def bootstrap():
    global driver, binaries
    helper = BASE / 'bootstrap/s52-control-helper-r1/prelaunch_go.py'
    require(hashlib.sha256(read_regular(helper)[0]).hexdigest() == HELPER_SHA, '既验helper身份改变')
    for name, expected in DRIVER_SHAS.items():
        require(hashlib.sha256(read_regular(ROOT / 'scripts' / name)[0]).hexdigest() == expected, '既验driver/helper身份改变：' + name)
    sys.path.insert(0, str(helper.parent))
    import prelaunch_go
    # 旧 helper 的只读 Git 统一经过本探针预算/wait；不调用其 timeout=30 的 subprocess.run。
    prelaunch_go.git = lambda root, *args: command(['git', '-C', str(root), *args])[1]
    driver, hashes = prelaunch_go.tracked_driver(ROOT / 'scripts/run_post_e_h2.py', ROOT, '4a8e171f27bf18625973aa4f3a6097e9b9fbed18')
    inputs = pin(BASE / 'bootstrap/s52-right-inputs-r1.json', '541d7f463948cfb5393dbf1a8fe20be648c6e550f014caa4245d4b446dbcbff7')
    manifests = {kind: prelaunch_go.reference(inputs[kind]) for kind in ('production', 'measurement', 'installed')}
    binaries = [Path(r['path']) for kind in ('production', 'measurement') for r in manifests[kind]['artifacts'].values()]
    binaries += [Path(r['path']) for n, r in manifests['installed']['files'].items() if n.startswith('installed:')]
    binaries.append(ELF)
    require(driver.UNITS == UNITS, '服务白名单与既验driver不符')
    for side, profile in PROFILES.items():
        actual = driver.arm_profile(side)
        require((actual.device, actual.usb_serial, actual.trust) == (profile['device'], profile['serial'], profile['trust']), 'USB/trust白名单不符')
    return {'driver_helpers': hashes, 'pinned_read_tool_is_current_build': False}

def elf_identity():
    raw, metadata = read_regular(ELF)
    require(hashlib.sha256(raw).hexdigest() == ELF_SHA and len(raw) == 1469904
            and raw[:6] == b'\x7fELF\x02\x01' and struct.unpack_from('<H', raw, 18)[0] == 183
            and metadata.st_uid == metadata.st_gid == 1000 and os.access(ELF, os.X_OK), '冻结READ ELF身份变化')
    return {'path': str(ELF), 'sha256': ELF_SHA, 'bytes': len(raw), 'elf_machine': 183,
            'mode': stat.S_IMODE(metadata.st_mode), 'uid': metadata.st_uid, 'gid': metadata.st_gid,
            'device': metadata.st_dev, 'inode': metadata.st_ino}

def formal(cleanup=False):
    prefix = 'after' if cleanup else 'before'
    def read_head():
        head = command(['git', '-C', str(FORMAL), 'rev-parse', 'HEAD'], cleanup=cleanup)[1].decode().strip()
        require(head == 'ca14f0e6cf6df8ecc6baaaa8dff2dddb64abbd0a', '正式ca14 HEAD变化')
        return head
    def read_status():
        status = command(['git', '-C', str(FORMAL), 'status', '--porcelain=v1', '--untracked-files=all'], cleanup=cleanup)[1].decode()
        require(status == '', '正式源码不clean')
        return status
    def baseline():
        installed = pin(BASE / 'right-readonly-r1/installed_before.json', '00c262bbbea00c8c2eff7c21b321a0b2ee82600c5e3d2362b8f2e6e46936a690')
        require({name: {key: row[key] for key in ('path', 'sha256', 'bytes', 'uid', 'gid', 'mode')}
                 for name, row in installed['files'].items()} == FORMAL_FILES, '固定文件白名单与既验manifest不同')
        return {'manifest_sha256': '00c262bbbea00c8c2eff7c21b321a0b2ee82600c5e3d2362b8f2e6e46936a690'}
    value = {'head': check(prefix + '_formal_HEAD', read_head, cleanup),
             'status_porcelain': check(prefix + '_formal_status', read_status, cleanup),
             'baseline': check(prefix + '_formal_baseline', baseline, cleanup), 'files': {}}
    for name, expected in FORMAL_FILES.items():
        def read_file(expected=expected, name=name):
            raw, m = read_regular(Path(expected['path']), allow_hardlink=True)
            row = {'path': expected['path'], 'sha256': hashlib.sha256(raw).hexdigest(), 'bytes': len(raw),
                   'uid': m.st_uid, 'gid': m.st_gid, 'mode': stat.S_IMODE(m.st_mode), 'nlink': m.st_nlink,
                   'device': m.st_dev, 'inode': m.st_ino, 'mtime_ns': m.st_mtime_ns, 'ctime_ns': m.st_ctime_ns}
            row['valid'] = all(row[key] == expected[key] for key in ('sha256', 'bytes', 'uid', 'gid', 'mode'))
            row['expected'] = expected
            return row
        value['files'][name] = check(prefix + '_formal_file_' + name, read_file, cleanup)
    value['valid'] = (value['head'] is not None and value['status_porcelain'] is not None and value['baseline'] is not None
                      and all(row is not None for row in value['files'].values()))
    return value

def services(cleanup=False):
    prefix = 'after' if cleanup else 'before'
    argv = ['systemctl', 'show', *UNITS, '--property=Id,LoadState,ActiveState,SubState,MainPID']
    shown = check(prefix + '_service_show', lambda: command(argv, cleanup=cleanup)[1].decode(), cleanup)
    # child失败时仍用已保留的完整stdout逐unit核实；不能由此把命令失败改成PASS。
    retained = result['commands'][-1] if result['commands'] and result['commands'][-1]['argv'] == argv else {}
    raw_text = shown if shown is not None else retained.get('stdout', '')
    value = {'raw_show': raw_text, 'show_success': shown is not None, 'units': {}}
    blocks = raw_text.strip().split('\n\n')
    def unit(name):
        matches = [block for block in blocks if 'Id=' + name in block.splitlines()]
        require(len(matches) == 1, '服务Id缺失/重复：' + name)
        fields = {}
        for line in matches[0].splitlines():
            key, content = line.split('=', 1)
            require(key not in fields, '服务字段重复：' + name)
            fields[key] = content
        valid = (set(fields) == {'Id', 'LoadState', 'ActiveState', 'SubState', 'MainPID'}
                 and fields.get('LoadState') == 'loaded' and fields.get('ActiveState') == 'inactive'
                 and fields.get('SubState') == 'dead' and fields.get('MainPID') == '0')
        return {'fields': fields, 'valid': valid}
    for name in UNITS:
        value['units'][name] = check(prefix + '_service_' + name, lambda name=name: unit(name), cleanup)
    def complete_unit_set():
        ids = [line[3:] for block in blocks for line in block.splitlines() if line.startswith('Id=')]
        require(len(ids) == len(UNITS) and set(ids) == set(UNITS), '六服务清单缺失/多项')
        return ids
    value['exact_unit_set'] = check(prefix + '_service_exact_set', complete_unit_set, cleanup)
    value['valid'] = value['show_success'] and value['exact_unit_set'] is not None and all(v is not None for v in value['units'].values())
    return value

def processes(cleanup=False):
    require(driver is not None, '既验driver未加载，进程门不能假称通过')
    def proc_probe(candidates):
        request = {'schema': 'P7_PROC_PROBE_V1', 'candidates': candidates}
        row, raw = command(['sudo', '-n', '/usr/bin/python3', '-I', '-S', '-c', driver.PROC_PROBE_CODE],
                           input_raw=json.dumps(request).encode(), cleanup=cleanup)
        return {'request': request, 'exit_code': row['exit_code'], 'response': json.loads(raw),
                'stdout': row['stdout'], 'stderr': row['stderr'], 'pid': row['pid'], 'reaped': row['reaped']}
    snap = driver.process_snapshot(-1, BASE / 'right-h2-run-01', binaries, probe_runner=proc_probe)
    require(snap['clean'], '控制/READ进程残留或身份不可读')
    return snap

def device(side, cleanup=False):
    profile = PROFILES[side]
    row, raw = command(['udevadm', 'info', '--query=property', '--name', profile['device']], cleanup=cleanup)
    lines = raw.decode().splitlines()
    for key, value in {'ID_VENDOR_ID': '1a86', 'ID_MODEL_ID': '55d3', 'ID_SERIAL_SHORT': profile['serial'], 'ID_USB_DRIVER': 'cdc_acm'}.items():
        require([l for l in lines if l.startswith(key + '=')] == [key + '=' + value], 'USB身份错误')
    path = Path(profile['device'])
    link, m = path.lstat(), path.stat()
    require(stat.S_ISLNK(link.st_mode) and stat.S_ISCHR(m.st_mode) and os.access(path, os.R_OK | os.W_OK), 'USB类型/权限错误')
    return {'device': str(path), 'resolved': str(path.resolve()), 'rdev': m.st_rdev, 'mode': stat.S_IMODE(m.st_mode),
            'uid': m.st_uid, 'gid': m.st_gid, 'device_inode': m.st_ino, 'link_inode': link.st_ino,
            'link_target': os.readlink(path), 'udev_command': row}

def holder(path, elevated, cleanup=False):
    require(path.exists(), '持有者路径缺失：' + str(path))
    row, raw = command((['sudo', '-n'] if elevated else []) + ['fuser', str(path)], 1, cleanup=cleanup)
    require(raw == b'', '串口/锁有持有者')
    return row

def protection(cleanup=False):
    prefix = 'after' if cleanup else 'before'
    states = {}
    for side, profile in PROFILES.items():
        def directory(profile=profile):
            trust = profile['trust'].lstat()
            return {'path': str(profile['trust']), 'device': trust.st_dev, 'inode': trust.st_ino,
                    'uid': trust.st_uid, 'gid': trust.st_gid, 'mode': stat.S_IMODE(trust.st_mode),
                    'valid': (profile['trust'] == profile['trust'].resolve() and stat.S_ISDIR(trust.st_mode)
                              and trust.st_uid == trust.st_gid == 1000 and stat.S_IMODE(trust.st_mode) == 0o750)}
        states[side] = {'directory': check(prefix + '_' + side + '_protection_directory', directory, cleanup)}
        for name in ('rx_trust_marker', 'rx_trust_marker.bak', 'estop_latch', 'estop_latch.bak', 'rx_trust.lock', 'estop_latch.lock'):
            path = profile['trust'] / name
            def read_ref(path=path, name=name):
                try:
                    raw, m = read_regular(path)
                except FileNotFoundError:
                    return {'path': str(path), 'missing': True}
                return {'path': str(path), 'hex': raw.hex(), 'sha256': hashlib.sha256(raw).hexdigest(),
                        'bytes': len(raw), 'mode': stat.S_IMODE(m.st_mode), 'uid': m.st_uid, 'gid': m.st_gid,
                        'device': m.st_dev, 'inode': m.st_ino, 'mtime_ns': m.st_mtime_ns, 'ctime_ns': m.st_ctime_ns,
                        'valid': (len(raw) <= 4096 and m.st_uid == m.st_gid == 1000
                                  and stat.S_IMODE(m.st_mode) == (0o640 if name in ('estop_latch', 'estop_latch.bak') else 0o600))}
            states[side][name] = check(prefix + '_' + side + '_protection_' + name, read_ref, cleanup)
    states['valid'] = all(row is not None for side in PROFILES for row in states[side].values())
    return states

def guard(epoch, exhaustive=False):
    value = {}
    for name, fn in (('identity', identity), ('formal', lambda: formal(exhaustive)), ('services', lambda: services(exhaustive)),
                     ('processes', lambda: processes(exhaustive)), ('protection', lambda: protection(exhaustive)), ('elf', elf_identity)):
        value[name] = check(epoch + '_' + name, fn, exhaustive)
    value['devices'], value['holders'] = {}, []
    for side, profile in PROFILES.items():
        value['devices'][side] = check(epoch + '_' + side + '_device', lambda side=side: device(side, exhaustive), exhaustive)
        for path in (Path(profile['device']), profile['trust'] / 'rx_trust.lock', profile['trust'] / 'estop_latch.lock'):
            for elevated in (False, True):
                value['holders'].append(check(epoch + '_' + side + '_' + path.name + ('_sudo' if elevated else ''),
                                              lambda path=path, elevated=elevated: holder(path, elevated, exhaustive), exhaustive))
    if not exhaustive:
        require(value['devices']['left']['resolved'] != value['devices']['right']['resolved'], '双USB映射相同')
    return value




def release_resources():
    # 对持有的所有 child 先真实 wait/reap；之后逐一释放fd，失败不跳过其余fd。
    for child, row in children:
        if not row['reaped']:
            collect_owned_child(child, None, row)
    for fd in reversed(locks):
        try:
            os.close(fd)
            for row in result['locks']:
                if row['fd'] == fd:
                    row['released'] = True
                    row['released_ns'] = time.time_ns()
        except BaseException as error:
            note_error('release_fd', error)
    locks.clear()

def lifecycle(preflight, body, teardown, postflight):
    try:
        preflight()
        body()
    except BaseException as error:
        note_error('preflight_or_read', error)
    finally:
        try:
            teardown()
        except BaseException as error:
            note_error('teardown', error)
        finally:
            try:
                postflight()
            except BaseException as error:
                note_error('postflight', error)



OLD_UNITS = ('xlerobot-coordinator.service', 'xlerobot-web.service', 'xlerobot-s0-bus1.service', 'xlerobot-s0-bus2.service', 'xlerobot-handoff.service')
FIXED_REFS = [{'path': '/etc/robot/xlerobot_left_arm.toml', 'sha256': '720979785a149f8f25a9a48f5bab10202e32f6e312a998267c4ce3c20d4a6194', 'bytes': 2161, 'uid': 0, 'gid': 0, 'mode': 420, 'nlink': 1}, {'path': '/etc/robot/xlerobot_right_arm.toml', 'sha256': 'ce46c7b1317811ce7cb267db3863624462823c58518cd5e044df4dbc54fd3992', 'bytes': 1589, 'uid': 0, 'gid': 0, 'mode': 420, 'nlink': 1}, {'path': '/etc/robot/rpc_roles.toml', 'sha256': '6b989264dccf599d22a83808226f049f05481fe57e2eb04519bbcfc3dab3278f', 'bytes': 3434, 'uid': 0, 'gid': 0, 'mode': 420, 'nlink': 1}, {'path': '/home/loosqk/repo/robot/robot-system/target/release/robot_rpc_gateway', 'sha256': '9e8d029c30472bcd5371b6ae1fb6e4f98446086f420c567d11891dab81cc8d78', 'bytes': 5883280, 'uid': 1000, 'gid': 1000, 'mode': 509, 'nlink': 2}, {'path': '/home/loosqk/repo/robot/robot-system/target/release/s0_daemon', 'sha256': '461aec751fc5a41a24ab4dcc3778ca1e88783c4c96467254419f7bf13d1fde7f', 'bytes': 3968152, 'uid': 1000, 'gid': 1000, 'mode': 509, 'nlink': 2}, {'path': '/home/loosqk/repo/robot/robot-system/target/release/s1_daemon', 'sha256': '1c9037443f9786f09631705bd8800bc5f85333a45c7e9b08d6fcfaf26738de93', 'bytes': 4033312, 'uid': 1000, 'gid': 1000, 'mode': 509, 'nlink': 2}, {'path': '/home/loosqk/repo/robot/robot-system/target/release/xlerobot_deploy', 'sha256': '7d0cfa3da22610e9a34749d1fbb0d081239a728ed1a30cb9836e01c909dff5c3', 'bytes': 1818776, 'uid': 1000, 'gid': 1000, 'mode': 509, 'nlink': 2}, {'path': '/etc/systemd/system/xlerobot-s0-left-arm.service', 'sha256': '842e732b55677567e914e2ad6862ccf561ef5b39c2bbe8647c42e2fef50332db', 'bytes': 5247, 'uid': 0, 'gid': 0, 'mode': 420, 'nlink': 1}, {'path': '/etc/systemd/system/xlerobot-s0-right-arm.service', 'sha256': '08d3b928d9206b7cc282efdad174ef1f4e66f61971f3d09f4e651a1f70c3e579', 'bytes': 5259, 'uid': 0, 'gid': 0, 'mode': 420, 'nlink': 1}, {'path': '/etc/systemd/system/xlerobot-s1-left.service', 'sha256': 'e8ceafd7540f6a78076ad7f7d51845a2df005f9e84998120e70e273dec62b0b2', 'bytes': 1830, 'uid': 0, 'gid': 0, 'mode': 420, 'nlink': 1}, {'path': '/etc/systemd/system/xlerobot-s1-right.service', 'sha256': 'faa3d9dbe85e721f383ec2e6a81a153aa136c4397c44603f64d421ba3125575f', 'bytes': 1839, 'uid': 0, 'gid': 0, 'mode': 420, 'nlink': 1}, {'path': '/etc/systemd/system/xlerobot-gateway-left.service', 'sha256': '1b0afa5c17a2be42b6b5286f2e3707471be1aa37390f65017fecc07c19839ea7', 'bytes': 2117, 'uid': 0, 'gid': 0, 'mode': 420, 'nlink': 1}, {'path': '/etc/systemd/system/xlerobot-gateway-right.service', 'sha256': '1233ce1571c626af494f87b26a9e084117fc6b8761ce6e39b24fae377502bd71', 'bytes': 2125, 'uid': 0, 'gid': 0, 'mode': 420, 'nlink': 1}, {'path': '/etc/systemd/system/xlerobot-handoff.service', 'sha256': '4cce48f85d40642bab7c7646e06be38f37e3412bcc51031b29737b5527e03ace', 'bytes': 3367, 'uid': 0, 'gid': 0, 'mode': 420, 'nlink': 1}, {'path': '/home/loosqk/repo/dimensional-applications/calibration/base.json', 'sha256': 'c35a8c47615293628fb88e28f0c90deb0b9cff6e3634e21f7de32790a7b4d671', 'bytes': 387, 'mode': 436}, {'path': '/home/loosqk/repo/dimensional-applications/calibration/head.json', 'sha256': 'a1f251d5c2baecb7bbdd7c8c7f8988d839977c32a190f4c31189cfe9829114ee', 'bytes': 263, 'mode': 436}, {'path': '/home/loosqk/repo/dimensional-applications/calibration/left_arm.json', 'sha256': 'd946abf3d0f4b68f63c81eb21a95b6e35dd66406d5bf5c3219b19d8ae8c6f7de', 'bytes': 824, 'mode': 436}, {'path': '/home/loosqk/repo/dimensional-applications/calibration/right_arm.json', 'sha256': '98ad69369b4bcfeb1cc84051116d8722709fe2d38b987c077e6e1453c2cea03e', 'bytes': 833, 'mode': 436}, {'path': '/home/loosqk/repo/dimensional-applications/src/xlerobot_dimos/adapters/bus2_base.py', 'sha256': '0d1e4967c703154d816fd6717d09c21d9204076072f578aac071eb222334f435', 'bytes': 12959, 'mode': 420}, {'path': '/home/loosqk/repo/dimensional-applications/src/xlerobot_dimos/common/config.py', 'sha256': '28073a3ee621738a8af08bdf6f72999907506f6ccfe89ac021bbe4fab4e72c1f', 'bytes': 7421, 'mode': 420}, {'path': '/home/loosqk/repo/dimensional-applications/src/xlerobot_dimos/common/feetech_io/__init__.py', 'sha256': '899a31c76e74085585c5f85fe7658e0524efc8d65e31b98c912c49d603f8d630', 'bytes': 1761, 'mode': 420}, {'path': '/home/loosqk/repo/dimensional-applications/src/xlerobot_dimos/common/feetech_io/_ranges_input.py', 'sha256': 'b93765cb4defba21fc5042ce6f89c17d720ae8f754eb3f1762a6a40ed438a14a', 'bytes': 1014, 'mode': 420}, {'path': '/home/loosqk/repo/dimensional-applications/src/xlerobot_dimos/common/feetech_io/bus.py', 'sha256': '706a7d9fad50a3d25dfe8dfc3f7d592a743b48cb7469fec8d822ce4fb90806c7', 'bytes': 14304, 'mode': 420}, {'path': '/home/loosqk/repo/dimensional-applications/src/xlerobot_dimos/common/feetech_io/calibration.py', 'sha256': '905ca73e31932e80559319336379bd6e413155ff921edf728dc432bb34a6f577', 'bytes': 6714, 'mode': 420}, {'path': '/home/loosqk/repo/dimensional-applications/src/xlerobot_dimos/common/feetech_io/encoding.py', 'sha256': '7e8c95b05ee4ae7ee0f65a874dbbf420a972c9302d6be52a0919b7f42e6590c6', 'bytes': 2956, 'mode': 420}, {'path': '/home/loosqk/repo/dimensional-applications/src/xlerobot_dimos/common/feetech_io/patches.py', 'sha256': '12af93818456729760e84c3976b87fc17166c0b65517408a8f6c7e711d0e766e', 'bytes': 1122, 'mode': 420}, {'path': '/home/loosqk/repo/dimensional-applications/src/xlerobot_dimos/common/feetech_io/registers.py', 'sha256': 'a11b129444177344a3d71bf86dbfba71c10131d3ffa70812df7655d8bd83139e', 'bytes': 4046, 'mode': 420}, {'path': '/home/loosqk/repo/dimensional-applications/src/xlerobot_dimos/common/feetech_io/types.py', 'sha256': '638be44dae884ef87b21e0161cd027eb2a41dc5e01c083f457e82813af63443a', 'bytes': 1581, 'mode': 420}, {'path': '/home/loosqk/repo/dimensional-applications/src/xlerobot_dimos/common/units.py', 'sha256': 'c7512eddfa3db04465bcbe99c28dc83519262a3e447e1ba40640c0d99cc6bdb1', 'bytes': 6790, 'mode': 420}, {'path': '/home/loosqk/robot-checks/hardware-verify-20260930-r2/maintenance/proc_identity.py', 'sha256': 'da28b6eee270a09bfbdb7f90613f2fe9f0d73537c076a8b54fb811648cadb70f', 'bytes': 10882}]
PROC_HELPER = {'path': '/home/loosqk/robot-checks/hardware-verify-20260930-r2/maintenance/proc_identity.py', 'sha256': 'da28b6eee270a09bfbdb7f90613f2fe9f0d73537c076a8b54fb811648cadb70f', 'bytes': 10882}

def allowed_command(argv):
    devices = {p['device'] for p in PROFILES.values()}
    holder_paths = devices | {str(p['trust'] / name) for p in PROFILES.values() for name in ('rx_trust.lock', 'estop_latch.lock')}
    if argv[:2] == ['git', '-C'] and len(argv) >= 4 and argv[2] in (str(ROOT), str(FORMAL)):
        return (argv[3:] in (['rev-parse', 'HEAD'], ['status', '--porcelain=v1', '--untracked-files=all'])
                or len(argv) == 5 and argv[3] == 'show' and argv[4] in
                ('HEAD:scripts/run_post_e_h2.py', 'HEAD:scripts/post_e_h2_report.py', 'HEAD:scripts/post_e_h2_artifacts.py'))
    if argv == ['systemctl', 'show', *UNITS, '--property=Id,LoadState,ActiveState,SubState,MainPID']:
        return True
    if len(argv) == 4 and argv[:2] == ['systemctl', 'show'] and argv[2] in OLD_UNITS and argv[3] == '--property=Id,LoadState,ActiveState,SubState,MainPID':
        return True
    if len(argv) == 5 and argv[:4] == ['udevadm', 'info', '--query=property', '--name']:
        return argv[4] in devices
    if len(argv) == 2 and argv[0] == 'fuser':
        return argv[1] in holder_paths
    if len(argv) == 4 and argv[:3] == ['sudo', '-n', 'fuser']:
        return argv[3] in holder_paths
    return driver is not None and argv == ['sudo', '-n', '/usr/bin/python3', '-I', '-S', '-c', driver.PROC_PROBE_CODE]

def fixed_refs(epoch, exhaustive=False):
    refs = {}
    for expected in FIXED_REFS:
        def read_ref(expected=expected):
            raw, m = read_regular(Path(expected['path']), allow_hardlink=True)
            value = {'path': expected['path'], 'sha256': hashlib.sha256(raw).hexdigest(), 'bytes': len(raw),
                     'uid': m.st_uid, 'gid': m.st_gid, 'mode': stat.S_IMODE(m.st_mode), 'nlink': m.st_nlink,
                     'device': m.st_dev, 'inode': m.st_ino, 'mtime_ns': m.st_mtime_ns, 'ctime_ns': m.st_ctime_ns}
            value['valid'] = all(value[key] == expected[key] for key in ('sha256', 'bytes')) and all(value[key] == expected[key] for key in ('uid', 'gid', 'mode') if key in expected)
            if str(Path(expected['path']).parent).endswith('/calibration'):
                value['calibration_json'] = json.loads(raw)
            return value
        refs[expected['path']] = check(epoch + '_fixed_ref_' + expected['path'], read_ref, exhaustive)
    return {'refs': refs, 'valid': all(value is not None for value in refs.values())}

def old_services(epoch, exhaustive=False):
    values = {}
    for name in OLD_UNITS:
        def read_unit(name=name):
            row, raw = command(['systemctl', 'show', name, '--property=Id,LoadState,ActiveState,SubState,MainPID'], cleanup=exhaustive)
            fields = {}
            for line in raw.decode().splitlines():
                key, value = line.split('=', 1)
                require(key not in fields, '服务字段重复')
                fields[key] = value
            valid = fields.get('Id') == name and fields.get('MainPID') == '0'
            if name == 'xlerobot-handoff.service':
                valid = valid and fields.get('LoadState') == 'loaded' and fields.get('ActiveState') == 'active' and fields.get('SubState') == 'exited'
            else:
                valid = valid and fields.get('LoadState') in ('loaded', 'not-found') and fields.get('ActiveState') == 'inactive' and fields.get('SubState') == 'dead'
            return {'raw_show': row['stdout'], 'fields': fields, 'valid': valid}
        values[name] = check(epoch + '_old_service_' + name, read_unit, exhaustive)
    return {'units': values, 'valid': all(value is not None for value in values.values())}

def prep_main():
    for sig in (signal.SIGINT, signal.SIGTERM, signal.SIGHUP, signal.SIGQUIT):
        signal.signal(sig, handler)
    def before():
        result['identity'] = check('launch_identity', identity)
        result['bootstrap'] = check('bootstrap', bootstrap)
        result['before'] = guard('before')
        result['fixed_refs_before'] = check('fixed_refs_before', lambda: fixed_refs('before'))
        result['old_services_before'] = check('old_services_before', lambda: old_services('before'))
        result['artifact_root_observation'] = {'path': '/home/loosqk/robot-checks/hardware-selected-targets-20261008-r1',
                                              'exists': Path('/home/loosqk/robot-checks/hardware-selected-targets-20261008-r1').exists(),
                                              'created_by_this_probe': False}
    def after():
        if result.get('identity') is None:
            result['postflight_status'] = 'NOT_RUN_HOST_IDENTITY_REFUSED_UART0'
            return
        result['after'] = guard('after', True)
        result['fixed_refs_after'] = check('fixed_refs_after', lambda: fixed_refs('after', True), True)
        result['old_services_after'] = check('old_services_after', lambda: old_services('after', True), True)
        if result.get('payload_before') is not None:
            result['payload_after'] = motion_payload_refs(True)
            check('payload_first_last', lambda: require(result['payload_before'] == result['payload_after'], '阶段payload首尾变化'), True)
    lifecycle(before, motion_driver, release_resources, after)
    if result.get('before') is not None and result.get('after') is not None:
        for name in ('identity', 'formal', 'services', 'protection', 'elf'):
            check('compare_' + name, lambda name=name: require(result['before'][name] is not None and result['after'][name] is not None
                  and result['before'][name] == result['after'][name], '前后逐项不同/缺项：' + name), True)
        for side in PROFILES:
            def compare_device(side=side):
                before_value, after_value = result['before']['devices'][side], result['after']['devices'][side]
                require(before_value is not None and after_value is not None, '前后USB缺项')
                require({k: v for k, v in before_value.items() if k != 'udev_command'} ==
                        {k: v for k, v in after_value.items() if k != 'udev_command'}, 'USB前后身份变化')
                def enum_fields(value):
                    fields = dict(line.split('=', 1) for line in value['udev_command']['stdout'].splitlines() if '=' in line)
                    return {key: fields.get(key) for key in ('ID_SERIAL_SHORT', 'DEVPATH', 'USEC_INITIALIZED')}
                require(enum_fields(before_value) == enum_fields(after_value), 'USB枚举代次前后变化')
            check('compare_' + side + '_device', compare_device, True)
    else:
        note_error('comparison', ValueError('前置缺项，不能假称前后一致'))
    for name in ('fixed_refs', 'old_services'):
        check('compare_' + name, lambda name=name: require(result.get(name + '_before') is not None
              and result.get(name + '_after') is not None and result[name + '_before'] == result[name + '_after'],
              '前后固定引用/旧unit变化或缺项'), True)
    check('total_budget', lambda: require(within_budget(), '整轮超过600秒；真实回收及后验保留'), True)
    check('all_wrapper_children_reaped', lambda: require(not stop and all(row['reaped'] for row in result['commands'])
          and all(row['argv'][0] != str(ELF) for row in result['commands']) and result['reads'] == [], 'child未回收/收到信号；不冒称driver没有UART'), True)
    result.update(finished_ns=time.time_ns(), elapsed_ns=time.monotonic_ns() - result['started_monotonic_ns'],
                  status='PASS' if not result['errors'] else 'FAIL', limitations=['实际整体结果遵循driver原报告；底盘DEFERRED不记PASS；封装独立后验不调用poke',
                  '历史左腕/H2 FAIL与D15 OPEN/DEFERRED、deployable=false不变'])
    print(json.dumps(result, ensure_ascii=False, allow_nan=False), flush=True)
    return 0 if result['status'] == 'PASS' else 1

MOTION_PAYLOAD = {'scripts/run_hardware_maintenance.py': {'sha256': 'caf87b36f0689b4e40fb8fade0f4577ef0a6ff691732c157a10ed620b9a6d4f4', 'bytes': 50013}, 'scripts/tests/test_hardware_maintenance.py': {'sha256': '0c817f14a3b56cb84b0f0453d6d8e74eeaeedc1d044dfd9f047f253e67fce25b', 'bytes': 43122}, 'scripts/tests/fixtures/hardware_maintenance_run02_return_error.json': {'sha256': 'a7bfa3fbfc3f3039be9db68973348ba4db156b74f807e57a01eecda8dfd27948', 'bytes': 6971}, 'maintenance_bindings_fresh_r1.json': {'sha256': '773a226ad1b50c6ba93b809a2195b0a44fd2dc3d4667819ec8845b307c53d2eb', 'bytes': 23571}, 'right_head_plan_r1.json': {'sha256': '480e45ba47cd2af520a777b0a25e95a48f2c32f8b6938e210fcb346714e6dd68', 'bytes': 26876}}
MOTION_FRESH_REFS = {'refs': {'/etc/robot/xlerobot_left_arm.toml': {'path': '/etc/robot/xlerobot_left_arm.toml', 'sha256': '720979785a149f8f25a9a48f5bab10202e32f6e312a998267c4ce3c20d4a6194', 'bytes': 2161, 'uid': 0, 'gid': 0, 'mode': 420, 'nlink': 1, 'device': 66305, 'inode': 29887825, 'mtime_ns': 1788168348475238803, 'ctime_ns': 1788168348475238803, 'valid': True}, '/etc/robot/xlerobot_right_arm.toml': {'path': '/etc/robot/xlerobot_right_arm.toml', 'sha256': 'ce46c7b1317811ce7cb267db3863624462823c58518cd5e044df4dbc54fd3992', 'bytes': 1589, 'uid': 0, 'gid': 0, 'mode': 420, 'nlink': 1, 'device': 66305, 'inode': 29887826, 'mtime_ns': 1788168348487238970, 'ctime_ns': 1788168348487238970, 'valid': True}, '/etc/robot/rpc_roles.toml': {'path': '/etc/robot/rpc_roles.toml', 'sha256': '6b989264dccf599d22a83808226f049f05481fe57e2eb04519bbcfc3dab3278f', 'bytes': 3434, 'uid': 0, 'gid': 0, 'mode': 420, 'nlink': 1, 'device': 66305, 'inode': 29887828, 'mtime_ns': 1788168348499239136, 'ctime_ns': 1788168348499239136, 'valid': True}, '/home/loosqk/repo/robot/robot-system/target/release/robot_rpc_gateway': {'path': '/home/loosqk/repo/robot/robot-system/target/release/robot_rpc_gateway', 'sha256': '9e8d029c30472bcd5371b6ae1fb6e4f98446086f420c567d11891dab81cc8d78', 'bytes': 5883280, 'uid': 1000, 'gid': 1000, 'mode': 509, 'nlink': 2, 'device': 66305, 'inode': 14052064, 'mtime_ns': 1788893840237424890, 'ctime_ns': 1788893840309426294, 'valid': True}, '/home/loosqk/repo/robot/robot-system/target/release/s0_daemon': {'path': '/home/loosqk/repo/robot/robot-system/target/release/s0_daemon', 'sha256': '461aec751fc5a41a24ab4dcc3778ca1e88783c4c96467254419f7bf13d1fde7f', 'bytes': 3968152, 'uid': 1000, 'gid': 1000, 'mode': 509, 'nlink': 2, 'device': 66305, 'inode': 14051956, 'mtime_ns': 1788893624317631230, 'ctime_ns': 1788893624373632091, 'valid': True}, '/home/loosqk/repo/robot/robot-system/target/release/s1_daemon': {'path': '/home/loosqk/repo/robot/robot-system/target/release/s1_daemon', 'sha256': '1c9037443f9786f09631705bd8800bc5f85333a45c7e9b08d6fcfaf26738de93', 'bytes': 4033312, 'uid': 1000, 'gid': 1000, 'mode': 509, 'nlink': 2, 'device': 66305, 'inode': 14051978, 'mtime_ns': 1788893728867357102, 'ctime_ns': 1788893728927358156, 'valid': True}, '/home/loosqk/repo/robot/robot-system/target/release/xlerobot_deploy': {'path': '/home/loosqk/repo/robot/robot-system/target/release/xlerobot_deploy', 'sha256': '7d0cfa3da22610e9a34749d1fbb0d081239a728ed1a30cb9836e01c909dff5c3', 'bytes': 1818776, 'uid': 1000, 'gid': 1000, 'mode': 509, 'nlink': 2, 'device': 66305, 'inode': 14051962, 'mtime_ns': 1788893645361959647, 'ctime_ns': 1788893645397960217, 'valid': True}, '/etc/systemd/system/xlerobot-s0-left-arm.service': {'path': '/etc/systemd/system/xlerobot-s0-left-arm.service', 'sha256': '842e732b55677567e914e2ad6862ccf561ef5b39c2bbe8647c42e2fef50332db', 'bytes': 5247, 'uid': 0, 'gid': 0, 'mode': 420, 'nlink': 1, 'device': 66305, 'inode': 29886791, 'mtime_ns': 1788250404811585809, 'ctime_ns': 1788250404811585809, 'valid': True}, '/etc/systemd/system/xlerobot-s0-right-arm.service': {'path': '/etc/systemd/system/xlerobot-s0-right-arm.service', 'sha256': '08d3b928d9206b7cc282efdad174ef1f4e66f61971f3d09f4e651a1f70c3e579', 'bytes': 5259, 'uid': 0, 'gid': 0, 'mode': 420, 'nlink': 1, 'device': 66305, 'inode': 29886794, 'mtime_ns': 1788250405287579227, 'ctime_ns': 1788250405287579227, 'valid': True}, '/etc/systemd/system/xlerobot-s1-left.service': {'path': '/etc/systemd/system/xlerobot-s1-left.service', 'sha256': 'e8ceafd7540f6a78076ad7f7d51845a2df005f9e84998120e70e273dec62b0b2', 'bytes': 1830, 'uid': 0, 'gid': 0, 'mode': 420, 'nlink': 1, 'device': 66305, 'inode': 29887832, 'mtime_ns': 1788168348519239414, 'ctime_ns': 1788168348519239414, 'valid': True}, '/etc/systemd/system/xlerobot-s1-right.service': {'path': '/etc/systemd/system/xlerobot-s1-right.service', 'sha256': 'faa3d9dbe85e721f383ec2e6a81a153aa136c4397c44603f64d421ba3125575f', 'bytes': 1839, 'uid': 0, 'gid': 0, 'mode': 420, 'nlink': 1, 'device': 66305, 'inode': 29887833, 'mtime_ns': 1788168348519239414, 'ctime_ns': 1788168348519239414, 'valid': True}, '/etc/systemd/system/xlerobot-gateway-left.service': {'path': '/etc/systemd/system/xlerobot-gateway-left.service', 'sha256': '1b0afa5c17a2be42b6b5286f2e3707471be1aa37390f65017fecc07c19839ea7', 'bytes': 2117, 'uid': 0, 'gid': 0, 'mode': 420, 'nlink': 1, 'device': 66305, 'inode': 29887834, 'mtime_ns': 1788168348519239414, 'ctime_ns': 1788168348519239414, 'valid': True}, '/etc/systemd/system/xlerobot-gateway-right.service': {'path': '/etc/systemd/system/xlerobot-gateway-right.service', 'sha256': '1233ce1571c626af494f87b26a9e084117fc6b8761ce6e39b24fae377502bd71', 'bytes': 2125, 'uid': 0, 'gid': 0, 'mode': 420, 'nlink': 1, 'device': 66305, 'inode': 29887835, 'mtime_ns': 1788168348519239414, 'ctime_ns': 1788168348519239414, 'valid': True}, '/etc/systemd/system/xlerobot-handoff.service': {'path': '/etc/systemd/system/xlerobot-handoff.service', 'sha256': '4cce48f85d40642bab7c7646e06be38f37e3412bcc51031b29737b5527e03ace', 'bytes': 3367, 'uid': 0, 'gid': 0, 'mode': 420, 'nlink': 1, 'device': 66305, 'inode': 29887829, 'mtime_ns': 1788168348519239414, 'ctime_ns': 1788168348519239414, 'valid': True}, '/home/loosqk/repo/dimensional-applications/calibration/base.json': {'path': '/home/loosqk/repo/dimensional-applications/calibration/base.json', 'sha256': 'c35a8c47615293628fb88e28f0c90deb0b9cff6e3634e21f7de32790a7b4d671', 'bytes': 387, 'uid': 1000, 'gid': 20, 'mode': 436, 'nlink': 1, 'device': 66305, 'inode': 13900989, 'mtime_ns': 1775792155827958628, 'ctime_ns': 1775792155827958628, 'valid': True, 'calibration_json': {'base_left_wheel': {'id': 7, 'drive_mode': 0, 'homing_offset': 0, 'range_min': 0, 'range_max': 4095}, 'base_back_wheel': {'id': 8, 'drive_mode': 0, 'homing_offset': 0, 'range_min': 0, 'range_max': 4095}, 'base_right_wheel': {'id': 9, 'drive_mode': 0, 'homing_offset': 0, 'range_min': 0, 'range_max': 4095}}}, '/home/loosqk/repo/dimensional-applications/calibration/head.json': {'path': '/home/loosqk/repo/dimensional-applications/calibration/head.json', 'sha256': 'a1f251d5c2baecb7bbdd7c8c7f8988d839977c32a190f4c31189cfe9829114ee', 'bytes': 263, 'uid': 1000, 'gid': 20, 'mode': 436, 'nlink': 1, 'device': 66305, 'inode': 13900997, 'mtime_ns': 1775807011783731289, 'ctime_ns': 1775807011783731289, 'valid': True, 'calibration_json': {'head_motor_1': {'id': 7, 'drive_mode': 0, 'homing_offset': 1303, 'range_min': 797, 'range_max': 3081}, 'head_motor_2': {'id': 8, 'drive_mode': 0, 'homing_offset': -1556, 'range_min': 678, 'range_max': 3454}}}, '/home/loosqk/repo/dimensional-applications/calibration/left_arm.json': {'path': '/home/loosqk/repo/dimensional-applications/calibration/left_arm.json', 'sha256': 'd946abf3d0f4b68f63c81eb21a95b6e35dd66406d5bf5c3219b19d8ae8c6f7de', 'bytes': 824, 'uid': 1000, 'gid': 20, 'mode': 436, 'nlink': 1, 'device': 66305, 'inode': 13900993, 'mtime_ns': 1775806707590046233, 'ctime_ns': 1775806707590046233, 'valid': True, 'calibration_json': {'left_arm_shoulder_pan': {'id': 1, 'drive_mode': 0, 'homing_offset': 10, 'range_min': 620, 'range_max': 3301}, 'left_arm_shoulder_lift': {'id': 2, 'drive_mode': 0, 'homing_offset': 290, 'range_min': 1086, 'range_max': 3410}, 'left_arm_elbow_flex': {'id': 3, 'drive_mode': 0, 'homing_offset': -756, 'range_min': 969, 'range_max': 3158}, 'left_arm_wrist_flex': {'id': 4, 'drive_mode': 0, 'homing_offset': 235, 'range_min': 690, 'range_max': 2964}, 'left_arm_wrist_roll': {'id': 5, 'drive_mode': 0, 'homing_offset': -296, 'range_min': 73, 'range_max': 3864}, 'left_arm_gripper': {'id': 6, 'drive_mode': 0, 'homing_offset': -1103, 'range_min': 1408, 'range_max': 2886}}}, '/home/loosqk/repo/dimensional-applications/calibration/right_arm.json': {'path': '/home/loosqk/repo/dimensional-applications/calibration/right_arm.json', 'sha256': '98ad69369b4bcfeb1cc84051116d8722709fe2d38b987c077e6e1453c2cea03e', 'bytes': 833, 'uid': 1000, 'gid': 20, 'mode': 436, 'nlink': 1, 'device': 66305, 'inode': 13900992, 'mtime_ns': 1775804173231726966, 'ctime_ns': 1775804173231726966, 'valid': True, 'calibration_json': {'right_arm_shoulder_pan': {'id': 1, 'drive_mode': 0, 'homing_offset': -136, 'range_min': 839, 'range_max': 3511}, 'right_arm_shoulder_lift': {'id': 2, 'drive_mode': 0, 'homing_offset': 513, 'range_min': 957, 'range_max': 3295}, 'right_arm_elbow_flex': {'id': 3, 'drive_mode': 0, 'homing_offset': -15, 'range_min': 812, 'range_max': 2991}, 'right_arm_wrist_flex': {'id': 4, 'drive_mode': 0, 'homing_offset': -804, 'range_min': 1000, 'range_max': 3250}, 'right_arm_wrist_roll': {'id': 5, 'drive_mode': 0, 'homing_offset': -1177, 'range_min': 114, 'range_max': 3884}, 'right_arm_gripper': {'id': 6, 'drive_mode': 0, 'homing_offset': -507, 'range_min': 1384, 'range_max': 2847}}}, '/home/loosqk/repo/dimensional-applications/src/xlerobot_dimos/adapters/bus2_base.py': {'path': '/home/loosqk/repo/dimensional-applications/src/xlerobot_dimos/adapters/bus2_base.py', 'sha256': '0d1e4967c703154d816fd6717d09c21d9204076072f578aac071eb222334f435', 'bytes': 12959, 'uid': 1000, 'gid': 1000, 'mode': 420, 'nlink': 1, 'device': 66305, 'inode': 13901003, 'mtime_ns': 1775828042029956109, 'ctime_ns': 1775828042029956109, 'valid': True}, '/home/loosqk/repo/dimensional-applications/src/xlerobot_dimos/common/config.py': {'path': '/home/loosqk/repo/dimensional-applications/src/xlerobot_dimos/common/config.py', 'sha256': '28073a3ee621738a8af08bdf6f72999907506f6ccfe89ac021bbe4fab4e72c1f', 'bytes': 7421, 'uid': 1000, 'gid': 1000, 'mode': 420, 'nlink': 1, 'device': 66305, 'inode': 13901018, 'mtime_ns': 1775814600452283626, 'ctime_ns': 1775814600452283626, 'valid': True}, '/home/loosqk/repo/dimensional-applications/src/xlerobot_dimos/common/feetech_io/__init__.py': {'path': '/home/loosqk/repo/dimensional-applications/src/xlerobot_dimos/common/feetech_io/__init__.py', 'sha256': '899a31c76e74085585c5f85fe7658e0524efc8d65e31b98c912c49d603f8d630', 'bytes': 1761, 'uid': 1000, 'gid': 1000, 'mode': 420, 'nlink': 1, 'device': 66305, 'inode': 13901304, 'mtime_ns': 1775828039545867523, 'ctime_ns': 1775828039545867523, 'valid': True}, '/home/loosqk/repo/dimensional-applications/src/xlerobot_dimos/common/feetech_io/_ranges_input.py': {'path': '/home/loosqk/repo/dimensional-applications/src/xlerobot_dimos/common/feetech_io/_ranges_input.py', 'sha256': 'b93765cb4defba21fc5042ce6f89c17d720ae8f754eb3f1762a6a40ed438a14a', 'bytes': 1014, 'uid': 1000, 'gid': 1000, 'mode': 420, 'nlink': 1, 'device': 66305, 'inode': 13901303, 'mtime_ns': 1775828039465864670, 'ctime_ns': 1775828039465864670, 'valid': True}, '/home/loosqk/repo/dimensional-applications/src/xlerobot_dimos/common/feetech_io/bus.py': {'path': '/home/loosqk/repo/dimensional-applications/src/xlerobot_dimos/common/feetech_io/bus.py', 'sha256': '706a7d9fad50a3d25dfe8dfc3f7d592a743b48cb7469fec8d822ce4fb90806c7', 'bytes': 14304, 'uid': 1000, 'gid': 1000, 'mode': 420, 'nlink': 1, 'device': 66305, 'inode': 13901297, 'mtime_ns': 1775980950813770617, 'ctime_ns': 1775980950813770617, 'valid': True}, '/home/loosqk/repo/dimensional-applications/src/xlerobot_dimos/common/feetech_io/calibration.py': {'path': '/home/loosqk/repo/dimensional-applications/src/xlerobot_dimos/common/feetech_io/calibration.py', 'sha256': '905ca73e31932e80559319336379bd6e413155ff921edf728dc432bb34a6f577', 'bytes': 6714, 'uid': 1000, 'gid': 1000, 'mode': 420, 'nlink': 1, 'device': 66305, 'inode': 13901298, 'mtime_ns': 1775828039133852830, 'ctime_ns': 1775828039133852830, 'valid': True}, '/home/loosqk/repo/dimensional-applications/src/xlerobot_dimos/common/feetech_io/encoding.py': {'path': '/home/loosqk/repo/dimensional-applications/src/xlerobot_dimos/common/feetech_io/encoding.py', 'sha256': '7e8c95b05ee4ae7ee0f65a874dbbf420a972c9302d6be52a0919b7f42e6590c6', 'bytes': 2956, 'uid': 1000, 'gid': 1000, 'mode': 420, 'nlink': 1, 'device': 66305, 'inode': 13901299, 'mtime_ns': 1775828039205855398, 'ctime_ns': 1775828039205855398, 'valid': True}, '/home/loosqk/repo/dimensional-applications/src/xlerobot_dimos/common/feetech_io/patches.py': {'path': '/home/loosqk/repo/dimensional-applications/src/xlerobot_dimos/common/feetech_io/patches.py', 'sha256': '12af93818456729760e84c3976b87fc17166c0b65517408a8f6c7e711d0e766e', 'bytes': 1122, 'uid': 1000, 'gid': 1000, 'mode': 420, 'nlink': 1, 'device': 66305, 'inode': 13901300, 'mtime_ns': 1775828039257857252, 'ctime_ns': 1775828039257857252, 'valid': True}, '/home/loosqk/repo/dimensional-applications/src/xlerobot_dimos/common/feetech_io/registers.py': {'path': '/home/loosqk/repo/dimensional-applications/src/xlerobot_dimos/common/feetech_io/registers.py', 'sha256': 'a11b129444177344a3d71bf86dbfba71c10131d3ffa70812df7655d8bd83139e', 'bytes': 4046, 'uid': 1000, 'gid': 1000, 'mode': 420, 'nlink': 1, 'device': 66305, 'inode': 13901301, 'mtime_ns': 1775828039325859677, 'ctime_ns': 1775828039325859677, 'valid': True}, '/home/loosqk/repo/dimensional-applications/src/xlerobot_dimos/common/feetech_io/types.py': {'path': '/home/loosqk/repo/dimensional-applications/src/xlerobot_dimos/common/feetech_io/types.py', 'sha256': '638be44dae884ef87b21e0161cd027eb2a41dc5e01c083f457e82813af63443a', 'bytes': 1581, 'uid': 1000, 'gid': 1000, 'mode': 420, 'nlink': 1, 'device': 66305, 'inode': 13901302, 'mtime_ns': 1775828039401862388, 'ctime_ns': 1775828039401862388, 'valid': True}, '/home/loosqk/repo/dimensional-applications/src/xlerobot_dimos/common/units.py': {'path': '/home/loosqk/repo/dimensional-applications/src/xlerobot_dimos/common/units.py', 'sha256': 'c7512eddfa3db04465bcbe99c28dc83519262a3e447e1ba40640c0d99cc6bdb1', 'bytes': 6790, 'uid': 1000, 'gid': 1000, 'mode': 420, 'nlink': 1, 'device': 66305, 'inode': 13901021, 'mtime_ns': 1775821892726629407, 'ctime_ns': 1775821892726629407, 'valid': True}, '/home/loosqk/robot-checks/hardware-verify-20260930-r2/maintenance/proc_identity.py': {'path': '/home/loosqk/robot-checks/hardware-verify-20260930-r2/maintenance/proc_identity.py', 'sha256': 'da28b6eee270a09bfbdb7f90613f2fe9f0d73537c076a8b54fb811648cadb70f', 'bytes': 10882, 'uid': 1000, 'gid': 1000, 'mode': 416, 'nlink': 1, 'device': 66305, 'inode': 13275038, 'mtime_ns': 1790802489540317490, 'ctime_ns': 1790802489540317490, 'valid': True}}, 'valid': True}
MOTION_FRESH_PROTECTION = {'left': {'directory': {'path': '/var/lib/robot/xlerobot_left', 'device': 66305, 'inode': 15864269, 'uid': 1000, 'gid': 1000, 'mode': 488, 'valid': True}, 'rx_trust_marker': {'path': '/var/lib/robot/xlerobot_left/rx_trust_marker', 'hex': '310a', 'sha256': '4355a46b19d348dc2f57c046f8ef63d4538ebb936000f3c9ee954a27460dd865', 'bytes': 2, 'mode': 384, 'uid': 1000, 'gid': 1000, 'device': 66305, 'inode': 15864277, 'mtime_ns': 1790710985695936226, 'ctime_ns': 1790710985699936395, 'valid': True}, 'rx_trust_marker.bak': {'path': '/var/lib/robot/xlerobot_left/rx_trust_marker.bak', 'hex': '310a', 'sha256': '4355a46b19d348dc2f57c046f8ef63d4538ebb936000f3c9ee954a27460dd865', 'bytes': 2, 'mode': 384, 'uid': 1000, 'gid': 1000, 'device': 66305, 'inode': 15864361, 'mtime_ns': 1790710985691936056, 'ctime_ns': 1790710985695936226, 'valid': True}, 'estop_latch': {'path': '/var/lib/robot/xlerobot_left/estop_latch', 'hex': '310a', 'sha256': '4355a46b19d348dc2f57c046f8ef63d4538ebb936000f3c9ee954a27460dd865', 'bytes': 2, 'mode': 416, 'uid': 1000, 'gid': 1000, 'device': 66305, 'inode': 15864353, 'mtime_ns': 1790710994912328740, 'ctime_ns': 1790710994916328911, 'valid': True}, 'estop_latch.bak': {'path': '/var/lib/robot/xlerobot_left/estop_latch.bak', 'hex': '310a', 'sha256': '4355a46b19d348dc2f57c046f8ef63d4538ebb936000f3c9ee954a27460dd865', 'bytes': 2, 'mode': 416, 'uid': 1000, 'gid': 1000, 'device': 66305, 'inode': 15864309, 'mtime_ns': 1790710994920329082, 'ctime_ns': 1790710994920329082, 'valid': True}, 'rx_trust.lock': {'path': '/var/lib/robot/xlerobot_left/rx_trust.lock', 'hex': '3338303933310a', 'sha256': '286950220e7f240be3315cfc9bddda53b1a84f6c94651a41fd1ae80c097a2152', 'bytes': 7, 'mode': 384, 'uid': 1000, 'gid': 1000, 'device': 66305, 'inode': 15864273, 'mtime_ns': 1790710985687935887, 'ctime_ns': 1790710985687935887, 'valid': True}, 'estop_latch.lock': {'path': '/var/lib/robot/xlerobot_left/estop_latch.lock', 'hex': '3338303933310a', 'sha256': '286950220e7f240be3315cfc9bddda53b1a84f6c94651a41fd1ae80c097a2152', 'bytes': 7, 'mode': 384, 'uid': 1000, 'gid': 1000, 'device': 66305, 'inode': 15864354, 'mtime_ns': 1790710985687935887, 'ctime_ns': 1790710985687935887, 'valid': True}}, 'right': {'directory': {'path': '/var/lib/robot/xlerobot_right', 'device': 66305, 'inode': 15864270, 'uid': 1000, 'gid': 1000, 'mode': 488, 'valid': True}, 'rx_trust_marker': {'path': '/var/lib/robot/xlerobot_right/rx_trust_marker', 'hex': '310a', 'sha256': '4355a46b19d348dc2f57c046f8ef63d4538ebb936000f3c9ee954a27460dd865', 'bytes': 2, 'mode': 384, 'uid': 1000, 'gid': 1000, 'device': 66305, 'inode': 15864365, 'mtime_ns': 1790791168880807099, 'ctime_ns': 1790791168884807170, 'valid': True}, 'rx_trust_marker.bak': {'path': '/var/lib/robot/xlerobot_right/rx_trust_marker.bak', 'hex': '310a', 'sha256': '4355a46b19d348dc2f57c046f8ef63d4538ebb936000f3c9ee954a27460dd865', 'bytes': 2, 'mode': 384, 'uid': 1000, 'gid': 1000, 'device': 66305, 'inode': 15864363, 'mtime_ns': 1790791168872806958, 'ctime_ns': 1790791168876807029, 'valid': True}, 'estop_latch': {'path': '/var/lib/robot/xlerobot_right/estop_latch', 'hex': '310a', 'sha256': '4355a46b19d348dc2f57c046f8ef63d4538ebb936000f3c9ee954a27460dd865', 'bytes': 2, 'mode': 416, 'uid': 1000, 'gid': 1000, 'device': 66305, 'inode': 15864357, 'mtime_ns': 1790794541227134730, 'ctime_ns': 1790794541231134871, 'valid': True}, 'estop_latch.bak': {'path': '/var/lib/robot/xlerobot_right/estop_latch.bak', 'hex': '310a', 'sha256': '4355a46b19d348dc2f57c046f8ef63d4538ebb936000f3c9ee954a27460dd865', 'bytes': 2, 'mode': 416, 'uid': 1000, 'gid': 1000, 'device': 66305, 'inode': 15864315, 'mtime_ns': 1790794541235135012, 'ctime_ns': 1790794541239135153, 'valid': True}, 'rx_trust.lock': {'path': '/var/lib/robot/xlerobot_right/rx_trust.lock', 'hex': '3432333533330a', 'sha256': '805bba6ca74903ccab339ef9e35c77af7554673a4a620db4dfed54bca8c6dee2', 'bytes': 7, 'mode': 384, 'uid': 1000, 'gid': 1000, 'device': 66305, 'inode': 15864348, 'mtime_ns': 1790791168872806958, 'ctime_ns': 1790791168872806958, 'valid': True}, 'estop_latch.lock': {'path': '/var/lib/robot/xlerobot_right/estop_latch.lock', 'hex': '3432333533330a', 'sha256': '805bba6ca74903ccab339ef9e35c77af7554673a4a620db4dfed54bca8c6dee2', 'bytes': 7, 'mode': 384, 'uid': 1000, 'gid': 1000, 'device': 66305, 'inode': 15864358, 'mtime_ns': 1790791168872806958, 'ctime_ns': 1790791168872806958, 'valid': True}}, 'valid': True}
MOTION_PLAN_SHA = 'a8ae2757e95acaca9524b2f1646fdfed4552c679c7df10f71d52f61369cb2f77'
MOTION_QA_SHA = 'aceddfcf1081c1120a939b5a8e21a6ebb5d89669c9ccbdc72e8e965579b94c57'
MOTION_QA_BYTES = 625331
MOTION_GO_BASE64 = 'ewogICJzY2hlbWEiOiAiTUFJTlRFTkFOQ0VfR09fVjIiLAogICJpc3N1ZWRfYnkiOiAicm9vdCIsCiAgImlzc3VlZF9hdF9ucyI6IDE3OTE0MzgwNjkyNTU4ODcwMDAsCiAgImV4cGlyZXNfYXRfbnMiOiAxNzkxNDM5ODY5MjU1ODg3MDAwLAogICJob3N0IjogewogICAgImhvc3RuYW1lIjogInVidW50dSIsCiAgICAidWlkIjogMTAwMCwKICAgICJnaWQiOiAxMDAwLAogICAgImJvb3RfaWQiOiAiNmNmN2VlM2UtYTNjNS00YzkxLTgwYmMtNGNhOTI0ODE4YjUzIgogIH0sCiAgInBsYW5fc2hhMjU2IjogImE4YWUyNzU3ZTk1YWNhY2E5NTI0YjJmMTY0NmZkZmVkNDU1MmM2NzljN2RmMTBmNzFkNTJmNjEzNjljYjJmNzciLAogICJhcnRpZmFjdF9yb290IjogIi9ob21lL2xvb3Nxay9yb2JvdC1jaGVja3MvaGFyZHdhcmUtc2VsZWN0ZWQtdGFyZ2V0cy0yMDI2MTAwOC1yMSIsCiAgInNvdXJjZSI6ICLmnKzova7nlKjmiLfopoHmsYLlnKjlrp7mnLrkuIrov5DooYzkuJTnjrDlnLrmnInkurrvvIzlubbnrZTlpI3lvZPliY3lpI3kvY0v5pSv5pKRL+epuui9vS/nqbrml7cv5Zyw6Z2i56m66Ze0L+aMgee7reeci+aKpC/nq4vljbPmiYvliqjmlq3nlLXlhajpg6jph43mlrDlsLHnu6rjgIIg546w5Zy65LqL5a6e5pe26Ze06YeH55Socm9vdOaUtuWIsOivpeetlOWkjeeahOiusOW9leaXtumXtO+8jOeJqeeQhuWKqOS9nOWunumZheaXtuWIu+acquefpe+8m+acrOi9rueci+aKpOacquino+mZpOOAgiIsCiAgInBoeXNpY2FsIjogewogICAgImxlZnQiOiB7CiAgICAgICJtb3Rvcl9wb3dlcl9jeWNsZSI6IHRydWUsCiAgICAgICJ1c2JfcmVwbHVnIjogdHJ1ZSwKICAgICAgInN1cHBvcnRlZCI6IHRydWUsCiAgICAgICJ1bmxvYWRlZCI6IHRydWUsCiAgICAgICJhcmVhX2NsZWFyIjogdHJ1ZSwKICAgICAgImJhc2Vfb25fZ3JvdW5kX3dpdGhfc3BhY2UiOiB0cnVlLAogICAgICAiY29udGludW91c19wcmVzZW5jZV91bnRpbF9jbGVhbnVwIjogdHJ1ZSwKICAgICAgImltbWVkaWF0ZV9wb3dlcl9jdXQiOiB0cnVlLAogICAgICAiY29uZmlybWVkX2F0X25zIjogMTc5MTQzNDU3MTA2ODgzOTE2OAogICAgfSwKICAgICJyaWdodCI6IHsKICAgICAgIm1vdG9yX3Bvd2VyX2N5Y2xlIjogdHJ1ZSwKICAgICAgInVzYl9yZXBsdWciOiB0cnVlLAogICAgICAic3VwcG9ydGVkIjogdHJ1ZSwKICAgICAgInVubG9hZGVkIjogdHJ1ZSwKICAgICAgImFyZWFfY2xlYXIiOiB0cnVlLAogICAgICAiYmFzZV9vbl9ncm91bmRfd2l0aF9zcGFjZSI6IHRydWUsCiAgICAgICJjb250aW51b3VzX3ByZXNlbmNlX3VudGlsX2NsZWFudXAiOiB0cnVlLAogICAgICAiaW1tZWRpYXRlX3Bvd2VyX2N1dCI6IHRydWUsCiAgICAgICJjb25maXJtZWRfYXRfbnMiOiAxNzkxNDM0NTcxMDY4ODM5MTY4CiAgICB9CiAgfSwKICAic2NvcGUiOiAi5LiA5qyh5Y+z6IWV4oaS5aS0MeKGkuWktDLlsI/luYXkvY3nva7lvoDov5TvvJvml6Dlt6bohZUv5bqV55uYL+iHquWKqOmHjeivle+8m+WOn+mYiOWAvOWSjOWFqDE355S15py65YGc5q2iL+i6q+S7veWQjumqjOOAgiIsCiAgImxhdW5jaF9jb25kaXRpb25zIjogWwogICAgIuacgOe7iG5hdGl2ZTQwK+e7keWumlBMQU5fT05MWeWQjGE4YWUgZGlnZXN05a6e6ZmFUEFTUy/miYDmnIljaGlsZOecn+WunnJlYXAiLAogICAgIueLrOeri+WFt+S9k+iuoeWIkuWuoeaguOmAmui/hyIsCiAgICAi5omn6KGM5YmN5omA5pyJ5ZCM5rqQL1VTQi9ob3N0L+S/neaKpC/mraPlvI/liY3nva7mo4Dmn6XpgJrov4ciCiAgXSwKICAiY29uZGl0aW9uYWxfZ28iOiB0cnVlLAogICJhY3R1YWxfcGh5c2ljYWxfYWN0aW9uX3RpbWUiOiAiVU5LTk9XTl9OT1RfSU5GRVJSRUQiCn0K'
MOTION_GO_SHA = 'c8acc58c3f246c1f92d1922aaa8d36e5b0d2ac4ccbb6d24b37e4a393bc203d79'
MOTION_GO_BYTES = 1851
"""爸爸，冻结动作封装；仅 root 最后批准后可单次启动，当前文件本身不授权动作。"""
import base64
import importlib.util

MOTION_ROOT = Path('/home/loosqk/robot-checks/hardware-selected-targets-20261008-r1')
MOTION_PYTHON = '/home/loosqk/.local/share/uv/python/cpython-3.12.13-linux-aarch64-gnu/bin/python3'
MOTION_SCRIPT = MOTION_ROOT / 'scripts/run_hardware_maintenance.py'
MOTION_APPROVAL = MOTION_ROOT / 'root_motion_go_r1.json'
MOTION_OUTPUT = MOTION_ROOT / 'right-head-run-01'
MOTION_COMMAND = [MOTION_PYTHON, '-B', str(MOTION_SCRIPT), '--bindings',
                  str(MOTION_ROOT / 'maintenance_bindings_fresh_r1.json'), '--artifact-root', str(MOTION_ROOT),
                  '--output', str(MOTION_OUTPUT), '--run-id', 'right-head-run-01',
                  '--position-target', 'right-wrist', '--position-target', 'head-1',
                  '--position-target', 'head-2', '--execute', '--approval', str(MOTION_APPROVAL)]


def motion_payload_refs(exhaustive=False):
    values = {}
    for relative, pin in MOTION_PAYLOAD.items():
        def one(relative=relative, pin=pin):
            raw, info = read_regular(MOTION_ROOT / relative)
            require(hashlib.sha256(raw).hexdigest() == pin['sha256'] and len(raw) == pin['bytes']
                    and info.st_uid == info.st_gid == 1000 and stat.S_IMODE(info.st_mode) == 0o644,
                    '阶段源/计划身份变化：' + relative)
            return {'path': str(MOTION_ROOT / relative), 'sha256': pin['sha256'], 'bytes': len(raw),
                    'uid': info.st_uid, 'gid': info.st_gid, 'mode': stat.S_IMODE(info.st_mode)}
        values[relative] = check(('after' if exhaustive else 'before') + '_payload_' + relative, one, exhaustive)
    return values


def motion_prepare():
    require(result['fixed_refs_before'] == MOTION_FRESH_REFS, 'fresh 引用身份漂移')
    require(result['before']['protection'] == MOTION_FRESH_PROTECTION, 'fresh 保护身份漂移')
    require(MOTION_ROOT == MOTION_ROOT.resolve() and MOTION_ROOT.is_dir()
            and MOTION_ROOT.stat().st_uid == 1000, '阶段目录身份错误')
    result['payload_before'] = motion_payload_refs()
    raw, _ = read_regular(MOTION_ROOT / 'native-qa-r3/native_qa_r3.json')
    require(hashlib.sha256(raw).hexdigest() == MOTION_QA_SHA and len(raw) == MOTION_QA_BYTES,
            'native QA 原件改变')
    qa = json.loads(raw)
    require(qa['status'] == 'PASS' and not qa['errors'] and len(qa['software_qa']) == 5
            and all(row['reaped'] and row['status'] == 'PASS' for row in qa['software_qa'])
            and all(row['reaped'] for row in qa['commands']) and not qa['received_signals'],
            'native 软件 QA 未完整通过')
    result['native_qa_reference'] = {'path': str(MOTION_ROOT / 'native-qa-r3/native_qa_r3.json'),
                                   'sha256': MOTION_QA_SHA, 'bytes': len(raw), 'status': qa['status']}
    plan = json.loads((MOTION_ROOT / 'right_head_plan_r1.json').read_text())
    require(hashlib.sha256(json.dumps(plan, sort_keys=True, ensure_ascii=False,
                                     separators=(',', ':')).encode()).hexdigest() == MOTION_PLAN_SHA,
            '完整计划摘要改变')
    require(plan['position_targets'] == [['right', 5, 'right_arm_wrist_roll'],
            ['left', 7, 'head_motor_1'], ['left', 8, 'head_motor_2']]
            and all(row['decision'] == 'DEFERRED' for row in plan['base_targets']), '计划目标越界')
    for side, device in result['before']['devices'].items():
        fields = dict(line.split('=', 1) for line in device['udev_command']['stdout'].splitlines())
        expected = plan['bindings']['usb'][side]
        require(all(device[k] == expected[k] for k in ('device', 'resolved', 'rdev', 'mode', 'uid', 'gid',
                                                       'device_inode', 'link_inode', 'link_target'))
                and fields['ID_SERIAL_SHORT'] == expected['serial'] and fields['DEVPATH'] == expected['devpath']
                and fields['USEC_INITIALIZED'] == expected['usec_initialized'], 'fresh USB 枚举代次改变')
    require(result['before']['elf'] == plan['bindings']['tool'], '历史位置维护 ELF 身份改变')
    raw = base64.b64decode(MOTION_GO_BASE64, validate=True)
    require(hashlib.sha256(raw).hexdigest() == MOTION_GO_SHA and len(raw) == MOTION_GO_BYTES, 'root GO 原件改变')
    go = json.loads(raw)
    sys.dont_write_bytecode = True
    spec = importlib.util.spec_from_file_location('maintenance_motion_frozen', MOTION_SCRIPT)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    module.validate_go(go, plan, time.time_ns())
    require(not MOTION_APPROVAL.exists() and not MOTION_APPROVAL.is_symlink()
            and not Path(str(MOTION_APPROVAL) + '.consumed').exists()
            and not MOTION_OUTPUT.exists() and not MOTION_OUTPUT.is_symlink(), 'GO 或 run 已存在，拒绝重试')
    with MOTION_APPROVAL.open('xb') as output:
        output.write(raw)
    MOTION_APPROVAL.chmod(0o644)
    result['uploaded_root_go'] = {'path': str(MOTION_APPROVAL), 'sha256': MOTION_GO_SHA, 'bytes': len(raw),
                                  'conditional': go['conditional_go'], 'root_final_launch_review_required': True}


def motion_driver():
    motion_prepare()
    require(not stop and within_budget(), '已收到信号或600秒总预算已过，拒绝 driver launch')
    row = {'argv': MOTION_COMMAND, 'started_ns': time.time_ns(), 'started_monotonic_ns': time.monotonic_ns(),
           'pid': None, 'reaped': False, 'signals_sent': [], 'cleanup': False,
           'budget_scope': '完整维护 driver 600秒观察预算；内部每 poke child 保原2秒'}
    result['commands'].append(row)
    child = subprocess.Popen(MOTION_COMMAND, stdin=subprocess.DEVNULL, stdout=subprocess.PIPE,
                             stderr=subprocess.PIPE, start_new_session=True,
                             env={**os.environ, 'PYTHONDONTWRITEBYTECODE': '1', 'GIT_OPTIONAL_LOCKS': '0', 'LC_ALL': 'C'})
    row['pid'] = child.pid
    children.append((child, row))
    stdout, stderr = collect_owned_child(child, None, row)
    elapsed = time.monotonic_ns() - row['started_monotonic_ns']
    row.update(exit_code=child.returncode, finished_ns=time.time_ns(), elapsed_ns=elapsed,
               child_end_class='EXIT_STATUS' if child.returncode >= 0 else 'SIGNAL',
               stdout=stdout.decode(errors='replace'), stderr=stderr.decode(errors='replace'),
               stdout_sha256=hashlib.sha256(stdout).hexdigest(), stderr_sha256=hashlib.sha256(stderr).hexdigest(),
               stdout_bytes=len(stdout), stderr_bytes=len(stderr))
    result['driver_child'] = row
    if not row['reaped'] or row['communicate_errors']:
        result['manual_power_cut_required'] = True
        print('爸爸，driver 回收异常，收尾状态未知；请立即人工断电。', file=sys.stderr, flush=True)
    require(row['reaped'] and not row['communicate_errors'], 'driver 回收异常；收尾状态未知')
    try:
        raw, _ = read_regular(MOTION_OUTPUT / 'run.json')
        run = json.loads(raw)
        result['driver_run'] = run
        result['driver_run_reference'] = {'path': str(MOTION_OUTPUT / 'run.json'),
                                          'sha256': hashlib.sha256(raw).hexdigest(), 'bytes': len(raw)}
        command_raw, _ = read_regular(MOTION_OUTPUT / 'commands.jsonl')
        result['driver_commands_raw'] = command_raw.decode()
        result['driver_commands_reference'] = {'path': str(MOTION_OUTPUT / 'commands.jsonl'),
                                               'sha256': hashlib.sha256(command_raw).hexdigest(), 'bytes': len(command_raw)}
        result['manual_power_cut_required'] = run.get('manual_power_cut_required', False)
    except BaseException:
        result['manual_power_cut_required'] = True
        print('爸爸，维护收尾原件缺失或不可读，状态未知；请立即人工断电。', file=sys.stderr, flush=True)
        raise
    if run['result'] == 'NEEDS_MANUAL_POWER_CUT' or result['manual_power_cut_required']:
        print('爸爸，维护报告要求立即人工断电，禁止后续动作。', file=sys.stderr, flush=True)
    require(elapsed <= 600_000_000_000, 'driver 超600秒；已真实wait/reap，不续动作')
    require(child.returncode == 0 and run['result'] == 'PASS',
            'driver 实际整体非PASS；底盘DEFERRED按原分类保留，不覆盖动作或收尾失败')

result.update(schema='SELECTED_MAINTENANCE_MOTION_OWNER_R1_V1', read_only=False, hardware_writes='delegated_to_driver_report', wrapper_UART_requests=0, read_tool_basis='历史f201已核本体位置维护工具，由固定driver执行', extra_read_only_handshake_frames='wrapper无UART；driver connect额外帧不冒称请求总数')
raise SystemExit(prep_main())

END_PY
