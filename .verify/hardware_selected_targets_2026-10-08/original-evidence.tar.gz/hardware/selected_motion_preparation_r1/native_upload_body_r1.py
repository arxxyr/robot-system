"""爸爸，只上传阶段产物并执行五条纯软件命令；不调用 UART/GO。"""
import base64

QA_ROOT = Path('/home/loosqk/robot-checks/hardware-selected-targets-20261008-r1')
QA_PYTHON = '/home/loosqk/.local/share/uv/python/cpython-3.12.13-linux-aarch64-gnu/bin/python3'
QA_SCRIPT = str(QA_ROOT / 'scripts/run_hardware_maintenance.py')
QA_BINDINGS = str(QA_ROOT / 'maintenance_bindings_fresh_r1.json')
QA_COMMON = [QA_PYTHON, '-B', QA_SCRIPT, '--bindings', QA_BINDINGS,
             '--artifact-root', str(QA_ROOT), '--output', str(QA_ROOT / 'right-head-run-01'),
             '--run-id', 'right-head-run-01']
QA_COMMANDS = [
    [QA_PYTHON, '-B', str(QA_ROOT / 'scripts/tests/test_hardware_maintenance.py')],
    QA_COMMON,
    QA_COMMON + ['--position-target', 'right-wrist', '--position-target', 'head-1', '--position-target', 'head-2'],
    [QA_PYTHON, '-B', QA_SCRIPT, '--position-target', 'right-wrist', '--position-target', 'right-wrist'],
    [QA_PYTHON, '-B', QA_SCRIPT, '--position-target', 'base'],
]
qa_previous_allowed = allowed_command


def allowed_command(argv):
    return argv in QA_COMMANDS or qa_previous_allowed(argv)


def qa_payload_refs():
    values = {}
    for relative, pin in QA_PAYLOAD.items():
        raw, info = read_regular(QA_ROOT / relative)
        require(hashlib.sha256(raw).hexdigest() == pin['sha256'] and len(raw) == pin['bytes'],
                '阶段源/计划身份变化：' + relative)
        values[relative] = {'path': str(QA_ROOT / relative), 'sha256': pin['sha256'], 'bytes': len(raw),
                            'uid': info.st_uid, 'gid': info.st_gid, 'mode': stat.S_IMODE(info.st_mode)}
    return values


def qa_before_upload():
    expected = json.loads(base64.b64decode(QA_PAYLOAD['maintenance_bindings_fresh_r1.json']['base64']))
    require(result['fixed_refs_before'] == QA_FRESH_REFS, 'fresh 引用身份漂移，不上传/不启动软件')
    require(result['before']['protection'] == QA_FRESH_PROTECTION, 'fresh 保护身份漂移')
    require(result['before']['elf'] == expected['tool'], '位置维护工具本体漂移')
    for side, device in result['before']['devices'].items():
        fields = dict(line.split('=', 1) for line in device['udev_command']['stdout'].splitlines())
        bound = expected['usb'][side]
        require(all(device[k] == bound[k] for k in ('device', 'resolved', 'rdev', 'mode', 'uid', 'gid',
                                                   'device_inode', 'link_inode', 'link_target'))
                and fields['ID_SERIAL_SHORT'] == bound['serial'] and fields['DEVPATH'] == bound['devpath']
                and fields['USEC_INITIALIZED'] == bound['usec_initialized'], 'fresh USB 枚举代次漂移')
    require(not QA_ROOT.exists() and not QA_ROOT.is_symlink() and QA_ROOT.parent == QA_ROOT.parent.resolve()
            and QA_ROOT.parent.stat().st_uid == 1000, '阶段根已存在或父目录身份错误')
    QA_ROOT.mkdir(mode=0o750)
    (QA_ROOT / 'scripts').mkdir(mode=0o750)
    (QA_ROOT / 'scripts/tests').mkdir(mode=0o750)
    for relative, pin in QA_PAYLOAD.items():
        raw = base64.b64decode(pin['base64'], validate=True)
        require(hashlib.sha256(raw).hexdigest() == pin['sha256'] and len(raw) == pin['bytes'], '上传输入不一致')
        with (QA_ROOT / relative).open('xb') as output:
            output.write(raw)
        (QA_ROOT / relative).chmod(0o644)
    result['uploaded_before'] = qa_payload_refs()


def qa_run():
    qa_before_upload()
    result['software_qa'] = []
    for index, argv in enumerate(QA_COMMANDS):
        row, _ = command(argv, allowed=(0,) if index < 3 else (2,))
        with (QA_ROOT / f'qa-{index + 1}.stdout').open('xb') as output:
            output.write(row['stdout'].encode())
        with (QA_ROOT / f'qa-{index + 1}.stderr').open('xb') as output:
            output.write(row['stderr'].encode())
        if index == 0:
            require('\nRan 40 tests in ' in row['stderr'] and row['stderr'].endswith('\nOK\n'), 'native40 未通过')
        elif index in (1, 2):
            value = json.loads(row['stdout'])
            require(value['result'] == 'PLAN_ONLY' and value['actions_started'] == 0, '计划入口触发动作')
            if index == 2:
                require(value['plan_sha256'] == QA_PLAN_SHA and value['plan'] == QA_EXPECTED_PLAN,
                        '所选 native 完整 canonical 计划与本机不同')
            else:
                require(value['plan']['position_targets'] == [['left', 5, 'left_arm_wrist_roll'],
                        ['right', 5, 'right_arm_wrist_roll'], ['left', 7, 'head_motor_1'], ['left', 8, 'head_motor_2']],
                        '缺省四目标顺序改变')
        result['software_qa'].append({'index': index + 1, 'pid': row['pid'], 'exit_code': row['exit_code'],
                                      'reaped': row['reaped'], 'status': 'PASS'})
    result['uploaded_after'] = qa_payload_refs()
    require(result['uploaded_before'] == result['uploaded_after'], '阶段源首尾不同')

