"""爸爸，冻结动作封装；仅 root 最后批准后可单次启动，当前文件本身不授权动作。"""
import base64
import importlib.util

MOTION_ROOT = Path('/home/loosqk/robot-checks/hardware-selected-targets-20261008-r1')
MOTION_PYTHON = '/home/loosqk/.local/share/uv/python/cpython-3.12.13-linux-aarch64-gnu/bin/python3'
MOTION_SCRIPT = MOTION_ROOT / 'scripts/run_hardware_maintenance.py'
MOTION_APPROVAL = MOTION_ROOT / 'root_motion_go_r1.json'
MOTION_OUTPUT = MOTION_ROOT / 'right-head-run-01'
MOTION_COMMAND = [MOTION_PYTHON, '-B', str(MOTION_SCRIPT), '--bindings',
                  str(MOTION_ROOT / 'maintenance_bindings_fresh_r1.json'), '--artifact-root', str(MOTION_ROOT),
                  '--output', str(MOTION_OUTPUT), '--run-id', 'right-head-run-01',
                  '--position-target', 'right-wrist', '--position-target', 'head-1',
                  '--position-target', 'head-2', '--execute', '--approval', str(MOTION_APPROVAL)]


def motion_payload_refs(exhaustive=False):
    values = {}
    for relative, pin in MOTION_PAYLOAD.items():
        def one(relative=relative, pin=pin):
            raw, info = read_regular(MOTION_ROOT / relative)
            require(hashlib.sha256(raw).hexdigest() == pin['sha256'] and len(raw) == pin['bytes']
                    and info.st_uid == info.st_gid == 1000 and stat.S_IMODE(info.st_mode) == 0o644,
                    '阶段源/计划身份变化：' + relative)
            return {'path': str(MOTION_ROOT / relative), 'sha256': pin['sha256'], 'bytes': len(raw),
                    'uid': info.st_uid, 'gid': info.st_gid, 'mode': stat.S_IMODE(info.st_mode)}
        values[relative] = check(('after' if exhaustive else 'before') + '_payload_' + relative, one, exhaustive)
    return values


def motion_prepare():
    require(result['fixed_refs_before'] == MOTION_FRESH_REFS, 'fresh 引用身份漂移')
    require(result['before']['protection'] == MOTION_FRESH_PROTECTION, 'fresh 保护身份漂移')
    require(MOTION_ROOT == MOTION_ROOT.resolve() and MOTION_ROOT.is_dir()
            and MOTION_ROOT.stat().st_uid == 1000, '阶段目录身份错误')
    result['payload_before'] = motion_payload_refs()
    raw, _ = read_regular(MOTION_ROOT / 'native-qa-r3/native_qa_r3.json')
    require(hashlib.sha256(raw).hexdigest() == MOTION_QA_SHA and len(raw) == MOTION_QA_BYTES,
            'native QA 原件改变')
    qa = json.loads(raw)
    require(qa['status'] == 'PASS' and not qa['errors'] and len(qa['software_qa']) == 5
            and all(row['reaped'] and row['status'] == 'PASS' for row in qa['software_qa'])
            and all(row['reaped'] for row in qa['commands']) and not qa['received_signals'],
            'native 软件 QA 未完整通过')
    result['native_qa_reference'] = {'path': str(MOTION_ROOT / 'native-qa-r3/native_qa_r3.json'),
                                   'sha256': MOTION_QA_SHA, 'bytes': len(raw), 'status': qa['status']}
    plan = json.loads((MOTION_ROOT / 'right_head_plan_r1.json').read_text())
    require(hashlib.sha256(json.dumps(plan, sort_keys=True, ensure_ascii=False,
                                     separators=(',', ':')).encode()).hexdigest() == MOTION_PLAN_SHA,
            '完整计划摘要改变')
    require(plan['position_targets'] == [['right', 5, 'right_arm_wrist_roll'],
            ['left', 7, 'head_motor_1'], ['left', 8, 'head_motor_2']]
            and all(row['decision'] == 'DEFERRED' for row in plan['base_targets']), '计划目标越界')
    for side, device in result['before']['devices'].items():
        fields = dict(line.split('=', 1) for line in device['udev_command']['stdout'].splitlines())
        expected = plan['bindings']['usb'][side]
        require(all(device[k] == expected[k] for k in ('device', 'resolved', 'rdev', 'mode', 'uid', 'gid',
                                                       'device_inode', 'link_inode', 'link_target'))
                and fields['ID_SERIAL_SHORT'] == expected['serial'] and fields['DEVPATH'] == expected['devpath']
                and fields['USEC_INITIALIZED'] == expected['usec_initialized'], 'fresh USB 枚举代次改变')
    require(result['before']['elf'] == plan['bindings']['tool'], '历史位置维护 ELF 身份改变')
    raw = base64.b64decode(MOTION_GO_BASE64, validate=True)
    require(hashlib.sha256(raw).hexdigest() == MOTION_GO_SHA and len(raw) == MOTION_GO_BYTES, 'root GO 原件改变')
    go = json.loads(raw)
    sys.dont_write_bytecode = True
    spec = importlib.util.spec_from_file_location('maintenance_motion_frozen', MOTION_SCRIPT)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    module.validate_go(go, plan, time.time_ns())
    require(not MOTION_APPROVAL.exists() and not MOTION_APPROVAL.is_symlink()
            and not Path(str(MOTION_APPROVAL) + '.consumed').exists()
            and not MOTION_OUTPUT.exists() and not MOTION_OUTPUT.is_symlink(), 'GO 或 run 已存在，拒绝重试')
    with MOTION_APPROVAL.open('xb') as output:
        output.write(raw)
    MOTION_APPROVAL.chmod(0o644)
    result['uploaded_root_go'] = {'path': str(MOTION_APPROVAL), 'sha256': MOTION_GO_SHA, 'bytes': len(raw),
                                  'conditional': go['conditional_go'], 'root_final_launch_review_required': True}


def motion_driver():
    motion_prepare()
    require(not stop and within_budget(), '已收到信号或600秒总预算已过，拒绝 driver launch')
    row = {'argv': MOTION_COMMAND, 'started_ns': time.time_ns(), 'started_monotonic_ns': time.monotonic_ns(),
           'pid': None, 'reaped': False, 'signals_sent': [], 'cleanup': False,
           'budget_scope': '完整维护 driver 600秒观察预算；内部每 poke child 保原2秒'}
    result['commands'].append(row)
    child = subprocess.Popen(MOTION_COMMAND, stdin=subprocess.DEVNULL, stdout=subprocess.PIPE,
                             stderr=subprocess.PIPE, start_new_session=True,
                             env={**os.environ, 'PYTHONDONTWRITEBYTECODE': '1', 'GIT_OPTIONAL_LOCKS': '0', 'LC_ALL': 'C'})
    row['pid'] = child.pid
    children.append((child, row))
    stdout, stderr = collect_owned_child(child, None, row)
    elapsed = time.monotonic_ns() - row['started_monotonic_ns']
    row.update(exit_code=child.returncode, finished_ns=time.time_ns(), elapsed_ns=elapsed,
               child_end_class='EXIT_STATUS' if child.returncode >= 0 else 'SIGNAL',
               stdout=stdout.decode(errors='replace'), stderr=stderr.decode(errors='replace'),
               stdout_sha256=hashlib.sha256(stdout).hexdigest(), stderr_sha256=hashlib.sha256(stderr).hexdigest(),
               stdout_bytes=len(stdout), stderr_bytes=len(stderr))
    result['driver_child'] = row
    if not row['reaped'] or row['communicate_errors']:
        result['manual_power_cut_required'] = True
        print('爸爸，driver 回收异常，收尾状态未知；请立即人工断电。', file=sys.stderr, flush=True)
    require(row['reaped'] and not row['communicate_errors'], 'driver 回收异常；收尾状态未知')
    try:
        raw, _ = read_regular(MOTION_OUTPUT / 'run.json')
        run = json.loads(raw)
        result['driver_run'] = run
        result['driver_run_reference'] = {'path': str(MOTION_OUTPUT / 'run.json'),
                                          'sha256': hashlib.sha256(raw).hexdigest(), 'bytes': len(raw)}
        command_raw, _ = read_regular(MOTION_OUTPUT / 'commands.jsonl')
        result['driver_commands_raw'] = command_raw.decode()
        result['driver_commands_reference'] = {'path': str(MOTION_OUTPUT / 'commands.jsonl'),
                                               'sha256': hashlib.sha256(command_raw).hexdigest(), 'bytes': len(command_raw)}
        result['manual_power_cut_required'] = run.get('manual_power_cut_required', False)
    except BaseException:
        result['manual_power_cut_required'] = True
        print('爸爸，维护收尾原件缺失或不可读，状态未知；请立即人工断电。', file=sys.stderr, flush=True)
        raise
    if run['result'] == 'NEEDS_MANUAL_POWER_CUT' or result['manual_power_cut_required']:
        print('爸爸，维护报告要求立即人工断电，禁止后续动作。', file=sys.stderr, flush=True)
    require(elapsed <= 600_000_000_000, 'driver 超600秒；已真实wait/reap，不续动作')
    require(child.returncode == 0 and run['result'] == 'PASS',
            'driver 实际整体非PASS；底盘DEFERRED按原分类保留，不覆盖动作或收尾失败')
