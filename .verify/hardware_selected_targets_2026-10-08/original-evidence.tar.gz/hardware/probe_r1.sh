set -eu
export PATH=/home/loosqk/.cargo/bin:/home/loosqk/.local/bin:$PATH
PROBE_PYTHON="/home/loosqk/.local/share/uv/python/cpython-3.12.13-linux-aarch64-gnu/bin/python3"
exec taskset -c 0-3 "$PROBE_PYTHON" - <<'END_PY'
import fcntl
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import re
import signal
import stat
import struct
import subprocess
import sys
import threading
import time
sys.dont_write_bytecode = True
BASE = Path('/home/loosqk/robot-checks/h2-serial-recovery-20260930-r1')
ROOT = BASE / 'source'
FORMAL = Path('/home/loosqk/repo/robot/robot-system')
ELF = Path('/home/loosqk/robot-checks/feetech-diagnostic-b0-20260930-r3/read-tool-r1/feetech_poke')
ELF_SHA = '2daabe75878989abfa759920ec07773d3c97b017042a42b3906483c3da4f5a71'
EXPECTED_BOOT = '6cf7ee3e-a3c5-4c91-80bc-4ca924818b53'
FORMAL_FILES = {'config:left': {'path': '/etc/robot/xlerobot_left_arm.toml', 'sha256': '720979785a149f8f25a9a48f5bab10202e32f6e312a998267c4ce3c20d4a6194', 'bytes': 2161, 'uid': 0, 'gid': 0, 'mode': 420}, 'config:right': {'path': '/etc/robot/xlerobot_right_arm.toml', 'sha256': 'ce46c7b1317811ce7cb267db3863624462823c58518cd5e044df4dbc54fd3992', 'bytes': 1589, 'uid': 0, 'gid': 0, 'mode': 420}, 'config:roles': {'path': '/etc/robot/rpc_roles.toml', 'sha256': '6b989264dccf599d22a83808226f049f05481fe57e2eb04519bbcfc3dab3278f', 'bytes': 3434, 'uid': 0, 'gid': 0, 'mode': 420}, 'installed:robot_rpc_gateway': {'path': '/home/loosqk/repo/robot/robot-system/target/release/robot_rpc_gateway', 'sha256': '9e8d029c30472bcd5371b6ae1fb6e4f98446086f420c567d11891dab81cc8d78', 'bytes': 5883280, 'uid': 1000, 'gid': 1000, 'mode': 509}, 'installed:s0_daemon': {'path': '/home/loosqk/repo/robot/robot-system/target/release/s0_daemon', 'sha256': '461aec751fc5a41a24ab4dcc3778ca1e88783c4c96467254419f7bf13d1fde7f', 'bytes': 3968152, 'uid': 1000, 'gid': 1000, 'mode': 509}, 'installed:s1_daemon': {'path': '/home/loosqk/repo/robot/robot-system/target/release/s1_daemon', 'sha256': '1c9037443f9786f09631705bd8800bc5f85333a45c7e9b08d6fcfaf26738de93', 'bytes': 4033312, 'uid': 1000, 'gid': 1000, 'mode': 509}, 'installed:xlerobot_deploy': {'path': '/home/loosqk/repo/robot/robot-system/target/release/xlerobot_deploy', 'sha256': '7d0cfa3da22610e9a34749d1fbb0d081239a728ed1a30cb9836e01c909dff5c3', 'bytes': 1818776, 'uid': 1000, 'gid': 1000, 'mode': 509}, 'discovered:/etc/systemd/system/xlerobot-s0-left-arm.service': {'path': '/etc/systemd/system/xlerobot-s0-left-arm.service', 'sha256': '842e732b55677567e914e2ad6862ccf561ef5b39c2bbe8647c42e2fef50332db', 'bytes': 5247, 'uid': 0, 'gid': 0, 'mode': 420}, 'discovered:/etc/systemd/system/xlerobot-s0-right-arm.service': {'path': '/etc/systemd/system/xlerobot-s0-right-arm.service', 'sha256': '08d3b928d9206b7cc282efdad174ef1f4e66f61971f3d09f4e651a1f70c3e579', 'bytes': 5259, 'uid': 0, 'gid': 0, 'mode': 420}, 'discovered:/etc/systemd/system/xlerobot-s1-left.service': {'path': '/etc/systemd/system/xlerobot-s1-left.service', 'sha256': 'e8ceafd7540f6a78076ad7f7d51845a2df005f9e84998120e70e273dec62b0b2', 'bytes': 1830, 'uid': 0, 'gid': 0, 'mode': 420}, 'discovered:/etc/systemd/system/xlerobot-s1-right.service': {'path': '/etc/systemd/system/xlerobot-s1-right.service', 'sha256': 'faa3d9dbe85e721f383ec2e6a81a153aa136c4397c44603f64d421ba3125575f', 'bytes': 1839, 'uid': 0, 'gid': 0, 'mode': 420}, 'discovered:/etc/systemd/system/xlerobot-gateway-left.service': {'path': '/etc/systemd/system/xlerobot-gateway-left.service', 'sha256': '1b0afa5c17a2be42b6b5286f2e3707471be1aa37390f65017fecc07c19839ea7', 'bytes': 2117, 'uid': 0, 'gid': 0, 'mode': 420}, 'discovered:/etc/systemd/system/xlerobot-gateway-right.service': {'path': '/etc/systemd/system/xlerobot-gateway-right.service', 'sha256': '1233ce1571c626af494f87b26a9e084117fc6b8761ce6e39b24fae377502bd71', 'bytes': 2125, 'uid': 0, 'gid': 0, 'mode': 420}, 'discovered:/etc/systemd/system/xlerobot-handoff.service': {'path': '/etc/systemd/system/xlerobot-handoff.service', 'sha256': '4cce48f85d40642bab7c7646e06be38f37e3412bcc51031b29737b5527e03ace', 'bytes': 3367, 'uid': 0, 'gid': 0, 'mode': 420}}
REGISTERS = ('Model_Number', 'Operating_Mode', 'Torque_Enable', 'Present_Velocity', 'Goal_Velocity', 'Present_Position', 'Goal_Position', 'Phase', 'CW_Dead_Zone', 'CCW_Dead_Zone')
STOP_REGISTERS = frozenset(('Torque_Enable', 'Present_Velocity', 'Goal_Velocity'))
PROFILES = {
    side: {'device': '/dev/serial/by-id/usb-1a86_USB_Single_Serial_' + serial + '-if00',
           'serial': serial, 'trust': Path('/var/lib/robot/xlerobot_' + side), 'count': count}
    for side, serial, count in (('left', '5A7C121427', 8), ('right', '5A7C122340', 9))
}
UNITS = tuple('xlerobot-' + role + '-' + side + ('-arm' if role == 's0' else '') + '.service'
              for role in ('gateway', 's1', 's0') for side in ('left', 'right'))
HELPER_SHA = '8121c8e8454d5a06dfa1f828ca85417917a0cdcd756d222717af89adf1024b77'
DRIVER_SHAS = {
    'run_post_e_h2.py': '1a679114cf9f6a719e4369486214a71280b35efbea46f69cb9fa5c53710b1c13',
    'post_e_h2_report.py': 'bd35923146c3841ec5f4547b85b99494abbd93970cb1b805ce0fb7692b368387',
    'post_e_h2_artifacts.py': 'bd2b3f7bb8527cd9ecec73894171638e9cf378656b89e284a585c3baa37b8731',
}
result = {'schema': 'HARDWARE_READ_ONLY_20261008_R1_V1', 'read_only': True, 'status': 'RUNNING',
          'started_ns': time.time_ns(), 'started_monotonic_ns': time.monotonic_ns(),
          'commands': [], 'checks': [], 'reads': [], 'errors': [], 'received_signals': [],
          'locks': [], 'hardware_writes': 0, 'expected_requested_register_outputs': 170,
          'extra_read_only_handshake_frames': '每次 connect(true) 另有 PING/型号 READ；170 不是总 wire 帧数',
          'budget': {'whole_python_seconds': 600, 'owned_child_seconds': 2, 'signals_sent': []},
          'read_tool_basis': '历史 B0/5c543b0b8 已验 READ 工具，不是本轮最新源码构建件',
          'physical_facts_source': 'root 已收到本轮用户全部重新就绪答复；不推定人工动作时间'}
stop = False
driver = None
binaries = [ELF]
locks = []
children = []

def require(value, message):
    if not value:
        raise ValueError(message)

def note_error(phase, error):
    result['errors'].append({'phase': phase, 'error': repr(error), 'at_ns': time.time_ns()})

def handler(signum, frame):
    global stop
    stop = True
    result['received_signals'].append({'name': signal.Signals(signum).name, 'at_ns': time.time_ns()})

def within_budget():
    return time.monotonic_ns() - result['started_monotonic_ns'] <= 600_000_000_000

def allowed_command(argv):
    devices = {p['device'] for p in PROFILES.values()}
    holder_paths = devices | {str(p['trust'] / name) for p in PROFILES.values()
                              for name in ('rx_trust.lock', 'estop_latch.lock')}
    if len(argv) == 5 and argv[0] == str(ELF):
        selected = [p for p in PROFILES.values() if p['device'] == argv[1]]
        return (len(selected) == 1 and re.fullmatch(r'[1-9][0-9]*', argv[2]) is not None
                and int(argv[2]) <= selected[0]['count'] and argv[3] == 'read' and argv[4] in REGISTERS)
    if argv[:2] == ['git', '-C'] and len(argv) >= 4 and argv[2] in (str(ROOT), str(FORMAL)):
        return (argv[3:] in (['rev-parse', 'HEAD'], ['status', '--porcelain=v1', '--untracked-files=all'])
                or len(argv) == 5 and argv[3] == 'show' and argv[4] in
                ('HEAD:scripts/run_post_e_h2.py', 'HEAD:scripts/post_e_h2_report.py', 'HEAD:scripts/post_e_h2_artifacts.py'))
    if argv == ['systemctl', 'show', *UNITS, '--property=Id,LoadState,ActiveState,SubState,MainPID']:
        return True
    if len(argv) == 5 and argv[:4] == ['udevadm', 'info', '--query=property', '--name']:
        return argv[4] in devices
    if len(argv) == 2 and argv[0] == 'fuser':
        return argv[1] in holder_paths
    if len(argv) == 4 and argv[:3] == ['sudo', '-n', 'fuser']:
        return argv[3] in holder_paths
    return (driver is not None and argv == ['sudo', '-n', '/usr/bin/python3', '-I', '-S', '-c', driver.PROC_PROBE_CODE])

def collect_owned_child(child, input_raw, row):
    # 无 timeout/kill。communicate 异常后仅接管同一个 child 的管道并真实 wait，不重启命令。
    stdout, stderr = b'', b''
    row['communicate_errors'] = []
    try:
        stdout, stderr = child.communicate(input_raw)
    except BaseException as error:
        row['communicate_errors'].append(repr(error))
        if child.stdin is not None and not child.stdin.closed:
            try:
                child.stdin.close()
            except BaseException as close_error:
                row['communicate_errors'].append(repr(close_error))
        values = {}
        def drain(name, stream):
            try:
                values[name] = b'' if stream is None or stream.closed else stream.read()
            except BaseException as drain_error:
                values[name] = b''
                row['communicate_errors'].append(repr(drain_error))
        drains = [threading.Thread(target=drain, args=(name, stream))
                  for name, stream in (('stdout', child.stdout), ('stderr', child.stderr))]
        for thread in drains:
            thread.start()
        while True:
            try:
                child.wait()
                break
            except BaseException as wait_error:
                row['communicate_errors'].append(repr(wait_error))
        for thread in drains:
            while True:
                try:
                    thread.join()
                    break
                except BaseException as join_error:
                    row['communicate_errors'].append(repr(join_error))
        stdout, stderr = values['stdout'], values['stderr']
    finally:
        while True:
            try:
                row['wait_returncode'] = child.wait()
                row['reaped'] = True
                break
            except BaseException as wait_error:
                row['communicate_errors'].append(repr(wait_error))
    for stream in (child.stdin, child.stdout, child.stderr):
        if stream is not None and not stream.closed:
            try:
                stream.close()
            except BaseException as close_error:
                row['communicate_errors'].append(repr(close_error))
    return stdout, stderr

def command(argv, code=0, input_raw=None, cleanup=False):
    argv = [str(a) for a in argv]
    require(allowed_command(argv), '非批准只读命令：' + repr(argv))
    if not cleanup:
        require(not stop and within_budget(), '已停止/已超过600秒，拒绝后续命令')
    row = {'argv': argv, 'started_ns': time.time_ns(), 'started_monotonic_ns': time.monotonic_ns(),
           'pid': None, 'reaped': False, 'signals_sent': [], 'cleanup': cleanup}
    result['commands'].append(row)
    child = subprocess.Popen(argv, stdin=subprocess.PIPE if input_raw is not None else subprocess.DEVNULL,
                             stdout=subprocess.PIPE, stderr=subprocess.PIPE, start_new_session=True,
                             env={**os.environ, 'GIT_OPTIONAL_LOCKS': '0', 'LC_ALL': 'C'})
    row['pid'] = child.pid
    children.append((child, row))
    stdout, stderr = collect_owned_child(child, input_raw, row)
    elapsed = time.monotonic_ns() - row['started_monotonic_ns']
    row.update(exit_code=child.returncode, finished_ns=time.time_ns(), elapsed_ns=elapsed,
               child_end_class='EXIT_STATUS' if child.returncode >= 0 else 'SIGNAL',
               stdout=stdout.decode(errors='replace'), stderr=stderr.decode(errors='replace'),
               stdout_sha256=hashlib.sha256(stdout).hexdigest(), stderr_sha256=hashlib.sha256(stderr).hexdigest(),
               stdout_bytes=len(stdout), stderr_bytes=len(stderr))
    require(not row['communicate_errors'], 'communicate异常已接管并回收：' + repr(row))
    require(elapsed <= 2_000_000_000, '自有child超2秒预算，已真实wait/reap；不启动后续READ')
    require(child.returncode == code and stderr == b'', '只读命令失败：' + repr(row))
    return row, stdout

def read_regular(path, allow_hardlink=False):
    require(path.is_absolute() and path == path.resolve(), '非规范文件路径')
    before = path.lstat()
    require(stat.S_ISREG(before.st_mode) and (allow_hardlink or before.st_nlink == 1), '非批准普通文件：' + str(path))
    fd = os.open(path, os.O_RDONLY | os.O_NOFOLLOW | os.O_CLOEXEC)
    try:
        opened = os.fstat(fd)
        require((before.st_dev, before.st_ino) == (opened.st_dev, opened.st_ino), '文件身份变化')
        with os.fdopen(fd, 'rb', closefd=False) as stream:
            raw = stream.read()
        after = os.fstat(fd)
        require((opened.st_size, opened.st_mtime_ns, opened.st_ctime_ns) ==
                (after.st_size, after.st_mtime_ns, after.st_ctime_ns), '读取期间文件变化')
    finally:
        os.close(fd)
    return raw, opened

def pin(path, digest):
    raw, _ = read_regular(path)
    require(hashlib.sha256(raw).hexdigest() == digest, 'SHA变化：' + str(path))
    return json.loads(raw)

def check(name, fn, exhaustive=False):
    row = {'name': name, 'status': 'FAIL', 'started_ns': time.time_ns()}
    result['checks'].append(row)
    try:
        row['value'] = fn()
        require(not isinstance(row['value'], dict) or row['value'].get('valid') is not False, '逐项检查有失败，保留完整结果')
        row['status'] = 'PASS'
        return row['value']
    except BaseException as error:
        row['error'] = repr(error)
        note_error(name, error)
        if not exhaustive:
            raise
    finally:
        row['finished_ns'] = time.time_ns()

def identity():
    value = {'hostname': os.uname().nodename, 'uid': os.getuid(), 'euid': os.geteuid(),
             'gid': os.getgid(), 'egid': os.getegid(), 'machine': os.uname().machine,
             'boot_id': Path('/proc/sys/kernel/random/boot_id').read_text().strip(), 'python': sys.version,
             'python_executable': sys.executable}
    require(value['hostname'] == 'ubuntu' and value['machine'] == 'aarch64'
            and value['uid'] == value['euid'] == value['gid'] == value['egid'] == 1000
            and value['boot_id'] == EXPECTED_BOOT, 'Orin主机/boot/运行身份错误')
    return value

def bootstrap():
    global driver, binaries
    helper = BASE / 'bootstrap/s52-control-helper-r1/prelaunch_go.py'
    require(hashlib.sha256(read_regular(helper)[0]).hexdigest() == HELPER_SHA, '既验helper身份改变')
    for name, expected in DRIVER_SHAS.items():
        require(hashlib.sha256(read_regular(ROOT / 'scripts' / name)[0]).hexdigest() == expected, '既验driver/helper身份改变：' + name)
    sys.path.insert(0, str(helper.parent))
    import prelaunch_go
    # 旧 helper 的只读 Git 统一经过本探针预算/wait；不调用其 timeout=30 的 subprocess.run。
    prelaunch_go.git = lambda root, *args: command(['git', '-C', str(root), *args])[1]
    driver, hashes = prelaunch_go.tracked_driver(ROOT / 'scripts/run_post_e_h2.py', ROOT, '4a8e171f27bf18625973aa4f3a6097e9b9fbed18')
    inputs = pin(BASE / 'bootstrap/s52-right-inputs-r1.json', '541d7f463948cfb5393dbf1a8fe20be648c6e550f014caa4245d4b446dbcbff7')
    manifests = {kind: prelaunch_go.reference(inputs[kind]) for kind in ('production', 'measurement', 'installed')}
    binaries = [Path(r['path']) for kind in ('production', 'measurement') for r in manifests[kind]['artifacts'].values()]
    binaries += [Path(r['path']) for n, r in manifests['installed']['files'].items() if n.startswith('installed:')]
    binaries.append(ELF)
    require(driver.UNITS == UNITS, '服务白名单与既验driver不符')
    for side, profile in PROFILES.items():
        actual = driver.arm_profile(side)
        require((actual.device, actual.usb_serial, actual.trust) == (profile['device'], profile['serial'], profile['trust']), 'USB/trust白名单不符')
    return {'driver_helpers': hashes, 'pinned_read_tool_is_current_build': False}

def elf_identity():
    raw, metadata = read_regular(ELF)
    require(hashlib.sha256(raw).hexdigest() == ELF_SHA and len(raw) == 1470368
            and raw[:6] == b'\x7fELF\x02\x01' and struct.unpack_from('<H', raw, 18)[0] == 183
            and metadata.st_uid == metadata.st_gid == 1000 and os.access(ELF, os.X_OK), '冻结READ ELF身份变化')
    return {'path': str(ELF), 'sha256': ELF_SHA, 'bytes': len(raw), 'elf_machine': 183,
            'mode': stat.S_IMODE(metadata.st_mode), 'uid': metadata.st_uid, 'gid': metadata.st_gid,
            'device': metadata.st_dev, 'inode': metadata.st_ino}

def formal(cleanup=False):
    prefix = 'after' if cleanup else 'before'
    def read_head():
        head = command(['git', '-C', str(FORMAL), 'rev-parse', 'HEAD'], cleanup=cleanup)[1].decode().strip()
        require(head == 'ca14f0e6cf6df8ecc6baaaa8dff2dddb64abbd0a', '正式ca14 HEAD变化')
        return head
    def read_status():
        status = command(['git', '-C', str(FORMAL), 'status', '--porcelain=v1', '--untracked-files=all'], cleanup=cleanup)[1].decode()
        require(status == '', '正式源码不clean')
        return status
    def baseline():
        installed = pin(BASE / 'right-readonly-r1/installed_before.json', '00c262bbbea00c8c2eff7c21b321a0b2ee82600c5e3d2362b8f2e6e46936a690')
        require({name: {key: row[key] for key in ('path', 'sha256', 'bytes', 'uid', 'gid', 'mode')}
                 for name, row in installed['files'].items()} == FORMAL_FILES, '固定文件白名单与既验manifest不同')
        return {'manifest_sha256': '00c262bbbea00c8c2eff7c21b321a0b2ee82600c5e3d2362b8f2e6e46936a690'}
    value = {'head': check(prefix + '_formal_HEAD', read_head, cleanup),
             'status_porcelain': check(prefix + '_formal_status', read_status, cleanup),
             'baseline': check(prefix + '_formal_baseline', baseline, cleanup), 'files': {}}
    for name, expected in FORMAL_FILES.items():
        def read_file(expected=expected, name=name):
            raw, m = read_regular(Path(expected['path']), allow_hardlink=True)
            row = {'path': expected['path'], 'sha256': hashlib.sha256(raw).hexdigest(), 'bytes': len(raw),
                   'uid': m.st_uid, 'gid': m.st_gid, 'mode': stat.S_IMODE(m.st_mode), 'nlink': m.st_nlink,
                   'device': m.st_dev, 'inode': m.st_ino, 'mtime_ns': m.st_mtime_ns, 'ctime_ns': m.st_ctime_ns}
            row['valid'] = all(row[key] == expected[key] for key in ('sha256', 'bytes', 'uid', 'gid', 'mode'))
            row['expected'] = expected
            return row
        value['files'][name] = check(prefix + '_formal_file_' + name, read_file, cleanup)
    value['valid'] = (value['head'] is not None and value['status_porcelain'] is not None and value['baseline'] is not None
                      and all(row is not None for row in value['files'].values()))
    return value

def services(cleanup=False):
    prefix = 'after' if cleanup else 'before'
    argv = ['systemctl', 'show', *UNITS, '--property=Id,LoadState,ActiveState,SubState,MainPID']
    shown = check(prefix + '_service_show', lambda: command(argv, cleanup=cleanup)[1].decode(), cleanup)
    # child失败时仍用已保留的完整stdout逐unit核实；不能由此把命令失败改成PASS。
    retained = result['commands'][-1] if result['commands'] and result['commands'][-1]['argv'] == argv else {}
    raw_text = shown if shown is not None else retained.get('stdout', '')
    value = {'raw_show': raw_text, 'show_success': shown is not None, 'units': {}}
    blocks = raw_text.strip().split('\n\n')
    def unit(name):
        matches = [block for block in blocks if 'Id=' + name in block.splitlines()]
        require(len(matches) == 1, '服务Id缺失/重复：' + name)
        fields = {}
        for line in matches[0].splitlines():
            key, content = line.split('=', 1)
            require(key not in fields, '服务字段重复：' + name)
            fields[key] = content
        valid = (set(fields) == {'Id', 'LoadState', 'ActiveState', 'SubState', 'MainPID'}
                 and fields.get('LoadState') == 'loaded' and fields.get('ActiveState') == 'inactive'
                 and fields.get('SubState') == 'dead' and fields.get('MainPID') == '0')
        return {'fields': fields, 'valid': valid}
    for name in UNITS:
        value['units'][name] = check(prefix + '_service_' + name, lambda name=name: unit(name), cleanup)
    def complete_unit_set():
        ids = [line[3:] for block in blocks for line in block.splitlines() if line.startswith('Id=')]
        require(len(ids) == len(UNITS) and set(ids) == set(UNITS), '六服务清单缺失/多项')
        return ids
    value['exact_unit_set'] = check(prefix + '_service_exact_set', complete_unit_set, cleanup)
    value['valid'] = value['show_success'] and value['exact_unit_set'] is not None and all(v is not None for v in value['units'].values())
    return value

def processes(cleanup=False):
    require(driver is not None, '既验driver未加载，进程门不能假称通过')
    def proc_probe(candidates):
        request = {'schema': 'P7_PROC_PROBE_V1', 'candidates': candidates}
        row, raw = command(['sudo', '-n', '/usr/bin/python3', '-I', '-S', '-c', driver.PROC_PROBE_CODE],
                           input_raw=json.dumps(request).encode(), cleanup=cleanup)
        return {'request': request, 'exit_code': row['exit_code'], 'response': json.loads(raw),
                'stdout': row['stdout'], 'stderr': row['stderr'], 'pid': row['pid'], 'reaped': row['reaped']}
    snap = driver.process_snapshot(-1, BASE / 'right-h2-run-01', binaries, probe_runner=proc_probe)
    require(snap['clean'], '控制/READ进程残留或身份不可读')
    return snap

def device(side, cleanup=False):
    profile = PROFILES[side]
    row, raw = command(['udevadm', 'info', '--query=property', '--name', profile['device']], cleanup=cleanup)
    lines = raw.decode().splitlines()
    for key, value in {'ID_VENDOR_ID': '1a86', 'ID_MODEL_ID': '55d3', 'ID_SERIAL_SHORT': profile['serial'], 'ID_USB_DRIVER': 'cdc_acm'}.items():
        require([l for l in lines if l.startswith(key + '=')] == [key + '=' + value], 'USB身份错误')
    path = Path(profile['device'])
    link, m = path.lstat(), path.stat()
    require(stat.S_ISLNK(link.st_mode) and stat.S_ISCHR(m.st_mode) and os.access(path, os.R_OK | os.W_OK), 'USB类型/权限错误')
    return {'device': str(path), 'resolved': str(path.resolve()), 'rdev': m.st_rdev, 'mode': stat.S_IMODE(m.st_mode),
            'uid': m.st_uid, 'gid': m.st_gid, 'device_inode': m.st_ino, 'link_inode': link.st_ino,
            'link_target': os.readlink(path), 'udev_command': row}

def holder(path, elevated, cleanup=False):
    require(path.exists(), '持有者路径缺失：' + str(path))
    row, raw = command((['sudo', '-n'] if elevated else []) + ['fuser', str(path)], 1, cleanup=cleanup)
    require(raw == b'', '串口/锁有持有者')
    return row

def protection(cleanup=False):
    prefix = 'after' if cleanup else 'before'
    states = {}
    for side, profile in PROFILES.items():
        def directory(profile=profile):
            trust = profile['trust'].lstat()
            return {'path': str(profile['trust']), 'device': trust.st_dev, 'inode': trust.st_ino,
                    'uid': trust.st_uid, 'gid': trust.st_gid, 'mode': stat.S_IMODE(trust.st_mode),
                    'valid': (profile['trust'] == profile['trust'].resolve() and stat.S_ISDIR(trust.st_mode)
                              and trust.st_uid == trust.st_gid == 1000 and stat.S_IMODE(trust.st_mode) == 0o750)}
        states[side] = {'directory': check(prefix + '_' + side + '_protection_directory', directory, cleanup)}
        for name in ('rx_trust_marker', 'rx_trust_marker.bak', 'estop_latch', 'estop_latch.bak', 'rx_trust.lock', 'estop_latch.lock'):
            path = profile['trust'] / name
            def read_ref(path=path, name=name):
                try:
                    raw, m = read_regular(path)
                except FileNotFoundError:
                    return {'path': str(path), 'missing': True}
                return {'path': str(path), 'hex': raw.hex(), 'sha256': hashlib.sha256(raw).hexdigest(),
                        'bytes': len(raw), 'mode': stat.S_IMODE(m.st_mode), 'uid': m.st_uid, 'gid': m.st_gid,
                        'device': m.st_dev, 'inode': m.st_ino, 'mtime_ns': m.st_mtime_ns, 'ctime_ns': m.st_ctime_ns,
                        'valid': (len(raw) <= 4096 and m.st_uid == m.st_gid == 1000
                                  and stat.S_IMODE(m.st_mode) == (0o640 if name in ('estop_latch', 'estop_latch.bak') else 0o600))}
            states[side][name] = check(prefix + '_' + side + '_protection_' + name, read_ref, cleanup)
    states['valid'] = all(row is not None for side in PROFILES for row in states[side].values())
    return states

def guard(epoch, exhaustive=False):
    value = {}
    for name, fn in (('identity', identity), ('formal', lambda: formal(exhaustive)), ('services', lambda: services(exhaustive)),
                     ('processes', lambda: processes(exhaustive)), ('protection', lambda: protection(exhaustive)), ('elf', elf_identity)):
        value[name] = check(epoch + '_' + name, fn, exhaustive)
    value['devices'], value['holders'] = {}, []
    for side, profile in PROFILES.items():
        value['devices'][side] = check(epoch + '_' + side + '_device', lambda side=side: device(side, exhaustive), exhaustive)
        for path in (Path(profile['device']), profile['trust'] / 'rx_trust.lock', profile['trust'] / 'estop_latch.lock'):
            for elevated in (False, True):
                value['holders'].append(check(epoch + '_' + side + '_' + path.name + ('_sudo' if elevated else ''),
                                              lambda path=path, elevated=elevated: holder(path, elevated, exhaustive), exhaustive))
    if not exhaustive:
        require(value['devices']['left']['resolved'] != value['devices']['right']['resolved'], '双USB映射相同')
    return value

def acquire_locks(before):
    for side, profile in PROFILES.items():
        for name in ('rx_trust.lock', 'estop_latch.lock'):
            path = profile['trust'] / name
            expected = before['protection'][side][name]
            require(not expected.get('missing') and path == path.resolve(), '合作锁缺失/路径不规范；不创建')
            fd = os.open(path, os.O_RDONLY | os.O_NOFOLLOW | os.O_CLOEXEC)
            locks.append(fd)
            lock_row = {'path': str(path), 'fd': fd, 'mode': 'O_RDONLY|O_NOFOLLOW|O_CLOEXEC',
                        'operation': 'LOCK_EX|LOCK_NB', 'opened': True, 'acquired': False, 'released': False}
            result['locks'].append(lock_row)
            m = os.fstat(fd)
            require(stat.S_ISREG(m.st_mode) and m.st_nlink == 1
                    and (m.st_dev, m.st_ino, m.st_uid, m.st_gid, stat.S_IMODE(m.st_mode), m.st_size, m.st_mtime_ns, m.st_ctime_ns)
                    == tuple(expected[key] for key in ('device', 'inode', 'uid', 'gid', 'mode', 'bytes', 'mtime_ns', 'ctime_ns')), '合作锁身份变化')
            fcntl.flock(fd, fcntl.LOCK_EX | fcntl.LOCK_NB)
            require(hashlib.sha256(os.pread(fd, 4097, 0)).hexdigest() == expected['sha256'], '合作锁内容变化')
            lock_row.update(device=m.st_dev, inode=m.st_ino, acquired=True)

def validate_read(side, motor, register, value):
    require(type(value) is int, 'READ不是整数')
    if register == 'Model_Number':
        require(value == 777, '型号不是STS3215/777，停止后续READ')
    elif register == 'Operating_Mode':
        require(value == (1 if side == 'right' and motor >= 7 else 0), '实际Operating_Mode不符，停止后续READ')
    elif register in STOP_REGISTERS:
        require(value == 0, '停止字段非int0，停止后续READ：' + register)
    elif register in ('Phase', 'CW_Dead_Zone', 'CCW_Dead_Zone'):
        require(0 <= value <= 255, '诊断元数据不是raw u8，停止后续READ：' + register)

def read_all():
    for side, profile in PROFILES.items():
        for motor in range(1, profile['count'] + 1):
            for register in REGISTERS:
                require(not stop and within_budget(), '停止/总预算超限；停止后续READ')
                identity()
                elf_identity()
                row, raw = command([str(ELF), profile['device'], str(motor), 'read', register])
                match = re.fullmatch(r'read ' + register + '@' + str(motor) + r' = (-?\d+)\n', raw.decode())
                require(match is not None, 'READ输出不精确')
                value = int(match.group(1))
                result['reads'].append({'index': len(result['reads']) + 1, 'side': side, 'motor_id': motor,
                                        'register': register, 'value': value, 'pid': row['pid'], 'exit_code': row['exit_code'],
                                        'reaped': row['reaped'], 'started_ns': row['started_ns'], 'finished_ns': row['finished_ns'],
                                        'stdout_sha256': row['stdout_sha256']})
                validate_read(side, motor, register, value)

def release_resources():
    # 对持有的所有 child 先真实 wait/reap；之后逐一释放fd，失败不跳过其余fd。
    for child, row in children:
        if not row['reaped']:
            collect_owned_child(child, None, row)
    for fd in reversed(locks):
        try:
            os.close(fd)
            for row in result['locks']:
                if row['fd'] == fd:
                    row['released'] = True
                    row['released_ns'] = time.time_ns()
        except BaseException as error:
            note_error('release_fd', error)
    locks.clear()

def lifecycle(preflight, body, teardown, postflight):
    try:
        preflight()
        body()
    except BaseException as error:
        note_error('preflight_or_read', error)
    finally:
        try:
            teardown()
        except BaseException as error:
            note_error('teardown', error)
        finally:
            try:
                postflight()
            except BaseException as error:
                note_error('postflight', error)

def main():
    for sig in (signal.SIGINT, signal.SIGTERM, signal.SIGHUP, signal.SIGQUIT):
        signal.signal(sig, handler)
    def preflight():
        result['identity'] = check('launch_identity', identity)
        result['bootstrap'] = check('bootstrap', bootstrap)
        result['before'] = guard('before')
        check('acquire_four_existing_readonly_locks', lambda: acquire_locks(result['before']))
    lifecycle(preflight, read_all, release_resources, lambda: result.update(after=guard('after', True)))
    before, after = result.get('before'), result.get('after')
    if before is not None and after is not None:
        for name in ('identity', 'formal', 'services', 'protection', 'elf'):
            check('compare_' + name, lambda name=name: require(before[name] is not None and after[name] is not None
                  and before[name] == after[name], '前后逐项不同/缺项：' + name), True)
        for side in PROFILES:
            def compare_device(side=side):
                require(before['devices'][side] is not None and after['devices'][side] is not None, '前后USB缺项')
                require({k: v for k, v in before['devices'][side].items() if k != 'udev_command'} ==
                        {k: v for k, v in after['devices'][side].items() if k != 'udev_command'}, 'USB前后身份变化')
            check('compare_' + side + '_device', compare_device, True)
    else:
        note_error('comparison', ValueError('前置未完整，不能宣称前后身份相同；后验已独立穷尽'))
    check('total_budget', lambda: require(within_budget(), '整轮Python超过600秒预算；仍完成真实回收与独立后验'), True)
    check('complete_reads_and_reap', lambda: require(len(result['reads']) == 170 and not stop
          and all(row['reaped'] for row in result['commands']) and all(row['released'] for row in result['locks']),
          'READ未完整/收信号/回收或释放不完整'), True)
    result.update(finished_ns=time.time_ns(), elapsed_ns=time.monotonic_ns() - result['started_monotonic_ns'],
                  completed=len(result['reads']), status='PASS' if not result['errors'] else 'FAIL',
                  limits=['仅本次寄存器采样；不证明连续静止、主动运动、Phase单位/零速合同或D15闭环',
                          '无新运动GO；历史左腕/右H2 FAIL、D15 OPEN/DEFERRED、deployable=false不变'])
    print(json.dumps(result, ensure_ascii=False, allow_nan=False), flush=True)
    return 0 if result['status'] == 'PASS' else 1

if __name__ == '__main__':
    raise SystemExit(main())
END_PY
