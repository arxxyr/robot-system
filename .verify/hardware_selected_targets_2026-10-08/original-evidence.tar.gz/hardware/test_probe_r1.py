"""只在本地夹具验证探针；不执行 main，不连接 SSH 或 UART。"""
import copy
import fcntl
import hashlib
import json
import os
from pathlib import Path
import stat
import subprocess
import sys
import tempfile
from types import SimpleNamespace
import unittest
from unittest.mock import patch

STAGE = Path(__file__).resolve().parent
SCRIPT = STAGE / 'probe_r1.sh'
PYTHON = SCRIPT.read_text().split("<<'END_PY'\n", 1)[1].rsplit('\nEND_PY', 1)[0]
ACTUAL_TEST_CHILDREN = []

def fixture():
    namespace = {'__name__': 'probe_test_fixture'}
    exec(compile(PYTHON, str(SCRIPT), 'exec'), namespace)
    namespace['within_budget'] = lambda: True
    return namespace

def read_backend(namespace, invalid=None):
    commands, identities = [], []
    namespace['identity'] = lambda: identities.append('identity')
    namespace['elf_identity'] = lambda: identities.append('elf')
    def command(argv):
        commands.append(argv)
        motor, register = int(argv[2]), argv[4]
        side = 'left' if '5A7C121427' in argv[1] else 'right'
        value = (777 if register == 'Model_Number' else
                 (1 if side == 'right' and motor >= 7 else 0) if register == 'Operating_Mode' else
                 255 if register in ('Phase', 'CW_Dead_Zone', 'CCW_Dead_Zone') else 0)
        if invalid is not None and (side, motor, register) == invalid[:3]:
            value = invalid[3]
        row = {'pid': len(commands), 'exit_code': 0, 'reaped': True,
               'started_ns': 1, 'finished_ns': 2, 'stdout_sha256': 'fixture'}
        return row, f'read {register}@{motor} = {value}\n'.encode()
    namespace['command'] = command
    return commands, identities

class ProbeMechanismTests(unittest.TestCase):
    def test_allowlist_rejects_every_write_and_foreign_path(self):
        ns = fixture()
        for profile in ns['PROFILES'].values():
            for register in ns['REGISTERS']:
                read = [str(ns['ELF']), profile['device'], '1', 'read', register]
                self.assertTrue(ns['allowed_command'](read))
                self.assertFalse(ns['allowed_command'](read[:3] + ['write', register]))
                self.assertFalse(ns['allowed_command'](read[:3] + ['write', register, '0']))
        for argv in ([str(ns['ELF']), '/dev/foreign', '1', 'read', 'Torque_Enable'],
                     ['systemctl', 'start', ns['UNITS'][0]], ['sudo', '-n', 'rm', '/var/lib/robot'],
                     ['git', '-C', str(ns['FORMAL']), 'reset', '--hard']):
            self.assertFalse(ns['allowed_command'](argv))

    def test_complete_170_reads_have_per_read_identity_and_raw_metadata(self):
        ns = fixture()
        commands, identities = read_backend(ns)
        ns['read_all']()
        self.assertEqual(len(commands), 170)
        self.assertEqual(len(ns['result']['reads']), 170)
        self.assertEqual(identities, ['identity', 'elf'] * 170)
        self.assertTrue(all(argv[3] == 'read' for argv in commands))
        self.assertEqual({(row['side'], row['motor_id']) for row in ns['result']['reads']},
                         {('left', i) for i in range(1, 9)} | {('right', i) for i in range(1, 10)})
        self.assertEqual([row['value'] for row in ns['result']['reads'] if row['register'] == 'Phase'], [255] * 17)

    def test_first_invalid_register_stops_every_later_read(self):
        failures = [('Model_Number', 776), ('Operating_Mode', 1), ('Torque_Enable', 1),
                    ('Present_Velocity', -1), ('Goal_Velocity', 1), ('Phase', -1),
                    ('CW_Dead_Zone', 256), ('CCW_Dead_Zone', 256)]
        for register, value in failures:
            with self.subTest(register=register):
                ns = fixture()
                commands, _ = read_backend(ns, ('left', 1, register, value))
                with self.assertRaises(ValueError):
                    ns['read_all']()
                self.assertEqual(len(commands), ns['REGISTERS'].index(register) + 1)
                self.assertEqual(commands[-1][4], register)
        for register in ('Torque_Enable', 'Present_Velocity', 'Goal_Velocity', 'Phase'):
            with self.assertRaises(ValueError):
                ns['validate_read']('left', 1, register, False)

    def test_preflight_read_and_teardown_failures_still_call_postflight(self):
        for failing in ('preflight', 'read', 'teardown'):
            with self.subTest(failing=failing):
                ns, observed = fixture(), []
                def phase(name):
                    def call():
                        observed.append(name)
                        if name == failing:
                            raise ValueError('fixture failure ' + name)
                    return call
                ns['lifecycle'](*(phase(name) for name in ('preflight', 'read', 'teardown', 'postflight')))
                self.assertEqual(observed[-2:], ['teardown', 'postflight'])
                self.assertTrue(ns['result']['errors'])
                self.assertEqual('read' in observed, failing != 'preflight')

    def test_independent_post_guard_attempts_all_20_top_level_items(self):
        ns = fixture()
        def fail(*args):
            raise ValueError('fixture unavailable')
        for name in ('identity', 'formal', 'services', 'processes', 'protection', 'elf_identity', 'device', 'holder'):
            ns[name] = fail
        after = ns['guard']('after', True)
        checks = ns['result']['checks']
        self.assertEqual(len(checks), 20)
        self.assertEqual(len({row['name'] for row in checks}), 20)
        self.assertEqual(len(after['holders']), 12)
        self.assertTrue(all(row['status'] == 'FAIL' for row in checks))

    def test_post_formal_attempts_both_git_checks_and_all_14_files(self):
        ns = fixture()
        ns['FORMAL_FILES'] = copy.deepcopy(ns['FORMAL_FILES'])
        paths, commands = [], []
        payload = b'fixture'
        for row in ns['FORMAL_FILES'].values():
            row['sha256'], row['bytes'] = hashlib.sha256(payload).hexdigest(), len(payload)
        first, second = list(ns['FORMAL_FILES'])[:2]
        def command(argv, **kwargs):
            commands.append(argv)
            return {}, b'wrong-head\n' if argv[-1] == 'HEAD' else b' M fixture\n'
        def read_regular(path, **kwargs):
            paths.append(str(path))
            name = next(name for name, row in ns['FORMAL_FILES'].items() if row['path'] == str(path))
            if name == second:
                raise PermissionError('fixture missing file')
            expected = ns['FORMAL_FILES'][name]
            m = SimpleNamespace(st_uid=expected['uid'], st_gid=expected['gid'], st_mode=stat.S_IFREG | expected['mode'],
                                st_nlink=1, st_dev=1, st_ino=1, st_mtime_ns=1, st_ctime_ns=1)
            return (b'changed' if name == first else payload), m
        ns['command'], ns['read_regular'] = command, read_regular
        ns['pin'] = lambda *a: (_ for _ in ()).throw(ValueError('fixture baseline missing'))
        value = ns['formal'](True)
        self.assertEqual(len(commands), 2)
        self.assertEqual(len(paths), 14)
        self.assertFalse(value['valid'])
        changed = next(row for row in ns['result']['checks'] if row['name'].endswith(first))
        self.assertEqual(changed['value']['sha256'], hashlib.sha256(b'changed').hexdigest())
        self.assertEqual(changed['status'], 'FAIL')

    def test_post_protection_attempts_both_directories_and_all_12_refs(self):
        ns = fixture()
        directories, refs = [], []
        def lstat(path):
            directories.append(str(path))
            return SimpleNamespace(st_uid=999 if str(path).endswith('_left') else 1000, st_gid=1000,
                                   st_mode=stat.S_IFDIR | 0o750, st_dev=1, st_ino=1)
        def read_regular(path):
            refs.append(str(path))
            if len(refs) == 1:
                raise PermissionError('fixture unreadable marker')
            mode = 0o640 if path.name in ('estop_latch', 'estop_latch.bak') else 0o600
            return b'1\n', SimpleNamespace(st_uid=1000, st_gid=1000, st_mode=stat.S_IFREG | mode,
                                          st_dev=1, st_ino=1, st_mtime_ns=1, st_ctime_ns=1)
        ns['read_regular'] = read_regular
        with patch.object(Path, 'lstat', lstat), patch.object(Path, 'resolve', lambda p: p):
            value = ns['protection'](True)
        self.assertEqual(len(directories), 2)
        self.assertEqual(len(refs), 12)
        self.assertFalse(value['valid'])
        self.assertIsNotNone(value['right']['estop_latch.lock'])

    def test_post_service_child_failure_keeps_raw_and_inspects_six_units(self):
        ns = fixture()
        raw = '\n\n'.join('Id=' + name + '\nLoadState=loaded\nActiveState=' + ('active' if i == 0 else 'inactive')
                             + '\nSubState=dead\nMainPID=0' for i, name in enumerate(ns['UNITS'])) + '\n'
        def command(argv, **kwargs):
            ns['result']['commands'].append({'argv': argv, 'stdout': raw})
            raise ValueError('fixture systemctl child failed')
        ns['command'] = command
        value = ns['services'](True)
        self.assertEqual(value['raw_show'], raw)
        self.assertEqual(len(value['units']), 6)
        self.assertFalse(value['valid'])
        checks = [row for row in ns['result']['checks'] if row['name'].startswith('after_service_xlerobot-')]
        self.assertEqual(len(checks), 6)
        self.assertEqual(checks[0]['value']['fields']['ActiveState'], 'active')
        self.assertTrue(all(row['status'] == 'PASS' for row in checks[1:]))

    def test_communicate_exceptions_reap_same_real_child_without_signals(self):
        for error in (OSError('fixture communicate failure'), KeyboardInterrupt('fixture interruption')):
            with self.subTest(error=type(error).__name__):
                ns = fixture()
                child = subprocess.Popen([sys.executable, '-I', '-S', '-c',
                                          'import sys;sys.stdout.write("o"*65536);sys.stderr.write("e"*65536)'],
                                         stdin=subprocess.DEVNULL, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
                def forbidden(*args):
                    raise AssertionError('不允许发信号')
                child.kill = child.terminate = child.send_signal = forbidden
                child.communicate = lambda *args: (_ for _ in ()).throw(error)
                row = {'reaped': False}
                stdout, stderr = ns['collect_owned_child'](child, None, row)
                self.assertEqual((stdout, stderr), (b'o' * 65536, b'e' * 65536))
                self.assertEqual(row['wait_returncode'], 0)
                self.assertTrue(row['reaped'])
                self.assertTrue(row['communicate_errors'])
                ACTUAL_TEST_CHILDREN.append({'pid': child.pid, 'wait_returncode': row['wait_returncode'],
                                             'reaped': row['reaped'], 'signals_sent': [],
                                             'injected_exception': type(error).__name__,
                                             'stdout_bytes': len(stdout), 'stderr_bytes': len(stderr)})

    def test_four_existing_locks_open_readonly_and_partial_contention_releases(self):
        ns = fixture()
        with tempfile.TemporaryDirectory(prefix='lock-fixture-', dir=STAGE) as directory:
            profiles, protection = {}, {}
            for side in ('left', 'right'):
                trust = Path(directory) / side
                trust.mkdir()
                profiles[side] = {'trust': trust}
                protection[side] = {}
                for name in ('rx_trust.lock', 'estop_latch.lock'):
                    path = trust / name
                    path.write_bytes(b'preserved fixture\n')
                    raw, m = ns['read_regular'](path)
                    protection[side][name] = {'device': m.st_dev, 'inode': m.st_ino, 'uid': m.st_uid,
                                              'gid': m.st_gid, 'mode': stat.S_IMODE(m.st_mode), 'bytes': len(raw),
                                              'mtime_ns': m.st_mtime_ns, 'ctime_ns': m.st_ctime_ns,
                                              'sha256': hashlib.sha256(raw).hexdigest()}
            ns['PROFILES'] = profiles
            opens, original_open = [], os.open
            def track_open(path, flags, *args, **kwargs):
                opens.append(flags)
                return original_open(path, flags, *args, **kwargs)
            blocker = original_open(profiles['left']['trust'] / 'estop_latch.lock', os.O_RDONLY)
            fcntl.flock(blocker, fcntl.LOCK_EX | fcntl.LOCK_NB)
            try:
                with patch.object(os, 'open', track_open):
                    with self.assertRaises(BlockingIOError):
                        ns['acquire_locks']({'protection': protection})
                self.assertTrue(all(flag & os.O_ACCMODE == os.O_RDONLY and flag & os.O_NOFOLLOW
                                    and not flag & (os.O_CREAT | os.O_TRUNC | os.O_APPEND) for flag in opens))
                ns['release_resources']()
                self.assertTrue(all(row['released'] for row in ns['result']['locks']))
                self.assertEqual(len(opens), 2)
            finally:
                os.close(blocker)
            ns['result']['locks'] = []
            ns['acquire_locks']({'protection': protection})
            self.assertEqual(len(ns['result']['locks']), 4)
            ns['release_resources']()
            self.assertTrue(all(row['acquired'] and row['released'] for row in ns['result']['locks']))
            self.assertTrue(all(path.read_bytes() == b'preserved fixture\n' for path in Path(directory).rglob('*.lock')))

    def test_child_budget_failure_preserves_reap_and_starts_no_second_read(self):
        ns = fixture()
        class Child:
            pid, returncode, stdin, stdout, stderr = 42, 0, None, None, None
            def communicate(self, data):
                return b'read Model_Number@1 = 777\n', b''
            def wait(self):
                return 0
        launches = []
        def launch(*args, **kwargs):
            launches.append(args[0])
            return Child()
        argv = [str(ns['ELF']), ns['PROFILES']['left']['device'], '1', 'read', 'Model_Number']
        with patch.object(subprocess, 'Popen', launch), patch.object(ns['time'], 'monotonic_ns', side_effect=[0, 2_000_000_001]):
            with self.assertRaises(ValueError):
                ns['command'](argv)
        self.assertEqual(len(launches), 1)
        self.assertTrue(ns['result']['commands'][0]['reaped'])
        self.assertEqual(ns['result']['commands'][0]['signals_sent'], [])

if __name__ == '__main__':
    suite = unittest.defaultTestLoader.loadTestsFromTestCase(ProbeMechanismTests)
    outcome = unittest.TextTestRunner(verbosity=2).run(suite)
    proof = {'schema': 'HARDWARE_READ_ONLY_LOCAL_MECHANISM_TESTS_V1',
             'status': 'PASS' if outcome.wasSuccessful() else 'FAIL', 'tests_run': outcome.testsRun,
             'failures': len(outcome.failures), 'errors': len(outcome.errors), 'skipped': len(outcome.skipped),
             'script_sha256': hashlib.sha256(SCRIPT.read_bytes()).hexdigest(), 'script_bytes': SCRIPT.stat().st_size,
             'actual_local_owned_children': ACTUAL_TEST_CHILDREN, 'ssh_uart_hardware': 'NOT_RUN'}
    print(json.dumps(proof, ensure_ascii=False, indent=2), flush=True)
    raise SystemExit(0 if outcome.wasSuccessful() else 1)
