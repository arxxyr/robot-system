"""提交前原生根Clippy；仅新独立同源源码/旧r7缓存，禁止工具链更新与硬件访问。"""
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import platform
import signal
from types import SimpleNamespace

BASE = Path('/home/loosqk/robot-checks/hardware-selected-targets-quality-20261008-r1')
SOURCE = BASE / 'source'
BOOT = BASE / 'bootstrap'
OUT = BASE / 'qa'
EXPECTED_HASH = '1d81eb4ad9cd207e3e638bd32b17ec4fce8412a6'


def module(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    value = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(value)
    return value


runner_module = module('natural_runner', BOOT / 'natural_runner.py')
artifacts = module('source_artifacts', BOOT / 'artifacts.py')
require = artifacts.require
require(artifacts.sha256(BOOT / 'natural_runner.py') == 'dad9bbc9405b8fac4d60d6efe794b36750e6a6f9ce9fdeba3debf7d3e1b9a471', '原runner身份不同')
require(artifacts.sha256(BOOT / 'artifacts.py') == 'bd2b3f7bb8527cd9ecec73894171638e9cf378656b89e284a585c3baa37b8731', '原artifact helper身份不同')
expected = artifacts.strict_json((BOOT / 'expected_source.json').read_text())
OUT.mkdir()
runner = runner_module.Runner(SimpleNamespace(source=SOURCE, out=OUT, target=Path('/home/loosqk/robot-checks/xlerobot-velocity-foundation-20261008-r7/build')), artifacts)
result = {'schema': 'XLEROBOT_ORIN_PRECOMMIT_CLIPPY_V1', 'status': 'FAIL', 'deployable': False,
          'native_git_head': None, 'scope': '仅新同源快照fmt→默认根Clippy提交前门；不更新nightly/不联网/不跑测试或release/不接硬件。',
          'runner_sha256': artifacts.sha256(BOOT / 'natural_runner.py'), 'receipts': []}


def source(label):
    require(not os.path.lexists(SOURCE / '.git'), '导出源不能伪称Git checkout')
    names = []
    for root, dirs, files in os.walk(SOURCE, followlinks=False):
        for name in dirs:
            path = Path(root) / name
            require(not path.is_symlink() and path.is_dir(), '导出源包含链接目录')
        for name in files:
            path = Path(root) / name
            require(not path.is_symlink() and path.is_file(), '导出源包含链接或特殊文件')
            names.append(path.relative_to(SOURCE).as_posix())
    require(set(names) == set(expected['files']) and len(names) == len(expected['files']) == 590, '590编译输入集合不同')
    value = artifacts.snapshot_source(SOURCE, names)
    require(value == expected, '590编译输入SHA/字节/exec不同')
    runner_module.save(OUT / (label + '.json'), value)
    return value


def command(label, argv, budget=60):
    ref, row = runner.command(label, argv, budget)
    return ref, row


old = {}
before = compiler = cargo = None


def interrupted(signum, frame):
    runner_module.INTERRUPTED = signum


try:
    for signum in (signal.SIGINT, signal.SIGTERM, signal.SIGHUP):
        old[signum] = signal.signal(signum, interrupted)
    identity = {'hostname': platform.node(), 'arch': platform.machine(), 'uid': os.getuid(), 'gid': os.getgid(),
                'boot_id': Path('/proc/sys/kernel/random/boot_id').read_text().strip()}
    require(identity == {'hostname': 'ubuntu', 'arch': 'aarch64', 'uid': 1000, 'gid': 1000, 'boot_id': '6cf7ee3e-a3c5-4c91-80bc-4ca924818b53'}, '主机身份不同')
    require(os.environ.get('CARGO_HOME') == '/home/loosqk/robot-checks/viz-orin-a6957cc-20260930-r1/cargo-home' and os.environ.get('CARGO_NET_OFFLINE') == 'true', 'r7既有离线缓存环境不同')
    result['identity'] = identity
    result['retained_cache_environment'] = {key: os.environ.get(key) for key in ('CARGO_HOME', 'CARGO_NET_OFFLINE', 'RUSTUP_AUTO_INSTALL', 'PYTHONDONTWRITEBYTECODE')}
    before = source('source_before')
    _, row = command('rustc_before', ['rustc', '-vV'])
    compiler = artifacts.parse_rustc_identity(Path(row['stdout']).read_text())
    require(compiler['commit_hash'] == EXPECTED_HASH, '实际nightly非已核1d81')
    _, row = command('cargo_before', ['cargo', '-V'])
    cargo = Path(row['stdout']).read_bytes()
    require(b'-nightly' in cargo, '实际cargo不是nightly')
    fmt_ref, _ = command('fmt', ['cargo', 'fmt', '--all'], 300)
    require(source('source_after_fmt') == before, 'fmt源码变化')
    clippy_ref, _ = command('clippy_default', ['cargo', 'clippy', '--locked', '--all', '--all-targets', '--', '-D', 'warnings'], 7200)
    result.update(status='PASS', compiler_before=compiler, cargo_before=cargo.decode(), fmt=fmt_ref, clippy=clippy_ref,
                  source_files=590, aggregate=before['source_manifest_sha256'])
except BaseException as error:
    result['error'] = repr(error)
finally:
    try:
        _, row = command('rustc_after', ['rustc', '-vV'])
        value = artifacts.parse_rustc_identity(Path(row['stdout']).read_text())
        require(compiler is not None and compiler == value, '前后rustc不符')
        _, row = command('cargo_after', ['cargo', '-V'])
        cargo_after = Path(row['stdout']).read_bytes()
        require(cargo is not None and cargo == cargo_after, '前后cargo不符')
        result.update(compiler_after=value, cargo_after=cargo_after.decode(), compiler_window='PASS')
    except BaseException as error:
        result.update(status='FAIL', compiler_window_error=repr(error))
    try:
        require(before is not None and source('source_after') == before, '源码前后漂移')
        result['source_before_after'] = 'PASS'
    except BaseException as error:
        result.update(status='FAIL', source_after_error=repr(error))
    result['receipts'] = runner.receipts
    runner_module.save(OUT / 'result.json', result)
    for signum, handler in old.items():
        signal.signal(signum, handler)
print(json.dumps(result, ensure_ascii=False), flush=True)
raise SystemExit(0 if result['status'] == 'PASS' else 1)
