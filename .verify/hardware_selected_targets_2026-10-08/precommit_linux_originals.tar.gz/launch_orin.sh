set -eu
export PATH=/home/loosqk/.cargo/bin:/home/loosqk/.local/bin:$PATH
export CARGO_HOME=/home/loosqk/robot-checks/viz-orin-a6957cc-20260930-r1/cargo-home
export CARGO_NET_OFFLINE=true
export RUSTUP_AUTO_INSTALL=0
export PYTHONDONTWRITEBYTECODE=1
cd /home/loosqk/robot-checks/hardware-selected-targets-quality-20261008-r1/bootstrap
sha256sum -c - <<'SHA_INPUTS'
bd2b3f7bb8527cd9ecec73894171638e9cf378656b89e284a585c3baa37b8731  artifacts.py
dad9bbc9405b8fac4d60d6efe794b36750e6a6f9ce9fdeba3debf7d3e1b9a471  natural_runner.py
ec22beaea06b70ed7c02cf67212d5c7face96a9a94bf17cc64aeca2b70f40c4e  run_orin.py
17d89cb1ea4c28c8fc5c0fd7eb6b3c0ce02e02db3371f01c10aee6d56790e0f1  receive_source.py
6a58b8cee7487bcd104a9c8ad3e7de5105ceb57ad997e343da878228329c3a1d  source-inputs.tar.gz
9761ec5dce8436a98198d399313e3dc576080fc751372a8f611fab9a52f189f8  expected_source.json
f5e7d37fab8c9c3b3b49dd334324bd7e5487b89af62b3977e6acaff97b15e8e1  source_export.json
SHA_INPUTS
uv run --no-project python receive_source.py
exec taskset -c 0-3 uv run --no-project python run_orin.py
