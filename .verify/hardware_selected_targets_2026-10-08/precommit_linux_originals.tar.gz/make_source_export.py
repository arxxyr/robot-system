"""主树只读导出590编译输入，另记录本阶段六个非编译域文件身份。"""
import hashlib, importlib.util, io, json, os, stat, subprocess, tarfile, time
from pathlib import Path
HERE=Path(__file__).resolve().parent
ROOT=Path('/Users/loosqk/repo/rust/robot-system')
spec=importlib.util.spec_from_file_location('artifacts',HERE/'artifacts.py');a=importlib.util.module_from_spec(spec);spec.loader.exec_module(a)
records=[]
def git(args):
 argv=['git',*args];started=time.monotonic_ns();p=subprocess.Popen(argv,cwd=ROOT,stdout=subprocess.PIPE,stderr=subprocess.PIPE);output,error=p.communicate();records.append({'argv':argv,'pid':p.pid,'exit_code':p.returncode,'reaped':True,'started_monotonic_ns':started,'ended_monotonic_ns':time.monotonic_ns(),'stdout':output.decode(),'stderr':error.decode()});a.require(p.returncode==0,'Git只读命令失败');return output
head=git(['rev-parse','HEAD']).decode().strip();a.require(head=='e8a5172963bcc9dddb943566e1fb453a8ec822c0','主HEAD变化')
status=git(['status','--porcelain=v1','--untracked-files=all']).decode();inventory=git(['ls-files','-z','--cached','--others','--exclude-standard']).decode().rstrip('\0').split('\0')
expected=a.snapshot_source(ROOT,inventory);original=json.loads((ROOT/'target/xlerobot_velocity_foundation/expected_source_r7.json').read_text());a.require(expected==original and len(expected['files'])==590,'当前编译域不是已验证r7同源590项')
dirty={row[3:] for row in status.splitlines() if any(row[3:]==d or row[3:].startswith(d+'/') for d in a.INPUT_DOMAINS)};a.require(not dirty,'当前编译域含未批准dirty')
other_names=['scripts/run_hardware_maintenance.py','scripts/tests/test_hardware_maintenance.py','CLAUDE.md','docs/CHANGELOG.md','docs/10_verification.md','team-swe/specs/post_e_comm_fault_hardening.HANDOFF.md']
other={name:{'sha256':a.sha256(ROOT/name),'bytes':(ROOT/name).stat().st_size} for name in other_names}
files={};archive=HERE/'source-inputs.tar.gz'
def identity(s):return(s.st_dev,s.st_ino,s.st_mode,s.st_size,s.st_mtime_ns,s.st_ctime_ns)
with tarfile.open(archive,'x:gz') as tar:
 for name,item in expected['files'].items():
  path=ROOT/name;info=path.lstat();a.require(stat.S_ISREG(info.st_mode) and path.resolve()==path,'非普通原文件')
  with os.fdopen(os.open(path,os.O_RDONLY|os.O_NOFOLLOW),'rb') as stream:first=os.fstat(stream.fileno());data=stream.read(item['bytes']+1);last=os.fstat(stream.fileno())
  a.require(identity(info)==identity(first)==identity(last)==identity(path.lstat()),'读取源身份漂移')
  a.require(len(data)==item['bytes'] and hashlib.sha256(data).hexdigest()==item['sha256'] and bool(info.st_mode&stat.S_IXUSR)==item['executable'],'原文不匹配冻结输入')
  row={**item,'mode':stat.S_IMODE(info.st_mode)};files[name]=row;member=tarfile.TarInfo(name);member.size=len(data);member.mode=row['mode'];tar.addfile(member,io.BytesIO(data))
a.require(git(['rev-parse','HEAD']).decode().strip()==head and git(['status','--porcelain=v1','--untracked-files=all']).decode()==status,'Git前后变化')
a.require(a.snapshot_source(ROOT,inventory)==expected,'导出后源码漂移')
a.require(other=={name:{'sha256':a.sha256(ROOT/name),'bytes':(ROOT/name).stat().st_size} for name in other_names},'阶段六文件身份导出时漂移')
value={'schema':'HARDWARE_MAINTENANCE_PRECOMMIT_SOURCE_EXPORT_V1','status':'PASS_EXPORT_ONLY','origin':{'main_root':str(ROOT),'main_head':head,'main_porcelain':status,'dirty_compilation_paths':[],'native_git_head':None,'source_kind':'exported compilation-input snapshot'},'non_compilation_stage_files':other,'source_manifest':expected,'files':files,'archive':{'sha256':a.sha256(archive),'bytes':archive.stat().st_size},'git_children':records,'artifacts_sha256':a.sha256(HERE/'artifacts.py')}
for name,data in [('expected_source.json',expected),('source_export.json',value)]:
 with (HERE/name).open('x') as f:json.dump(data,f,ensure_ascii=False,indent=2);f.write('\n')
print(json.dumps({'status':value['status'],'head':head,'files':len(files),'aggregate':expected['source_manifest_sha256'],'archive':value['archive'],'stage_files':other},ensure_ascii=False))
