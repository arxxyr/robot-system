set -eu
export PATH=/home/loosqk/.cargo/bin:/home/loosqk/.local/bin:$PATH
uv run --no-project python - <<'PY_REMOTE'
import os,stat,json
from pathlib import Path
base=Path('/home/loosqk/robot-checks/hardware-selected-targets-quality-20261008-r1')
assert os.getuid()==1000 and Path('/proc/sys/kernel/random/boot_id').read_text().strip()=='6cf7ee3e-a3c5-4c91-80bc-4ca924818b53'
assert base.parent.resolve()==base.parent and stat.S_ISDIR(base.parent.lstat().st_mode)
assert not os.path.lexists(base)
base.mkdir();(base/'bootstrap').mkdir()
print(json.dumps({'status':'PASS_CREATED_NEW_SOFTWARE_DIRECTORY','base':str(base)}))
PY_REMOTE
