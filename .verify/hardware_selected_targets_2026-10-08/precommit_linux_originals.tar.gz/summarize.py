"""逐项复核已下载原件与主树身份；不运行Cargo/SSH/UART。"""
import hashlib, importlib.util, json, subprocess, time
from pathlib import Path
HERE=Path(__file__).resolve().parent;ROOT=Path('/Users/loosqk/repo/rust/robot-system');NATIVE=HERE/'orin-originals'
spec=importlib.util.spec_from_file_location('artifacts',HERE/'artifacts.py');a=importlib.util.module_from_spec(spec);spec.loader.exec_module(a)
records=[]
def identity(p):return {'path':str(p),'bytes':p.stat().st_size,'sha256':a.sha256(p)}
def git(args):
 argv=['git',*args];start=time.monotonic_ns();p=subprocess.Popen(argv,cwd=ROOT,stdout=subprocess.PIPE,stderr=subprocess.PIPE);out,err=p.communicate();records.append({'argv':argv,'pid':p.pid,'exit_code':p.returncode,'reaped':True,'stdout':out.decode(),'stderr':err.decode(),'started_monotonic_ns':start,'ended_monotonic_ns':time.monotonic_ns()});a.require(p.returncode==0,'Git只读命令失败');return out
def save(name,value):
 p=HERE/name
 with p.open('x') as f:json.dump(value,f,ensure_ascii=False,indent=2);f.write('\n')
 a.strict_json(p.read_text());return identity(p)
expected=a.strict_json((HERE/'expected_source.json').read_text());export=a.strict_json((HERE/'source_export.json').read_text());native=a.strict_json((NATIVE/'result.json').read_text())
a.require(native['status']=='PASS' and native['source_before_after']=='PASS' and native['compiler_window']=='PASS','原生总结果未通过')
before=a.strict_json((NATIVE/'source_before.json').read_text());after=a.strict_json((NATIVE/'source_after.json').read_text());fmt_after=a.strict_json((NATIVE/'source_after_fmt.json').read_text());a.require(before==after==fmt_after==expected,'原生590输入前/格式化后/最终后不同')
completion_names=['rustc_before','cargo_before','fmt','clippy_default','rustc_after','cargo_after'];children=[]
for name in completion_names:
 p=NATIVE/name/'completion.json';row=a.strict_json(p.read_text());ref=next(item for item in native['receipts'] if item['path'].endswith('/'+name+'/completion.json'))
 a.require(a.sha256(p)==ref['sha256'] and row['exit_code']==0 and row['reaped'] is True and row.get('runner_error') is None and not row['budget_exceeded'] and not row['signals'] and not row['session_residual_before_cleanup'] and not row['session_residual_after_cleanup'],'原生真实完成/回收门未过')
 for stream in ['stdout','stderr']:
  raw=NATIVE/name/(stream+'.log');a.require(raw.stat().st_size==row[stream+'_bytes'] and a.sha256(raw)==row[stream+'_sha256'],'stdout/stderr原件身份不符')
 a.require(row['argv']=={'rustc_before':['rustc','-vV'],'cargo_before':['cargo','-V'],'fmt':['cargo','fmt','--all'],'clippy_default':['cargo','clippy','--locked','--all','--all-targets','--','-D','warnings'],'rustc_after':['rustc','-vV'],'cargo_after':['cargo','-V']}[name],'原生实际argv扩大或不同')
 children.append({'name':name,'pid':row['pid'],'identity':row['identity'],'exit_code':0,'reaped':True,'elapsed_ns':row['elapsed_ns'],'completion':identity(p)})
compiler=a.parse_rustc_identity((NATIVE/'rustc_before/stdout.log').read_text());a.require(compiler==a.parse_rustc_identity((NATIVE/'rustc_after/stdout.log').read_text()) and compiler['commit_hash']=='1d81eb4ad9cd207e3e638bd32b17ec4fce8412a6' and compiler['host']=='aarch64-unknown-linux-gnu','实际nightly窗口不同')
a.require((NATIVE/'cargo_before/stdout.log').read_bytes()==(NATIVE/'cargo_after/stdout.log').read_bytes(),'cargo窗口不同')
head=git(['rev-parse','HEAD']).decode().strip();inventory=git(['ls-files','-z','--cached','--others','--exclude-standard']).decode().rstrip('\0').split('\0');current=a.snapshot_source(ROOT,inventory);a.require(current==expected and head==export['origin']['main_head'],'主树编译域/HEAD在QA后变化')
stage={name:{'sha256':a.sha256(ROOT/name),'bytes':(ROOT/name).stat().st_size} for name in export['non_compilation_stage_files']}
for name in ['scripts/run_hardware_maintenance.py','scripts/tests/test_hardware_maintenance.py']:a.require(stage[name]==export['non_compilation_stage_files'][name],'两Python文件身份QA期间漂移')
host_owners=[]
for folder in sorted(HERE.glob('*.owner')):
 row=a.strict_json((folder/'result.json').read_text());a.require(row['status']=='PASS' and row['reaped'] and row['wait_returncode']==0 and not row['owner_sent_signals'] and not row['errors'],'本机owner未实际成功回收')
 host_owners.append({'name':folder.name,'owner_pid':row['owner_pid'],'child_pid':row['pid'],'exit_code':0,'reaped':True,'result':identity(folder/'result.json')})
tool=a.strict_json((HERE/'tool_owner_wait.json').read_text());a.require(tool['result']['exit_code']==0,'工具owner没实际完成')
host_identity=a.strict_json((HERE/'remote_identity.owner/child.log').read_text());a.require(host_identity['active_cargo_compilers']==[] and host_identity['identity']==native['identity'],'严格远端身份前置不符')
native_files=[identity(p) for p in sorted(NATIVE.rglob('*')) if p.is_file()]
summary={'schema':'HARDWARE_SELECTED_TARGETS_PRECOMMIT_LINUX_QUALITY_R1','status':'PASS_SCOPED_LINUX_FMT_ROOT_CLIPPY','deployable':False,'scope':'仅Linux新同源590快照fmt→根Clippy提交前门；无update/workspace-test/release/UART/service/formal修改','origin':export['origin'],'stage_files_before':export['non_compilation_stage_files'],'stage_files_after':stage,'python_same':True,'docs_same':{name:stage[name]==old for name,old in export['non_compilation_stage_files'].items() if not name.startswith('scripts/')},'source_count':590,'source_aggregate':expected['source_manifest_sha256'],'source_four_way_same':True,'compiler':compiler,'cargo':(NATIVE/'cargo_before/stdout.log').read_text().strip(),'compiler_cargo_before_after_same':True,'native_children':children,'host_owners':host_owners,'tool_owner_wait':identity(HERE/'tool_owner_wait.json'),'native_result':identity(NATIVE/'result.json'),'original_native_files':native_files,'retained_cache_environment':native['retained_cache_environment'],'cargo_target_reused_only':'/home/loosqk/robot-checks/xlerobot-velocity-foundation-20261008-r7/build','new_native_base':'/home/loosqk/robot-checks/hardware-selected-targets-quality-20261008-r1','git_final_readonly_children':records,'mac_root_clippy_original_fail':'root已有S0 Linux专属thread/O_PATH原101保持，本轮不改平台/安全语义','old_r7_local_owner_wait':'UNKNOWN保持，不由本轮PASS回填','hardware':'物理断电仍由root确认；未UART/未解释或改写现场-50和原FAIL；D15 OPEN_DEFERRED/deployable=false保持','firmware_candidate':'独立7源候选冻结未改，未纳入本轮590主树输入'}
summary_ref=save('summary.json',summary)
index_ref=save('artifact_index.json',{'files':[identity(p) for p in sorted(HERE.rglob('*')) if p.is_file() and p.name!='artifact_index.json'],'summary':summary_ref,'readback':'PASS'})
print(json.dumps({'status':summary['status'],'summary':summary_ref,'index':index_ref,'source_count':590,'aggregate':summary['source_aggregate'],'native_children':len(children),'host_owners':len(host_owners),'docs_same':summary['docs_same']},ensure_ascii=False))
