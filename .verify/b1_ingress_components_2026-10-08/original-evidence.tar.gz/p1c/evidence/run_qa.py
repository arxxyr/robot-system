import hashlib
import importlib.util
import json
import os
from pathlib import Path
import signal
import subprocess
import sys
import time

ROOT = Path(__file__).resolve().parents[2]
PHASE = sys.argv[1]
OUT = ROOT / 'target/b1_freshness_reducer' / PHASE
OUT.mkdir(exist_ok=False)
ROWS = []
REQUESTS = []
TARGET = ROOT / 'target/b1_freshness_reducer/cargo-target'
sys.dont_write_bytecode = True


def received(number, _frame):
    REQUESTS.append(number)


for name in ('SIGINT', 'SIGTERM', 'SIGHUP', 'SIGQUIT'):
    if hasattr(signal, name):
        signal.signal(getattr(signal, name), received)


def save(name, value):
    with (OUT / name).open('x') as output:
        json.dump(value, output, ensure_ascii=False, indent=2)
        output.write('\n')


def run(name, argv, budget_s=900):
    if REQUESTS:
        raise RuntimeError('已收到停止请求，不再启动child')
    env = os.environ.copy()
    env['CARGO_TARGET_DIR'] = str(TARGET)
    stdout_path, stderr_path = OUT / (name + '.stdout'), OUT / (name + '.stderr')
    row = {'name': name, 'argv': argv, 'owner_pid': os.getpid(), 'started_monotonic_ns': time.monotonic_ns(),
           'budget_s': budget_s, 'signals_sent': [], 'wait_errors': [], 'reaped': False}
    with stdout_path.open('xb') as stdout, stderr_path.open('xb') as stderr:
        child = subprocess.Popen(argv, cwd=ROOT, env=env, stdout=stdout, stderr=stderr, start_new_session=True)
        row['pid'] = child.pid
        row['session_id'] = os.getsid(child.pid)
        save(name + '.launch.json', row)
        print(json.dumps({'started': name, 'pid': child.pid}), flush=True)
        stop_started = None
        while True:
            try:
                code = child.wait(timeout=0.5)
                break
            except subprocess.TimeoutExpired:
                elapsed = (time.monotonic_ns() - row['started_monotonic_ns']) / 1e9
                if (REQUESTS or elapsed > budget_s) and stop_started is None:
                    os.killpg(child.pid, signal.SIGTERM)
                    row['signals_sent'].append(signal.SIGTERM)
                    stop_started = time.monotonic_ns()
                elif stop_started is not None and time.monotonic_ns() - stop_started > 10_000_000_000 and signal.SIGKILL not in row['signals_sent']:
                    os.killpg(child.pid, signal.SIGKILL)
                    row['signals_sent'].append(signal.SIGKILL)
            except BaseException as error:
                row['wait_errors'].append(repr(error))
        row.update(exit_code=code, wait_returncode=code, reaped=child.returncode is not None,
                   finished_monotonic_ns=time.monotonic_ns(), received_signals=list(REQUESTS))
    row['elapsed_ns'] = row['finished_monotonic_ns'] - row['started_monotonic_ns']
    row['over_budget'] = row['elapsed_ns'] > budget_s * 1_000_000_000
    for channel, path in [('stdout', stdout_path), ('stderr', stderr_path)]:
        raw = path.read_bytes()
        row[channel] = {'path': str(path), 'sha256': hashlib.sha256(raw).hexdigest(), 'bytes': len(raw)}
    ROWS.append(row)
    save(name + '.completion.json', row)
    print(json.dumps({'finished': name, 'exit_code': code, 'reaped': row['reaped']}), flush=True)
    if code != 0 or row['wait_errors'] or row['signals_sent'] or row['over_budget'] or REQUESTS:
        raise RuntimeError(name + '实际未自然通过')
    return stdout_path.read_bytes()


def window(label):
    inventory = [item.decode() for item in run(label + '_git_inventory', ['git', 'ls-files', '--cached', '--others', '--exclude-standard', '-z']).split(b'\0') if item]
    head = run(label + '_git_head', ['git', 'rev-parse', 'HEAD']).decode().strip()
    compiler = run(label + '_rustc', ['rustc', '+nightly', '-Vv']).decode()
    cargo = run(label + '_cargo', ['cargo', '+nightly', '-V']).decode()
    components = run(label + '_components', ['rustup', 'component', 'list', '--installed', '--toolchain', 'nightly']).decode()
    spec = importlib.util.spec_from_file_location('candidate_snapshot_source', ROOT / 'scripts/post_e_h2_artifacts.py')
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    snapshot = module.snapshot_source(ROOT, inventory)
    save(label + '_source.json', snapshot)
    value = {'head': head, 'compiler': compiler, 'cargo': cargo, 'components': components,
             'git_inventory_count': len(inventory), 'input_count': len(snapshot['files']),
             'source_manifest_sha256': snapshot['source_manifest_sha256'], 'source': snapshot}
    save(label + '_binding.json', {key: item for key, item in value.items() if key != 'source'})
    return value


result = {'schema': 'B1_P1C_LOCAL_QA_OWNER_R1', 'phase': PHASE, 'status': 'RUNNING', 'root': str(ROOT),
          'cargo_target_dir': str(TARGET), 'read_only_hardware': True, 'SSH': 0, 'UART': 0,
          'commands': ROWS, 'errors': [], 'scope': '独立Mac候选，不宣称Linux/RT调度/IPC接入/完整B1'}
try:
    if PHASE == 'combined_dependency_qa_r1':
        run('nightly_update', ['rustup', 'update', 'nightly'], 600)
    before = window('before')
    result['before'] = {key: value for key, value in before.items() if key != 'source'}
    fmt_argv = ['cargo', '+nightly', 'fmt', '--all']
    if not PHASE.startswith('pure_format_'):
        fmt_argv += ['--', '--check']
    run('fmt', fmt_argv)
    if PHASE == 'combined_dependency_qa_r1':
        run('transport', ['cargo', '+nightly', 'test', '-p', 'robot-transport'])
        run('core', ['cargo', '+nightly', 'test', '-p', 'robot-core', '--lib'])
        run('clippy', ['cargo', '+nightly', 'clippy', '-p', 'robot-core', '-p', 'robot-transport', '--all-targets', '--', '-D', 'warnings'])
    elif PHASE.startswith('pure_format_'):
        pass
    elif PHASE.startswith('pure_reducer_qa_'):
        run('default_tests', ['cargo', '+nightly', 'test', '-p', 'robot-s0', '--lib', 'base_ingress::tests::', '--', '--test-threads=1'])
        run('guard_tests', ['cargo', '+nightly', 'test', '-p', 'robot-s0', '--lib', '--features', 'rt_guard', 'base_ingress::tests::', '--', '--test-threads=1'])
        run('clippy', ['cargo', '+nightly', 'clippy', '-p', 'robot-s0', '--all-targets', '--', '-D', 'warnings'])
        run('guard_clippy', ['cargo', '+nightly', 'clippy', '-p', 'robot-s0', '--all-targets', '--features', 'rt_guard', '--', '-D', 'warnings'])
    else:
        raise ValueError('未知QA阶段')
    after = window('after')
    result['after'] = {key: value for key, value in after.items() if key != 'source'}
    result['source_before_after_equal'] = before['source'] == after['source']
    result['tools_before_after_equal'] = all(before[key] == after[key] for key in ('head', 'compiler', 'cargo', 'components'))
    changed = [name for name in set(before['source']['files']) | set(after['source']['files'])
               if before['source']['files'].get(name) != after['source']['files'].get(name)]
    result['changed_input_paths'] = sorted(changed)
    allowed_fmt = PHASE.startswith('pure_format_') and set(changed).issubset({
        'crates/robot-s0/src/base_ingress.rs', 'crates/robot-s0/src/base_ingress/tests.rs', 'crates/robot-s0/src/lib.rs'})
    if (not result['source_before_after_equal'] and not allowed_fmt) or not result['tools_before_after_equal']:
        raise RuntimeError('批次源或工具身份漂移')
    result['status'] = 'PASS'
except BaseException as error:
    result['status'] = 'FAIL'
    result['errors'].append(repr(error))
finally:
    result['commands'] = ROWS
    result['all_owned_children_reaped'] = all(row['reaped'] for row in ROWS)
    save('result.json', result)
    print(json.dumps({'result': str(OUT / 'result.json'), 'status': result['status'], 'actual_child_count': len(ROWS)}), flush=True)
sys.exit(0 if result['status'] == 'PASS' else 1)
