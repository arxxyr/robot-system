"""只读复核冻结候选与主树；仅写候选target下的派生合并计划。"""
from __future__ import annotations

from copy import deepcopy
from datetime import datetime, timezone
import hashlib
import importlib.util
import json
from pathlib import Path
import re
import stat
import subprocess
import time


MAIN = Path("/Users/loosqk/repo/rust/robot-system")
CANDIDATE = Path("/Users/loosqk/.codex/worktrees/b1-freshness-reducer/robot-system")
OUT = CANDIDATE / "target/b1_freshness_reducer"
RECEIPTS = OUT / "integration_read_r1"
BASE = "e8a5172963bcc9dddb943566e1fb453a8ec822c0"
EXPECTED_HEAD = "bfad2015f7772557b884d3ea4f6218aaa2ae4062"
FIRMWARE = [
    "crates/robot-adapters/feetech/examples/feetech_poke.rs",
    "crates/robot-adapters/feetech/src/bus.rs",
    "crates/robot-adapters/feetech/src/diagnostic.rs",
    "crates/robot-adapters/feetech/src/error.rs",
    "crates/robot-adapters/feetech/src/lib.rs",
    "crates/robot-adapters/feetech/src/registers.rs",
    "crates/robot-adapters/feetech/src/velocity_profile.rs",
]
CHILDREN = []


def canonical(value):
    return json.dumps(value, sort_keys=True, separators=(",", ":"), ensure_ascii=False, allow_nan=False).encode()


def sha(data):
    return hashlib.sha256(data).hexdigest()


def pin(path):
    info = path.lstat()
    assert stat.S_ISREG(info.st_mode), path
    data = path.read_bytes()
    assert len(data) == info.st_size
    return {"path": str(path), "sha256": sha(data), "bytes": len(data)}


def write_new(path, value):
    data = (json.dumps(value, ensure_ascii=False, indent=2, allow_nan=False) + "\n").encode()
    with path.open("xb") as stream:
        stream.write(data)
    return pin(path)


def git(name, root, *args):
    argv = ["git", *args]
    stdout_path = RECEIPTS / (name + ".stdout")
    stderr_path = RECEIPTS / (name + ".stderr")
    started_utc = datetime.now(timezone.utc).isoformat()
    started_ns = time.monotonic_ns()
    with stdout_path.open("xb") as stdout, stderr_path.open("xb") as stderr:
        child = subprocess.Popen(argv, cwd=root, stdout=stdout, stderr=stderr, start_new_session=True)
        launch = {"name": name, "argv": argv, "cwd": str(root), "pid": child.pid,
                  "started_utc": started_utc, "started_monotonic_ns": started_ns,
                  "owner": "本脚本直接Popen创建，不收养已有进程", "reaped": False}
        launch_ref = write_new(RECEIPTS / (name + ".launch.json"), launch)
        try:
            exit_code = child.wait(timeout=20)
        except BaseException:
            child.kill()
            child.wait()
            raise
    result = {**launch, "finished_utc": datetime.now(timezone.utc).isoformat(),
              "finished_monotonic_ns": time.monotonic_ns(), "exit_code": exit_code,
              "reaped": True, "signals": [], "launch": launch_ref,
              "stdout": pin(stdout_path), "stderr": pin(stderr_path)}
    reference = write_new(RECEIPTS / (name + ".completion.json"), result)
    CHILDREN.append(reference)
    assert exit_code == 0, result
    return stdout_path.read_bytes()


def inventory(name, root):
    data = git(name, root, "ls-files", "--cached", "--others", "--exclude-standard", "-z")
    return [s.decode() for s in data.split(b"\0") if s]


def tree_identity(name, revision, path):
    data = git(name, MAIN, "show", revision + ":" + path)
    return {"sha256": sha(data), "bytes": len(data)}


def line_containing(path, needle):
    rows = path.read_text().splitlines()
    return next(i for i, row in enumerate(rows, 1) if needle in row)


def run():
    RECEIPTS.mkdir(exist_ok=False)
    helper_path = MAIN / "scripts/post_e_h2_artifacts.py"
    helper_before = pin(helper_path)
    spec = importlib.util.spec_from_file_location("integration_artifacts", helper_path)
    helper = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(helper)
    candidate_manifest_path = OUT / "candidate_manifest_r1.json"
    candidate_manifest_before = pin(candidate_manifest_path)
    assert candidate_manifest_before["sha256"] == "87236b0fc75433a3e0be57b65ff05ba332303f2a33b3ce637ce0989230b58cec"
    manifest = json.loads(candidate_manifest_path.read_text())
    full_candidate_before = helper.snapshot_source(CANDIDATE, inventory("candidate_before_inventory", CANDIDATE))
    assert len(full_candidate_before["files"]) == 595
    assert full_candidate_before["source_manifest_sha256"] == manifest["source_manifest_sha256"]
    candidate_head = git("candidate_head", CANDIDATE, "rev-parse", "HEAD").decode().strip()
    assert candidate_head == BASE
    main_head_before = git("main_before_head", MAIN, "rev-parse", "HEAD").decode().strip()
    assert main_head_before == EXPECTED_HEAD
    main_before = helper.snapshot_source(MAIN, inventory("main_before_inventory", MAIN))
    assert len(main_before["files"]) == 591
    main_before_ref = write_new(OUT / "integration_main_before_source_r1.json", main_before)
    e8_paths = set(git("e8_tree_paths", MAIN, "ls-tree", "-r", "--name-only", "-z", BASE).decode().split("\0"))
    head_paths = set(git("head_tree_paths", MAIN, "ls-tree", "-r", "--name-only", "-z", main_head_before).decode().split("\0"))
    between_commits = git("e8_to_head_changed_paths", MAIN, "diff", "--name-only", "-z", BASE, main_head_before)
    baseline_changed = [p.decode() for p in between_commits.split(b"\0") if p]
    assert not any(any(p == d or p.startswith(d + "/") for d in helper.INPUT_DOMAINS) for p in baseline_changed)
    overlays = []
    for index, row in enumerate(manifest["eleven_changed_source"]):
        path = row["path"]
        assert path not in FIRMWARE
        final = full_candidate_before["files"][path]
        assert {k: final[k] for k in ("sha256", "bytes")} == {k: row[k] for k in ("sha256", "bytes")}
        assert final["executable"] is False
        assert (path in e8_paths) == (path in head_paths)
        if path in e8_paths:
            old_e8 = tree_identity(f"old_{index}_e8", BASE, path)
            old_head = tree_identity(f"old_{index}_head", main_head_before, path)
            old_main = {k: main_before["files"][path][k] for k in ("sha256", "bytes")}
            assert old_e8 == old_head == old_main
            old = {"state": "PRESENT", **old_main}
        else:
            assert path not in main_before["files"]
            old_e8 = old_head = {"state": "ABSENT", "sha256": None, "bytes": None}
            old = old_e8.copy()
        overlays.append({"path": path, "origin": row["origin"], "old_e8": old_e8,
                         "old_HEAD": old_head, "old_main_current": old,
                         "precondition": "当前旧值必须逐项相同或明确缺失，方可写入此new",
                         "new_candidate": final,
                         "action": "CREATE" if old["state"] == "ABSENT" else "REPLACE"})
    assert len(overlays) == 11
    assert sum(row["action"] == "CREATE" for row in overlays) == 5
    projected_files = deepcopy(main_before["files"])
    for row in overlays:
        projected_files[row["path"]] = row["new_candidate"]
    projected = {"domains": list(helper.INPUT_DOMAINS), "files": projected_files,
                 "source_manifest_sha256": sha(canonical(projected_files))}
    helper.validate_source_manifest(projected)
    assert len(projected_files) == 596
    firmware = [{"path": p, **main_before["files"][p], "overlay_action": "PRESERVE_CURRENT_MAIN_BYTES"} for p in FIRMWARE]
    differences = sorted(p for p in set(projected_files) | set(full_candidate_before["files"])
                         if projected_files.get(p) != full_candidate_before["files"].get(p))
    assert differences == sorted(FIRMWARE)
    assert all(projected_files[p] == main_before["files"][p] for p in FIRMWARE)
    serial = manifest["unchanged_serial_services"]["path"]
    expected_serial = {k: manifest["unchanged_serial_services"][k] for k in ("sha256", "bytes")}
    assert {k: main_before["files"][serial][k] for k in expected_serial} == expected_serial
    assert full_candidate_before["files"][serial] == main_before["files"][serial] == projected_files[serial]
    serial_e8 = tree_identity("serial_e8", BASE, serial)
    serial_head = tree_identity("serial_head", main_head_before, serial)
    assert serial_e8 == serial_head == expected_serial
    source_path = CANDIDATE / "crates/robot-s0/src/base_ingress.rs"
    tests_path = CANDIDATE / "crates/robot-s0/src/base_ingress/tests.rs"
    source = source_path.read_text()
    tests = tests_path.read_text()
    declared = re.findall(r"#\[test\]\s*fn\s+(\w+)\s*\(", tests)
    methods = manifest["source_method_roster"]["methods"]
    assert declared == methods and len(declared) == len(set(declared)) == 36
    guarded = declared[-1]
    assert re.search(r'#\[cfg\(feature = "rt_guard"\)\]\s*#\[test\]\s*fn\s+' + guarded, tests)
    guard_body = tests[tests.index("fn " + guarded):]
    guard_calls = re.findall(r"^\s{8}([a-z_0-9]+)\(\);$", guard_body, re.M)
    assert guard_calls == declared[:-1] and len(guard_calls) == 35
    assert "assert_no_alloc::assert_no_alloc(||" in guard_body
    assert not re.search(r"\b(Vec|Box|HashMap|BTreeMap|Arc|String)\b|SystemTime::now|Instant::now", source)
    assert "pub fn gated_command" in source and "pub struct BaseIngressSnapshot" in source
    assert "allow(dead_code)" not in source
    lib = CANDIDATE / "crates/robot-s0/src/lib.rs"
    allocator = CANDIDATE / "crates/robot-s0/src/post_e_convergence_acceptance.rs"
    cargo = CANDIDATE / "crates/robot-s0/Cargo.toml"
    workspace = CANDIDATE / "Cargo.toml"
    assert "#[cfg(test)]\nmod post_e_convergence_acceptance;" in lib.read_text()
    assert '#[cfg(feature = "rt_guard")]\n#[global_allocator]\nstatic LIB_TEST_ALLOCATOR: assert_no_alloc::AllocDisabler' in allocator.read_text()
    assert 'rt_guard = ["robot-core/rt_guard", "dep:assert_no_alloc"]' in cargo.read_text()
    assert 'assert_no_alloc = { version = "1.1", default-features = false }' in workspace.read_text()
    assert "#[global_allocator]" not in source + tests
    assert all(full_candidate_before["files"][str(p.relative_to(CANDIDATE))] == main_before["files"][str(p.relative_to(CANDIDATE))]
               for p in (allocator, cargo, workspace))
    projected_ref = write_new(OUT / "integration_expected_source_r1.json", projected)
    peer_receipt = pin(OUT / "peer_static_review_message_receipt_r1.json")
    assert peer_receipt["sha256"] == "43947a052d535134861d326c8598373ec8f81cfc76cea97b4cebf2460bbb2244"
    main_after = helper.snapshot_source(MAIN, inventory("main_after_inventory", MAIN))
    main_head_after = git("main_after_head", MAIN, "rev-parse", "HEAD").decode().strip()
    candidate_after = helper.snapshot_source(CANDIDATE, inventory("candidate_after_inventory", CANDIDATE))
    assert main_after == main_before and main_head_after == main_head_before
    assert candidate_after == full_candidate_before
    assert pin(helper_path) == helper_before and pin(candidate_manifest_path) == candidate_manifest_before
    main_after_ref = write_new(OUT / "integration_main_after_source_r1.json", main_after)
    commands = [
        ["cargo", "+nightly", "fmt", "--all", "--", "--check"],
        ["cargo", "+nightly", "clippy", "--locked", "--all", "--all-targets", "--", "-D", "warnings"],
        ["cargo", "+nightly", "clippy", "--locked", "-p", "robot-s0", "--all-targets", "--features", "rt_guard", "--", "-D", "warnings"],
        ["cargo", "+nightly", "test", "--locked", "-p", "robot-s0", "--lib", "base_ingress::tests::", "--", "--list"],
        ["cargo", "+nightly", "test", "--locked", "-p", "robot-s0", "--lib", "base_ingress::tests::", "--", "--test-threads=1"],
        ["cargo", "+nightly", "test", "--locked", "-p", "robot-s0", "--lib", "--features", "rt_guard", "base_ingress::tests::", "--", "--list"],
        ["cargo", "+nightly", "test", "--locked", "-p", "robot-s0", "--lib", "--features", "rt_guard", "base_ingress::tests::", "--", "--test-threads=1"],
    ]
    plan = {
        "schema": "B1_P1C_INTEGRATION_PLAN_R1",
        "status": "STATIC_PRECONDITIONS_PASS_PREDICTED_596_NOT_INTEGRATED_NOT_LINUX_TESTED",
        "created_utc": datetime.now(timezone.utc).isoformat(),
        "scope": "只读main与冻结candidate，唯一新增文件均在candidate target；无Cargo/SSH/UART/主树源码修改",
        "candidate": {"root": str(CANDIDATE), "HEAD": candidate_head, "manifest": candidate_manifest_before,
                      "complete_input_count": 595, "source_manifest_sha256": full_candidate_before["source_manifest_sha256"]},
        "main": {"root": str(MAIN), "HEAD": main_head_before, "base_commit": BASE,
                 "baseline_compile_domains_same_between_commits": True,
                 "noncompile_paths_changed_between_commits": baseline_changed,
                 "current_firmware_dirty_source_count": 7, "complete_input_count": 591,
                 "source_manifest_sha256": main_before["source_manifest_sha256"],
                 "before": main_before_ref, "after": main_after_ref, "source_and_HEAD_before_after_equal": True},
        "eleven_source_overlay_preconditions": overlays,
        "overlap_with_firmware": [], "preserve_firmware_seven": firmware,
        "serial_services_verify_only": {"path": serial, **expected_serial, "main_e8_HEAD_candidate_equal": True,
                                        "action": "NO_WRITE"},
        "expected_integrated_input": {"basis": "main实际591（bfad+7固件dirty）内存overlay e8冻结candidate11，其中5新增",
                                      "status": "PREDICTED_ONLY_NO_ACTUAL_MERGE_OR_QA", "files": projected_ref,
                                      "complete_input_count": 596, "source_manifest_sha256": projected["source_manifest_sha256"],
                                      "differences_from_candidate595_exactly": differences},
        "executable_integration_precondition": "root批准后，11旧值仍逐项一致才应用；不复制整树、不覆盖firmware7或serial_services。导出综合QA也须完整596逐项读回匹配该预测清单。",
        "actual_read_children": {"count": len(CHILDREN), "all_natural_exit_0_and_real_wait_reap": True, "completion_receipts": CHILDREN},
        "snapshot_helper": helper_before,
        "static_method_roster": {"status": "SOURCE_DECLARATIONS_ONLY_NOT_EXECUTABLE_LIST_YET",
                                 "source": pin(tests_path), "default_count": 35, "rt_guard_count": 36,
                                 "default_exact": ["base_ingress::tests::" + name for name in declared[:-1]],
                                 "rt_guard_exact": ["base_ingress::tests::" + name for name in declared],
                                 "guard_only": "base_ingress::tests::" + guarded,
                                 "guard_calls_35_default_methods_once_each": True,
                                 "count_rule": "35默认与36guard重叠35；guard入口内部重复35不再累计方法，唯一声明36。"},
        "Linux_QA_commands_NOT_EXECUTED": commands,
        "Linux_QA_boundaries": ["root安排latest nightly实际update与rustc/cargo/components首尾，源596首尾及每ownedchild真实wait/reap",
                                 "--list实际名单必须分别精确35/36，不能只以源码regex当作运行名单",
                                 "仅默认features及rt_guard；无xlerobot-real/RPC/USB/runtime生产接入；不宣称完整workspace测试",
                                 "纯reducer全部测试/Clippy仍未运行，不因Mac格式PASS或依赖QA外推"],
        "reuse_existing_noalloc_allocator": {
            "status": "STATIC_LINKAGE_VERIFIED_RUNTIME_PENDING", "no_second_allocator_added": True,
            "lib_cfg_test_module": {**pin(lib), "line": line_containing(lib, "mod post_e_convergence_acceptance;")},
            "existing_global_allocator": {**pin(allocator), "line": line_containing(allocator, "static LIB_TEST_ALLOCATOR:")},
            "s0_feature": {**pin(cargo), "line": line_containing(cargo, 'rt_guard = [')},
            "workspace_dependency": {**pin(workspace), "line": line_containing(workspace, 'assert_no_alloc = {')},
            "guard_entry": {**pin(tests_path), "line": line_containing(tests_path, "fn " + guarded)},
            "interpretation": "--lib --features rt_guard 编译现有cfg(test)模块内唯一AllocDisabler；guard闭包内真实分配将拒绝，不新增全局allocator。实际执行待Linux。"},
        "peer_static_review_original_messages": peer_receipt,
        "peer_review_limit": "由本agent转录实际peer消息，非peer签署JSON；peer最终字节窗口在最终fmt前89605a/3fcf29/25c42c。最终fmt后候选未冒充peer已逐字节核验；均静态未编译。root已另完整静态读审反馈无新增阻断。",
        "remaining_limits": ["Linux真实编译/Clippy/35与36方法/分配guard待验证",
                             "纯类型与reducer不证明实际publisher caller授权、IPC公平/队列/跨线程slot/WCET；不替代control authority或安全门",
                             "不关闭H2/左腕/头部实际FAIL或D15 OPEN_DEFERRED，deployable=false保持；无硬件GO/部署/push"]}
    plan_ref = write_new(OUT / "integration_plan_r1.json", plan)
    print(json.dumps({"plan": plan_ref, "expected_input": plan["expected_integrated_input"],
                      "main_source_aggregate": main_before["source_manifest_sha256"], "read_child_count": len(CHILDREN)}, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    run()
