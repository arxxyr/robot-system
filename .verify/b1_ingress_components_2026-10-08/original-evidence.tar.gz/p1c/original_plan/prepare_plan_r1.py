"""只读形成P1C函数级候选计划；不写业务源，不运行Cargo/SSH/UART。"""
import hashlib
import json
from pathlib import Path
import subprocess

ROOT=Path('/Users/loosqk/repo/rust/robot-system')
BASE=Path(__file__).resolve().parent
P1A=Path('/Users/loosqk/.codex/worktrees/xlerobot-base-profile/robot-system')
P1B=Path('/Users/loosqk/.codex/worktrees/xlerobot-wheel-profile/robot-system')
def ref(path):
 raw=Path(path).read_bytes();return {'path':str(path),'sha256':hashlib.sha256(raw).hexdigest(),'bytes':len(raw)}
names=['crates/robot-s0/src/lib.rs','crates/robot-s0/src/ipc_thread.rs','crates/robot-s0/src/ipc_runtime.rs','crates/robot-s0/src/serial_io_thread.rs','crates/robot-s0/src/serial_tick.rs','crates/robot-s0/src/watchdog.rs','crates/robot-core/src/adapter.rs','crates/robot-core/src/time.rs','crates/robot-transport/src/lib.rs','crates/robot-transport/src/sample.rs','crates/robot-transport/src/iceoryx2/subscriber.rs','crates/robot-transport/src/command_slot.rs','crates/robot-msg/schemas/frame_header.fbs','crates/robot-msg/schemas/event.fbs','crates/robot-msg/schemas/joint.fbs','docs/00_design.md','target/xlerobot_velocity_foundation/base_execution_root_decisions.md','target/xlerobot_velocity_foundation/full_base_execution_plan_r2.json']
before={n:ref(ROOT/n) for n in names}
head=subprocess.run(['/usr/bin/git','rev-parse','HEAD'],cwd=ROOT,capture_output=True,text=True,check=True).stdout.strip()
transport=(ROOT/'crates/robot-transport/src/sample.rs').read_text()
lib=(ROOT/'crates/robot-transport/src/lib.rs').read_text()
assert 'fn publisher_origin' not in transport and 'mod origin' not in lib and not (ROOT/'crates/robot-core/src/wheel_velocity_profile.rs').exists() and not (ROOT/'crates/robot-s0/src/base_ingress.rs').exists()
plan={
 'schema':'B1_P1C_BOUNDED_FRESHNESS_REDUCER_FUNCTION_PLAN_R1',
 'status':'PROPOSED_PENDING_ROOT_APPROVAL_NOT_IMPLEMENTED',
 'scope':'纯类型、有界状态与确定性reducer；不含实际IPC、RPC授权、writer或硬件接入，不宣称完整B1',
 'basis':{'main_head':head,'foundation':'e8a5172963bcc9dddb943566e1fb453a8ec822c0；编译域590/43b9基础已提交，当前2个Python目标选择改动独立','latest_root_decisions':'本轮root直接给定1 current Node+两个独立port/1 retired identity、SourceId显式0合法、100ms TTL、checked非0 accepted_counter、Lost双新恢复、显式Enable重建/internalZero Ack屏障，优先于旧计划未裁决项','source_readback':before},
 'dependencies':[
  {'id':'P1A','state':'独立Mac候选已独审但主树仍未整合','manifest':ref(P1A/'target/b1-p1a-origin/final_r5/candidate_manifest.json'),'source':ref(P1A/'crates/robot-transport/src/origin.rs'),'required_actual_API':['robot_transport::PublisherOrigin','PublisherOrigin::{node_id,publisher_id}','PublisherNodeId/PublisherPortId完整u128 private wrapper','SampleLease::publisher_origin()->Option<PublisherOrigin>'],'constraints':'只借用实际P1A强类型，不复制身份定义，不哈希/截断，不从FrameHeader.source_id或RPC caller伪造origin；None为未知，显式0保持合法。'},
  {'id':'P1B','state':'独立Mac候选已独审但主树仍未整合','manifest':ref(P1B/'target/wheel_velocity_profile/final_candidate_manifest_r1.json'),'source':ref(P1B/'crates/robot-core/src/wheel_velocity_profile.rs'),'required_actual_API':['robot_core::wheel_velocity_profile::WheelVelocityProfile'],'constraints':'纯contract接收已验证profile值；几何/轮速不得自填默认，target还须有限并可表示为f32。'},
  {'id':'integration_first','state':'业务实现前置','constraints':'先由root批准并独立整合P1A/P1B最终源和必要同源软件门；本计划不假装主树已有这些符号。不为了本计划新增wire字段或robot-core→transport依赖。'}
 ],
 'current_facts':[
  {'file':'crates/robot-s0/src/ipc_thread.rs','symbols':['poll_command','poll_heartbeat','parse_joint_command'],'facts':'poll_command仍latest()后按layout和基础Velocity期限解析；poll_heartbeat只存接收时clock.now()，没有配置source/actual origin/header-body序号时间一致性门；parse_joint_command当前buf.seq=fb.source_task_id()。'},
  {'file':'crates/robot-transport/src/iceoryx2/subscriber.rs','symbols':['try_recv','iceoryx2_latest'],'facts':'已有FIFO单样本try_recv；latest会drain并丢中间样本。因此纯reducer不能证明实际A→B→A身份变化已经被观察。'},
  {'file':'crates/robot-core/src/adapter.rs','symbols':['JointCommandBuf','MAX_JOINTS'],'facts':'POD seq为u64，MAX_JOINTS=32；P1C不改其布局，只在base转换函数赋checked accepted_counter并保留单独task关联。'},
  {'file':'crates/robot-s0/src/watchdog.rs','symbols':['WatchdogConfig'],'facts':'heartbeat_timeout_ns既有默认200ms；P1C接收显式已配置预算，不用100ms command TTL代替HB预算。'},
  {'file':'crates/robot-s0/src/ipc_runtime.rs','symbols':['start_enable','process_link'],'facts':'现显式Enable路径没有expected actual Node字段；纯reducer只有受信runtime事件相关性，不能验证RPC调用者等于候选publisher。'},
  {'file':'docs/00_design.md','symbols':['§1.2','§4.2','§6.7'],'facts':'不改冻结分层；RT不碰iceoryx2/Arc clone-drop/分配。安全与权限仍由现authority/执行器负责，reducer不能清EStop或覆写安全门。'}
 ],
 'planned_source_files':[
  {'path':'crates/robot-s0/src/base_ingress.rs','kind':'new','contents':'纯contract/输入/固定状态/snapshot/错误/effect及reducer全部放一模块，使用既有robot-core、P1A Copy身份和P1B Copy配置；不增Cargo依赖。'},
  {'path':'crates/robot-s0/src/base_ingress/tests.rs','kind':'new','contents':'确定性纯输入正负oracle；显式PublisherOrigin::for_mock夹具（现transport默认启mock）；RT guard条件下真实无分配检查。'},
  {'path':'crates/robot-s0/src/lib.rs','kind':'one module declaration','contents':'新增pub(crate) mod base_ingress；本包不引用IPC/runtime/SerialIo，不接生产路径。'}
 ],
 'types':[
  {'name':'ConfiguredSourceId','fields':'private u32','API':'const new(value:u32)->Self；const get()->u32；无Default','contract':'0是明确配置的合法SourceId，不是unknown sentinel；实际header/body source与本值逐项比较。'},
  {'name':'BaseIngressContract','fields':'ConfiguredSourceId、layout_id:u64、WheelVelocityProfile、heartbeat_timeout_ns:DurationNs；轮数量固定3、顺序8/7/9；COMMAND_TTL_MAX_NS=100_000_000','API':'new显式校验非0 HB预算；其余已验证值保真。layout_id/source_id原始0不因本模块新设sentinel而拒绝','contract':'没有默认配置；目标形状/值/TTL在命令入口再校验，不把profile正值当无限f32值可写证明。'},
  {'name':'ProducerCursor','fields':'Seen::{Unseen,Seen{seq:u64,stamp_ns:MonoRawNs}}；每port一份','contract':'首个header.seq=0合法，之后严格大于本port已见seq；不把HB与cmd seq互比。不回绕，MAX后同port的0/MAX均不能通过。'},
  {'name':'SessionIdentity/CurrentSessionSlot','fields':'一个PublisherNodeId + command_port:Option<PublisherPortId> + heartbeat_port:Option<PublisherPortId>；CurrentSessionSlot区分Empty/Partial/Bound','contract':'仅1当前候选/绑定Node，两port固定对应各topic且互不相等；Partial与Bound共用这一槽，不另外维护候选Node注册表。'},
  {'name':'RetiredSession','fields':'Option<完整旧SessionIdentity+两个已知cursor>，容量1','contract':'只保留最近失效/被替代的完整身份；换代覆盖该槽。相同Node重建一个port可在显式重建后成为新pair，不能因retired Node存在一概禁合法port重建；完整旧pair不得自动回绑。更早身份的队列重放靠cutoff/seq和显式屏障拒绝，不声称有无限退休历史。'},
  {'name':'RebindTicket/AcceptedCounter','fields':'private NonZeroU64（内部checked_add生成）；未建立用Option','contract':'ticket按重建请求checked推进；accepted_counter按完整有效命令checked推进并在整个reducer生命期不重置。0只作为无accepted命令的Option编码边界，不产生可执行POD.seq=0。'},
  {'name':'BaseCommandInput<'+'a>','fields':'origin:Option<PublisherOrigin>；header source/seq/stamp；layout_id；mode；target:&[f64]；deadline_ns；timeout intent；source_task_id:u64','contract':'字段来自外部已解码样本，纯reducer自行核真实数值合同；不接受一个verified布尔值替代字段检查。输入只借用，校验后固定[3]栈复制；actual wire decode和header来源获取另包。'},
  {'name':'HeartbeatInput','fields':'origin、header source/seq/stamp和body source/seq/stamp/tick_rate_hz','contract':'body三字段必须等于header；tick_rate有限且>0（不是caller权限证明）。'},
  {'name':'BaseIngressSnapshot','fields':'固定3轮f32目标、stamp/deadline、checked accepted_counter、task_association:u64、完整cmd/HB origin、ticket、phase、恢复floor及producer cursors/新鲜状态；全部Copy','contract':'snapshot是一次一致逻辑值，未接共享slot。无命令用Option/显式valid=false，不能把默认0 origin标Seen；RT consumer未来只能借Guard或Copy。'},
  {'name':'ReducerEffect/IngressReject','fields':'固定Copy枚举，无String/Vec；Accepted/Staged/Rejected/EnterSafe/MayRequestEnable/Exhausted','contract':'effect只是要求runtime采取动作或候选条件；不制造authority token、物理Zero Ack或真实TorqeOff证明。'}
 ],
 'bounded_state':{
  'phases':['Disabled','RebindPending','ReadyToEnable','Active','Lost','RebindRequired','Exhausted'],
  'capacity':{'current_Node':1,'current_command_port':1,'current_heartbeat_port':1,'retired_complete_identity':1,'staged_command':1,'staged_heartbeat':1,'latest_accepted_command':1,'registry_or_queue':0},
  'other_fixed_fields':['全局accepted_counter','checked重建ticket','binding_cutoff','barrier_cutoff','Lost floor和loss_cutoff','每port已接受cursor和必要的绑定屏障floor','internalZero Ack相关ticket/connection代次','Enable committed相关ticket','显式状态/拒绝原因'],
  'forbidden':['HashMap/BTreeMap/Vec/VecDeque/无限退休registry','按不同publisher增长记录','按burst增长重试/日志数组','任务UUID到tag映射（另属S1包）'],
  'staging_rule':'待绑定时两个固定暂存槽保存各自最高有效seq的样本；Staged不推进accepted_counter、不刷新运动freshness。两个来源配对/完整合同/Zero Ack屏障都满足后才一次提交当前身份、cursor与首个accepted命令。'
 },
 'state_transitions':[
  {'from':'initial','event':'new(contract)','to':'Disabled','rule':'current/retired/staged均空、accepted=None；不自动enable、不将时钟0或origin0当seen。'},
  {'from':'Disabled/RebindRequired','event':'begin_explicit_enable(disabled_evidence,now)','to':'RebindPending','rule':'受信runtime确认Disabled、唯一owner已退休、扭矩实际已确认关闭和相关代次一致；checked新ticket；清暂存，binding_cutoff=now；保留accepted_counter与retired/cursors。物理证据由接入包验证，纯event不声称真机已关闭。'},
  {'from':'RebindPending','event':'observe_internal_zero_ack(ticket,connection_epoch,now)','to':'RebindPending','rule':'仅预期ticket/连接代次合法的成功Ack；失败/未知/迟到旧Ack不推进。barrier_cutoff=max(binding_cutoff,now)，清之前暂存；此后HB和cmd stamp必须严格>barrier_cutoff，不能用Ack前消息补齐。'},
  {'from':'RebindPending','event':'post-Ack有效HB和cmd任意次序','to':'ReadyToEnable','rule':'先将样本各暂存1条；同配置SourceId、同完整Node、两个固定独立port、不是旧retired完整pair、各自seq超过匹配已知floor、stamp>cutoff、两者在现在仍fresh；counter/ticket全部checked准备后才原子逻辑提交。MayRequestEnable仅可预约现真实authority enable链。'},
  {'from':'ReadyToEnable','event':'observe_enable_committed(ticket,now)','to':'Active','rule':'真实runtime仅在authority/执行器成功结果后调用，ticket相符且HB与command仍fresh，非未知/旧Ack；否则不开放gate，超时走Lost或RebindRequired。不能把ReadyToEnable直接当上扭/Active。'},
  {'from':'Active','event':'valid same-session heartbeat/command','to':'Active','rule':'分别strict seq/freshness；HB不推进accepted_counter，有效cmd checked推进并独立保留task_association。每次gate读取仍校验now<cmd deadline和HB有效。'},
  {'from':'Active/ReadyToEnable','event':'control_lost或HB/command期限失效','to':'Lost','rule':'先motion gate=false并返回安全effect；捕获accepted_counter floor和loss_cutoff=now，清newHB/newcmd恢复标记；重复Lost观测不不断移动floor。旧command仍可作为诊断，不能forward。'},
  {'from':'Lost','event':'same-session post-loss新HB+新有效cmd','to':'Active（仅原Enable仍真实有效时）','rule':'两者producer stamp>loss_cutoff、各port seq高于loss前cursor、新cmd counter>floor，现HB/命令期限均fresh；仅HB或仅cmd不得恢复；reducer不会重新Enable或清authority inhibit。接入包还要原权限/安全门为真。'},
  {'from':'Active/Lost/ReadyToEnable/RebindPending','event':'well-formed且配置SourceId匹配的Node或port变化/配对冲突','to':'RebindRequired','rule':'立刻关闭候选motion gate/返回EnterSafe，退休原完整identity（容量1），不采用新消息、不推进counter/cursors/freshness；待Disabled真实确认后新的显式Enable重建。未知origin/错Source/坏body只是拒绝，不把任意垃圾当合法换代。'},
  {'from':'any except Exhausted','event':'explicit disable/external safety inhibit','to':'Disabled或RebindRequired（保留变化粘性）','rule':'撤motion gate、清暂存，保留counter/有效退休身份，不清EStop/fault/authority。身份变化要求重新重建，不能用旧HB恢复。'},
  {'from':'any','event':'accepted_counter或ticket checked溢出','to':'Exhausted','rule':'安全gate=false且不可在本reducer生命期解除；counter/seq/cursor/slot不提交溢出部分，不能wrap/saturating重用或用新identity reset counter。'}
 ],
 'validation_order':[
  'pure输入结构和actual origin Some；SourceId配置相等；Heartbeat body/source/seq/stamp逐项匹配；mode=Velocity/on_timeout=Zero/layout相等/target len恰好3/各值finite且abs<=显式轮速限与f32MAX（归零是三轮目标全0的合法Velocity命令，不把Stop mode冒称Velocity Zero）',
  '时钟使用调用者提供RobotClock.now()的MonoRawNs；stamp<=now；cmd deadline.checked_sub(stamp)为1..=100ms且now<deadline；HB年龄checked_sub为0..heartbeat_timeout（上端不含），必要deadline checked_add溢出拒绝；不可用收到旧消息时的now替代producer stamp来续命',
  '候选/bound身份阶段和每portseq严格增；stamp不得低于其已接受stamp；绑定/恢复样本stamp必须严格大于相应cutoff和已知barrier stamp floor。一般连续seq可允许相同纳秒stamp（仍fresh），不平白把同tick合法多帧误拒；绑定/恢复严格下限例外必须>。',
  'Identity变化对已完成上述数值/来源有效性验证的样本返回安全effect；不自动选择替代Node/port。Unknown/非法/旧/未来/重复只拒绝，accepted counter/freshness/latest均保持。',
  '所有checked counter/ticket下一值和fixed f32转换先在栈上准备；全部成功再一次提交state与snapshot。错误观察计数由外层记录，不让metrics溢出变成授权。'
 ],
 'functions':[
  {'name':'BaseIngressContract::new','inputs':'显式ConfiguredSourceId/layout/WheelVelocityProfile/HB预算','result':'Result<Contract,ConfigReject>','notes':'无Default/单位猜测，HB预算必须>0。'},
  {'name':'BaseIngress::new','inputs':'Contract','result':'Disabled reducer','notes':'固定值初始化，无clock读取/IO/alloc。'},
  {'name':'validate_command_fields','inputs':'&Contract,&BaseCommandInput,now','result':'Result<固定ValidatedCommand,IngressReject>','notes':'只读；形状3、finite/f32/profile/layout/mode/Zero/100ms窗；task标签独立。'},
  {'name':'validate_heartbeat_fields','inputs':'&Contract,&HeartbeatInput,now','result':'Result<固定ValidatedHeartbeat,IngressReject>','notes':'只读；header-body一致、配置source、producer clock新鲜。'},
  {'name':'validate_port_progress','inputs':'actual typed origin,port role,cursor/fence,inputseq/stamp','result':'Result<PreparedCursor,IngressReject>','notes':'严格u64 seq，不把两个portseq比较，不先写Seen。'},
  {'name':'begin_explicit_enable','inputs':'受信Disabled/退休/关闭上下文、expected connection代次、now','result':'Result<RebindTicket,LifecycleReject>+fixed effect','notes':'只预备；不真实RPC鉴权/预约物理enable/清保护。'},
  {'name':'observe_internal_zero_ack','inputs':'ticket、expected连接代次、Ack outcome、now','result':'fixed effect','notes':'ticket/连接不符或失败不推进；成功后清前Ack样本并设严格新cutoff。'},
  {'name':'accept_heartbeat','inputs':'&mut self,HeartbeatInput,now','result':'ReducerEffect','notes':'字段校验→身份/port→阶段→栈Prepared→commit；Pending仅Staged，Lost记new HB但单独不能forward。'},
  {'name':'accept_command','inputs':'&mut self,BaseCommandInput,now','result':'ReducerEffect','notes':'字段校验→身份/port→阶段→next counter checked→commit；Pending仅Staged，任务tag不作seq。'},
  {'name':'try_complete_rebind_barrier','inputs':'&mut self,now','result':'Staged/MayRequestEnable/Reject','notes':'固定两个暂存槽，新鲜共同Node+不同port+cutoff+floor+Ack后完成；没有while drain、registry或分配。'},
  {'name':'observe_enable_committed','inputs':'ticket、真实runtime结果投影、now','result':'fixed effect','notes':'只同ticket且仍fresh可进入Active；纯reducer不验证外部caller/物理结果的真实性。'},
  {'name':'on_control_lost / on_tick','inputs':'now、显式link/safety事件','result':'Lost、安全effect或当前gate','notes':'Lost只捕获一次floor；tick必须拒绝now==deadline与HB年龄上端。'},
  {'name':'invalidate_identity / observe_disabled','inputs':'已验证的身份变化或显式disabled上下文','result':'RebindRequired/Disabled fixed effect','notes':'one retired slot；no automatic rebind，preserve accepted_counter和故障粘性。'},
  {'name':'snapshot / recovery_ready','inputs':'&self,now','result':'Copy snapshot / bool候选条件','notes':'不分配、不clone Arc；bool只是额外软件条件，不是authority许可，后续与真实安全权限门AND。'},
  {'name':'BaseIngressSnapshot::to_joint_command_buf','inputs':'完整accepted snapshot且gate调用上下文','result':'固定JointCommandBuf','notes':'栈初始化三类MAX_JOINTS数组，mode Velocity/count3、velocities前三值、其余全0、seq=nonzero accepted_counter；source_task_id只在snapshot单独保留。'}
 ],
 'errors':['UnknownOrigin','ConfiguredSourceMismatch','HeartbeatHeaderBodyMismatch','InvalidHeartbeatRate','InvalidLayout','InvalidMode','UnsupportedTimeout','WrongTargetCount','NonFiniteTarget','TargetOutsideProfile','TargetOutsideF32','InvalidCommandTtl','FutureStamp','ExpiredCommand','ExpiredHeartbeat','ClockArithmeticOverflow','ProducerSeqNotIncreasing','ProducerStampRegression','BelowBindingCutoff','BelowRecoveryCutoff','BelowKnownFence','PortAlias','NodeMismatch','PortChanged','RetiredPair','RebindRequired','WrongLifecyclePhase','DisabledOrRetirementUnconfirmed','WrongRebindTicket','WrongConnectionEpoch','InternalZeroAckUnconfirmed','EnableResultUnconfirmed','CounterExhausted','TicketExhausted'],
 'test_oracles':{
  'positive':['显式source0、mock typed Node/port高128bit及显式0保真；未知仍None','相同Node的HB/cmd两独立port，HB先/命令先都只Staged，Zero Ack后双新样本才Ready，Enable committed后才Active','同任务source_task_id固定0或固定非0，producer seq严格递增且accepted seq非0独立；HBseq与cmdseq不同合法','TTL=1ns/100ms、stamp==now且now<deadline合格；HB按显式预算合格；finite f32边界、全0 Velocity合法','Lost floor保存一次；仅新HB/仅新cmd门均false，两者真正post-loss且仍fresh并counter>floor才恢复','显式Disable→退休/关闭确认→Enable重建→正确Zero Ack→新pair→真实Enable结果正例；同Node单port重建正例','固定Burst有限fold，结果与逐条相同，无增加容量；Copy snapshot与POD三个值/counter/task标签一致'],
  'negative':['origin None、错SourceId、Node高bit别名/Port高bit别名、同port充当两topic一律不能授权','HB header/body任一source/seq/stamp不等、NaN/Inf/非正tick_rate不刷新last_hb','target len0/1/2/4/MAX+1、错layout/Position/Stop/未知mode、Hold/Stop/未知timeout、NaN/Inf/f64超过f32/超过profile全拒，无counter/cursor/snapshot改写','TTL0/100ms+1、deadline<=stamp、now==deadline、未来stamp、HB恰预算上端/过期、checked timestamp溢出拒绝','各port重复/倒退/MAX后wrap0拒绝；首见seq0合法不能和Unseen混淆；stamp回退拒绝，active相同stamp+更大seq仍按时间窗判','Lost前排队高seq但stamp<=loss_cutoff不能恢复；新HB加旧命令、过期新命令或只一端新消息不得恢复','B实际合法身份打断A后，A的排队残留/A→B→A不得恢复；换node/任一port立即安全/require Disabled显式重建，坏消息不冒作合法换代','Ack前已暂存HB/cmd、cutoff相等、正确source但旧retired完整pair、旧ticket Ack、错connection Ack、Zero Ack失败/未知或Enable迟到成功均不能开启','accepted_counter=u64::MAX后下一有效cmd进Exhausted但不提交部分seq/snapshot；ticketMAX不能wrap；新publisher不能reset accepted counter','外部EStop/Disable/inhibit事件不得被新HB或cmd覆盖；Disabled未确认/owner未退休/扭矩关闭未知禁止begin','不变量坏输入state位级不变（身份变化/计数耗尽只允许定义的fail-closed变化）；一次logic snapshot不得混旧command与新identity','rt_guard真allocator关闭下跑所有有限分支与snapshot/POD转换；无Vec/String/heap/Arc/refcount/FlatBuffers/IO及panic路径'],
  'counter_injection':'只在cfg(test)模块私有状态夹具注入MAX-1/MAX，不增加生产unsafe unchecked/public构造或默认启用feature。',
  'counting':'列举oracle未执行，不预报通过数量；实施后以Rust实际方法名册去重，default/rt_guard重复运行不累加新方法。'
 },
 'burst_and_replay_boundary':{
  'pure':'每次处理1个显式输入，O(3) target验证/O(1)状态与origin比较；每port最多1个staged最高有效seq，不增长缓存或无限循环；invalid latest不能覆盖上个有效accepted snapshot。',
  'sequence':'Strict seq只对同actual port，首见用Unseen表达；不以wrapping跨MAX承认重放，也不按task tag推断顺序。',
  'fence':'bind/Zero Ack后cutoff严格下限拒绝全部已在队列中但producer stamp旧的样本；匹配当前/retired已知port继续要求seq和stamp超过原floor。未知port没有伪造seq0 floor，必须经新pair与cutoff屏障；队列丢弃不是fresh接受。',
  'old_registry_limit':'容量1退休身份不能逐项记录无限重启。更早A样本按旧producer时间/单调seq/显式换代拒绝；若历史Node重新生成新stamp且已不在1槽退休记录中，纯reducer不能证明密码学身份或永远封禁，仍必须新的显式重建，实际caller/node选择认证未实现。',
  'integration_required':'现latest会隐藏中间origin，不能用纯fold oracle外推真实队列。下一IPC包须用现try_recv有界批次逐条校验/观测身份变化并在处理普通命令前保高优先收紧；批次超限需保守关闭gate并留原消息证据，不能无界drain/静默skip身份变更。具体batch预算由IPC接入计划测量/批准，本包不设未经测量的硬实时承诺。'
 },
 'RT_no_alloc_contract':{
  'hot_functions':'所有pure reducers/validation/snapshot/POD转换仅栈固定数组、Copy强类型、checked整数算术和match；最多固定3 target/2port分支，无锁或外部时间获取。',
  'writer_location':'未来reducer仍由单IPC owner调用，RT只读一次一致snapshot；本包不将transport lease/view带入RT，也不实现跨线程共享方案。',
  'guard':'复用robot-s0既有rt_guard和post_e_convergence_acceptance的LIB_TEST_ALLOCATOR，不能新增第二global_allocator；测试初始化/fixture创建在guard外，实际分支在assert_no_alloc闭包内。',
  'layout':'Copy/无Drop类型与固定字段尺寸编译时守卫；实施后报告真实size_of，无当前测量不声称具体byte/WCET；不改JointCommandBuf ABI。'
 },
 'planned_validation_not_executed':['实现后浮动latest nightly先核实际rustc/cargo并绑定当次源码首尾','本机scoped fmt→S0默认和rt_guard纯模块方法（实际方法去重）→必要Clippy；Linux同源rt_guard需独立原件，不能外推Mac真RT','集成提交前按现root fmt→根Clippy要求绑定；此计划阶段不运行Cargo或更新工具链','源/静态/动态独审通过后root确认P1C仅pure软件范围；实际IPC→同slot→SerialIo/authority/adapter Mock正负路径另包并分别验收'],
 'out_of_scope':['P1A/P1B实际整合（root另包）','TOML/profile解析和真实source配置选择','FlatBuffers/schema更改/生产wire decode映射','RPC权限/调用方expected Node绑定验证','当前poll_command/poll_heartbeat/run_loop、IpcRuntime start_enable/process_link改动','真实InternalZero/Disable/Enable写入与确认、全局authority token/权限结构','LatestCommandSlot跨线程原子元数据接入/RT reader更新','S1 BaseVelocity任务/UUID映射/终态publish','固件Model/Phase/单位/轮速量化/右USB混合六臂与三轮writer','任何SSH/UART/运动/部署/安装/服务激活/push、完整B1或H2/D15闭环'],
 'root_approval_items':['认可Pending只Staged且Zero Ack之前暂存不作fresh，双新pair完成后才分配accepted counter/MayRequestEnable；真实Enable结果再开Active，防Ready直接冒作运动许可','认可常态stamp不得回退但同纳秒更大seq可合法；绑定/恢复严格stamp>cutoff/floor且Lost队列stamp<=loss时拒绝','认可1 retired完整pair保留，允许同Node单port显式重建；不会承诺无限历史Node永久封禁或已验证RPC caller identity','认可IPC真实FIFO/batch/高优先收紧另包；P1C只最多3源码pure reducer，不可宣称完整B1'],
 'execution_record':{'business_source_edits':0,'Cargo':0,'SSH':0,'UART':0,'tests_executed':0,'motion_GO':'NOT_ISSUED','deployment':'NOT_RUN','deployable':False,'D15':'OPEN/DEFERRED'},
}
after={n:ref(ROOT/n) for n in names}
assert before==after
plan['planning_readback_before_after_equal']=True
out=BASE/'plan_r1.json'
with out.open('x') as f:json.dump(plan,f,ensure_ascii=False,indent=2);f.write('\n')
print(json.dumps({'status':plan['status'],'planned_source_files':len(plan['planned_source_files']),'report':ref(out),'source_unchanged':True},ensure_ascii=False))
