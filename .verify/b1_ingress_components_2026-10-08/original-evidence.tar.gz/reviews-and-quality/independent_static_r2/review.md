爸爸，P1C r2三源静态复核通过，无阻断；Linux实际验收仍须另核。

- Counter/Ticket原因只在各自checked溢出入口设定一次。Exhausted在8个公共生命周期/入站入口和私有rebind中保持原cause，不清状态、不重置counter/ticket；POD gate关闭。
- Ready→Lost恢复的新HB/命令即使同时新鲜，也只返回Ready；当前ticket真正Committed Enable事件后才Active，诊断snapshot没有POD转换。
- Ack前置屏障及已保存producer stamp之前的回退时刻均拒绝或进入RebindRequired，不建立较低Lost fence；重复Lost不移动cutoff/floor。这个门不是任意now历史的全局单调监控，调用方仍须提供正确MonoRawNs。
- 固定值状态没有动态容器、I/O或取时钟；guard oracle复用现有唯一lib allocator，并包含全部36个普通oracle。这里只核源码，不宣称已运行无分配测试或RT WCET。
- 新分类oracle覆盖两种真实checked耗尽入口、公共事件/入站回放、无效或新身份、0/MAX时刻及反向故障分类，断言状态、snapshot和counter不变。当前声明36普通+1 guard，测试尚须实际Linux结果。

三源SHA与候选manifest一致，r1→r2 diff可从封存r1三源精确重建；r1历史manifest/plan/expected原字节保留，Linux状态NOT_RUN不回填为FAIL或PASS。仅纯库模块，没有IPC/authority/writer或硬件接入；不称完整B1。原硬件失败和D15 OPEN/DEFERRED保持。本独审未SSH、UART、编译、测试或修改控制源码。
