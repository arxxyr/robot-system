import datetime
import hashlib
import json
import re
import stat
import tarfile
from pathlib import Path

top = Path('/Users/loosqk/repo/rust/robot-system/target/b1_freshness_integration_2026-10-08')
base = top/'native-r5'
raw = base/'orin-originals'
out = top/'independent_native_r5'

def ref(path):
    data=path.read_bytes()
    return {'path':str(path),'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest(),'mode':stat.S_IMODE(path.stat().st_mode)}

def load(path):
    def pairs(rows):
        result={}
        for k,v in rows:
            assert k not in result
            result[k]=v
        return result
    return json.loads(path.read_text(),object_pairs_hook=pairs)

def check(reference):
    actual=ref(Path(reference['path']))
    for field in ('bytes','sha256','mode'):
        if field in reference: assert actual[field]==reference[field], (field,reference['path'])
    return actual

summary_path=base/'summary.json'
assert ref(summary_path)['sha256']=='ed0491172989729a573a7f81d19f7981efab59483909bb87772bc0db920454b5' and ref(summary_path)['bytes']==152363
summary=load(summary_path)
index_path=top/'native-r5-original-evidence.index.json'
assert ref(index_path)['sha256']=='56bb62fd1ab49db47db45ac731e31acdbe6167a68049c552736121ef61220671'
index=load(index_path)
archive_ref=check(index['archive'])
assert archive_ref['bytes']==10910022 and archive_ref['sha256']=='313d441472e3c3e3bc20f3b2aa5d58b13a7f8ef59b06dba1ccdaad82b2974b1b'
entries={x['name']:x for x in index['files']}
assert len(entries)==len(index['files'])==168
with tarfile.open(archive_ref['path'],'r:gz') as archive:
    members=archive.getmembers()
    assert len(members)==len({m.name for m in members})==168 and {m.name for m in members}==set(entries)
    for member in members:
        assert member.isfile() and not member.name.startswith('/') and '..' not in Path(member.name).parts
        item=entries[member.name]
        data=archive.extractfile(member).read()
        assert len(data)==item['bytes'] and hashlib.sha256(data).hexdigest()==item['sha256'] and member.mode==item['mode']
        original=ref(Path(item['original_path']))
        assert all(original[k]==item[k] for k in ('bytes','sha256','mode'))

expected=load(base/'expected_source.json')
assert len(expected['files'])==596
assert hashlib.sha256(json.dumps(expected['files'],sort_keys=True,separators=(',',':'),ensure_ascii=False).encode()).hexdigest()==expected['source_manifest_sha256']=='b919cd320dd81693ae49612dcd0778b98e6ee97191d2344bdf87cefd69c2eed0'
source_data={}
with tarfile.open(base/'source-inputs.tar.gz','r:gz') as archive:
    members=archive.getmembers()
    assert len(members)==len({m.name for m in members})==596 and {m.name for m in members}==set(expected['files'])
    for member in members:
        assert member.isfile()
        data=archive.extractfile(member).read()
        item=expected['files'][member.name]
        assert len(data)==item['bytes'] and hashlib.sha256(data).hexdigest()==item['sha256'] and bool(member.mode&0o100)==item['executable']
        if member.name in ['crates/robot-s0/src/lib.rs','crates/robot-s0/src/base_ingress/tests.rs','crates/robot-s0/src/post_e_convergence_acceptance.rs','crates/robot-s0/Cargo.toml','Cargo.toml']:
            source_data[member.name]=data.decode()
assert (base/'source-inputs.tar.gz').read_bytes()==(top/'native-r4/source-inputs.tar.gz').read_bytes()

result=load(raw/'result.json')
plan=load(base/'execution_plan.json')
assert result['status']=='PASS' and summary['status']=='PASS_SCOPED_SOFTWARE' and result['deployable']==summary['deployable']==False
assert len(result['receipts'])==len(summary['commands'])==len(plan['child_order'])==18
assert result['interrupted_signal'] is None
rows=[]
prior_end=0
for name,receipt,reported in zip(plan['child_order'],result['receipts'],summary['commands']):
    folder=raw/name
    path=folder/'completion.json'
    assert receipt['path'].endswith('/qa/'+name+'/completion.json') and ref(path)['sha256']==receipt['sha256']
    row=load(path); launch=load(folder/'launch.json')
    assert row['name']==reported['name']==name and row['reaped'] is True and row['exit_code']==0 and row['signals']==[] and not row['budget_exceeded']
    assert 'runner_error' not in row and row['exec_gate_released'] is True and row['session_residual_before_cleanup']==row['session_residual_after_cleanup']==[]
    assert prior_end<=row['started_monotonic_ns']<row['ended_monotonic_ns']<=row['deadline_monotonic_ns']
    prior_end=row['ended_monotonic_ns']
    for field in ['name','argv','cwd','env','started_at','started_monotonic_ns','timeout_seconds','deadline_monotonic_ns','pid','identity','stdout','stderr','bootstrap_argv','bootstrap_sha256']:
        assert launch[field]==row[field]
    assert launch['reaped'] is False and launch['exit_code'] is None
    for stream in ('stdout','stderr'):
        actual=ref(folder/(stream+'.log'))
        assert actual['sha256']==row[stream+'_sha256'] and actual['bytes']==row[stream+'_bytes']
    assert reported['pid']==row['pid'] and reported['argv']==row['argv'] and reported['actual_exit']==0
    rows.append(row)
assert len({r['pid'] for r in rows})==18
windows=sorted(raw.glob('*source*.json'))
assert len(windows)==38 and all(load(p)==expected for p in windows)
compiler=(raw/'rustc_before/stdout.log').read_bytes()
cargo=(raw/'cargo_before/stdout.log').read_bytes()
assert compiler==(raw/'rustc_after/stdout.log').read_bytes() and cargo==(raw/'cargo_after/stdout.log').read_bytes()
assert b'commit-hash: 1d81eb4ad9cd207e3e638bd32b17ec4fce8412a6\n' in compiler and b'host: aarch64-unknown-linux-gnu\n' in compiler
assert rows[2]['argv']==['cargo','+nightly','fmt','--all']
assert rows[3]['argv']==['cargo','+nightly','clippy','--locked','--all','--all-targets','--','-D','warnings']
assert rows[4]['argv']==['cargo','+nightly','clippy','--locked','--all','--all-targets','--features','robot-s0/rt_guard,robot-adapter-feetech/real-hw','--','-D','warnings']

def lists(text):
    result=[]; end=0
    for match in re.finditer(r'^(\d+) tests?, (\d+) benchmarks?\s*$',text,re.M):
        names=re.findall(r'^(.+): test$',text[end:match.start()],re.M)
        assert len(names)==len(set(names))==int(match[1]) and int(match[2])==0
        result.append(names); end=match.end()
    return result

def runs(text):
    result=[]; end=0
    pattern=r'^test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored; (\d+) measured; (\d+) filtered out;.*$'
    for match in re.finditer(pattern,text,re.M):
        methods=re.findall(r'^test (.+) \.\.\. (ok|ignored(?:,.*)?)$',text[end:match.start()],re.M)
        counts=[int(x) for x in match.groups()]
        assert len(methods)==len({n for n,s in methods}) and counts[1]==counts[3]==0
        assert sum(s=='ok' for n,s in methods)==counts[0] and sum(s.startswith('ignored') for n,s in methods)==counts[2]
        result.append({'methods':[{'name':n,'raw_status':s} for n,s in methods],'counts':dict(zip(['passed','failed','ignored','measured','filtered_out'],counts))})
        end=match.end()
    assert result
    return result

dependency=load(base/'dependency_expected_linux_roster_r1.json')
display=load(base/'expected_roster_display_r1.json')
p1c=load(base/'integration_plan_r4.json')['static_method_roster']
core_list=lists((raw/'core_list/stdout.log').read_text())
assert len(core_list)==1 and set(core_list[0])==set(display['core']['list_exact']) and len(core_list[0])==147
core_run=runs((raw/'core_lib/stdout.log').read_text())
assert len(core_run)==1 and set(m['name'] for m in core_run[0]['methods'])==set(display['core']['run_display_exact'])
assert core_run[0]['counts']==dict(passed=147,failed=0,ignored=0,measured=0,filtered_out=0)
assert display['core']['run_display_exact']==dependency['core_default_lib']['Linux_static_expected_exact_methods']
suite_rows={}
for step,key in [('transport_default','transport_default'),('transport_mock','transport_mock_only')]:
    wanted=[s for s in dependency[key]['exact_suite_rosters'] if not s['suite'].startswith('doctest:')]
    got=runs((raw/step/'stdout.log').read_text()); listed=lists((raw/(step+'_list')/'stdout.log').read_text())
    assert len(got)==len(listed)==len(wanted)==9
    identities=set()
    for actual,names,expected_suite in zip(got,listed,wanted):
        expected_methods={(m['name'],m['raw_status']) for m in expected_suite['methods']}
        assert actual['counts']==expected_suite['counts'] and {(m['name'],m['raw_status']) for m in actual['methods']}==expected_methods
        assert set(names)=={m['name'] for m in expected_suite['methods']}
        identities.update((expected_suite['suite'],m['name']) for m in actual['methods'] if m['raw_status']=='ok')
    suite_rows[step]=identities
assert len(suite_rows['transport_default'])==129 and len(suite_rows['transport_mock'])==61
assert suite_rows['transport_mock']<=suite_rows['transport_default']
docs=runs((raw/'transport_doc/stdout.log').read_text())
docrows=[m for s in docs for m in s['methods']]
assert {(m['name'],m['raw_status']) for m in docrows}=={(m['name'],m['raw_status']) for m in dependency['origin_doctest']['exact_methods_default']}
assert sum(s['counts']['passed'] for s in docs)==1 and sum(s['counts']['ignored'] for s in docs)==2
for step,names in [('p1c_default',p1c['default_exact']),('p1c_guard',p1c['rt_guard_exact'])]:
    listed=lists((raw/(step+'_list')/'stdout.log').read_text()); ran=runs((raw/step/'stdout.log').read_text())
    assert len(listed)==len(ran)==1 and set(listed[0])==set(names)=={m['name'] for m in ran[0]['methods']}
    assert ran[0]['counts']['passed']==len(names) and ran[0]['counts']['ignored']==0 and all(m['raw_status']=='ok' for m in ran[0]['methods'])
assert len(p1c['default_exact'])==36 and len(p1c['rt_guard_exact'])==37
assert set(p1c['rt_guard_exact'])-set(p1c['default_exact'])=={p1c['guard_only']}
assert len(suite_rows['transport_default'])+147+len(set(p1c['rt_guard_exact'])|set(p1c['default_exact']))==313
guard_row=next(row for row in rows if row['name']=='p1c_guard')
assert guard_row['argv']==['cargo','+nightly','test','--locked','-p','robot-s0','--lib','--features','rt_guard','base_ingress::tests::','--','--test-threads=1']
lib=source_data['crates/robot-s0/src/lib.rs']; allocator=source_data['crates/robot-s0/src/post_e_convergence_acceptance.rs']; tests=source_data['crates/robot-s0/src/base_ingress/tests.rs']
assert '#[cfg(test)]\nmod post_e_convergence_acceptance;' in lib
assert '#[cfg(feature = "rt_guard")]\n#[global_allocator]\nstatic LIB_TEST_ALLOCATOR: assert_no_alloc::AllocDisabler = assert_no_alloc::AllocDisabler;' in allocator
assert 'rt_guard = ["robot-core/rt_guard", "dep:assert_no_alloc"]' in source_data['crates/robot-s0/Cargo.toml']
guard_name=p1c['guard_only'].rsplit('::',1)[1]
guard=tests.split('fn '+guard_name+'()',1)[1]
assert 'assert_no_alloc::assert_no_alloc(|| {' in guard
guard_calls=['base_ingress::tests::'+n for n in re.findall(r'^\s+(\w+)\(\);$',guard,re.M)]
assert len(guard_calls)==len(set(guard_calls))==36 and set(guard_calls)==set(p1c['default_exact'])

owners=[]
for reported in summary['host_owners']:
    row=load(Path(reported['reference']['path']))
    assert row['reaped'] is True and row['wait_returncode']==0 and row['phase']=='REAPED' and row['status']=='PASS'
    assert row['owner_sent_signals']==[] and row['received_signals']=={} and row['errors']==[]
    check(row['log']); check(row['input'])
    owners.append({'name':reported['name'],'owner_pid':row['owner_pid'],'child_pid':row['pid'],'natural_exit':0})
assert len(owners)==5 and len({o['child_pid'] for o in owners})==5
wait=load(base/'tool_owner_wait.json'); owner=load(base/'orin_composite.owner/result.json')
assert wait['final']['exit_code']==0 and json.loads(wait['final']['output'])==owner
tool_session=wait['initial']['session_id']
precommit=load(base/'precommit_quality_binding.json')
assert ref(base/'precommit_quality_binding.json')['sha256']=='2beec92b45a34d3813b1ff7da962924a40123e22f3db4b82918c4222bae463f7'
assert precommit['status']=='PASS_NATIVE_FMT_THEN_ROOT_CLIPPY_SAME_596' and precommit['source_aggregate']==expected['source_manifest_sha256']
assert precommit['fmt_ended_monotonic_ns']==rows[2]['ended_monotonic_ns']<=precommit['root_clippy_started_monotonic_ns']==rows[3]['started_monotonic_ns']

checked=[]
def walk(value):
    if isinstance(value,dict):
        if isinstance(value.get('path'),str) and 'sha256' in value:
            if value['path'].startswith('/Users/'):
                checked.append(check(value))
            elif not value['path'].startswith('/') and value['path'] in expected['files']:
                item=expected['files'][value['path']]
                assert value['sha256']==item['sha256'] and value['bytes']==item['bytes']
        for child in value.values(): walk(child)
    elif isinstance(value,list):
        for child in value: walk(child)
for value in [summary,precommit,load(base/'parser_preflight_r1.json')]: walk(value)
for version in ('r2','r3','r4'):
    old=load(top/('native-'+version)/'summary.json')
    assert old['status'].startswith('FAIL') and old.get('Rust_test_method_executions',old.get('Rust_method_executions'))==0
assert not summary['NOT_RUN_steps']
summary_after=ref(summary_path)
assert summary_after['sha256']=='ed0491172989729a573a7f81d19f7981efab59483909bb87772bc0db920454b5'

review={
    'schema':'B1_P1ABC_NATIVE_R5_INDEPENDENT_SCOPED_REVIEW',
    'status':'PASS_SCOPED_SOFTWARE_NO_BLOCKER_PENDING_MAIN_INTEGRATION_BINDING',
    'created_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'summary':summary_after,'archive':archive_ref,'original_index':ref(index_path),
    'archive_validation':{'members':168,'all_original_and_member_bytes_sha_mode_equal':True,'typed_reference_checks':len(checked),'typed_reference_unique_paths':len({x['path'] for x in checked}),'history_outside_r5_archive_pinned_and_checked':True},
    'source':{'count':596,'aggregate':expected['source_manifest_sha256'],'source_tar':ref(base/'source-inputs.tar.gz'),'same_r4_tar_bytes':True,'all_member_bytes_sha_exec_equal':True,'native_windows':38,'all_equal':True,'native_git_head':None},
    'quality':{'actual_order':'fmt→root default Clippy→rt_guard+real-hw root Clippy','all_exit_zero_and_zero_warning_gate':True,'precommit_binding':ref(base/'precommit_quality_binding.json'),'future_main_binding':'REQUIRED_AFTER_11_SOURCE_INTEGRATION'},
    'compiler':compiler.decode(),'cargo':cargo.decode(),'compiler_cargo_before_after_bytes_equal':True,
    'method_counts':{'core':147,'core_Mac143_not_added':True,'transport_default_pass':129,'transport_default_original_ignored':2,'transport_mock_pass':61,'transport_mock_subset_overlap':61,'transport_unique_pass':129,'p1c_default_pass':36,'p1c_guard_pass':37,'p1c_unique':37,'different_Rust_methods':313,'doc_compile_fail_separate':1,'doc_original_ignored_separate':2,'trybuild_one_method_eight_nested_cases_not_added':True},
    'actual_roster_validation':'全部5 list与6 run门从原日志重新解析，对各suite精确名称、展示后缀、状态和计数；core运行3条should panic后缀仍严格保留；unknown/重复拒绝门未放宽。',
    'real_allocation_guard':{'actual_method':p1c['guard_only'],'actual_status':'ok','library_test_feature_argv':guard_row['argv'],'module_cfg':'test','allocator_cfg':'rt_guard','allocator_static_line':36,'allocator_source':'crates/robot-s0/src/post_e_convergence_acceptance.rs','allocator_type':'assert_no_alloc::AllocDisabler','guard_calls_all_36_under_closure':True,'claims_limit':'纯模块这些输入和分支的分配保护测试；不外推生产整条RT执行面或WCET'},
    'natural_child_reap':{'native':18,'no_signals_budget_excess_residual':True,'host_owners':owners,'actual_tool_session':tool_session,'actual_tool_exit':0},
    'history':'r1 NOT_RUN、r2/r3 Clippy101和r4名单FAIL/0方法执行均保留；r5为新的严格批次，不称单轮全过。',
    'blockers':[],
    'remaining':['主树11源整合后的596输入绑定与该native预提交质量门复核仍REQUIRED。','未跑完整workspace/release/H2/真实RT或完整B1运行接入；未读取现场FW或执行硬件。','无UART/服务/正式安装/部署/push；旧NEEDS/FAIL、D15 OPEN/DEFERRED、deployable=false保持。'],
    'operations_this_review':{'SSH':0,'Cargo':0,'UART':0,'source_edits':0,'original_evidence_edits':0}
}
(out/'review.json').write_text(json.dumps(review,ensure_ascii=False,indent=2)+'\n')
(out/'review.md').write_text('爸爸，r5 限定软件独审通过，无当前原件阻断；主树整合身份绑定仍待完成。168 原件的封包成员及本机原件 bytes/SHA/mode 全同，596 输入及 38 原生窗口一致，nightly 1d81/Cargo 首尾相同。fmt、根 Clippy、rt_guard+real-hw 组合根 Clippy 按序 exit0；18 原生 child、5 本机监督 child 与真实工具 session 均自然回收。\n\n全部实际 list/run 原日志名单、展示名、状态和计数已重新核对：core147；transport 默认129（原2 ignored保留），mock61全为其子集；P1C默认36、guard37共37不同方法，合计313个不同 Rust 方法。doctest compile_fail1及原2 ignored另列；trybuild一个方法内8个编译子例不加成8个方法。\n\nrt_guard 实际执行了已注册 AllocDisabler 下的新增 guard 方法，其闭包复跑全部36个纯模块方法；这证明该输入/分支范围的分配保护测试，不证明整条生产RT面或WCET。core三条should panic运行展示后缀仍严格核对。\n\nr1未测和r2/r3 Clippy101、r4名单FAIL均保留。主树11源整合后必须核596身份与本native预提交门绑定；未测完整workspace/release/H2/完整B1运行接入或硬件，无UART/部署/push，D15 OPEN/DEFERRED与deployable=false不变。\n')
(out/'index.json').write_text(json.dumps({'schema':'B1_R5_INDEPENDENT_REVIEW_INDEX','files':[ref(out/'review.json'),ref(out/'review.md'),ref(out/'verify.py')],'original_index':ref(index_path),'original_archive':archive_ref},ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'status':review['status'],'files':[ref(out/'review.json'),ref(out/'review.md'),ref(out/'index.json')],'typed_refs':review['archive_validation'],'tool_session':tool_session},ensure_ascii=False,indent=2))
