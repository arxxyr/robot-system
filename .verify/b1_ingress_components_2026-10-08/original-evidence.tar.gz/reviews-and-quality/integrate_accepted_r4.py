"""验收后只整合冻结的十一源；旧值先核，失败恢复，不覆盖其它文件。"""
import importlib.util
import json
import os
import stat
import subprocess
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path('/Users/loosqk/repo/rust/robot-system')
CANDIDATE = Path('/Users/loosqk/.codex/worktrees/b1-freshness-reducer/robot-system')
AREA = ROOT / 'target/b1_freshness_integration_2026-10-08'
spec = importlib.util.spec_from_file_location('artifacts', AREA / 'native-r5/artifacts.py')
a = importlib.util.module_from_spec(spec)
spec.loader.exec_module(a)
require = a.require
plan_path = CANDIDATE / 'target/b1_freshness_reducer/integration_plan_r4.json'
require(a.sha256(plan_path) == '4d9ca3d5ed4e3e9ccf8bf0c896657aa9d26c2abe7964e1cc2624927a598c50d6', '计划变化')
plan = a.strict_json(plan_path.read_text())
expected = a.strict_json((AREA / 'native-r5/expected_source.json').read_text())
require(expected['source_manifest_sha256'] == 'b919cd320dd81693ae49612dcd0778b98e6ee97191d2344bdf87cefd69c2eed0', '组合源码变化')
native = a.strict_json((AREA / 'native-r5/summary.json').read_text())
require(native['status'] == 'PASS_SCOPED_SOFTWARE' and native['source_count'] == 596
        and native['source_aggregate'] == expected['source_manifest_sha256']
        and native['actual_native_child_count'] == 18 and native['NOT_RUN_steps'] == []
        and native['all_requested_native_children_natural_reap_no_signals_no_residual'] is True
        and native['count_policy']['different_Rust_method_pass_total'] == 313,
        '原生软件门或同源身份不同')
children = []


def git(args):
    p = subprocess.Popen(['git', *args], cwd=ROOT, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    out, err = p.communicate()
    children.append({'argv': ['git', *args], 'pid': p.pid, 'exit_code': p.returncode,
                     'real_wait_reap': True, 'stdout': out.decode(), 'stderr': err.decode()})
    require(p.returncode == 0, 'Git 失败')
    return out.decode()


require(git(['rev-parse', 'HEAD']).strip() == 'e6d6d111091b29b791bae0375b209692fdf3eed5', '主树基线不同')
require(git(['status', '--porcelain=v1', '--untracked-files=all']) == '', '主树已有改动')
before_names = git(['ls-files', '-z', '--cached', '--others', '--exclude-standard']).rstrip('\0').split('\0')
before = a.snapshot_source(ROOT, before_names)
require(before == a.strict_json((AREA / 'native-r5/main_source_before.json').read_text()), '591 主树变化')
rows = plan['eleven_source_overlay_preconditions']
require(len(rows) == 11 and not plan['overlap_with_firmware'], '整合集合变化')
backup = AREA / 'root_integration_backup_r1'
backup.mkdir()
payloads = {}
old = {}
for row in rows:
    name = row['path']
    target = ROOT / name
    source = CANDIDATE / name
    require(not target.is_symlink() and not source.is_symlink(), '拒绝符号链接')
    require(source.stat().st_size == row['new_candidate']['bytes'] and a.sha256(source) == row['new_candidate']['sha256'], '候选变化')
    require(bool(source.stat().st_mode & stat.S_IXUSR) == row['new_candidate']['executable'], '候选权限变化')
    payloads[name] = (source.read_bytes(), stat.S_IMODE(source.stat().st_mode))
    if row['action'] == 'CREATE':
        require(not os.path.lexists(target), '新文件已存在')
        old[name] = None
    else:
        require(target.stat().st_size == row['old_main_current']['bytes'] and a.sha256(target) == row['old_main_current']['sha256'], '旧值变化')
        old[name] = (target.read_bytes(), stat.S_IMODE(target.stat().st_mode))
        saved = backup / name
        saved.parent.mkdir(parents=True, exist_ok=True)
        saved.write_bytes(old[name][0])
        saved.chmod(old[name][1])


def replace(path, data, mode):
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_name(path.name + '.p1_integrate_tmp')
    with tmp.open('xb') as f:
        f.write(data)
    tmp.chmod(mode)
    os.replace(tmp, path)


written = []
try:
    for name, (data, mode) in payloads.items():
        replace(ROOT / name, data, mode)
        written.append(name)
    actual_names = git(['ls-files', '-z', '--cached', '--others', '--exclude-standard']).rstrip('\0').split('\0')
    after = a.snapshot_source(ROOT, actual_names)
    require(after == expected and len(after['files']) == 596, '整合后全部输入不同')
    for row in plan['preserve_firmware_seven']:
        require(a.sha256(ROOT / row['path']) == row['sha256'], '固件七源变化')
except BaseException:
    for name in reversed(written):
        if old[name] is None:
            (ROOT / name).unlink()
        else:
            replace(ROOT / name, *old[name])
    raise

receipt = {'schema': 'B1_INGRESS_ROOT_INTEGRATION_R1', 'status': 'PASS_EXACT_ELEVEN_OVERLAYS_SAME_NATIVE_596',
           'created_utc': datetime.now(timezone.utc).isoformat(), 'base_head': 'e6d6d111091b29b791bae0375b209692fdf3eed5',
           'before': before, 'after': after, 'paths': written, 'firmware_seven_preserved': plan['preserve_firmware_seven'],
           'native_summary_sha256': a.sha256(AREA / 'native-r5/summary.json'), 'git_children': children,
           'scope': '仅纯软件来源/参数/状态机；不接运行时或串口，无硬件动作、安装、push'}
with (AREA / 'root_integration_r1.json').open('x') as f:
    json.dump(receipt, f, ensure_ascii=False, indent=2)
    f.write('\n')
print(json.dumps({'status': receipt['status'], 'source_count': 596, 'aggregate': after['source_manifest_sha256']}, ensure_ascii=False))
