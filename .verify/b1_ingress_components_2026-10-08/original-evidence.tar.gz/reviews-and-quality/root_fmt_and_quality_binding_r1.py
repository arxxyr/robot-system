"""主树格式化及596同源复核；绑定本轮Linux已真实执行的fmt→Clippy。"""
import hashlib
import importlib.util
import json
import os
import subprocess
from pathlib import Path

ROOT = Path('/Users/loosqk/repo/rust/robot-system')
AREA = ROOT / 'target/b1_freshness_integration_2026-10-08'
OUT = AREA / 'root_precommit_r1'
OUT.mkdir()
spec = importlib.util.spec_from_file_location('artifacts', AREA / 'native-r5/artifacts.py')
a = importlib.util.module_from_spec(spec)
spec.loader.exec_module(a)
expected = a.strict_json((AREA / 'native-r5/expected_source.json').read_text())
quality_path = AREA / 'native-r5/precommit_quality_binding.json'
quality = a.strict_json(quality_path.read_text())
records = []


def run(name, args):
    with (OUT / (name + '.stdout')).open('xb') as out, (OUT / (name + '.stderr')).open('xb') as err:
        child = subprocess.Popen(args, cwd=ROOT, env={**os.environ, 'RUSTUP_TOOLCHAIN': 'nightly'}, stdout=out, stderr=err)
        code = child.wait()
    records.append({'name': name, 'argv': args, 'pid': child.pid, 'exit_code': code,
                    'real_wait_reap': True, 'stdout': str(OUT / (name + '.stdout')),
                    'stderr': str(OUT / (name + '.stderr'))})
    a.require(code == 0, name + ' 未通过')
    return (OUT / (name + '.stdout')).read_text()


def snapshot(label):
    inventory = run('inventory_' + label, ['git', 'ls-files', '-z', '--cached', '--others', '--exclude-standard']).rstrip('\0').split('\0')
    value = a.snapshot_source(ROOT, inventory)
    a.require(value == expected and len(value['files']) == 596, '主树并非原生同596')
    (OUT / ('source_' + label + '.json')).write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n')
    return value


before = snapshot('before')
compiler = run('rustc_before', ['rustc', '-Vv'])
cargo = run('cargo_before', ['cargo', '-V'])
a.require('commit-hash: 1d81eb4ad9cd207e3e638bd32b17ec4fce8412a6' in compiler
          and '1.101.0-nightly' in cargo, '本机nightly身份不同')
run('fmt', ['cargo', 'fmt', '--all'])
after = snapshot('after')
a.require(run('rustc_after', ['rustc', '-Vv']) == compiler
          and run('cargo_after', ['cargo', '-V']) == cargo, '格式化前后工具链变化')
receipt = {'schema': 'B1_ROOT_PRECOMMIT_QUALITY_BINDING_R1', 'status': 'PASS_MAIN_FMT_SAME_596_AND_ACTUAL_NATIVE_FMT_CLIPPY',
           'main_source_aggregate': after['source_manifest_sha256'], 'main_source_count': 596,
           'actual_main_fmt_exit': 0, 'main_before_after_equal': before == after,
           'compiler_before_after_equal': True, 'compiler': compiler, 'cargo': cargo,
           'native_quality_binding_sha256': hashlib.sha256(quality_path.read_bytes()).hexdigest(),
           'native_actual_quality_binding': quality,
           'native_main_required_binding_now_observed_separately': True, 'children': records,
           'limits': 'Linux实际fmt→根Clippy门来自本轮r5；本机未执行不受支持的S0根Clippy，源未变不重复测试'}
(AREA / 'root_precommit_quality_binding_r1.json').write_text(json.dumps(receipt, ensure_ascii=False, indent=2) + '\n')
print(json.dumps({'status': receipt['status'], 'source_count': 596, 'owned_children': len(records)}, ensure_ascii=False))
