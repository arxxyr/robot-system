"""逐字节核原生原件包；不执行或修改原件。"""
import hashlib
import json
import stat
import tarfile
from pathlib import Path

AREA = Path('/Users/loosqk/repo/rust/robot-system/target/b1_freshness_integration_2026-10-08')
INDEX = AREA / 'native-r5-original-evidence.index.json'
p = json.loads(INDEX.read_text())
rows = {r['name']: r for r in p['files']}
assert len(rows) == len(p['files']) == 168
archive = Path(p['archive']['path'])
assert archive.stat().st_size == p['archive']['bytes']
assert hashlib.sha256(archive.read_bytes()).hexdigest() == p['archive']['sha256']
with tarfile.open(archive, 'r:gz') as t:
    members = t.getmembers()
    assert len(members) == 168 and {m.name for m in members} == set(rows)
    for m in members:
        r = rows[m.name]
        assert m.isfile() and m.size == r['bytes'] and m.mode == r['mode']
        data = t.extractfile(m).read()
        assert hashlib.sha256(data).hexdigest() == r['sha256']
        original = Path(r['original_path'])
        assert stat.S_ISREG(original.lstat().st_mode) and not original.is_symlink()
        assert original.stat().st_size == r['bytes'] and stat.S_IMODE(original.stat().st_mode) == r['mode']
        assert hashlib.sha256(original.read_bytes()).hexdigest() == r['sha256']
receipt = {'status': 'PASS_168_NATIVE_ORIGINAL_MEMBERS_BYTES_SHA_MODE',
           'index_sha256': hashlib.sha256(INDEX.read_bytes()).hexdigest(),
           'archive_sha256': p['archive']['sha256'], 'members': 168}
(AREA / 'root_native_archive_review_r5.json').write_text(json.dumps(receipt, indent=2) + '\n')
print(json.dumps(receipt))
