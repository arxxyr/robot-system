import datetime
import hashlib
import json
import re
import tarfile
from pathlib import Path

main = Path('/Users/loosqk/repo/rust/robot-system')
base = main / 'target/b1_freshness_integration_2026-10-08/native-r4'
raw = base / 'orin-originals'
out = main / 'target/b1_freshness_integration_2026-10-08/independent_r4_roster_failure'

def ref(path):
    data = path.read_bytes()
    return {'path': str(path), 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()}

def load(path):
    def pairs(rows):
        result = {}
        for k, v in rows:
            assert k not in result
            result[k] = v
        return result
    return json.loads(path.read_text(), object_pairs_hook=pairs)

expected = load(base / 'expected_source.json')
assert len(expected['files']) == 596
assert hashlib.sha256(json.dumps(expected['files'],sort_keys=True,separators=(',',':'),ensure_ascii=False,allow_nan=False).encode()).hexdigest() == expected['source_manifest_sha256'] == 'b919cd320dd81693ae49612dcd0778b98e6ee97191d2344bdf87cefd69c2eed0'
with tarfile.open(base/'source-inputs.tar.gz','r:gz') as archive:
    members = archive.getmembers()
    assert len(members) == len({m.name for m in members}) == 596
    assert {m.name for m in members} == set(expected['files'])
    for member in members:
        assert member.isfile() and member.name[0] != '/' and '..' not in Path(member.name).parts
        data = archive.extractfile(member).read()
        wanted = expected['files'][member.name]
        assert len(data) == wanted['bytes'] and hashlib.sha256(data).hexdigest() == wanted['sha256'] and bool(member.mode & 0o100) == wanted['executable']
    rt_guard = archive.extractfile('crates/robot-core/src/rt_guard.rs').read().decode()

result = load(raw/'result.json')
assert result['status'] == 'FAIL' and result['error'] == "ValueError('core_list 实际方法名单不同')" and result['tests'] == {} and result['interrupted_signal'] is None
order = ['rustc_before','cargo_before','fmt','clippy_default','clippy_combined','core_list','rustc_after','cargo_after']
assert len(result['receipts']) == 8
rows = []
prior_end = 0
for name, receipt in zip(order,result['receipts']):
    directory = raw / name
    completion = directory / 'completion.json'
    assert receipt['path'].endswith('/qa/'+name+'/completion.json') and ref(completion)['sha256'] == receipt['sha256']
    row = load(completion)
    launch = load(directory/'launch.json')
    assert row['name'] == name and row['reaped'] is True and row['exit_code'] == 0 and row['signals'] == [] and not row['budget_exceeded']
    assert 'runner_error' not in row and row['exec_gate_released'] is True
    assert row['session_residual_before_cleanup'] == row['session_residual_after_cleanup'] == []
    assert prior_end <= row['started_monotonic_ns'] < row['ended_monotonic_ns'] <= row['deadline_monotonic_ns']
    prior_end = row['ended_monotonic_ns']
    for field in ['name','argv','cwd','env','started_at','started_monotonic_ns','timeout_seconds','deadline_monotonic_ns','pid','identity','stdout','stderr','bootstrap_argv','bootstrap_sha256']:
        assert launch[field] == row[field]
    assert launch['reaped'] is False and launch['exit_code'] is None
    for stream in ('stdout','stderr'):
        actual = ref(directory/(stream+'.log'))
        assert actual['sha256'] == row[stream+'_sha256'] and actual['bytes'] == row[stream+'_bytes']
    rows.append({'name':name,'pid':row['pid'],'argv':row['argv'],'exit':0,'natural_reap_no_signals_no_residual':True,'completion':ref(completion)})
assert len({r['pid'] for r in rows}) == 8
source_windows = sorted(raw.glob('*source*.json'))
assert len(source_windows) == 18 and all(load(path) == expected for path in source_windows)
assert (raw/'rustc_before/stdout.log').read_bytes() == (raw/'rustc_after/stdout.log').read_bytes()
assert (raw/'cargo_before/stdout.log').read_bytes() == (raw/'cargo_after/stdout.log').read_bytes()
compiler = (raw/'rustc_before/stdout.log').read_text()
assert 'commit-hash: 1d81eb4ad9cd207e3e638bd32b17ec4fce8412a6\n' in compiler and 'host: aarch64-unknown-linux-gnu\n' in compiler

dependency_path = base / 'dependency_expected_linux_roster_r1.json'
assert ref(dependency_path)['sha256'] == 'c514af72074a523a84f2fc63e93fbcd7b90e2897b16306f532701811894b177e'
core = load(dependency_path)['core_default_lib']
actual_text = (raw/'core_list/stdout.log').read_text()
actual = re.findall(r'^(.+): test$',actual_text,re.M)
assert re.findall(r'^(\d+) tests, (\d+) benchmarks$',actual_text,re.M) == [('147','0')]
assert len(actual) == len(set(actual)) == 147
original = core['Linux_static_expected_exact_methods']
assert len(original) == len(set(original)) == 147
mapping = [{'actual_list_base': 'rt_guard::tests::'+name, 'original_run_display': 'rt_guard::tests::'+name+' - should panic'} for name in ['guard_cannot_nest','rt_arc_clone_in_scope_panics','rt_arc_drop_in_scope_panics']]
assert set(actual)-set(original) == {x['actual_list_base'] for x in mapping}
assert set(original)-set(actual) == {x['original_run_display'] for x in mapping}
corrected = [(next((x['actual_list_base'] for x in mapping if x['original_run_display']==name),name)) for name in original]
assert set(corrected) == set(actual) and len(corrected) == 147
assert set(core['Linux_only_four']) <= set(actual)
panic_expectations = ['already in RT scope','RtArc::clone called inside RT scope','RtArc::drop called inside RT scope']
for entry, panic in zip(mapping,panic_expectations):
    name = entry['actual_list_base'].rsplit('::',1)[1]
    assert '#[should_panic(expected = "'+panic+'")]\n    fn '+name+'()' in rt_guard
    entry['source_should_panic_expected'] = panic

owner = load(base/'orin_composite.owner/result.json')
assert owner['phase']=='REAPED' and owner['status']=='FAIL' and owner['wait_returncode']==1 and owner['reaped'] is True
assert owner['owner_sent_signals']==[] and owner['received_signals']=={} and owner['errors']==[]
assert owner['log']['sha256']==ref(base/'orin_composite.owner/child.log')['sha256']
wait = load(base/'tool_owner_wait.json')
assert wait['initial']['session_id']==14072 and wait['final']['exit_code']==1
assert json.loads(wait['final']['output'])==owner
plan=load(base/'execution_plan.json')
not_run=[name for name in plan['child_order'] if name not in order]
assert len(not_run)==10 and all(not (raw/name).exists() for name in not_run)

review = {
    'schema':'B1_P1ABC_R4_ROSTER_FAILURE_INDEPENDENT_REVIEW',
    'status':'PASS_FAILURE_DIAGNOSIS_ORIGINAL_R4_FAIL_PRESERVED',
    'created_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'native_result':ref(raw/'result.json'),
    'original_batch_status':'FAIL_CORE_LIST_EXPECTED_FIXTURE_DISPLAY_NAME_MISMATCH',
    'original_expected_roster':ref(dependency_path),
    'actual_core_list':ref(raw/'core_list/stdout.log'),
    'counts':{'actual_unique':147,'expected_unique':147,'duplicates':0,'benchmarks':0,'actual_Rust_method_executions':0},
    'exact_difference_and_limited_correction':mapping,
    'linux_only_four_all_present':core['Linux_only_four'],
    'diagnosis':'差集仅3条运行展示名的should panic后缀；真实list基名与源码定义一致，panic expected断言仍完整。不是缺方法/少计数/未知不同。',
    'correction_boundary':'r5只能将这3条list基名和原运行展示名分别严格比较；运行原后缀仍必需，147与原忽略/所有断言/预算保持。r4原件与FAIL不得改为PASS。',
    'native_quality_actual':'fmt→根Clippy→rt_guard+real-hw组合根Clippy均真实exit0顺序完成；这里只确认质量门，不称测试PASS。',
    'native_children':rows,
    'source_binding':{'count':596,'aggregate':expected['source_manifest_sha256'],'source_archive':ref(base/'source-inputs.tar.gz'),'all_archive_members_bytes_sha_exec_match':True,'source_windows':18,'all_windows_exact':True,'expected_manifest':ref(base/'expected_source.json')},
    'compiler':compiler,
    'cargo':(raw/'cargo_before/stdout.log').read_text(),
    'compiler_cargo_before_after_bytes_equal':True,
    'local_orin_owner':ref(base/'orin_composite.owner/result.json'),
    'tool_owner_wait':ref(base/'tool_owner_wait.json'),
    'tool_session_real_final':{'id':14072,'exit':1},
    'not_run':not_run,
    'blockers':['本r4整体FAIL；修正新批次实际QA结果另验，本报告不赋予软件阶段PASS。'],
    'limits':['同596源码未修改；只本机原件读取和旁附件写入，无SSH/Cargo/UART。','非完整workspace/release/H2/完整B1或硬件门；旧NEEDS/FAIL、D15 OPEN/DEFERRED、deployable=false保持。'],
    'review_operations':{'SSH':0,'Cargo':0,'UART':0,'source_edits':0,'old_evidence_edits':0}
}
(out/'review.json').write_text(json.dumps(review,ensure_ascii=False,indent=2)+'\n')
(out/'review.md').write_text('爸爸，r4 名单失败原因已由原件独核：实际与预期均 147 个不同方法、0 benchmark，唯一差集是三个 rt_guard should_panic 方法的运行展示后缀。Linux 线程四项全部在实际名单中；冻结源保留三条 expected panic 断言。\n\n允许的修正仅把三个 --list 基名和运行原展示名分开严格比较，数量、忽略、断言与预算保持。r4 仍为原 FAIL，未执行任何 Rust 测试，后续 10 门 NOT_RUN。\n\n8 个实际原生 child 全部自然 exit0/wait/reap、无信号或残留；fmt、根 Clippy、组合 Clippy 按序通过。18 源窗口与冻结 tar 596 输入 bytes/SHA/可执行位全部相同，聚合 b919cd32；nightly 1d81 与 Cargo 首尾字节相同。本地 SSH owner 与工具 session 14072 实际 exit1/reap，不能由子门 exit0 覆盖整体失败。\n\n此独审只记录失败诊断，r5 实际验收另核；未执行 SSH/Cargo/UART 或改源码/原件。旧硬件 FAIL、D15 OPEN/DEFERRED、deployable=false 不变。\n')
(out/'index.json').write_text(json.dumps({'schema':'B1_R4_ROSTER_FAILURE_REVIEW_INDEX','files':[ref(out/'review.json'),ref(out/'review.md'),ref(out/'verify.py')]},ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'status':review['status'],'files':[ref(out/'review.json'),ref(out/'review.md'),ref(out/'index.json')],'exact_delta':mapping},ensure_ascii=False,indent=2))
