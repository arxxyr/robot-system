爸爸，r4 名单失败原因已由原件独核：实际与预期均 147 个不同方法、0 benchmark，唯一差集是三个 rt_guard should_panic 方法的运行展示后缀。Linux 线程四项全部在实际名单中；冻结源保留三条 expected panic 断言。

允许的修正仅把三个 --list 基名和运行原展示名分开严格比较，数量、忽略、断言与预算保持。r4 仍为原 FAIL，未执行任何 Rust 测试，后续 10 门 NOT_RUN。

8 个实际原生 child 全部自然 exit0/wait/reap、无信号或残留；fmt、根 Clippy、组合 Clippy 按序通过。18 源窗口与冻结 tar 596 输入 bytes/SHA/可执行位全部相同，聚合 b919cd32；nightly 1d81 与 Cargo 首尾字节相同。本地 SSH owner 与工具 session 14072 实际 exit1/reap，不能由子门 exit0 覆盖整体失败。

此独审只记录失败诊断，r5 实际验收另核；未执行 SSH/Cargo/UART 或改源码/原件。旧硬件 FAIL、D15 OPEN/DEFERRED、deployable=false 不变。
