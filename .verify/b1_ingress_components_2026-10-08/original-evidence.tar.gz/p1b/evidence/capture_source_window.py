import hashlib
import importlib.util
import json
import os
from pathlib import Path
import subprocess
import signal
import sys
import time

sys.dont_write_bytecode = True
BASE = Path(__file__).resolve().parents[2]
LABEL = sys.argv[1]
if LABEL not in ("after_fmt", "after_all_cargo"):
    raise SystemExit("只接受已批准的前后窗口")
OUT = BASE / "target/wheel_velocity_profile/native_qa_r1/supplementary" / LABEL
OUT.mkdir(parents=True, exist_ok=False)
TARGET = BASE / "target/wheel_velocity_profile/cargo-target"
REQUESTS = []
def stop_request(signum, _frame):
    REQUESTS.append(signum)
for name in ("SIGINT", "SIGTERM", "SIGHUP", "SIGQUIT"):
    if hasattr(signal, name):
        signal.signal(getattr(signal, name), stop_request)

def save(path, value):
    with path.open("x", encoding="utf-8") as stream:
        json.dump(value, stream, ensure_ascii=False, indent=2)
        stream.write("\n")

def run(name, argv):
    if REQUESTS:
        raise RuntimeError("已收到停止请求，不再启动后续child")
    started = time.monotonic_ns()
    errors = []
    with (OUT / (name + ".stdout")).open("xb") as stdout, (OUT / (name + ".stderr")).open("xb") as stderr:
        child = subprocess.Popen(argv, cwd=BASE, stdout=stdout, stderr=stderr)
        while True:
            try:
                code = child.wait(timeout=0.5)
                break
            except subprocess.TimeoutExpired:
                continue
            except BaseException as error:
                errors.append(repr(error))
                continue
    row = {"argv": argv, "pid": child.pid, "owner_pid": os.getpid(), "exit_code": code, "wait_reaped": child.returncode is not None, "started_monotonic_ns": started, "ended_monotonic_ns": time.monotonic_ns(), "wait_errors": errors, "signal_requests": list(REQUESTS)}
    for channel in ("stdout", "stderr"):
        raw = (OUT / (name + "." + channel)).read_bytes()
        row[channel] = {"sha256": hashlib.sha256(raw).hexdigest(), "bytes": len(raw)}
    save(OUT / (name + ".json"), row)
    if code != 0 or errors or REQUESTS:
        raise RuntimeError(name + "未自然成功")
    return (OUT / (name + ".stdout")).read_bytes()

inventory_raw = run("git_inventory", ["git", "ls-files", "--cached", "--others", "--exclude-standard", "-z"])
inventory = [row.decode("utf-8") for row in inventory_raw.split(b"\0") if row]
head = run("git_head", ["git", "rev-parse", "HEAD"]).decode().strip()
status = run("git_status", ["git", "status", "--porcelain=v1", "-z"]).decode()
branch = run("git_branch", ["git", "symbolic-ref", "--short", "HEAD"]).decode().strip()
compiler = run("rustc_identity", ["rustc", "+nightly", "-Vv"]).decode()
cargo = run("cargo_identity", ["cargo", "+nightly", "-V"]).decode()
helper = BASE / "scripts/post_e_h2_artifacts.py"
spec = importlib.util.spec_from_file_location("local_post_e_h2_artifacts", helper)
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)
source = module.snapshot_source(BASE, inventory)
save(OUT / "source_snapshot.json", source)
expected_new = ("crates/robot-core/src/wheel_velocity_profile.rs",)
if not all(name in source["files"] for name in expected_new):
    raise RuntimeError("新增两源未纳入全量编译输入")
keys = ("RUSTUP_TOOLCHAIN", "CARGO_BUILD_TARGET", "CARGO_BUILD_JOBS", "CARGO_TERM_COLOR", "RUSTC", "RUSTC_WRAPPER", "RUSTC_WORKSPACE_WRAPPER", "RUSTFLAGS", "CARGO_ENCODED_RUSTFLAGS", "RUSTDOCFLAGS")
env = {key: {"present": key in os.environ, "nonempty": bool(os.environ.get(key)), "sha256": hashlib.sha256(os.environ[key].encode()).hexdigest() if key in os.environ else None} for key in keys}
# 仅列构建开关的存在和摘要，避免输出任何代理凭据或完整环境。
save(OUT / "binding.json", {"label": LABEL, "root": str(BASE), "head": head, "branch": branch, "status_entries": [row for row in status.split("\0") if row], "inventory_count": len(inventory), "input_count": len(source["files"]), "source_manifest_sha256": source["source_manifest_sha256"], "snapshot_helper": {"path": str(helper), "sha256": hashlib.sha256(helper.read_bytes()).hexdigest(), "bytes": helper.stat().st_size}, "target": str(TARGET), "toolchain_selection": "+nightly argv（浮动工具链）", "compiler": compiler, "cargo": cargo, "inherited_build_environment": env, "additional_environment": {"CARGO_TARGET_DIR": str(TARGET)}, "scope": "补充完整性记录，不新增测试计数"})
print(json.dumps({"label": LABEL, "input_count": len(source["files"]), "source_manifest_sha256": source["source_manifest_sha256"], "binding": str(OUT / "binding.json")}))
