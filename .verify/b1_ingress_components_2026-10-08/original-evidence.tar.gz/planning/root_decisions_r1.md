爸爸，root 已批准绝对期限写入的函数级合同，当前暂不实施；原方案保持原字节。

新 bus 入口必须安装真实 probe，仅允许 NormalEffectful/PeriodicWrite；新增第11原因 NoAuthorityProbe，按 InvalidParameter 和固定 diag reason11 分类。原固件/诊断寄存器拒写优先级不变。

零 write 尝试的来源/调用期限失败按 PendingDeadline；实际尝试、partial、时钟回退和 IO 按 IoWrite；能力、溢出、错误 class、无 probe 按 InvalidParameter。kind9 记录明确原因与进度，原0..8不变，完整 wanted/got/期限仍在原错误。

来源及调用期限相等即失败；timeout安装后再查，全部返回却晚到也失败，不整帧重放，不宣称内核硬期限或字节撤回。

已批准 lib test 唯一 AllocDisabler＋固定夹具直接守生产共享核心，并复验完整 lib；生产及其它 test 二进制不变。本组件无缓存/重发，真实 S0/P1C pending 撤权和 fresh barrier 留后包，不接 SerialTick。

原24个拟议oracle另加无probe前置拒绝一项，合计25项待实现/待运行。完整 parent 消息转录和原方案 pins 见 [决策记录](/Users/loosqk/repo/rust/robot-system/target/b1_freshness_integration_2026-10-08/root_decisions_r1.json)。
