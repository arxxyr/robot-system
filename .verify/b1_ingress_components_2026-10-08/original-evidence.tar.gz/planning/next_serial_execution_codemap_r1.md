爸爸，当前底盘速度尚未进入串口：`FeetechAdapter::write_command` 的非 Position 分支直接返回 Ok，Velocity 只有诊断。此文件是静态 CodeMap 与函数计划，未实施、未编译、未触串口。

主树 `e6d6d111091b29b791bae0375b209692fdf3eed5`、591 输入聚合 `ddad9513566f51fecf915ac7f39e0cccc66b8ae93732847b70ac7c0315458294` 本次逐项复核，24 个引用文件首尾同 SHA/bytes、主树 clean。P1C r4 仍在独立候选；Linux 验证由 native 另包负责。

| 接缝 | 现有事实 | 下一步必要合同 |
| --- | --- | --- |
| 唯一 UART writer | `s0_daemon::prepare_execution` 先建同域 authority/probe，adapter 按值移入一个 serial worker | 同一右 USB 的右臂和底盘不能另开两个实例；跨实例排他与具名子集仍待 root 定案 |
| 实际 Velocity TX | `adapter.rs:575` 非 Position 无 TX | 固定 Front8/Left7/Right9，三轮全检查后固定数组 `_into`，旧 Position 不变 |
| 截止时间 | `serial_tick.rs:583` 传给 probe 的 min 期限仅约束 checkpoint/liveness；`transport.rs:137` 每调用另起相对期限 | 显式借用来源绝对期限，首字节和每次 partial write 前检查；已写字节不能撤回，不自动重放整帧 |
| Profile 与连接 | `velocity_profile.rs:143` 是纯值检查，没有 USB/连接代次或 authority | 当前唯一 writer 同连接的三轮只读身份＋指定实际固件/完整 Phase 合同，连接变化撤销 |
| 零速先于 Enable | `adapter.rs:640` 普通 Enable 是全关节位置同步后启扭 | 当前 EnableExecution/EnableStep 下三轮零写＋真实读回，关联 ticket/session；零 ACK 后 fresh HB+cmd 到 Ready，真实启扭及原 authority commit 后才 Active |
| 停止 | 原 Safety→TorqueDisable 单广播→独立 Confirm | 原快路径和故障收敛保留；normal Motion 期限不可中断 Safety/Confirm |

Profile 规定 Front8/Left7/Right9。历史 Phase12 的 bit3=1，零表示最高速度的合同会被明确拒绝；现场 Firmware 尚未读取，Phase 未改，不能填默认白名单或提前启扭。Firmware 地址0/1两个原始字节也不等于厂家资料版本字段。

数值接口必须统一：profile 返回已编码 `u16`，既有 bus `_into` 接收 signed `i32` 并再次编码。计划可在全部三轮检查后通过 `decode_velocity_word(word).signed_raw` 进入既有编码，不能把负速度 word 直接 cast 成正整数。反馈目前仍是 raw as f32，SI 反馈另需同 profile 转换。

Root 有四项实质决策：共享物理 writer 的执行范围、真实连接观察的 owner、原 Enable owner 下有界分阶段零准备桥、来源期限中途到期时 partial TX 的分类和停止责任。单整体 `JointCommandView.mode` 与当前同步 Enable 不能默认拼成臂 Position＋轮 Velocity 的混合流程。

建议先把“明确绝对期限的串口 partial-write 合同”作为软件小件，聚焦 `transport.rs`、`bus.rs` 与 `post_e_transport_acceptance.rs` 的 `PartialPort` fixture；公开 trait 兼容影响和调用域先由 root 定案。组件通过后，仍须完成 session/profile、三轮零速及 Enable receipt、P1C 真实 IPC/生命周期接入，才能验收完整 B1。

可复用夹具包括 adapter MockHandle 的 ACK/read/golden frame、PartialPort 时钟及进度、LeaseTransport 的原 authority、SerialTick RecordingAdapter、S0 TickFixture 的原 Enable owner 与停止补偿。每个夹具的现有方法和新增正负 oracle 在 JSON 逐项列出，均未重跑。真实 noalloc 应复用 S0 lib rt_guard 或 feetech `abort_diagnostics` 的既有全局 AllocDisabler；Feetech lib 单测仅有 assert_no_alloc 名称，未注册该全局 allocator，不能单凭名称当成捕获证明。

该静态计划不关闭硬件失败、D15 OPEN/DEFERRED、底盘动作 DEFERRED 或 deployable=false。源 pins、完整证据路径、必要 API 和未验证边界见 [JSON](/Users/loosqk/repo/rust/robot-system/target/b1_freshness_integration_2026-10-08/next_serial_execution_codemap_r1.json)。
