# 仅产出静态方案与来源绑定，不实现或验证任何新Rust代码。
import hashlib
import json
from pathlib import Path
import subprocess
from datetime import datetime, timezone

main=Path('/Users/loosqk/repo/rust/robot-system')
out=main/'target/b1_freshness_integration_2026-10-08'
json_path=out/'absolute_write_plan_r1.json'
md_path=out/'absolute_write_plan_r1.md'
if json_path.exists() or md_path.exists():
    raise SystemExit('拒绝覆盖已有方案')
def pin(p):
    raw=p.read_bytes()
    return {'path':str(p),'sha256':hashlib.sha256(raw).hexdigest(),'bytes':len(raw)}
def now():
    return datetime.now(timezone.utc).isoformat()
children=[]
def git(args):
    start=now(); p=subprocess.Popen(['git',*args],cwd=main,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
    stdout,stderr=p.communicate()
    children.append({'argv':['git',*args],'pid':p.pid,'started_at':start,'ended_at':now(),
                     'returncode':p.returncode,'wait_reap':True,'stdout':stdout.decode(),'stderr':stderr.decode()})
    assert p.returncode==0
    return stdout.decode().strip()
head=git(['rev-parse','HEAD']); status=git(['status','--porcelain=v1'])
assert head=='e6d6d111091b29b791bae0375b209692fdf3eed5' and not status
source_path=out/'native-r4/main_source_before.json'
source=json.loads(source_path.read_text())
assert len(source['files'])==591
for rel,exp in source['files'].items():
    actual=pin(main/rel)
    assert actual['sha256']==exp['sha256'] and actual['bytes']==exp['bytes'],rel
paths=[
 'crates/robot-adapters/feetech/src/transport.rs','crates/robot-adapters/feetech/src/bus.rs',
 'crates/robot-adapters/feetech/src/error.rs','crates/robot-adapters/feetech/src/diagnostic.rs',
 'crates/robot-adapters/feetech/src/adapter.rs','crates/robot-adapters/feetech/src/lib.rs',
 'crates/robot-adapters/feetech/src/post_e_transport_acceptance.rs',
 'crates/robot-adapters/feetech/tests/comm_fault_transport.rs',
 'crates/robot-adapters/feetech/tests/abort_diagnostics.rs',
 'crates/robot-s0/src/post_e_diag_acceptance.rs','crates/robot-tests/src/comm_fault/hardware.rs',
 'crates/robot-core/src/time.rs','crates/robot-core/src/serial_services.rs',
 'crates/robot-s0/src/serial_tick.rs','crates/robot-s0/src/serial_preempt.rs',
 'crates/robot-s0/src/serial_convergence.rs','crates/robot-adapters/feetech/Cargo.toml',
]
pins={rel:pin(main/rel) for rel in paths}
serialport=Path('/Users/loosqk/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/serialport-4.10.0/src/lib.rs')

def ref(path,line,function):
    return {'path':str(main/path),'line':line,'function':function,'sha256':pins[path]['sha256']}

implementations=[
 {'type':'MockTransport','file':'crates/robot-adapters/feetech/src/transport.rs','line':269,'cfg':'默认与real-hw均可用',
  'plan':'继承新增默认明确拒绝；旧mock的Vec/Mutex TX log 不自动获得绝对期限能力。新增正向夹具另外显式实现。'},
 {'type':'RealSerialTransport','file':'crates/robot-adapters/feetech/src/transport.rs','line':449,'cfg':'real-hw',
  'plan':'显式override新方法，借context.clock而非假定self.clock同源；本次调用预算仍取self.call_timeout，与来源绝对期限min。旧write_all/read_exact/set_timeout不变。'},
 {'type':'LeaseTransport','file':'crates/robot-adapters/feetech/tests/comm_fault_transport.rs','line':176,'cfg':'独立test二进制',
  'plan':'旧fixture继承默认拒绝，现有lease/response断言不变。新期限bus oracle使用显式支持的固定缓冲fixture，禁止旧write_all fallback。'},
 {'type':'ObservedTransport','file':'crates/robot-adapters/feetech/tests/abort_diagnostics.rs','line':154,'cfg':'独立test二进制',
  'plan':'旧错误脚本继承默认拒绝，不增加隐式TX。新错误映射/默认拒绝oracle可复用既有真实allocator。'},
 {'type':'ScriptedTransport','file':'crates/robot-s0/src/post_e_diag_acceptance.rs','line':136,'cfg':'S0 lib cfg(test)',
  'plan':'继承默认拒绝；原诊断脚本的每个TX/RX序列不改。本组件不接SerialTick。'},
 {'type':'MeasuredTransport<T>','file':'crates/robot-tests/src/comm_fault/hardware.rs','line':159,'cfg':'测量工具模块',
  'plan':'继承默认拒绝，不能默认把新入口转发为inner.write_all；本轮不扩测量工具记录语义。未来显式支持只能转发原context到inner的新方法，需独立验证时间/进度记录。'},
]

api={
 'context':{
  'module':'robot_adapter_feetech::transport',
  'declaration':'pub struct SourceWriteDeadline<\'clock> { clock: &\'clock dyn RobotClock, source_deadline: Deadline }',
  'construct':'pub const fn new(clock: &\'clock dyn RobotClock, source_deadline: Deadline) -> Self',
  'fields':'私有；可只读借clock及取原source_deadline，无Default、无从relative timeout构造、无续期/clock替换setter、无Arc所有权。',
  'meaning':'只绑定显式借用的单调时基与原来源绝对期限，不授予authority、不证明来源认证、也不验证两个不同Clock实例物理同源。调用方必须从该clock的同一时基生成期限。'},
 'trait_method':{
  'signature':'fn write_all_until(&mut self, buf: &[u8], deadline: SourceWriteDeadline<\'_>) -> Result<(), FeetechError>',
  'default':'立即Err(AbsoluteWriteFailure{reason:Unsupported,wanted:buf.len(),got:0,source_deadline:原值,call_deadline:None,observed_at:None,write_attempted:false})；即使empty也不返回成功；不调用旧write_all、不set_timeout、不IO。',
  'compatibility':'新增带body方法，不新增trait泛型或required associated type；预期现有6实现可继续编译且dyn SerialTransport对象安全。此为静态方案，需Linux编译确认，不记PASS。'},
 'shared_private_core':{
  'signature':'fn write_all_until_bounded<P: Write + DeadlinePortTimeout + ?Sized>(port: &mut P, deadline: SourceWriteDeadline<\'_>, call_budget: Duration, buf: &[u8]) -> Result<(), FeetechError>',
  'timeout_shim':'新私有DeadlinePortTimeout::apply_timeout_kind(Duration)->Result<(),io::ErrorKind>；real直接按serialport ErrorKind映射NoDevice→NotFound/InvalidInput→InvalidInput/Unknown→Other/Io(kind)→kind，不to_string，不构造新io::Error。旧SerialPortTimeout及其旧错误行为不改。',
  'reason':'旧apply_timeout桥在错误路径error.to_string会新增分配；新路径使用固定错误原因。serialport错误自身含String，外部backend是否先分配另有明确限界。'},
 'bus':{
  'signature':'pub fn sync_write_by_id_into_until(&mut self, reg_name: &\'static str, entries: &[(u8,i32)], frame_buf: &mut [u8], deadline: SourceWriteDeadline<\'_>) -> Result<(), FeetechError>',
  'meaning':'显式opt-in具名预分配broadcast写；原诊断/固件只读寄存器拒写优先于参数检查，原signed i32编码及MAX_JOINTS/帧容量边界不变。无response/ACK承诺，不改变旧_into方法。',
  'class_proposal':'只允许NormalEffectful或PeriodicWrite；Safety/Confirm/Connect/PeriodicRead新入口明确InvalidOperationClass拒绝，旧API保持原行为。该class约束需root定案。',
  'normal_lease':'Some(preempt)保原begin_leased/finish_leased；None仍是现有泛型bus无authority模式，不冒称运行权限。本组件不引入默认认证，生产wheel后续必须安装真实probe。若root要新bus入口强制Some，需另加NoAuthorityProbe错误，不静默假设。'},
 'lease_method':{
  'signature':'BusTransactionLease::write_until<T:SerialTransport>(&self, transport:&mut T, buf:&[u8], deadline:SourceWriteDeadline<\'_>)->Result<(),FeetechError>',
  'sequence':'持有同一已有lease→transport.write_all_until→返回原Result→若有probe恰一次checkpoint→同一RAII Drop恰一次finish_leased。事务中不重复申请、不先drop租约、不用checkpoint替代授权；失败也保原checkpoint时序。'},
}

reasons=[
 {'reason':'Unsupported','fields':'固定原因，无动态文案','comm_kind':'None','robot_error':'InvalidParameter(静态字符串：绝对期限写入不受支持)','diagnostic_reason':1},
 {'reason':'SourceExpired','fields':'原source_deadline/call_deadline/observed_at,wanted/got,write_attempted',
  'comm_kind':'无write尝试且got=0→PendingDeadline；已有write尝试或got>0→IoWrite','robot_error':'Comm(上述明确类别)','diagnostic_reason':2},
 {'reason':'CallBudgetExpired','fields':'同上','comm_kind':'无write尝试且got=0→PendingDeadline；已有write尝试或got>0→IoWrite','robot_error':'Comm(上述明确类别)','diagnostic_reason':3},
 {'reason':'ClockRegressed','fields':'observed_at和前一时刻的固定值；保wanted/got','comm_kind':'IoWrite','robot_error':'Comm(IoWrite)','diagnostic_reason':4},
 {'reason':'BudgetOverflow','fields':'Duration纳秒超u64或start.checked_add溢出；未TX','comm_kind':'None','robot_error':'InvalidParameter(静态字符串：写入预算不可表示)','diagnostic_reason':5},
 {'reason':'TimeoutConfiguration{kind:io::ErrorKind}','fields':'固定kind,wanted/got,write_attempted；无io::Error/String所有权','comm_kind':'IoWrite','robot_error':'Comm(IoWrite)','diagnostic_reason':6},
 {'reason':'WriteZero','fields':'wanted/got与期限原值；write_attempted=true','comm_kind':'IoWrite','robot_error':'Comm(IoWrite)','diagnostic_reason':7},
 {'reason':'WriteIo{kind:io::ErrorKind}','fields':'固定kind,wanted/got与期限；write_attempted=true','comm_kind':'IoWrite','robot_error':'Comm(IoWrite)','diagnostic_reason':8},
 {'reason':'InvalidOperationClass{class:BusOpClass}','fields':'固定class，未申请lease/未TX','comm_kind':'None','robot_error':'InvalidParameter(静态字符串：来源期限仅用于普通写入)','diagnostic_reason':9},
 {'reason':'InvalidWriteCount{reported:usize}','fields':'恶意/损坏Write实现count>remaining；got不按此无效值递增，不伪报真实进度','comm_kind':'IoWrite','robot_error':'Comm(IoWrite)','diagnostic_reason':10},
]
error_plan={
 'new_types':'公开Copy/Debug原因及固定metadata结构；FeetechError新增AbsoluteWriteFailure(固定结构)。结构wanted/got为usize全量，不截断；source_deadline必有，call_deadline/observed_at可Option；write_attempted bool。ClockRegressed可附previous_at；无Vec/Box/String/io::Error动态所有权。',
 'reasons':reasons,
 'mapping_required':[ref('crates/robot-adapters/feetech/src/error.rs',180,'FeetechError::comm_kind'),
                     ref('crates/robot-adapters/feetech/src/error.rs',203,'From<FeetechError> for RobotError'),
                     ref('crates/robot-adapters/feetech/src/diagnostic.rs',29,'FeetechDiagnostic::classify'),
                     ref('crates/robot-adapters/feetech/src/diagnostic.rs',82,'FeetechDiagnostic::encode')],
 'strictness':'新增原因在comm_kind/From/classify中显式穷尽match；不能被原comm_kind的_=>None吞掉；不以Unknown代替已知原因。原全部FeetechError类别/编码不变。',
 'diagnostic_proposal':'新增固定AbsoluteWrite diagnostic；建议(kind=9,a=原因1..10,b=进度0未write尝试/1尝试但got0/2partial/3complete)。原kind0..8不改；此新局部诊断编码须root确认。完整wanted/got/期限保留在原错误，现DiagEvent容量不能无损保存任意usize两长度，不能宣称日志保留了全部进度。',
 'mapping_boundary':'RobotError固定现有类别不能容纳完整错误metadata；在转换前调用方必须保原结果/独立事实记录。本组件只提供error转换及分类，不改diag wire或生产adapter记录入口。',
 'trust_policy':'建议无尝试的本地期限是PendingDeadline，保持clears_trust=false；实际write尝试/部分TX及IO问题是IoWrite→clears_trust=true。错误仍触发原fault/停止责任，capability/参数失败走AdapterErr。须root定案。',
}

algorithm=[
 '仅Real显式支持；未知trait默认先拒，不读取clock或触IO。支持核心只用deadline.clock显式借用，旧self.clock不混作deadline时基。',
 '支持核心入口取start=clock.now；首先now>=source_deadline拒；call_budget.as_nanos用checked u64转换，start.checked_add得固定call_deadline，溢出拒，budget0由call期限门拒。绝不saturating延长窗口。',
 '有效empty输入在上述来源/预算检查之后Ok，无timeout安装/无Write。expired empty拒；unsupported empty仍Unsupported。',
 'got=0,last_observed=start,write_attempted=false；固定局部状态。每次attempt的now若<last_observed→ClockRegressed；先检查now>=source_deadline，再检查now>=call_deadline。两个期限同时到期固定SourceExpired优先。',
 'remaining_ns=min(source_deadline,call_deadline)-now；给native apply_timeout_kind(Duration::from_nanos(remaining_ns))。不修改self.call_timeout，不把来源转换成后续新起点。timeout安装失败保got，返回固定TimeoutConfiguration。',
 'timeout安装返回后再次读同clock，检测回退和期限；安装过程中已到期则不发Write。随后write_attempted=true，调用port.write(&buf[got..])，只发送未写前缀之外的remaining slice，不flush。',
 'Ok(count>0)先检查count<=buf.len()-got，合法才got+=count；Ok(0)→WriteZero；Interrupted/WouldBlock/TimedOut只在原两期限内进入下一loop；其它错误→WriteIo(kind)，保已知got。不重新发整帧。',
 '每个native Write返回后读clock，回退/到期立即返回相应固定错误，got可等wanted，不能因全部返回就忽略晚到期。完成严格要求now<source及now<call；等号FAIL。',
 '每次尝试的timeout取设置时观测的两个期限min剩余值，且Write前另做期限检查。最终clock读与内核write之间仍有不可原子化窗口，serialport是相对timeout接口：不宣称已经发送字节可撤回、OS硬期限或foreign backend绝不超时。若调用返回晚，完整got也保持FAIL。',
 '不添加新的无界registry、任务、IPC、Arc clone/drop、heap buffer或日志格式化。瞬态错误循环由绝对期限限制，依赖RobotClock单调推进；无额外自创重试阈值，不声称任意恶意不推进clock下的WCET。',
]

bus_order=[
 'ensure_not_diagnostic_write→ensure_not_firmware_readonly_write→get_register→MAX_JOINTS/encoded value/frame容量检查→固定栈build_sync_write。保原拒写优先级，无partial编码TX。',
 '已知frame字节数后校验新入口允许的op_class与source时刻；过期前置返回wanted=frame_len/got0，无lease、无checkpoint、无TX。',
 '申请一次真实原lease；若revoked/emergency直接保原FeetechError::Aborted，不伪造期限失败。申请耗时可跨source期限，transport新方法必须重新读时拒，lease仍通过RAII归还。',
 'lease.write_until透传同deadline context；transport未实现返回Unsupported，不fallback旧方法。所有正常Result后checkpoint一次，lease在Err/Ok路径都Drop回收；不读broadcast ACK。',
 '新API只声明该显式调用的写入合同，不扫描/改变已有bus op_class调用者，不自动接serialTick、Velocity、Enable、Position或Safety。',
]

oracles=[]
def oracle(name,fixture,expected):
    oracles.append({'method_proposed_NOT_IMPLEMENTED':name,'fixture':fixture,'oracle':expected,'status':'NOT_RUN'})
oracle('absolute_default_refuses_even_empty_without_legacy_io','DefaultRejectTransport，旧write计数且可panic','有效/过期/empty上下文均Unsupported；wanted精确/got0/attemptfalse；旧write/set_timeout/读/flush计数0；dyn SerialTransport可调用新方法。')
oracle('absolute_source_equal_or_past_rejects_before_first_native_write','支持核心+FixedDeadlinePort','now=source及now>source都SourceExpired/wantedN/got0；timeout安装0/write0；避免Deadline::remaining相等Some(0)陷阱。')
oracle('absolute_context_does_not_refresh_after_prepare_delay','SourceWriteDeadline先构造，再MockClock推进越过原deadline','原deadline逐字段保留，不以调用时now+相对值续期；0 native IO。')
oracle('absolute_native_timeout_is_min_of_source_and_call_budget','FixedDeadlinePort，同共享生产核心','source30ms/call50ms得到timeout30/20/10；反向source100/call20得到20/10；每次重试只剩余原deadline，不增长。')
oracle('absolute_equal_limits_have_deterministic_source_reason','source与call同截止','等号/超过优先SourceExpired，原两期限都保留。')
oracle('absolute_partial_expiry_preserves_prefix_without_packet_replay','wanted6，脚本返回2+2，第二返回恰到source','got4且written恰前4字节，无第三Write/flush；SourceExpired/attempttrue；没有完整帧重放。')
oracle('absolute_full_write_returning_at_or_after_limit_is_failure','一次返回wanted并推进到equal或greater','got==wanted仍SourceExpired或CallBudgetExpired；不能改为Ok，保已发送事实。')
oracle('absolute_expiry_during_timeout_install_suppresses_native_write','timeout安装夹具推进clock至source','安装1/write0/got0/attemptfalse；错误原source不变。')
oracle('absolute_retryable_errors_preserve_both_absolute_windows','Interrupted/WouldBlock/TimedOut脚本+时钟推进','只在有效原窗口重试remaining slice；各错误不重起call/source；到期固定cause/got。')
oracle('absolute_zero_or_terminal_io_preserves_progress_and_does_not_retry','先合法partial，再0或BrokenPipe','一次后失败，WriteZero/WriteIo(BrokenPipe)，got为合法partial长度，无额外TX/flush。')
oracle('absolute_timeout_install_failure_preserves_progress','0字节及一次partial后，安装返回PermissionDenied','TimeoutConfiguration固定kind，无to_string/新io::Error；当前got全量，之后Write0。')
oracle('absolute_regressed_clock_and_budget_overflow_fail_closed','固定时钟脚本倒退、Duration超u64、start+budget超u64','ClockRegressed/BudgetOverflow，未伪饱和续期；已known got保留，溢出未TX。')
oracle('absolute_supported_empty_is_freshness_checked_without_io','有效/expired empty','仅有效且budget可表示为Ok，无timeout/write；expired空Err；不改变旧helper空输入行为。')
oracle('absolute_invalid_native_write_count_does_not_wrap_progress','损坏Write实现返回remaining+1','InvalidWriteCount reported原值/got保原前缀；不usize溢出，不继续重试。')
oracle('deadline_bus_forbidden_registers_keep_prelease_priority','原RejectOnLeaseProbe+默认拒绝transport','Firmware两个/Phase三个诊断写原错误先于新class/shape/deadline，begin/checkpoint/finish/native0。')
oracle('deadline_bus_shape_value_and_frame_errors_never_acquire_lease','固定MAX_JOINTS+1、短frame_buf、sign幅度超限','保持原ByteLength/Magnitude错误、无native IO；整体全部编码检查先于TX。')
oracle('deadline_bus_preexpired_frame_has_exact_wanted_and_no_lease','golden三轮frame+过期source','Wanted=实际build帧长度、got0，lease begin/checkpoint/finish全部0。')
oracle('deadline_bus_lease_across_success_expiry_and_unsupported','真authority LeaseProbe+固定支持/拒绝transport','begin1，期间authority NORMAL_IO_ACTIVE为true，checkpoint1在transport返回之后，finish1在末尾；success及Err均真回收，不额外ACK。')
oracle('deadline_bus_lease_revocation_preserves_original_abort','原revoked/emergency authority fixture','保持Aborted reason，无nativecall，不以deadline Unknown替代。')
oracle('deadline_bus_source_expiring_while_acquiring_lease_has_no_tx','lease acquire脚本推进clock越过期限','transport后验检查Err got0；heldlease按原checkpoint/drop顺序归还一次。')
oracle('deadline_bus_invalid_class_refuses_without_changing_legacy_safety','Safety/Confirm/Connect/PeriodicRead新入口+旧safety golden','新入口InvalidOperationClass且无lease/TX，旧_into TorqueDisable原golden与调用预算不变。')
oracle('absolute_error_conversion_and_diagnostic_reason_are_exhaustive','每个10cause×零尝试/尝试0/partial/full的合法状态','comm_kind/RobotError/FeetechDiagnostic原因进度与表逐项一致，无Unknown或动态format，wanted/got和原期限未在原error中丢失；转换本来降为固定RobotError须清楚。')
oracle('absolute_legacy_write_position_response_and_fast_stop_are_unchanged','原post_e_transport11+bus与adapter已有定向','旧write_all fresh per-call预算、完整response原lease、Position既有模式不变、Safety/Confirm不调用deadline方法；只算实际方法名单不叠计。')
oracle('absolute_production_hot_core_and_bus_paths_run_under_real_allocator_guard','新固定端口/固定脚本/固定日志+选定真实全局AllocDisabler','constructor/所有权准备在guard外；支持成功/partial/expired/unknown/default及diagnostic转换全在guard内；留确定性分配负控。默认Vec夹具不能用于此证明，真实foreign backend另有限界。')

allocation={
 'application_code':'新context只借clock，helper仅got/last时刻等固定局部；Error只POD原因/usize/Option时刻/io::ErrorKind；bus固定data_bufs/entry_refs及调用方frame_buf；无新Vec/Box/String/Arc生命周期/IPC/format。',
 'existing_fixture_limit':'PartialPort目前VecDeque/Vec记录，适合结果oracle，不适合真实guard热路径；新FixedDeadlinePort使用固定数组/计数，fixture创建与所有Arc/log空间在guard外。',
 'real_backend_limit':'serialport4.10 Error含description:String；新shim不再to_string或追加allocation，但backend自己构造/返回错误可能分配。真实set_timeout/read/write底层是否分配不能用fixed fixture证据外推。',
 'existing_actual_allocator':ref('crates/robot-adapters/feetech/tests/abort_diagnostics.rs',29,'TEST_ALLOCATOR=AllocDisabler'),
 'guard_root_choice':'推荐在Feetech lib cfg(test)注册该test二进制唯一AllocDisabler来直接守生产private helper与bus；生产allocator不变，既有lib同名alloc_free方法由此成为真捕获，需全lib复验。若root要求严格复用现有abort_diagnostics二进制，只能通过真正调用相同生产核心的显式测试接缝或fake SerialPort构造，不接受镜像循环/占位forward；不要为测试泛公开底层核心。当前均未实施。',
}

boundary={
 'bus_has_no_pending_output':'该组件bus/transport无latest-slot或P1C状态引用，局部frame借用在返回即结束，不保存/自动重放pending帧。',
 'future_caller_obligation':'失败必须在转换前保原wanted/got/cause事实，并走既有SerialTick fault→CONVERGING/fault publication/authority收紧→Safety/Confirm。回收此次frame且不得retry同旧输出；P1C当前ticket/session的pending/staged输出撤销和新fresh barrier由后续真实bridge完成，不能由bus伪清。',
 'existing_fault_evidence':[ref('crates/robot-s0/src/serial_tick.rs',652,'SerialTick::route_periodic'),
                            ref('crates/robot-s0/src/serial_convergence.rs',342,'SerialConvergence::enter_fault_impl'),
                            ref('crates/robot-s0/src/serial_tick.rs',318,'reject_inhibited_pending')],
 'claim_limit':'本组件不自动接SerialTick/Velocity。可验证错误转换和原fault行为的注入oracle，但未接实际调用不得称pending真实撤销或完整执行链通过。latest_slot的原字节不被删除；撤销权限不等于抹除数据。',
}
root_decisions=[
 {'id':'class_and_authority_boundary','proposal':'新bus API只NormalEffectful/PeriodicWrite；拒Safety/Confirm/Connect/PeriodicRead，旧路径不变。Some probe保真实lease；None只无authority组件能力。','decision_needed':'是否要求新bus入口强制Some probe，若是明确额外NoAuthorityProbe原因，不推定已有授权。'},
 {'id':'failure_and_diagnostic_codes','proposal':'按10原因表：无write期限PendingDeadline、尝试/partial期限IoWrite；能力/溢出/错误opclass为InvalidParameter。kind9明确cause+progress，不扩CommErrorKind/wire schema。','decision_needed':'确认是否采用此trust分类及新本地diagnostic编码；日志不装完整usize进度，完整error保留后续调用方负责原件。'},
 {'id':'completion_and_native_gap','proposal':'来源及call完成都严格now<截止，相等Fail；set_timeout后再check，晚返回有got也FAIL；不可原子化最后check→write窗口和relative OS timeout限界明记。','decision_needed':'确认该观察/错误合同为小件验收边界；不接受借源码方案宣称OS硬期限或撤回已发字节。'},
 {'id':'true_allocator_fixture','proposal':'本lib test注册唯一AllocDisabler直接守private共享核心；或root指定既有integration binary的真实生产调用接缝。','decision_needed':'确认测试allocator范围及既有lib alloc_free复验，不创建第二process内allocator，不用镜像算法。'},
 {'id':'pending_revocation_scope','proposal':'本组件不缓存/重发，错误供原fault及后续P1C bridge消费。','decision_needed':'明确root“旧pending输出撤销”在当前组件只指局部帧不重放；真正S0/P1C旧pending撤销须后包接入且单验，不要求本组件偷偷接生产。'},
]

files_planned=[
 {'path':'crates/robot-adapters/feetech/src/transport.rs','change':'SourceWriteDeadline、trait default reject、私有absolute core/无format timeout shim、Real override；旧helper保留'},
 {'path':'crates/robot-adapters/feetech/src/bus.rs','change':'新具名_into_until与lease.write_until，固定栈编码/原guards/原lease顺序'},
 {'path':'crates/robot-adapters/feetech/src/error.rs','change':'固定AbsoluteWriteFailure类型/10原因/穷尽comm_kind+From映射'},
 {'path':'crates/robot-adapters/feetech/src/diagnostic.rs','change':'穷尽classify+固定cause/progress诊断及table oracle'},
 {'path':'crates/robot-adapters/feetech/src/post_e_transport_acceptance.rs','change':'生产共享absolute core的时间/partial行为oracles与固定端口'},
 {'path':'crates/robot-adapters/feetech/tests/comm_fault_transport.rs','change':'新bus真正lease/默认拒绝/顺序oracle；原fixture旧方法不隐式支持'},
 {'path':'crates/robot-adapters/feetech/src/lib.rs','conditional':'仅root选lib test唯一allocator时','change':'cfg(test)唯一全局AllocDisabler，不影响生产allocator'},
]
qa=[
 '最新nightly身份/所改源及完整输入清单首尾绑定；以下命令仅建议，当前NOT_RUN。',
 'cargo +nightly fmt --all',
 'cargo +nightly clippy --locked --all --all-targets -- -D warnings',
 'cargo +nightly clippy --locked -p robot-adapter-feetech --all-targets --features real-hw -- -D warnings',
 'cargo +nightly test --locked -p robot-adapter-feetech --lib',
 'cargo +nightly test --locked -p robot-adapter-feetech --lib --features real-hw',
 'cargo +nightly test --locked -p robot-adapter-feetech --test comm_fault_transport',
 'cargo +nightly test --locked -p robot-adapter-feetech --test abort_diagnostics',
 '编译未知/默认实现及dyn调用由真实fixture验证，不网络、不打开串口；精确--list/运行方法名单独核，新24是计划不能预写实际测试计数。',
]

head_after=git(['rev-parse','HEAD']);status_after=git(['status','--porcelain=v1'])
assert head==head_after and status==status_after==''
for rel,before in pins.items():
    assert pin(main/rel)==before,rel
plan={
 'schema':'absolute_write_plan_r1','status':'FUNCTION_PLAN_ONLY_NOT_IMPLEMENTED_NOT_COMPILED_NOT_RUN',
 'author':'/root/acceptance_resume','created_at':now(),
 'root_requested_scope':'显式来源绝对期限的普通串口写入，新的具名预分配bus API；默认旧行为兼容，不自动接SerialTick/Velocity，不加Enable/Firmware/Phase/EEPROM/hardware动作。',
 'basis':{'head_before':head,'head_after':head_after,'status_before':status,'status_after':status_after,
          'source_count':591,'aggregate':source['source_manifest_sha256'],'source_manifest':pin(source_path),'pins':pins,
          'external_dependency_source':pin(serialport),'candidate596':'P1候选596未改；该方案不生成新combined source身份'},
 'actual_actions':'仅本机read/source hash与target新方案。无Cargo/SSH/UART/业务源写。',
 'api_proposal_NOT_IMPLEMENTED':api,'all_known_transport_implementations':implementations,
 'algorithm_NOT_IMPLEMENTED':algorithm,'bus_and_lease_order':bus_order,
 'error_diagnostic_plan':error_plan,'allocation_boundary':allocation,
 'existing_core_deadline_equality_pitfall':{'evidence':ref('crates/robot-core/src/time.rs',140,'Deadline::remaining'),
    'fact':'实现checked_sub在相等返回Some(DurationNs(0))，不能靠Option::None代表相等到期；新API显式now>=deadline检查，不改无关core helper。'},
 'root_material_decisions':root_decisions,'files_planned_NOT_MODIFIED':files_planned,
 'proposed_unique_oracle_count':len(oracles),'oracles_NOT_IMPLEMENTED_NOT_RUN':oracles,
 'caller_convergence_and_pending_boundary':boundary,'proposed_QA_NOT_RUN':qa,
 'acceptance_claim_limit':'组件PASS只证明绝对写合同及其实际软件边界；不证明固件profile/session/zero-before-enable/P1C production IPC/完整B1/无人值守/D15/硬件截止。原FAIL/Phase12/底盘DEFERRED/deployable=false保持。',
 'readonly_git_owned_children':children,
}
json_path.write_text(json.dumps(plan,ensure_ascii=False,indent=2)+'\n')
md=f'''爸爸，本小件拟增加显式借用 `RobotClock` 的 `SourceWriteDeadline`、`SerialTransport::write_all_until` 和 `FeetechBus::sync_write_by_id_into_until`。这是函数方案，未实现、未编译、未测试；主树 `{head}` 和候选596均未改。

新增 trait 方法带默认明确拒绝。未知 transport、现有 Mock/测量包装/旧脚本即使收到空 buffer，也返回固定 Unsupported，不得退回旧 `write_all`。当前6实现均已列出；仅 real-hw 的 RealSerialTransport 计划显式支持新核心，实际对象安全/兼容编译另验。

新核心每次首写及 partial write 前检查原来源期限与本次固定调用预算，native timeout 取两者最早截止的剩余值；timeout 安装后再查期限。来源期限不变、每次重试不续期；只发送未写 slice，不 flush、不整帧重放。任何已知进度失败保 wanted/got 与期限原因，全部字节返回却到截止等号或之后也保持失败。最后 clock 检查与内核 write 无法原子化，不能承诺撤回已发字节或操作系统硬期限。

新 bus 入口复用原只读/诊断拒写优先级、完整编码和固定栈 buffer。申请一次原 lease，整个 transport 新调用持有，返回后恰一次 checkpoint，RAII 恰一次归还；broadcast 仍没有 ACK。建议新入口只允许 NormalEffectful/PeriodicWrite，Safety/Confirm/Connect/PeriodicRead 明确拒绝，旧 API 全部不变。

固定错误含10原因及完整 wanted/got、原来源期限、本次调用期限、观测时刻和是否尝试 write。方案建议零尝试本地期限→PendingDeadline，实际尝试/partial→IoWrite，能力/预算溢出/错误 class→InvalidParameter；穷尽更新原 comm_kind、From 与诊断分类，不落 Unknown。固定 diagnostic 原因和进度建议新 kind9，完整任意 usize 两长度仍保在原错误，不能声称原3字节日志装下全部信息。

root 需确认五项：新 bus 入口是否强制安装 authority probe、错误与诊断/trust分类、严格完成边界及 native相对timeout限界、真实 allocator test范围、当前“pending撤销”是否仅指本组件帧不缓存/重放。bus没有P1C或latest-slot引用，真实旧输出撤权/新fresh barrier必须在后续生产接入验证；本轮不偷偷接SerialTick。

无alloc方案使用借用context、固定原因和固定数组。旧 native timeout 错误桥会 to_string；新桥只映射 ErrorKind。serialport自己的错误含 String，不能据固定夹具守卫外推其内部零分配。建议 lib test 注册该test二进制唯一 AllocDisabler，直接守共享private核心；这需 root 批准并复验既有 lib alloc_free 方法，生产allocator不变。

JSON列出24个精确待实施 oracle，覆盖首写等号/准备后延迟/min期限/途中partial/晚完成/timeout安装/重试/回退溢出/非法write计数/未知默认拒绝/原lease/禁止寄存器/旧fast stop/穷尽分类/真实allocator。计划涉及6个主要文件，另1个测试allocator条件文件；没有伪记任何方法已运行。详见 [完整方案]({json_path})。
'''
md_path.write_text(md)
print(json.dumps({'json':pin(json_path),'markdown':pin(md_path),'planned_oracles':len(oracles),
                  'known_transport_impls':len(implementations),'source_changed':False,'status':plan['status']},ensure_ascii=False))
