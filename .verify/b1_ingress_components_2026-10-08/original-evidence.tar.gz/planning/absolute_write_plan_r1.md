爸爸，本小件拟增加显式借用 `RobotClock` 的 `SourceWriteDeadline`、`SerialTransport::write_all_until` 和 `FeetechBus::sync_write_by_id_into_until`。这是函数方案，未实现、未编译、未测试；主树 `e6d6d111091b29b791bae0375b209692fdf3eed5` 和候选596均未改。

新增 trait 方法带默认明确拒绝。未知 transport、现有 Mock/测量包装/旧脚本即使收到空 buffer，也返回固定 Unsupported，不得退回旧 `write_all`。当前6实现均已列出；仅 real-hw 的 RealSerialTransport 计划显式支持新核心，实际对象安全/兼容编译另验。

新核心每次首写及 partial write 前检查原来源期限与本次固定调用预算，native timeout 取两者最早截止的剩余值；timeout 安装后再查期限。来源期限不变、每次重试不续期；只发送未写 slice，不 flush、不整帧重放。任何已知进度失败保 wanted/got 与期限原因，全部字节返回却到截止等号或之后也保持失败。最后 clock 检查与内核 write 无法原子化，不能承诺撤回已发字节或操作系统硬期限。

新 bus 入口复用原只读/诊断拒写优先级、完整编码和固定栈 buffer。申请一次原 lease，整个 transport 新调用持有，返回后恰一次 checkpoint，RAII 恰一次归还；broadcast 仍没有 ACK。建议新入口只允许 NormalEffectful/PeriodicWrite，Safety/Confirm/Connect/PeriodicRead 明确拒绝，旧 API 全部不变。

固定错误含10原因及完整 wanted/got、原来源期限、本次调用期限、观测时刻和是否尝试 write。方案建议零尝试本地期限→PendingDeadline，实际尝试/partial→IoWrite，能力/预算溢出/错误 class→InvalidParameter；穷尽更新原 comm_kind、From 与诊断分类，不落 Unknown。固定 diagnostic 原因和进度建议新 kind9，完整任意 usize 两长度仍保在原错误，不能声称原3字节日志装下全部信息。

root 需确认五项：新 bus 入口是否强制安装 authority probe、错误与诊断/trust分类、严格完成边界及 native相对timeout限界、真实 allocator test范围、当前“pending撤销”是否仅指本组件帧不缓存/重放。bus没有P1C或latest-slot引用，真实旧输出撤权/新fresh barrier必须在后续生产接入验证；本轮不偷偷接SerialTick。

无alloc方案使用借用context、固定原因和固定数组。旧 native timeout 错误桥会 to_string；新桥只映射 ErrorKind。serialport自己的错误含 String，不能据固定夹具守卫外推其内部零分配。建议 lib test 注册该test二进制唯一 AllocDisabler，直接守共享private核心；这需 root 批准并复验既有 lib alloc_free 方法，生产allocator不变。

JSON列出24个精确待实施 oracle，覆盖首写等号/准备后延迟/min期限/途中partial/晚完成/timeout安装/重试/回退溢出/非法write计数/未知默认拒绝/原lease/禁止寄存器/旧fast stop/穷尽分类/真实allocator。计划涉及6个主要文件，另1个测试allocator条件文件；没有伪记任何方法已运行。详见 [完整方案](/Users/loosqk/repo/rust/robot-system/target/b1_freshness_integration_2026-10-08/absolute_write_plan_r1.json)。
