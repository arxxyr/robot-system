# 按已批准边界封存本阶段原件；不执行构建、SSH、UART或业务源码写入。
import hashlib
import io
import json
import os
from pathlib import Path, PurePosixPath
import stat
import tarfile
from datetime import datetime, timezone

main=Path('/Users/loosqk/repo/rust/robot-system')
base=main/'target/b1_freshness_integration_2026-10-08'
A=Path('/Users/loosqk/.codex/worktrees/xlerobot-base-profile/robot-system')
B=Path('/Users/loosqk/.codex/worktrees/xlerobot-wheel-profile/robot-system')
C=Path('/Users/loosqk/.codex/worktrees/b1-freshness-reducer/robot-system')
out=main/'.verify/b1_ingress_components_2026-10-08'
if out.exists():
    raise SystemExit('目标已存在，拒绝覆盖')

def load(p):
    return json.loads(p.read_text())
def sha(raw):
    return hashlib.sha256(raw).hexdigest()
def identity(p):
    s=p.lstat()
    if not stat.S_ISREG(s.st_mode):
        raise RuntimeError('非普通原件：'+str(p))
    return {'dev':s.st_dev,'ino':s.st_ino,'bytes':s.st_size,'mtime_ns':s.st_mtime_ns,
            'ctime_ns':s.st_ctime_ns,'mode':stat.S_IMODE(s.st_mode)}
def pin(p):
    s=identity(p);r=p.read_bytes();return {'path':str(p),'sha256':sha(r),'bytes':len(r),'mode':s['mode']}

native=load(base/'native-r5/summary.json')
review=load(base/'independent_native_r5/review.json')
integration=load(base/'root_integration_r1.json')
quality=load(base/'root_precommit_quality_binding_r1.json')
assert native['status']=='PASS_SCOPED_SOFTWARE'
assert review['status'].startswith('PASS_SCOPED_SOFTWARE_NO_BLOCKER') and not review['blockers']
assert integration['status']=='PASS_EXACT_ELEVEN_OVERLAYS_SAME_NATIVE_596'
assert quality['status']=='PASS_MAIN_FMT_SAME_596_AND_ACTUAL_NATIVE_FMT_CLIPPY'
aggregate='b919cd320dd81693ae49612dcd0778b98e6ee97191d2344bdf87cefd69c2eed0'
assert native['source_count']==596 and native['source_aggregate']==aggregate
assert quality['main_source_count']==596 and quality['main_source_aggregate']==aggregate
assert len(integration['paths'])==11 and integration['firmware_seven_preserved']
assert native['actual_native_child_count']==18
counts=native['count_policy']
assert counts['different_Rust_method_pass_total']==313 and counts['core_linux_Rust_methods']==147
assert counts['transport_default_Rust_pass']==129 and counts['p1c_guard_Rust_pass']==37
assert counts['doc_compile_fail_pass_separate']==1 and counts['transport_default_original_ignored']==2 and counts['doc_original_ignored_separate']==2
assert len(quality['children'])==7

# 只选择本阶段证据目录，绝不遍历工作树的Cargo缓存或其它.verify阶段包。
selected={}
def add(p,name,group):
    if not p.is_file():
        raise RuntimeError('必需原件缺失：'+str(p))
    parts=PurePosixPath(name).parts
    if not parts or PurePosixPath(name).is_absolute() or '..' in parts:
        raise RuntimeError('不安全成员：'+name)
    identity(p)
    if name in selected and selected[name]['original_path']!=str(p):
        raise RuntimeError('重复成员：'+name)
    selected[name]={'original_path':str(p),'group':group}

def directory(root,prefix,group):
    if not root.is_dir():
        raise RuntimeError('必需目录缺失：'+str(root))
    for folder,dirs,names in os.walk(root,followlinks=False):
        dirs[:]=sorted(d for d in dirs if d not in {'cargo-target','target','debug','release','__pycache__','.git','.cache'})
        for name in sorted(names):
            p=Path(folder)/name
            if p.suffix in {'.pyc','.pyo'}:
                continue
            add(p,prefix+'/'+p.relative_to(root).as_posix(),group)

directory(A/'target/b1-p1a-origin','p1a/evidence','P1A_MAC')
directory(B/'target/wheel_velocity_profile','p1b/evidence','P1B_MAC')
cp=C/'target/b1_freshness_reducer'
for p in sorted(cp.iterdir()):
    if p.is_file() and p.suffix in {'.json','.md','.diff','.py'}:
        add(p,'p1c/evidence/'+p.name,'P1C_PLAN_SOURCE_HISTORY')
    elif p.is_dir() and (p.name.startswith('history_candidate_') or p.name.startswith('pure_format_') or p.name.startswith('integration_read_') or p.name=='combined_dependency_qa_r1'):
        directory(p,'p1c/evidence/'+p.name,'P1C_HISTORY_OR_MAC_RECEIPTS')
for p in sorted((main/'target/b1_freshness_reducer').iterdir()):
    if p.is_file() and p.suffix in {'.json','.md','.py'}:
        add(p,'p1c/original_plan/'+p.name,'P1C_ORIGINAL_PLAN')

components=[
 'crates/robot-transport/src/origin.rs','crates/robot-transport/src/lib.rs','crates/robot-transport/src/sample.rs',
 'crates/robot-transport/src/mock.rs','crates/robot-transport/src/iceoryx2/subscriber.rs','crates/robot-transport/tests/publisher_origin.rs',
 'crates/robot-core/src/lib.rs','crates/robot-core/src/wheel_velocity_profile.rs',
 'crates/robot-s0/src/base_ingress.rs','crates/robot-s0/src/base_ingress/tests.rs','crates/robot-s0/src/lib.rs',
]
expected=load(base/'native-r5/expected_source.json')['files']
for rel in components:
    for root in [C,main]:
        actual=pin(root/rel)
        assert actual['sha256']==expected[rel]['sha256'] and actual['bytes']==expected[rel]['bytes'],str(root/rel)
    add(C/rel,'candidate/source/'+rel,'FINAL_ELEVEN_SOURCE')

nested={}
for r in [2,3,4,5]:
    for suffix in ['original-evidence.tar.gz','original-evidence.index.json','archive-verification.json']:
        p=base/f'native-r{r}-{suffix}'
        add(p,'native-packages/'+p.name,'NATIVE_IMMUTABLE_FAIL' if r<5 else 'NATIVE_IMMUTABLE_PASS')
    # 原封包里已经有全部raw，不再重复摊平收包；summary可能在原封包后生成，单独保留。
    p=base/f'native-r{r}/summary.json'
    add(p,f'native-summary/native-r{r}-summary.json','NATIVE_SUMMARY')
    idx=load(base/f'native-r{r}-original-evidence.index.json')
    archive=base/f'native-r{r}-original-evidence.tar.gz'
    observed=pin(archive)
    assert observed['sha256']==idx['archive']['sha256'] and observed['bytes']==idx['archive']['bytes']
    nested[f'native_r{r}']={
        'archive_member':'native-packages/'+archive.name,
        'index_member':f'native-packages/native-r{r}-original-evidence.index.json',
        'verification_member':f'native-packages/native-r{r}-archive-verification.json',
        'summary_member':f'native-summary/native-r{r}-summary.json',
        'sha256':observed['sha256'],'bytes':observed['bytes'],'original_member_count':len(idx['files']),
        'status':'FAIL_ORIGINAL_UNCHANGED' if r<5 else 'PASS_SCOPED_SOFTWARE',
    }

for folder in ['independent_static_r2','independent_r4_roster_failure','independent_native_r5','root_precommit_r1']:
    directory(base/folder,'reviews-and-quality/'+folder,'STATIC_DYNAMIC_OR_ROOT_REVIEW')
# 包内保留整合backup/rollback字节，与root主树写操作原回执绑定。
for p in sorted(base.iterdir()):
    if p.is_dir() and p.name.startswith('root_integration'):
        directory(p,'reviews-and-quality/'+p.name,'ROOT_INTEGRATION_BACKUP')
    if p.is_file() and (p.name.startswith('root_') or p.name=='integrate_accepted_r4.py') and p.suffix in {'.json','.py','.md'}:
        add(p,'reviews-and-quality/'+p.name,'ROOT_RECEIPT_OR_HELPER')
for name in ['next_serial_execution_codemap_r1.json','next_serial_execution_codemap_r1.md',
             'absolute_write_plan_r1.json','absolute_write_plan_r1.md','root_decisions_r1.json','root_decisions_r1.md',
             'archive_retention_plan_r1.json','build_next_codemap_r1.py','build_absolute_write_plan_r1.py',
             'build_component_archive_r1.py']:
    add(base/name,'planning/'+name,'NEXT_PIECE_PLAN_ONLY')

# 只记录本轮封存时真实身份，不补造旧builder没有落盘的历史stat列表。
records=[]
for name,entry in sorted(selected.items()):
    p=Path(entry['original_path']);before=identity(p);raw=p.read_bytes();after_read=identity(p)
    assert before==after_read and len(raw)==before['bytes'],str(p)
    records.append({'name':name,**entry,'sha256':sha(raw),'bytes':len(raw),'mode':before['mode'],
                    'identity_before':before,'identity_after_read':after_read})
out.mkdir(parents=True)
archive_path=out/'original-evidence.tar.gz'
with tarfile.open(archive_path,'w:gz',compresslevel=6) as tar:
    for item in records:
        p=Path(item['original_path']);raw=p.read_bytes()
        assert sha(raw)==item['sha256'] and identity(p)==item['identity_before'],str(p)
        info=tarfile.TarInfo(item['name']);info.size=len(raw);info.mode=item['mode'];info.mtime=0
        info.uid=0;info.gid=0;info.uname='';info.gname=''
        tar.addfile(info,io.BytesIO(raw))
for item in records:
    p=Path(item['original_path']);after=identity(p);raw=p.read_bytes()
    assert after==item['identity_before'] and sha(raw)==item['sha256'],str(p)
    item['identity_after_archive']=after
manifest_aggregate=sha(json.dumps([{k:i[k] for k in ['name','sha256','bytes','mode']} for i in records],sort_keys=True,separators=(',',':')).encode())
index={'schema':'B1_INGRESS_COMPONENTS_ORIGINAL_INDEX_R1','archive':pin(archive_path),
       'member_count':len(records),'member_manifest_sha256':manifest_aggregate,'files':records,
       'nested_native_archives':nested,'self_index_excluded':True,
       'excluded':'本index/summary/verification不在原件tar，防循环；旧固件/hardware.verify包不收；本轮脚本cache/Cargo产物不收，历史native tar字节immutable。'}
index_path=out/'original-evidence.index.json';index_path.write_text(json.dumps(index,ensure_ascii=False,indent=2)+'\n')

# 仅做本新外层包的字节/安全闭包自核；不重复运行168项native语义审核。
expected_members={r['name']:r for r in records}
seen=set()
with tarfile.open(archive_path,'r:gz') as tar:
    for member in tar:
        parts=PurePosixPath(member.name).parts
        assert member.isfile() and not PurePosixPath(member.name).is_absolute() and '..' not in parts
        assert member.name not in seen and member.name in expected_members
        seen.add(member.name);r=expected_members[member.name];raw=tar.extractfile(member).read()
        assert len(raw)==r['bytes']==member.size and sha(raw)==r['sha256'] and member.mode==r['mode']
assert seen==set(expected_members)
verification={'schema':'B1_INGRESS_COMPONENTS_ARCHIVE_SELF_VERIFICATION_R1','status':'PASS',
 'created_at':datetime.now(timezone.utc).isoformat(),'archive':pin(archive_path),'index':pin(index_path),
 'member_count':len(seen),'all_regular_safe_relative_unique':True,'all_bytes_sha_mode_match':True,
 'all_current_originals_identity_and_bytes_before_after_match':True,
 'member_manifest_sha256':manifest_aggregate,'self_index_and_summary_excluded':True,
 'not_claimed':'此为封存自核，不是另一次独立动态验收；native语义结论引用实际peer/root原件；工具链/外部原执行binary只有identity与回执，未收binary。'}
verification_path=out/'archive-verification.json';verification_path.write_text(json.dumps(verification,ensure_ascii=False,indent=2)+'\n')

by_path={r['original_path']:r for r in records}
def archived(p):
    r=by_path[str(p)]
    return {'archive_member':r['name'],'sha256':r['sha256'],'bytes':r['bytes']}
summary={
 'schema':'B1_INGRESS_COMPONENTS_STAGE_SUMMARY_R1','status':'MAIN_INTEGRATED_SOFTWARE_PASS','commit_status':'PENDING_ROOT_COMMIT',
 'created_at':datetime.now(timezone.utc).isoformat(),'deployable':False,
 'implemented':'P1A强类型publisher origin、P1B纯wheel velocity profile接口、P1C纯bounded ingress reducer（含粘性耗尽原因）共11源已整合主树；不含生产IPC/adapter/串口执行接入。',
 'source':{'main_integrated_count':596,'aggregate':aggregate,'candidate_worktree_count':595,'eleven_source_members':['candidate/source/'+p for p in components],
           'root_integration':archived(base/'root_integration_r1.json'),'seven_firmware_sources_preserved':True,
           'native_compiler':'1.101.0-nightly 1d81eb4ad9cd207e3e638bd32b17ec4fce8412a6 aarch64-unknown-linux-gnu',
           'toolchain_channel':'浮动nightly未pin；本轮18门复用最新已更新1d81实际身份，不伪记新rustup update'},
 'actual_validation':{'native_owned_children':18,'all_actual_natural_exit0_wait_reap':True,
     'different_Rust_method_passes':313,'core':147,'transport':129,'p1c':37,
     'compile_fail_doctest_passes_separate':1,'original_Rust_ignored':2,'original_doc_ignored':2,
     'non_additive':'mock61是transport129子集；default36是guard37子集；guard内部重复36调用不新增方法；trybuild8 nested cases不加；Mac143不加Linux147。',
     'primary_summary':archived(base/'native-r5/summary.json'),'native_package':nested['native_r5'],
     'independent_review':archived(base/'independent_native_r5/review.json'),'independent_index':archived(base/'independent_native_r5/index.json')},
 'precommit_quality':{'status':'PASS_SEPARATE_ROOT_BINDING_SAME_596',
     'actual_native_order':'fmt→default root Clippy→rt_guard+real-hw root Clippy，实际0',
     'actual_main_fmt_exit':0,'main_fmt_owned_children':7,'compiler_1d81_before_after_same':True,'same_all_596_after_main_fmt':True,
     'root_binding':archived(base/'root_precommit_quality_binding_r1.json'),
     'original_native_record':'native-r5/precommit_quality_binding原REQUIRED_AFTER_11_SOURCE_INTEGRATION未改；新root同源整合/mainfmt/质量旁证单独闭环。'},
 'history':{'p1a':'r1/r2 TLS1、r3 SIGINT-2及后9 NOT_RUN、r4 Clippy101及后3 NOT_RUN均原件保留',
     'p1b':'原PREPARED plan/旧SHA保留，格式化后实际Mac receipt单独绑定',
     'p1c_r1':'旧r1静态批准被耗尽分类修订supersede，Linux NOT_RUN，不伪记FAIL',
     'native_r2':'fmt0→生产10lint Clippy101、后测试NOT_RUN',
     'native_r3':'fmt0→测试9lint Clippy101、后测试NOT_RUN',
     'native_r4':'fmt及两Clippy0、core_list展示expected夹具错误strictFAIL/0 Rust执行；旧3 should_panic展示后缀原件保留',
     'immutable_native_packages':{k:v for k,v in nested.items() if k!='native_r5'}},
 'next_piece':{'status':'FUNCTION_PLAN_ROOT_APPROVED_NOT_IMPLEMENTED_NOT_TESTED',
     'codemap':archived(base/'next_serial_execution_codemap_r1.json'),
     'absolute_write_plan_original':archived(base/'absolute_write_plan_r1.json'),
     'root_decisions_separate':archived(base/'root_decisions_r1.json'),
     'scope':'借RobotClock的来源绝对写期限；未知transport默认拒绝、新bus强制authority probe；11固定原因/25拟议oracle仅计划，不计本轮313。'},
 'limits':['非完整workspace/release/真实RT调度验收；仅纯模块组合软件与根质量门',
   'P1C origin数据不证明RPC caller认证；USB/连接代次、真实FW/Phase/zero-before-Enable和生产fresh事件桥未接入',
   '底盘Velocity当前adapter仍无TX；硬件FAIL/右H2/D15 OPEN_DEFERRED/deployable=false不变；历史Phase12未改/现场FW未读',
   '本阶段无UART/硬件GO/部署/正式安装/push；parent本轮明确人工已断电，本builder未进行物理读取，不回填旧硬件PENDING原件',
   'archive不收旧固件/hardware阶段包，不把host绝对路径存在当归档闭包；本轮源输入在native包内，外部工具binary身份仅identity-only未收字节'],
 'archive':{'original_evidence':pin(archive_path),'index':pin(index_path),'verification':pin(verification_path),
            'member_count':len(records),'member_manifest_sha256':manifest_aggregate,
            'scope':'原件outer闭包逐成员bytes/SHA/mode与当前真实before/after stat清单自核；native r2..r5原包保持原字节，内部索引可递归解析'},
 'root_remaining':['最终验收和提交；不得以此summary声称已经commit/push'],
}
summary_path=out/'summary.json';summary_path.write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'summary':pin(summary_path),'archive':pin(archive_path),'index':pin(index_path),
 'verification':pin(verification_path),'members':len(records),'aggregate':manifest_aggregate,
 'status':summary['status'],'commit_status':summary['commit_status']},ensure_ascii=False))
