# 仅整理本机静态读审证据，不运行构建或硬件入口。
import hashlib
import json
from pathlib import Path
import subprocess
from datetime import datetime, timezone

main = Path('/Users/loosqk/repo/rust/robot-system')
candidate = Path('/Users/loosqk/.codex/worktrees/b1-freshness-reducer/robot-system')
out = main / 'target/b1_freshness_integration_2026-10-08'
report_path = out / 'next_serial_execution_codemap_r1.json'
md_path = out / 'next_serial_execution_codemap_r1.md'
if report_path.exists() or md_path.exists():
    raise SystemExit('已存在报告，拒绝覆盖')

def stamp():
    return datetime.now(timezone.utc).isoformat()

def pin(path):
    raw = path.read_bytes()
    return {'path': str(path), 'sha256': hashlib.sha256(raw).hexdigest(), 'bytes': len(raw)}

children = []
def read_git(args):
    started = stamp()
    child = subprocess.Popen(['git', *args], cwd=main, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    stdout, stderr = child.communicate()
    children.append({'argv': ['git', *args], 'cwd': str(main), 'pid': child.pid,
                     'started_at': started, 'ended_at': stamp(), 'returncode': child.returncode,
                     'wait_reap': True, 'natural_completion': child.returncode == 0,
                     'stdout': stdout.decode(), 'stderr': stderr.decode()})
    if child.returncode != 0:
        raise SystemExit('只读 Git 命令失败')
    return stdout.decode().strip()

head_before = read_git(['rev-parse', 'HEAD'])
status_before = read_git(['status', '--porcelain=v1'])
if head_before != 'e6d6d111091b29b791bae0375b209692fdf3eed5' or status_before:
    raise SystemExit('主树基线变化，暂停生成')
manifest_path = out / 'native-r4/main_source_before.json'
source_manifest = json.loads(manifest_path.read_text())
source_map = source_manifest['files']
assert len(source_map) == 591
for rel, expected in source_map.items():
    p = main / rel
    actual = pin(p)
    assert actual['sha256'] == expected['sha256'] and actual['bytes'] == expected['bytes'], rel

files = [
    'crates/robot-adapters/feetech/src/adapter.rs', 'crates/robot-adapters/feetech/src/bus.rs',
    'crates/robot-adapters/feetech/src/transport.rs', 'crates/robot-adapters/feetech/src/factory.rs',
    'crates/robot-adapters/feetech/src/velocity_profile.rs', 'crates/robot-adapters/feetech/src/registers.rs',
    'crates/robot-adapters/feetech/src/lib.rs', 'crates/robot-adapters/feetech/src/post_e_transport_acceptance.rs',
    'crates/robot-adapters/feetech/tests/comm_fault_transport.rs',
    'crates/robot-adapters/feetech/tests/abort_diagnostics.rs',
    'crates/robot-core/src/adapter.rs', 'crates/robot-core/src/control_authority.rs',
    'crates/robot-core/src/serial_services.rs', 'crates/robot-s0/src/bin/s0_daemon.rs',
    'crates/robot-s0/src/serial_io_thread.rs', 'crates/robot-s0/src/serial_tick.rs',
    'crates/robot-s0/src/serial_preempt.rs', 'crates/robot-s0/src/serial_convergence.rs',
    'crates/robot-s0/src/ipc_pending.rs', 'crates/robot-s0/src/hard_rt_ctrl.rs',
    'crates/robot-s0/src/post_e_convergence_acceptance.rs', 'crates/robot-s0/tests/serial_rt_e2e.rs',
    'configs/xlerobot_right_arm.toml', 'configs/xlerobot_bus2_full.toml',
]
main_pins = {rel: pin(main / rel) for rel in files}

def ref(path, line, function):
    return {'path': str(main / path), 'line': line, 'function': function,
            'sha256': main_pins[path]['sha256']}

def finding(key, conclusion, evidence, limit):
    return {'id': key, 'conclusion': conclusion, 'evidence': evidence, 'limit': limit}

findings = [
    finding('velocity_no_tx',
        'FeetechAdapter::write_command 对非 Position 直接返回 Ok；Velocity 只记诊断，没有 Goal_Velocity TX。当前周期策略能转发速度 POD，但不代表串口执行。',
        [ref('crates/robot-adapters/feetech/src/adapter.rs',575,'ManipulatorAdapter::write_command'),
         ref('crates/robot-s0/src/serial_tick.rs',544,'SerialTick::periodic_write'),
         ref('crates/robot-adapters/feetech/src/adapter.rs',1289,'write_command_non_position_mode_is_noop_with_warning')],
        '本报告未修改无 TX 分支，也未执行任何硬件动作。'),
    finding('writer_owner',
        'prepare_execution 在 factory 打开串口前构造同域 authority/ctrl/probe/services；SerialRt adapter 随后按值移入唯一 serial_io_thread，在该实例的 tick 中访问 bus。',
        [ref('crates/robot-s0/src/bin/s0_daemon.rs',676,'prepare_execution'),
         ref('crates/robot-s0/src/bin/s0_daemon.rs',1813,'spawn_workers 的 BuiltAdapter::SerialRt 分支'),
         ref('crates/robot-s0/src/serial_io_thread.rs',294,'run_serial_hardened_io_loop'),
         ref('crates/robot-adapters/feetech/src/factory.rs',44,'FeetechFactory::build_concrete')],
        '这是单实例 UART 所有权；不证明另一个进程或底盘实例不会打开同一个 USB。latch_writer 的唯一 writer 术语不是 UART 排他证明。'),
    finding('ordinary_authority',
        '普通事务使用 begin_leased→acquire_normal_io 的原门；Motion 需要 Idle、非 Disabled/Latch/Shutdown/Exhausted，EnableStep 必须持当前同域 ExecutionView。',
        [ref('crates/robot-s0/src/serial_preempt.rs',201,'LeasedPreemptProbe::begin_leased'),
         ref('crates/robot-core/src/control_authority.rs',2067,'ControlAuthority::acquire_normal_io'),
         ref('crates/robot-core/src/control_authority.rs',2174,'motion_gate'),
         ref('crates/robot-core/src/control_authority.rs',2194,'enable_step_gate'),
         ref('crates/robot-core/src/control_authority.rs',2140,'release_normal_io_impl')],
        'PermissionEpoch/ExecutionView 不是 USB/供电/连接代次；profile 或纯 reducer 不能代替真实 authority。'),
    finding('absolute_wire_deadline_gap',
        'Velocity selector 拒 now>=来源deadline；periodic_write 设置 min(来源deadline,分派时刻+50ms) 给 probe。probe 仅 checkpoint/liveness；bus lease 直接 write_all；transport 每次调用重新计算 now+相对budget。因此尚无来源绝对截止在首字节及每个 partial write 前的拒写。',
        [ref('crates/robot-s0/src/serial_tick.rs',57,'select_periodic_output'),
         ref('crates/robot-s0/src/serial_tick.rs',583,'SerialTick::periodic_write 的 transaction_deadline'),
         ref('crates/robot-s0/src/serial_tick.rs',588,'现有注释明确非 wire 硬期限'),
         ref('crates/robot-s0/src/serial_preempt.rs',120,'PreemptProbe::should_abort'),
         ref('crates/robot-s0/src/serial_preempt.rs',145,'PreemptProbe::checkpoint'),
         ref('crates/robot-adapters/feetech/src/bus.rs',84,'BusTransactionLease::write'),
         ref('crates/robot-adapters/feetech/src/transport.rs',137,'write_all_bounded')],
        '已发送的字节不可撤回；需要分清未发送拒绝、部分 TX 超时与已完整发送后越界，不能承诺物理回滚或操作系统调用绝不超时。'),
    finding('enable_and_mode_not_wheel_safe',
        '普通 set_mode 遍历全部 joint_names；普通 Enable=true 同步全部 Present_Position→Goal_Position、等待50ms、再逐电机启扭。它既没有三轮 Goal_Velocity=0 前置，也没有三轮固件/Phase/session 合同。',
        [ref('crates/robot-adapters/feetech/src/adapter.rs',612,'ManipulatorAdapter::set_mode'),
         ref('crates/robot-adapters/feetech/src/adapter.rs',640,'ManipulatorAdapter::enable'),
         ref('crates/robot-adapters/feetech/src/adapter.rs',346,'sync_goal_to_present'),
         ref('crates/robot-s0/src/ipc_pending.rs',1030,'start_enable_owned'),
         ref('crates/robot-s0/src/ipc_pending.rs',1061,'submit_enable'),
         ref('crates/robot-s0/src/serial_tick.rs',679,'execute_serial_normal')],
        '不可把普通 Enable(true)、全9电机模式写或 Motion 租约当作底盘零速准备入口。'),
    finding('profile_value_not_session',
        '纯 profile 检查 Front8/Left7/Right9、型号777、Mode1、固件两个原始字节、完整Phase和bit3零停止、明确raw上限。Phase12 bit3=1，必拒绝零停止合同。Firmware字节相等只绑定值，不证明厂家表适用于现场固件。',
        [ref('crates/robot-adapters/feetech/src/velocity_profile.rs',24,'WheelRole::motor_id'),
         ref('crates/robot-adapters/feetech/src/velocity_profile.rs',35,'FirmwareVersion'),
         ref('crates/robot-adapters/feetech/src/velocity_profile.rs',143,'Sts3215WheelProfile::try_bind'),
         ref('crates/robot-adapters/feetech/src/velocity_profile.rs',379,'phase12_and_every_bit3_set_value_reject_zero_contract'),
         ref('crates/robot-adapters/feetech/src/registers.rs',73,'Firmware地址0/1'),
         ref('crates/robot-adapters/feetech/src/registers.rs',118,'ensure_not_diagnostic_write')],
        '现场 Firmware 未读，历史Phase12未改；没有真实固件白名单、连接代次或零停止证明。本报告不产生这些值，不要求 EEPROM 写授权。'),
    finding('numeric_and_noalloc_seam',
        'profile.try_encode_rad_s 返回已编码u16 sign-magnitude；bus.sync_write_by_id_into 需要 signed i32，encode_value 会再编码。负速度word不能直接cast给该入口。_into 使用固定栈数组；旧 sync_write_by_id 构造多个Vec。',
        [ref('crates/robot-adapters/feetech/src/velocity_profile.rs',200,'Sts3215WheelProfile::try_encode_rad_s'),
         ref('crates/robot-adapters/feetech/src/velocity_profile.rs',227,'Sts3215WheelProfile::decode_velocity_word'),
         ref('crates/robot-adapters/feetech/src/bus.rs',490,'FeetechBus::sync_write_by_id'),
         ref('crates/robot-adapters/feetech/src/bus.rs',546,'FeetechBus::sync_write_by_id_into'),
         ref('crates/robot-adapters/feetech/src/bus.rs',635,'encode_value'),
         ref('crates/robot-adapters/feetech/src/adapter.rs',542,'ManipulatorAdapter::read_state')],
        '计划优先完整检查三轮后用 decode_velocity_word(word).signed_raw→既有_into 编码，或独立 typed word 接口；只选一种表示。轮反馈当前还是raw as f32，不是profile SI反馈。'),
    finding('fast_stop_preserved',
        'SerialConvergence::step_stop→safety_stop→safety_stop_fast→sync_write_by_id_into 是 Safety 类固定buffer一次Torque_Enable=0广播。方法本身不等ACK；后续 Confirm 独立验证。',
        [ref('crates/robot-s0/src/serial_convergence.rs',774,'SerialConvergence::step_stop'),
         ref('crates/robot-adapters/feetech/src/adapter.rs',665,'ManipulatorAdapter::safety_stop'),
         ref('crates/robot-adapters/feetech/src/adapter.rs',495,'FeetechAdapter::safety_stop_fast'),
         ref('crates/robot-adapters/feetech/src/bus.rs',546,'FeetechBus::sync_write_by_id_into')],
        '范围是该 adapter 已配置ID，不能扩称整个物理bus全部电机；普通 Velocity deadline 不能阻断 Safety/Confirm。保留原收敛重试和独立停止证据，不把broadcast成功当零速/启扭ACK。'),
    finding('shared_right_usb_mixed_scope',
        '右臂现配置仅IDs1..6；历史full配置同USB 5A7C122340含IDs1..9，其中left7/back8/right9。JointCommandView 只有一个整体mode，不能静默扩为同bus臂Position+轮Velocity。',
        [ref('configs/xlerobot_right_arm.toml',18,'右臂USB/ID配置'),
         ref('configs/xlerobot_bus2_full.toml',110,'历史bus2 USB/ID配置'),
         ref('crates/robot-core/src/adapter.rs',172,'JointCommandView')],
        '必须由 root 决定现有同一物理writer的具名子集分派，或软件验证期独占wheel scope且臂实例不开串口；不新增第二writer、不修改ArmIK或历史轮名。'),
    finding('real_allocation_guard_boundary',
        'Feetech lib 中命名 alloc_free 的单测使用assert_no_alloc，但该lib test未注册全局AllocDisabler；不能据名称证明真实allocator捕获。S0 lib rt_guard 与 feetech abort_diagnostics 独立test二进制已有真实全局AllocDisabler。',
        [ref('crates/robot-adapters/feetech/src/adapter.rs',1409,'safety_stop_fast_is_alloc_free'),
         ref('crates/robot-adapters/feetech/src/lib.rs',1,'lib test未定义全局allocator'),
         ref('crates/robot-s0/src/post_e_convergence_acceptance.rs',35,'LIB_TEST_ALLOCATOR'),
         ref('crates/robot-s0/src/post_e_convergence_acceptance.rs',2400,'serial_enable_compensation_uses_real_allocator_without_allocating'),
         ref('crates/robot-adapters/feetech/tests/abort_diagnostics.rs',29,'TEST_ALLOCATOR')],
        '新真实noalloc oracle须复用对应test二进制既有allocator并留负控；不能增加冲突allocator或把纯数学无分配外推wire/worker。'),
]

seams = [
 {'name':'WheelSessionBinding（建议名，未实现）','existing_hooks':['factory.rs::build_concrete','adapter.rs::connect/disconnect'],
  'files':['crates/robot-adapters/feetech/src/factory.rs','crates/robot-adapters/feetech/src/adapter.rs','crates/robot-adapters/feetech/src/velocity_profile.rs'],
  'contract':'固定3个已检profile与真实物理连接身份/代次；观察必须来自当前唯一writer同一连接，固件及完整Phase由独立合同指定。连接/身份/USB代次变化撤销绑定；普通connected bool或authority epoch不得充当session。热路径仅借用固定值。'},
 {'name':'prepare_wheel_entries（建议名，未实现）','existing_hooks':['adapter.rs::write_command','velocity_profile.rs::try_encode_rad_s','bus.rs::sync_write_by_id_into'],
  'files':['crates/robot-adapters/feetech/src/adapter.rs'],
  'contract':'精确三维Front8/Left7/Right9速度，有限值/全部profile/raw上限/当前session/来源截止全部先验通过后才构建[(8,signed),(7,signed),(9,signed)]；固定数组和buffer，禁止独立单轮clamp，保持旧Position分支原行为。'},
 {'name':'write_all_until / read_exact_until（建议名，未实现）','existing_hooks':['transport.rs::write_all_bounded','bus.rs::BusTransactionLease::write/read','serial_preempt.rs::begin_leased'],
  'files':['crates/robot-adapters/feetech/src/transport.rs','crates/robot-adapters/feetech/src/bus.rs','crates/robot-core/src/serial_services.rs','crates/robot-s0/src/serial_preempt.rs','crates/robot-s0/src/serial_tick.rs'],
  'contract':'borrow不可刷新来源绝对deadline，min于实际事务预算；每个首字节/partial write尝试前检RobotClock并下发剩余timeout，保wanted/got和独立partial TX分类，不重发整帧。begin lease保原authority。Safety/Confirm保原fast path与预算；只有新增velocity域要求该绝对合同，旧Position语义不扩张。'},
 {'name':'prepare_zero_and_enable_wheels（建议名，未实现）','existing_hooks':['ipc_pending.rs::start_enable_owned','hard_rt_ctrl.rs::start_enable_execution/finish_enable_owned','serial_tick.rs::normal/execute_serial_normal','adapter.rs::enable'],
  'files':['crates/robot-s0/src/ipc_pending.rs','crates/robot-s0/src/hard_rt_ctrl.rs','crates/robot-s0/src/serial_tick.rs','crates/robot-adapters/feetech/src/adapter.rs'],
  'contract':'由原同域EnableExecution/EnableStep owner执行，仅三轮Goal_Velocity=0，分别真实读回或逐电机ACK形成当前ticket/session关联的Committed InternalZero；再收零ACK之后fresh HB+cmd到Ready，之后三轮TorqueEnable真实完成并经原authority finish/commit才给reducer同ticket真实Enable committed。不能用普通Motion或默认adapter.enable、不能broadcast写成功伪作ACK，也不能阻塞IPC等待无限输入。具体分阶段桥接需root先裁决。'},
 {'name':'publish_wheel_feedback（建议名，未实现）','existing_hooks':['adapter.rs::read_state','velocity_profile.rs::decode_velocity_word'],
  'files':['crates/robot-adapters/feetech/src/adapter.rs'],
  'contract':'原始PresentVelocity word与同session profile转换一起保留，SI明确为厂家名义rad/s；未绑定反馈不得假SI。旧arm read/position/ArmIK不变。'},
]

root_decisions = [
 {'id':'physical_writer_scope','question':'同一右USB如何归属一个真实writer，且三轮命令不会触发全臂模式/使能？',
  'recommended_next_scope':'下一软件小件仅在同一adapter/fixture内验证固定三轮子集；生产启用前明确现有writer内具名子集分派或专属wheel实例排他切换。不得两个S0同时开USB。',
  'material_effect':'现单mode POD及config scope不足以表示混合执行；不可据full9历史配置默认接入。'},
 {'id':'session_observation_owner','question':'哪个现有启动/重连接缝保存并验证真实USB/打开代次及三轮fresh只读观察，失效怎样传递？',
  'recommended_next_scope':'由唯一bus owner生成固定size连接代次并保存实际观察与指定合同，打开/身份变化立即撤销profile与纯reducer绑定。具体身份来源由root决定；本报告不给默认固件或Phase。',
  'material_effect':'纯ConnectionEpoch、connected bool、authority epoch均不能证明外部物理代次。'},
 {'id':'bounded_enable_bridge','question':'如何将当前同步普通Enable拆成原owner下的零准备/真实ACK/fresh输入/最终启扭完成，不伪造P1C committed？',
  'recommended_next_scope':'保持原authority token/补偿/收敛链，增加有界三轮分阶段执行 receipt；P1C各事件仅来自真实结果，Zero失败/Enable部分成功按原停止责任收敛。具体阶段state和超时责任由root定。',
  'material_effect':'当前adapter.enable(true)一次同步位置流程与P1C需要的Ready barrier不同，不能直接拼接成PASS。'},
 {'id':'absolute_wire_expiry_policy','question':'绝对来源deadline在TX中途到期时，停止下一chunk及已写字节如何分类/收敛？',
  'recommended_next_scope':'未写字节期限拒绝；partial TX保got/wanted、不得自动整帧重放，交原通信故障收敛和独立TorqueDisable；末次写后才发现越界也保失败事实。Safety/Confirm不受普通Motion期限中断。',
  'material_effect':'严格比较/相等边界/剩余timeout和外部absolute API需确定；set_timeout(relative)后重新起点不足以闭环。'},
]

fixtures = [
 {'file':'crates/robot-adapters/feetech/src/adapter.rs','line':785,'fixture':'make_adapter / make_adapter_with_calibration / MockHandle ACK与read注入',
  'reuse':['write_command_non_position_mode_is_noop_with_warning','enable_true_follows_dimos_sequence','safety_stop_fast_broadcasts_torque_disable','safety_stop_uses_fast_path_one_broadcast_frame','safety_stop_fast_before_connect_sends_all_configured_motors'],
  'new_oracles':'独立golden仅8/7/9的GoalVelocity三条；负数word防双编码；第三轮不合法前两轮也无TX；arm1..6无Mode/Torque/Goal改变；zero读回缺失/非零/错ID/坏checksum不得给Committed。'},
 {'file':'crates/robot-adapters/feetech/src/post_e_transport_acceptance.rs','line':25,'fixture':'PartialPort + RobotClock + 实际bounded helpers',
  'reuse':['write_drip_reports_actual_progress_and_tx_timeout_kind','interrupted_and_would_block_retry_only_the_remaining_budget','next_call_gets_a_fresh_budget_after_a_short_success'],
  'new_oracles':'显式absolute来源期限首写等号拒绝0字节；prepare与wire间时钟推进；partial后恰到截止不再下一chunk；WouldBlock/Interrupted不续期；已写后过期保持wanted/got；Safety不误套来源期限。'},
 {'file':'crates/robot-adapters/feetech/tests/comm_fault_transport.rs','line':143,'fixture':'LeaseTransport / LeaseProbe / 原真实authority接口',
  'reuse':['transaction_response_is_not_preempted_after_the_request_write','every_broadcast_variant_holds_one_lease_without_reading_an_ack','read_state_aborted_between_position_and_velocity_preserves_the_whole_snapshot'],
  'new_oracles':'一个完整事务原租约，连接代次改变与authority撤权按既有门拒；broadcast zero不读ACK必须另读；不把transaction response既有不中断合同扩为正常Motion无deadline。'},
 {'file':'crates/robot-s0/src/serial_tick.rs','line':800,'fixture':'RecordingAdapter + 原SerialPreemptProbe',
  'reuse':['tick_active_velocity_forwards_exact_goal_and_reads_with_independent_lease','velocity_deadline_bounds_probe_progress_without_claiming_wire_rejection','revoked_velocity_motion_keeps_independently_authorized_read','velocity_estop_uses_fast_safety_chain_without_periodic_write'],
  'new_oracles':'连接/固件/profile/来源门拒绝无TX；Ready不做普通Velocity写；Hold/Zero是三轮验证过的0；原Position和独立Read路径回归；wire绝对门明确使用新fixture，不改旧测试让其假证明。'},
 {'file':'crates/robot-s0/src/post_e_convergence_acceptance.rs','line':882,'fixture':'TickFixture / 原Enable owner/补偿/真实rt_guard allocator',
  'reuse':['actual_partial_enable_and_late_success_cannot_retire_lower_using_old_off','serial_enable_compensation_uses_real_allocator_without_allocating'],
  'new_oracles':'zeroAck错误ticket/session、Enable未committed及Lost恢复Ready不得开门；Enable失败/超时/部分启扭保原补偿与停止责任；gated output到wire全路径真实assert_no_alloc和原负控。'},
 {'file':'crates/robot-s0/tests/serial_rt_e2e.rs','line':294,'fixture':'spawn_harness 的真实IPC/RR/serial worker（mock adapter）',
  'reuse':['test_estop_topic_preempts_and_safety_state_reflects_serial_confirm'],
  'new_oracles':'后续生产IPC接入另包验收；当前5场景不证明三轮固件/USB/wire。'},
 {'file':'crates/robot-adapters/feetech/src/velocity_profile.rs','line':379,'fixture':'pure WheelObservation/WheelContract',
  'reuse':['phase12_and_every_bit3_set_value_reject_zero_contract','all_wire_words_roundtrip_in_both_units_and_preserve_negative_zero','sign_magnitude_and_exact_half_rounding_are_not_twos_complement','nonfinite_overflow_and_rawlimit_are_rejected_without_clamp'],
  'new_oracles':'现有数学门保留，session/ACK/authority另外验；测试fixture固件1.2仅样本，不升级成现场whitelist。'},
]

candidate_files = ['crates/robot-s0/src/base_ingress.rs','crates/robot-s0/src/base_ingress/tests.rs','crates/robot-s0/src/lib.rs']
candidate_pins = {rel:pin(candidate / rel) for rel in candidate_files}
assert candidate_pins[candidate_files[0]]['sha256'] == 'bac6d5df703a16ce632194f620151cef486b9117411c4719e300766cb43b6292'
assert candidate_pins[candidate_files[1]]['sha256'] == 'fccd4b1fb8dca3a9a93edc7254726fe6a8fd0c880126c4301ea68add91535e36'
assert candidate_pins[candidate_files[2]]['sha256'] == '25c42c8aa0c0ebe0f5269fb26b903abfab91354e494d675f499f7d313382f872'

head_after = read_git(['rev-parse','HEAD'])
status_after = read_git(['status','--porcelain=v1'])
for rel, before in main_pins.items():
    assert pin(main / rel) == before, rel
assert head_before == head_after and status_before == status_after == ''
report = {
 'schema':'next_serial_execution_codemap_r1', 'author':'/root/acceptance_resume',
 'created_at':stamp(), 'status':'STATIC_CODEMAP_AND_FUNCTION_PLAN_ONLY',
 'scope':'本机静态读审与target新报告；无实施、无main/candidate业务源码修改、无Cargo/SSH/UART或硬件GO。',
 'executed_checks':['主树HEAD/status首尾相同clean','本次逐项复核现有591输入清单的SHA/bytes','报告引用24文件首尾SHA/bytes一致','候选r4三源当前SHA/bytes复核'],
 'not_executed':['Linux或Mac构建/Clippy/tests','串口/Firmware/Phase/USB当前读取','Motion/Enable/Mode/EEPROM写','物理断电确认或重新值守授权'],
 'basis':{'main_head_before':head_before,'main_head_after':head_after,'git_status_before':status_before,'git_status_after':status_after,
          'source_count':len(source_map),'source_manifest_sha256':source_manifest['source_manifest_sha256'],
          'manifest_file':pin(manifest_path),'reference_source_pins':main_pins,'source_changed':False},
 'fixed_constraints':{'roles':[{'role':'Front','id':8},{'role':'Left','id':7},{'role':'Right','id':9}],
    'history_phase12':'保留历史原件、没有改写；bit3置位时不允许零停止合同',
    'firmware_current':'UNREAD_UNVERIFIED','base_live':'DEFERRED','D15':'OPEN_DEFERRED','deployable':False,
    'safety_fast_path':'TorqueDisable原链保留','legacy':'Position/ArmIK/历史轮名不变','runtime_rules':'RT不碰IPC、不Arc clone/drop、不heap allocation；不新开共享右USB writer'},
 'findings':findings,
 'p1c_candidate_only':{'pins':candidate_pins,'present_in_main':False,'status':'纯reducer r4冻结，当前Linux QA由native另包执行，本报告不推定结果',
    'hooks':[{'function':'BaseIngressReducer::observe_internal_zero_ack','line':413},
             {'function':'BaseIngressReducer::observe_enable_committed','line':455},
             {'function':'BaseIngressReducer::gated_command','line':542}],
    'boundary':'仅当前ticket/session真实Zero committed、Zero之后fresh HB+cmd到Ready、同ticket真实Enable committed后Active且当下fresh才输出POD；snapshot没有权限。调用方真实IO/authority事件桥尚未接入。'},
 'necessary_api_seams_not_implemented':seams,
 'existing_fixtures_and_proposed_oracles_not_run':fixtures,
 'root_material_decisions':root_decisions,
 'recommended_next_small_package':{
    'name':'新增明确绝对期限的串口partial-write合同，先完成软件可执行边界',
    'why':'当前明确可单独闭环的真实执行缺口是probe期限与transport相对期限之间；它不要求选择或写现场Firmware/Phase，也不赋Enable能力。',
    'files_primary':['crates/robot-adapters/feetech/src/transport.rs','crates/robot-adapters/feetech/src/bus.rs','crates/robot-adapters/feetech/src/post_e_transport_acceptance.rs'],
    'functions':['显式absolute写调用与partial-write核心','BusTransactionLease的显式有期限路径','PartialPort绝对期限/partial进度oracle'],
    'scope_boundary':'需root确定normal velocity调用如何携带绝对deadline。不得默默改变旧Position/响应完整事务、不得stub trait实现返回成功；若必须调整SerialTransport公开API及其它实现，另列真实文件数并审批该兼容影响。没有接生产velocity、session、Enable或IPC前，仅此组件的软件门。',
    'after_decisions':'再实现当前唯一writer的三轮profile/session准备和zero→Enable receipts，最后另包把P1C真实origin/生命周期接到IPC与SerialTick。不能以组件PASS称完整B1。'},
 'unverified':['实际固件及其厂家零停止语义适用性','新USB/供电连接代次与唯一writer跨实例排他','三轮zero读回/启扭ACK及真实authority提交','绝对期限首字节/途中TX实现','实际allocator覆盖的wire执行路径','真实IPC/latest-slot接入与排队重放','现场底盘运动/停止/轮单位测量','硬件失败根因及人工断电确认'],
 'delegation_note':'前peer只读CodeMap提供过函数线索；本报告由作者再次读源并绑定当前pins。续请求peer自落receipt未成功（agent thread limit reached），没有伪造peer签署或原始工具回执。',
 'readonly_git_owned_children':children,
}
report_raw = (json.dumps(report,ensure_ascii=False,indent=2)+'\n').encode()
report_path.write_bytes(report_raw)
md = f'''爸爸，当前底盘速度尚未进入串口：`FeetechAdapter::write_command` 的非 Position 分支直接返回 Ok，Velocity 只有诊断。此文件是静态 CodeMap 与函数计划，未实施、未编译、未触串口。

主树 `{head_before}`、591 输入聚合 `{source_manifest['source_manifest_sha256']}` 本次逐项复核，24 个引用文件首尾同 SHA/bytes、主树 clean。P1C r4 仍在独立候选；Linux 验证由 native 另包负责。

| 接缝 | 现有事实 | 下一步必要合同 |
| --- | --- | --- |
| 唯一 UART writer | `s0_daemon::prepare_execution` 先建同域 authority/probe，adapter 按值移入一个 serial worker | 同一右 USB 的右臂和底盘不能另开两个实例；跨实例排他与具名子集仍待 root 定案 |
| 实际 Velocity TX | `adapter.rs:575` 非 Position 无 TX | 固定 Front8/Left7/Right9，三轮全检查后固定数组 `_into`，旧 Position 不变 |
| 截止时间 | `serial_tick.rs:583` 传给 probe 的 min 期限仅约束 checkpoint/liveness；`transport.rs:137` 每调用另起相对期限 | 显式借用来源绝对期限，首字节和每次 partial write 前检查；已写字节不能撤回，不自动重放整帧 |
| Profile 与连接 | `velocity_profile.rs:143` 是纯值检查，没有 USB/连接代次或 authority | 当前唯一 writer 同连接的三轮只读身份＋指定实际固件/完整 Phase 合同，连接变化撤销 |
| 零速先于 Enable | `adapter.rs:640` 普通 Enable 是全关节位置同步后启扭 | 当前 EnableExecution/EnableStep 下三轮零写＋真实读回，关联 ticket/session；零 ACK 后 fresh HB+cmd 到 Ready，真实启扭及原 authority commit 后才 Active |
| 停止 | 原 Safety→TorqueDisable 单广播→独立 Confirm | 原快路径和故障收敛保留；normal Motion 期限不可中断 Safety/Confirm |

Profile 规定 Front8/Left7/Right9。历史 Phase12 的 bit3=1，零表示最高速度的合同会被明确拒绝；现场 Firmware 尚未读取，Phase 未改，不能填默认白名单或提前启扭。Firmware 地址0/1两个原始字节也不等于厂家资料版本字段。

数值接口必须统一：profile 返回已编码 `u16`，既有 bus `_into` 接收 signed `i32` 并再次编码。计划可在全部三轮检查后通过 `decode_velocity_word(word).signed_raw` 进入既有编码，不能把负速度 word 直接 cast 成正整数。反馈目前仍是 raw as f32，SI 反馈另需同 profile 转换。

Root 有四项实质决策：共享物理 writer 的执行范围、真实连接观察的 owner、原 Enable owner 下有界分阶段零准备桥、来源期限中途到期时 partial TX 的分类和停止责任。单整体 `JointCommandView.mode` 与当前同步 Enable 不能默认拼成臂 Position＋轮 Velocity 的混合流程。

建议先把“明确绝对期限的串口 partial-write 合同”作为软件小件，聚焦 `transport.rs`、`bus.rs` 与 `post_e_transport_acceptance.rs` 的 `PartialPort` fixture；公开 trait 兼容影响和调用域先由 root 定案。组件通过后，仍须完成 session/profile、三轮零速及 Enable receipt、P1C 真实 IPC/生命周期接入，才能验收完整 B1。

可复用夹具包括 adapter MockHandle 的 ACK/read/golden frame、PartialPort 时钟及进度、LeaseTransport 的原 authority、SerialTick RecordingAdapter、S0 TickFixture 的原 Enable owner 与停止补偿。每个夹具的现有方法和新增正负 oracle 在 JSON 逐项列出，均未重跑。真实 noalloc 应复用 S0 lib rt_guard 或 feetech `abort_diagnostics` 的既有全局 AllocDisabler；Feetech lib 单测仅有 assert_no_alloc 名称，未注册该全局 allocator，不能单凭名称当成捕获证明。

该静态计划不关闭硬件失败、D15 OPEN/DEFERRED、底盘动作 DEFERRED 或 deployable=false。源 pins、完整证据路径、必要 API 和未验证边界见 [JSON]({report_path})。
'''
md_path.write_text(md)
print(json.dumps({'json':pin(report_path),'markdown':pin(md_path),'main_source_count':len(source_map),
                  'main_source_aggregate':source_manifest['source_manifest_sha256'],
                  'source_changed':False,'git_children':len(children),'status':'STATIC_ONLY_NOT_COMPILED'},ensure_ascii=False))
