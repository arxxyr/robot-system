import hashlib
import json
import os
from pathlib import Path
import signal
import subprocess
import time

BASE = Path(__file__).resolve().parents[2]
OUT = BASE / "target/b1-p1a-origin/r3-regression"
TARGET = BASE / "target/b1-p1a-origin/cargo-target"
FILES = ["crates/robot-transport/src/origin.rs", "crates/robot-transport/src/lib.rs", "crates/robot-transport/src/sample.rs", "crates/robot-transport/src/mock.rs", "crates/robot-transport/src/iceoryx2/subscriber.rs", "crates/robot-transport/tests/publisher_origin.rs", "Cargo.lock", "rust-toolchain.toml"]
REQUESTS = []

def stop_request(signum, _frame):
    REQUESTS.append(signum)

for name in ("SIGINT", "SIGTERM", "SIGHUP", "SIGQUIT"):
    if hasattr(signal, name):
        signal.signal(getattr(signal, name), stop_request)

def save(path, value):
    with path.open("x", encoding="utf-8") as stream:
        json.dump(value, stream, ensure_ascii=False, indent=2)
        stream.write("\n")

def identity():
    result = {}
    for name in FILES:
        raw = (BASE / name).read_bytes()
        result[name] = {"sha256": hashlib.sha256(raw).hexdigest(), "bytes": len(raw)}
    return result

def log_identity(path):
    raw = path.read_bytes()
    return {"sha256": hashlib.sha256(raw).hexdigest(), "bytes": len(raw)}

STAGES = [
    ("clippy_default_all_targets", ["cargo", "+nightly", "clippy", "--locked", "-p", "robot-transport", "--all-targets", "--", "-D", "warnings"]),
    ("clippy_mock_only_all_targets", ["cargo", "+nightly", "clippy", "--locked", "-p", "robot-transport", "--no-default-features", "--features", "mock", "--all-targets", "--", "-D", "warnings"]),
    ("tests_default_full_crate", ["cargo", "+nightly", "test", "--locked", "-p", "robot-transport"]),
    ("tests_mock_only_full_crate", ["cargo", "+nightly", "test", "--locked", "-p", "robot-transport", "--no-default-features", "--features", "mock"]),
]

def run():
    original = json.loads((BASE / "target/b1-p1a-origin/r3/results.json").read_text())
    if not original.get("commands") or any(row.get("status") != "PASS" for row in original["commands"].values()):
        raise RuntimeError("专项回执尚未全部通过，禁止启动追加回归")
    OUT.mkdir(exist_ok=False)
    initial = identity()
    save(OUT / "source_before.json", initial)
    env = os.environ.copy()
    env["CARGO_TARGET_DIR"] = str(TARGET)
    records = []
    failed = False
    for name, argv in STAGES:
        if failed or REQUESTS:
            records.append({"name": name, "status": "NOT_RUN", "reason": "此前阶段失败或停止请求"})
            continue
        if identity() != initial:
            failed = True
            records.append({"name": name, "status": "NOT_RUN", "reason": "源码身份改变"})
            continue
        folder = OUT / name
        folder.mkdir()
        child = None
        wait_errors = []
        failure = None
        started = time.monotonic()
        with (folder / "stdout.log").open("xb") as stdout, (folder / "stderr.log").open("xb") as stderr:
            try:
                child = subprocess.Popen(argv, cwd=BASE, env=env, stdout=stdout, stderr=stderr)
                save(folder / "launch.json", {"argv": argv, "cwd": str(BASE), "pid": child.pid, "owner_pid": os.getpid(), "cargo_target_dir": str(TARGET)})
                print(json.dumps({"stage": name, "pid": child.pid, "status": "RUNNING"}), flush=True)
            except BaseException as error:
                failure = repr(error)
            finally:
                if child is not None:
                    while True:
                        try:
                            exit_code = child.wait(timeout=0.5)
                            break
                        except subprocess.TimeoutExpired:
                            continue
                        except BaseException as error:
                            wait_errors.append(repr(error))
                            failure = repr(error)
                            continue
                else:
                    exit_code = None
        after = identity()
        record = {"name": name, "argv": argv, "pid": child.pid if child else None, "exit_code": exit_code, "wait_reaped": child is not None and child.returncode is not None, "elapsed_seconds": time.monotonic() - started, "error": failure, "wait_errors": wait_errors, "signal_requests": list(REQUESTS), "source_unchanged": after == initial, "stdout": log_identity(folder / "stdout.log"), "stderr": log_identity(folder / "stderr.log")}
        record["status"] = "PASS" if exit_code == 0 and not failure and not REQUESTS and record["source_unchanged"] else "FAIL"
        save(folder / "result.json", record)
        records.append(record)
        print(json.dumps(record), flush=True)
        failed = record["status"] != "PASS"
    final = identity()
    save(OUT / "source_after.json", final)
    summary = {"status": "PASS" if not failed and not REQUESTS and all(row["status"] == "PASS" for row in records) and initial == final else "FAIL", "owner_pid": os.getpid(), "stages": records, "source_unchanged": initial == final, "signal_requests": REQUESTS}
    save(OUT / "results.json", summary)
    print(json.dumps({"status": summary["status"], "results": str(OUT / "results.json")}), flush=True)
    raise SystemExit(0 if summary["status"] == "PASS" else 1)

if __name__ == "__main__":
    run()
