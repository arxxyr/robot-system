import hashlib
import json
import os
from pathlib import Path
import signal
import subprocess
import time

BASE = Path(__file__).resolve().parents[2]
OUT = BASE / "target/b1-p1a-origin/r4"
TARGET = BASE / "target/b1-p1a-origin/cargo-target"
FILES = ["crates/robot-transport/src/origin.rs", "crates/robot-transport/src/lib.rs", "crates/robot-transport/src/sample.rs", "crates/robot-transport/src/mock.rs", "crates/robot-transport/src/iceoryx2/subscriber.rs", "crates/robot-transport/tests/publisher_origin.rs"]
REQUESTS = []
def stop_request(signum, _frame):
    REQUESTS.append(signum)
for name in ("SIGINT", "SIGTERM", "SIGHUP", "SIGQUIT"):
    if hasattr(signal, name):
        signal.signal(getattr(signal, name), stop_request)

def save(path, value):
    with path.open("x", encoding="utf-8") as stream:
        json.dump(value, stream, ensure_ascii=False, indent=2)
        stream.write("\n")

def source_identity():
    result = {}
    for name in FILES + ["Cargo.lock", "rust-toolchain.toml"]:
        path = BASE / name
        raw = path.read_bytes()
        result[name] = {"sha256": hashlib.sha256(raw).hexdigest(), "bytes": len(raw), "executable": bool(path.stat().st_mode & 0o100)}
    return result

def log_identity(path):
    raw = path.read_bytes()
    return {"sha256": hashlib.sha256(raw).hexdigest(), "bytes": len(raw)}

OUT.mkdir(exist_ok=False)
initial = source_identity()
save(OUT / "source_before_fmt.json", initial)
env = os.environ.copy()
env["CARGO_TARGET_DIR"] = str(TARGET)
assert env.get("TRYBUILD") != "overwrite", "禁止覆写已有trybuild golden"
save(OUT / "provenance.json", {"status": "LATEST_INSTALLED_VERIFIED_BY_USER_AND_RUNTIME", "update_executed_in_this_round": False, "user_confirmation_via_root": "用户确认本地rustup update已完成；root验证完整1d81eb4ad9cd207e3e638bd32b17ec4fce8412a6", "prior_repeat_update": "r3 FAIL：root有意SIGINT19324，真实exit-2/wait_reap，9后门NOT_RUN", "target": str(TARGET), "toolchain": "nightly", "expected_rustc_commit": "1d81eb4ad9cd207e3e638bd32b17ec4fce8412a6", "scope": "仅transport六源与已授权专项/crate软件QA，不是workspace/硬件/部署"})

STAGES = [
    ("rustc_before", ["rustc", "+nightly", "-Vv"]),
    ("cargo_before", ["cargo", "+nightly", "-V"]),
    ("rustfmt_before", ["rustfmt", "+nightly", "--version"]),
    ("clippy_before", ["cargo", "+nightly", "clippy", "--version"]),
    ("components_before", ["rustup", "component", "list", "--installed", "--toolchain", "nightly"]),
    ("scoped_rustfmt", ["rustfmt", "+nightly", "--edition", "2024", "--config", "skip_children=true"] + FILES),
    ("source_snapshot_after_fmt", ["uv", "run", "--no-project", "python", str(BASE / "target/b1-p1a-origin/capture_source_window.py"), "after_fmt"]),
    ("origin_unit_default", ["cargo", "+nightly", "test", "--locked", "-p", "robot-transport", "--lib", "origin::tests"]),
    ("origin_integration_default", ["cargo", "+nightly", "test", "--locked", "-p", "robot-transport", "--test", "publisher_origin"]),
    ("origin_integration_mock_only", ["cargo", "+nightly", "test", "--locked", "-p", "robot-transport", "--no-default-features", "--features", "mock", "--test", "publisher_origin"]),
    ("origin_integration_native_only", ["cargo", "+nightly", "test", "--locked", "-p", "robot-transport", "--no-default-features", "--features", "iceoryx2", "--test", "publisher_origin"]),
    ("origin_unit_no_backend", ["cargo", "+nightly", "test", "--locked", "-p", "robot-transport", "--no-default-features", "--lib", "origin::tests"]),
    ("origin_no_default_doctest", ["cargo", "+nightly", "test", "--locked", "-p", "robot-transport", "--doc", "origin::PublisherOrigin"]),
    ("clippy_default_all_targets", ["cargo", "+nightly", "clippy", "--locked", "-p", "robot-transport", "--all-targets", "--", "-D", "warnings"]),
    ("clippy_mock_only_all_targets", ["cargo", "+nightly", "clippy", "--locked", "-p", "robot-transport", "--no-default-features", "--features", "mock", "--all-targets", "--", "-D", "warnings"]),
    ("tests_default_full_crate", ["cargo", "+nightly", "test", "--locked", "-p", "robot-transport"]),
    ("tests_mock_only_full_crate", ["cargo", "+nightly", "test", "--locked", "-p", "robot-transport", "--no-default-features", "--features", "mock"]),
]
CLOSING = [
    ("source_snapshot_after_all_cargo", ["uv", "run", "--no-project", "python", str(BASE / "target/b1-p1a-origin/capture_source_window.py"), "after_all_cargo"]),
    ("rustfmt_after", ["rustfmt", "+nightly", "--version"]),
    ("clippy_after", ["cargo", "+nightly", "clippy", "--version"]),
    ("components_after", ["rustup", "component", "list", "--installed", "--toolchain", "nightly"]),
]

def run_one(name, argv):
    folder = OUT / name
    folder.mkdir()
    child = None
    errors = []
    failure = None
    started = time.monotonic_ns()
    with (folder / "stdout.log").open("xb") as stdout, (folder / "stderr.log").open("xb") as stderr:
        try:
            child = subprocess.Popen(argv, cwd=BASE, env=env, stdout=stdout, stderr=stderr)
            save(folder / "launch.json", {"argv": argv, "cwd": str(BASE), "pid": child.pid, "owner_pid": os.getpid(), "cargo_target_dir": str(TARGET), "started_monotonic_ns": started})
            print(json.dumps({"stage": name, "pid": child.pid, "status": "RUNNING"}), flush=True)
        except BaseException as error:
            failure = repr(error)
        finally:
            if child is not None:
                while True:
                    try:
                        code = child.wait(timeout=0.5)
                        break
                    except subprocess.TimeoutExpired:
                        continue
                    except BaseException as error:
                        errors.append(repr(error))
                        failure = repr(error)
                        continue
            else:
                code = None
    row = {"name": name, "argv": argv, "pid": child.pid if child else None, "owner_pid": os.getpid(), "exit_code": code, "wait_reaped": child is not None and child.returncode is not None, "runner_error": failure, "wait_errors": errors, "signals": list(REQUESTS), "started_monotonic_ns": started, "ended_monotonic_ns": time.monotonic_ns(), "stdout": log_identity(folder / "stdout.log"), "stderr": log_identity(folder / "stderr.log")}
    row["status"] = "PASS" if code == 0 and not failure and not REQUESTS else "FAIL"
    if name == "rustc_before" and row["status"] == "PASS":
        text = (folder / "stdout.log").read_text()
        if "commit-hash: 1d81eb4ad9cd207e3e638bd32b17ec4fce8412a6" not in text or "host: aarch64-apple-darwin" not in text or "release: 1.101.0-nightly" not in text:
            row["status"] = "FAIL"
            row["verification_error"] = "已安装compiler与root核定latest不同"
    save(folder / "result.json", row)
    print(json.dumps({"stage": name, "status": row["status"], "exit_code": code, "wait_reaped": row["wait_reaped"]}), flush=True)
    return row

rows = []
failed = False
frozen = None
for name, argv in STAGES:
    if failed or REQUESTS:
        rows.append({"name": name, "status": "NOT_RUN", "reason": "此前阶段FAIL或停止请求", "argv": argv})
        continue
    if frozen is not None and source_identity() != frozen:
        failed = True
        rows.append({"name": name, "status": "NOT_RUN", "reason": "fmt后源码身份变化", "argv": argv})
        continue
    row = run_one(name, argv)
    rows.append(row)
    failed = row["status"] != "PASS"
    if name == "scoped_rustfmt" and not failed:
        frozen = source_identity()
        save(OUT / "source_after_fmt.json", frozen)
for name, argv in CLOSING:
    if REQUESTS:
        rows.append({"name": name, "status": "NOT_RUN", "reason": "停止请求", "argv": argv})
        continue
    row = run_one(name, argv)
    rows.append(row)
    failed = failed or row["status"] != "PASS"
final = source_identity()
save(OUT / "source_after_all_checks.json", final)
unchanged = frozen is not None and frozen == final
summary = {"schema": "B1_P1A_INSTALLED_LATEST_SCOPED_QA_R4", "status": "PASS" if not failed and not REQUESTS and unchanged else "FAIL", "toolchain_provenance": "LATEST_INSTALLED_VERIFIED_BY_USER_AND_RUNTIME", "update_executed": False, "commands": rows, "source_unchanged_after_fmt": unchanged, "signals": REQUESTS, "target": str(TARGET), "hardware_actions": 0, "not_workspace_quality_gate": True}
save(OUT / "results.json", summary)
print(json.dumps({"status": summary["status"], "results": str(OUT / "results.json")}), flush=True)
raise SystemExit(0 if summary["status"] == "PASS" else 1)
