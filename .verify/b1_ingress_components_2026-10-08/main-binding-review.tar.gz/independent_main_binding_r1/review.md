爸爸，主树整合和提交前同源绑定独核通过。fresh Git inventory 的596输入逐项bytes/SHA/可执行位与r5完全一致，聚合b919cd32；相对591基线只变11路径/新增5路径，固件7源及serial_services保持。

本次主树实际fmt exit0及7个记录child自然wait/reap，前后源相同；本机rustc1d81/Cargo首尾字节相同。Linux r5已有实际fmt→根Clippy与组合Clippy，同596和同编译器提交身份可绑定当前主树；没有冒称本机执行S0根Clippy，也不重计测试。

此前native/静态reviews保持原字节。本次不重做源码或native审，未执行Cargo/SSH/UART。阶段封包/summary仍待独核；完整B1运行接入、硬件、D15/旧FAIL与deployable=false边界保持。
