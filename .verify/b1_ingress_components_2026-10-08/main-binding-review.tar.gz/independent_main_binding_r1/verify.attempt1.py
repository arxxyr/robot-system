import datetime
import hashlib
import json
import stat
import subprocess
from pathlib import Path

root=Path('/Users/loosqk/repo/rust/robot-system')
top=root/'target/b1_freshness_integration_2026-10-08'
out=top/'independent_main_binding_r1'

def ref(path):
    data=path.read_bytes()
    return {'path':str(path),'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest(),'mode':stat.S_IMODE(path.stat().st_mode)}

def load(path):
    def pairs(rows):
        result={}
        for k,v in rows:
            assert k not in result
            result[k]=v
        return result
    return json.loads(path.read_text(),object_pairs_hook=pairs)

def digest(value):
    return hashlib.sha256(json.dumps(value,sort_keys=True,separators=(',',':'),ensure_ascii=False).encode()).hexdigest()

expected=load(top/'native-r5/expected_source.json')
integration=load(top/'root_integration_r1.json')
binding=load(top/'root_precommit_quality_binding_r1.json')
native_quality_path=top/'native-r5/precommit_quality_binding.json'
native=load(native_quality_path)
prior=ref(top/'independent_native_r5/review.json')
assert prior['sha256']=='ea62f8af800fea05392776ce381508c389594236ada5d23383aa47e7a6d3e301'
assert binding['native_actual_quality_binding']==native and ref(native_quality_path)['sha256']==binding['native_quality_binding_sha256']=='2beec92b45a34d3813b1ff7da962924a40123e22f3db4b82918c4222bae463f7'
assert integration['status']=='PASS_EXACT_ELEVEN_OVERLAYS_SAME_NATIVE_596'
assert binding['status']=='PASS_MAIN_FMT_SAME_596_AND_ACTUAL_NATIVE_FMT_CLIPPY'
assert integration['after']==expected and expected['source_manifest_sha256']==digest(expected['files'])=='b919cd320dd81693ae49612dcd0778b98e6ee97191d2344bdf87cefd69c2eed0'
assert len(integration['before']['files'])==591 and len(expected['files'])==596
differences=[p for p in sorted(set(integration['before']['files'])|set(expected['files'])) if integration['before']['files'].get(p)!=expected['files'].get(p)]
assert len(differences)==11 and set(differences)==set(integration['paths'])
assert len(set(expected['files'])-set(integration['before']['files']))==5

children=[]
for label,argv in [('inventory',['git','ls-files','-z','--cached','--others','--exclude-standard']),('head',['git','rev-parse','HEAD'])]:
    child=subprocess.Popen(argv,cwd=root,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
    stdout,stderr=child.communicate()
    assert child.returncode==0 and not stderr
    children.append({'name':label,'argv':argv,'pid':child.pid,'exit_code':child.returncode,'natural_wait_reap':True})
    if label=='inventory': inventory=stdout.decode().rstrip('\0').split('\0')
    else: head=stdout.decode().strip()
assert len(inventory)==len(set(inventory))
names=sorted(p for p in inventory if any(p==d or p.startswith(d+'/') for d in expected['domains']))
assert set(names)==set(expected['files']) and len(names)==596
fresh={}
for name in names:
    path=root/name
    assert path.is_file() and not path.is_symlink()
    metadata=ref(path)
    fresh[name]={'sha256':metadata['sha256'],'bytes':metadata['bytes'],'executable':bool(path.stat().st_mode&stat.S_IXUSR)}
assert fresh==expected['files']
assert head==integration['base_head']=='e6d6d111091b29b791bae0375b209692fdf3eed5'
for item in integration['firmware_seven_preserved']:
    assert all(integration['before']['files'][item['path']][k]==fresh[item['path']][k]==item[k] for k in ['bytes','sha256','executable'])
serial='crates/robot-core/src/serial_services.rs'
assert integration['before']['files'][serial]==fresh[serial] and fresh[serial]['sha256']=='70d4de1c8beda2ab4be5b025df70663cf885f681305fc4cef1f16508a5a82a4a'

main_raw=top/'root_precommit_r1'
assert load(main_raw/'source_before.json')==load(main_raw/'source_after.json')==expected
records=binding['children']
order=['inventory_before','rustc_before','cargo_before','fmt','inventory_after','rustc_after','cargo_after']
assert [x['name'] for x in records]==order and len({x['pid'] for x in records})==7
log_refs=[]
for row in records:
    assert row['exit_code']==0 and row['real_wait_reap'] is True
    for stream in ('stdout','stderr'):
        path=Path(row[stream]);assert path==main_raw/(row['name']+'.'+stream)
        log_refs.append(ref(path))
        if stream=='stderr': assert not path.read_bytes()
assert records[3]['argv']==['cargo','fmt','--all']
compiler=(main_raw/'rustc_before.stdout').read_bytes();cargo=(main_raw/'cargo_before.stdout').read_bytes()
assert compiler==(main_raw/'rustc_after.stdout').read_bytes() and compiler.decode()==binding['compiler']
assert cargo==(main_raw/'cargo_after.stdout').read_bytes() and cargo.decode()==binding['cargo']
assert b'commit-hash: 1d81eb4ad9cd207e3e638bd32b17ec4fce8412a6\n' in compiler and b'host: aarch64-apple-darwin\n' in compiler
assert native['actual_compiler']['commit_hash']=='1d81eb4ad9cd207e3e638bd32b17ec4fce8412a6'
assert native['actual_cargo']==cargo.decode()
assert native['source_aggregate']==digest(fresh) and native['fmt_ended_monotonic_ns']<=native['root_clippy_started_monotonic_ns']
driver=(top/'root_fmt_and_quality_binding_r1.py').read_text()
assert "child = subprocess.Popen" in driver and 'code = child.wait()' in driver and "'RUSTUP_TOOLCHAIN': 'nightly'" in driver
assert [x['argv'] for x in integration['git_children']]==[['git','rev-parse','HEAD'],['git','status','--porcelain'],['git','ls-files','-z','--cached','--others','--exclude-standard'],['git','ls-files','-z','--cached','--others','--exclude-standard']]
assert all(x['exit_code']==0 and x['real_wait_reap'] is True for x in integration['git_children'])

review={
    'schema':'B1_INGRESS_MAIN_INTEGRATION_INDEPENDENT_REVIEW_R1',
    'status':'PASS_MAIN_596_EXACT_AND_NATIVE_PRECOMMIT_QUALITY_BOUND',
    'created_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'root_integration':ref(top/'root_integration_r1.json'),
    'root_precommit_binding':ref(top/'root_precommit_quality_binding_r1.json'),
    'prior_native_review_unchanged':prior,
    'native_precommit':ref(native_quality_path),
    'source':{'current_head':head,'count':596,'aggregate':digest(fresh),'fresh_inventory_unique':True,'every_source_bytes_sha_exec_exact_r5':True,'eleven_changes':differences,'five_new_source_paths':sorted(set(expected['files'])-set(integration['before']['files'])),'all_firmware7_before_after_current_exact':True,'serial_services_before_after_current_exact':fresh[serial]},
    'main_format':{'actual_exit':0,'actual_children':7,'order':order,'all_recorded_natural_wait_reap':True,'source_before_after_exact_r5':True,'compiler_before_after_bytes_equal':True,'compiler':compiler.decode(),'cargo':cargo.decode(),'actual_driver':ref(top/'root_fmt_and_quality_binding_r1.py'),'raw_log_identity':log_refs},
    'quality_binding':'本机主树实际fmt；Linux r5已实际fmt→根Clippy及组合根Clippy，输入全596同源且编译器同1d81/Cargo相同，完成future-main同输入绑定。没有冒称本机执行不支持S0根Clippy，也不新增质量门次数。',
    'integration_git_children_recorded_reaped':4,
    'review_fresh_readonly_children':children,
    'blockers':[],
    'remaining':['阶段summary与归档封包范围独审待其就绪。','不重跑静态/native QA，不将软件组件整合称完整B1运行接入/硬件/生产替换；历史FAIL/D15 OPEN/DEFERRED/deployable=false保持。','无本轮完整workspace/release/H2/RT硬件或现场FW读回；无UART/正式安装/部署/push。'],
    'operations':{'SSH':0,'Cargo':0,'UART':0,'source_edits':0,'old_review_or_evidence_edits':0}
}
out.mkdir(parents=True,exist_ok=True)
(out/'review.json').write_text(json.dumps(review,ensure_ascii=False,indent=2)+'\n')
(out/'review.md').write_text('爸爸，主树整合和提交前同源绑定独核通过。fresh Git inventory 的596输入逐项bytes/SHA/可执行位与r5完全一致，聚合b919cd32；相对591基线只变11路径/新增5路径，固件7源及serial_services保持。\n\n本次主树实际fmt exit0及7个记录child自然wait/reap，前后源相同；本机rustc1d81/Cargo首尾字节相同。Linux r5已有实际fmt→根Clippy与组合Clippy，同596和同编译器提交身份可绑定当前主树；没有冒称本机执行S0根Clippy，也不重计测试。\n\n此前native/静态reviews保持原字节。本次不重做源码或native审，未执行Cargo/SSH/UART。阶段封包/summary仍待独核；完整B1运行接入、硬件、D15/旧FAIL与deployable=false边界保持。\n')
(out/'index.json').write_text(json.dumps({'schema':'B1_MAIN_BINDING_REVIEW_INDEX','files':[ref(out/'review.json'),ref(out/'review.md'),ref(out/'verify.py')]},ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'status':review['status'],'files':[ref(out/'review.json'),ref(out/'review.md'),ref(out/'index.json')]},ensure_ascii=False,indent=2))
