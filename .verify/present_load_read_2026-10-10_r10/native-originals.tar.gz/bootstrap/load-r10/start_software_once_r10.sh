#!/bin/bash
set -eu
export PYTHONDONTWRITEBYTECODE=1
exec /home/loosqk/.local/share/uv/python/cpython-3.12.13-linux-aarch64-gnu/bin/python3 - <<'PYREMOTE'
import hashlib,json,os,subprocess,time
from pathlib import Path
base=Path('/home/loosqk/robot-checks/position-return-20261010-r1/position-return-r7');boot=base/'bootstrap/load-r10'
inputs=json.loads((boot/'inputs_r10.json').read_bytes());assert inputs['approved_by']=='root'
for name,ref in inputs['software_sources'].items():
 path=boot/name;raw=path.read_bytes();assert path.is_file() and not path.is_symlink() and len(raw)==ref['bytes'] and hashlib.sha256(raw).hexdigest()==ref['sha256']
assert (base/'source').is_dir() and not (base/'load-software-r10').exists() and not (base/'load-readback-tool-r10').exists()
argv=['tmux','new-session','-d','-s','position-load-software-20261010-r10','-P','-F','#{session_name} #{window_id} #{pane_id} #{pane_pid}','bash '+str(boot/'launch_software_r10.sh')]
started=time.time_ns();child=subprocess.Popen(argv,stdin=subprocess.DEVNULL,stdout=subprocess.PIPE,stderr=subprocess.PIPE);out,err=child.communicate();code=child.wait()
row={'argv':argv,'pid':child.pid,'started_ns':started,'finished_ns':time.time_ns(),'exit_code':code,'wait_returncode':code,'reaped':True,'stdout':out.decode(),'stderr':err.decode(),'signals_sent':[],'input_sha256':hashlib.sha256((boot/'inputs_r10.json').read_bytes()).hexdigest()}
with (boot/'tmux-start-r10.json').open('x') as stream:json.dump(row,stream,ensure_ascii=False,indent=2);stream.write('\n');stream.flush();os.fsync(stream.fileno())
print(json.dumps(row,ensure_ascii=False),flush=True)
assert code==0 and not err

PYREMOTE
