#!/bin/bash
set -eu
export PATH=/home/loosqk/.cargo/bin:/home/loosqk/.local/bin:$PATH
export PYTHONDONTWRITEBYTECODE=1
exec /home/loosqk/.local/share/uv/python/cpython-3.12.13-linux-aarch64-gnu/bin/python3 - <<'END_PY'
# 本轮一次非 UART 事实探针；复用既验只读命令与自然 wait 方法，不生成现场或 GO。
import hashlib, json, os, signal, stat, struct, subprocess, sys, threading, time
from pathlib import Path
sys.dont_write_bytecode = True
BASE = Path('/home/loosqk/robot-checks/h2-exit-observation-20261009-r1')
ROOT = BASE / 'source'
FORMAL = Path('/home/loosqk/repo/robot/robot-system')
HEAD = '894084738d95a7239611c2b8fbecfe081d3a7fc9'
PROFILES = {
    side: {'device': '/dev/serial/by-id/usb-1a86_USB_Single_Serial_' + serial + '-if00',
           'serial': serial, 'trust': Path('/var/lib/robot/xlerobot_' + side), 'count': count}
    for side, serial, count in (('left', '5A7C121427', 8), ('right', '5A7C122340', 9))
}
UNITS = tuple('xlerobot-' + role + '-' + side + ('-arm' if role == 's0' else '') + '.service'
              for role in ('gateway', 's1', 's0') for side in ('left', 'right'))
OLD_UNITS = ()
TOOLS = {
'position_f201': {'path': '/home/loosqk/robot-checks/h2-serial-recovery-20260930-r1/readback-tool-r1/feetech_poke',
 'sha256': 'f2014ee4008311e7a8725235a39f0d1b3913391f17cbd977b7441f120539114b', 'bytes': 1469904},
'read_raw_13c97115': {'path': '/home/loosqk/robot-checks/h2-right-ready-20261009-r1/readback-tool-r1/feetech_poke',
 'sha256': '13c97115b89d9f8780ea8b9cac80a091ddcc2b73549d34b2d5cbad83c718ffe1', 'bytes': 1510912},
}
result = {'schema': 'MAINTENANCE_NON_UART_CURRENT_FACTS_20261010_R1', 'read_only': True,
 'status': 'RUNNING', 'started_ns': time.time_ns(), 'started_monotonic_ns': time.monotonic_ns(),
 'commands': [], 'checks': [], 'errors': [], 'received_signals': [],
 'uart_open_or_read': False, 'hardware_writes': 0, 'physical_facts': 'NOT_COLLECTED',
 'authorization': 'NOT_AUTHORIZED', 'elf_executions': 0}
stop = False
driver = None
binaries = []
children = []
FORMAL_FILES = {'installed:robot_rpc_gateway': {'path': '/home/loosqk/repo/robot/robot-system/target/release/robot_rpc_gateway', 'sha256': '9e8d029c30472bcd5371b6ae1fb6e4f98446086f420c567d11891dab81cc8d78', 'bytes': 5883280, 'uid': 1000, 'gid': 1000, 'mode': 509}, 'installed:s0_daemon': {'path': '/home/loosqk/repo/robot/robot-system/target/release/s0_daemon', 'sha256': '461aec751fc5a41a24ab4dcc3778ca1e88783c4c96467254419f7bf13d1fde7f', 'bytes': 3968152, 'uid': 1000, 'gid': 1000, 'mode': 509}, 'installed:s1_daemon': {'path': '/home/loosqk/repo/robot/robot-system/target/release/s1_daemon', 'sha256': '1c9037443f9786f09631705bd8800bc5f85333a45c7e9b08d6fcfaf26738de93', 'bytes': 4033312, 'uid': 1000, 'gid': 1000, 'mode': 509}, 'installed:xlerobot_deploy': {'path': '/home/loosqk/repo/robot/robot-system/target/release/xlerobot_deploy', 'sha256': '7d0cfa3da22610e9a34749d1fbb0d081239a728ed1a30cb9836e01c909dff5c3', 'bytes': 1818776, 'uid': 1000, 'gid': 1000, 'mode': 509}}



def require(value, message):
    if not value:
        raise ValueError(message)

def note_error(phase, error):
    result['errors'].append({'phase': phase, 'error': repr(error), 'at_ns': time.time_ns()})

def handler(signum, frame):
    global stop
    stop = True
    result['received_signals'].append({'name': signal.Signals(signum).name, 'at_ns': time.time_ns()})

def within_budget():
    return time.monotonic_ns() - result['started_monotonic_ns'] <= 600_000_000_000

def collect_owned_child(child, input_raw, row):
    # 无 timeout/kill。communicate 异常后仅接管同一个 child 的管道并真实 wait，不重启命令。
    stdout, stderr = b'', b''
    row['communicate_errors'] = []
    try:
        stdout, stderr = child.communicate(input_raw)
    except BaseException as error:
        row['communicate_errors'].append(repr(error))
        if child.stdin is not None and not child.stdin.closed:
            try:
                child.stdin.close()
            except BaseException as close_error:
                row['communicate_errors'].append(repr(close_error))
        values = {}
        def drain(name, stream):
            try:
                values[name] = b'' if stream is None or stream.closed else stream.read()
            except BaseException as drain_error:
                values[name] = b''
                row['communicate_errors'].append(repr(drain_error))
        drains = [threading.Thread(target=drain, args=(name, stream))
                  for name, stream in (('stdout', child.stdout), ('stderr', child.stderr))]
        for thread in drains:
            thread.start()
        while True:
            try:
                child.wait()
                break
            except BaseException as wait_error:
                row['communicate_errors'].append(repr(wait_error))
        for thread in drains:
            while True:
                try:
                    thread.join()
                    break
                except BaseException as join_error:
                    row['communicate_errors'].append(repr(join_error))
        stdout, stderr = values['stdout'], values['stderr']
    finally:
        while True:
            try:
                row['wait_returncode'] = child.wait()
                row['reaped'] = True
                break
            except BaseException as wait_error:
                row['communicate_errors'].append(repr(wait_error))
    for stream in (child.stdin, child.stdout, child.stderr):
        if stream is not None and not stream.closed:
            try:
                stream.close()
            except BaseException as close_error:
                row['communicate_errors'].append(repr(close_error))
    return stdout, stderr

def command(argv, code=0, input_raw=None, cleanup=False):
    argv = [str(a) for a in argv]
    require(allowed_command(argv), '非批准只读命令：' + repr(argv))
    if not cleanup:
        require(not stop and within_budget(), '已停止/已超过600秒，拒绝后续命令')
    row = {'argv': argv, 'started_ns': time.time_ns(), 'started_monotonic_ns': time.monotonic_ns(),
           'pid': None, 'reaped': False, 'signals_sent': [], 'cleanup': cleanup}
    result['commands'].append(row)
    child = subprocess.Popen(argv, stdin=subprocess.PIPE if input_raw is not None else subprocess.DEVNULL,
                             stdout=subprocess.PIPE, stderr=subprocess.PIPE, start_new_session=True,
                             env={**os.environ, 'GIT_OPTIONAL_LOCKS': '0', 'LC_ALL': 'C'})
    row['pid'] = child.pid
    children.append((child, row))
    stdout, stderr = collect_owned_child(child, input_raw, row)
    elapsed = time.monotonic_ns() - row['started_monotonic_ns']
    row.update(exit_code=child.returncode, finished_ns=time.time_ns(), elapsed_ns=elapsed,
               child_end_class='EXIT_STATUS' if child.returncode >= 0 else 'SIGNAL',
               stdout=stdout.decode(errors='replace'), stderr=stderr.decode(errors='replace'),
               stdout_sha256=hashlib.sha256(stdout).hexdigest(), stderr_sha256=hashlib.sha256(stderr).hexdigest(),
               stdout_bytes=len(stdout), stderr_bytes=len(stderr))
    require(not row['communicate_errors'], 'communicate异常已接管并回收：' + repr(row))
    require(elapsed <= 2_000_000_000, '自有child超2秒预算，已真实wait/reap；不启动后续READ')
    require(child.returncode == code and stderr == b'', '只读命令失败：' + repr(row))
    return row, stdout

def read_regular(path, allow_hardlink=False):
    require(path.is_absolute() and path == path.resolve(), '非规范文件路径')
    before = path.lstat()
    require(stat.S_ISREG(before.st_mode) and (allow_hardlink or before.st_nlink == 1), '非批准普通文件：' + str(path))
    fd = os.open(path, os.O_RDONLY | os.O_NOFOLLOW | os.O_CLOEXEC)
    try:
        opened = os.fstat(fd)
        require((before.st_dev, before.st_ino) == (opened.st_dev, opened.st_ino), '文件身份变化')
        with os.fdopen(fd, 'rb', closefd=False) as stream:
            raw = stream.read()
        after = os.fstat(fd)
        require((opened.st_size, opened.st_mtime_ns, opened.st_ctime_ns) ==
                (after.st_size, after.st_mtime_ns, after.st_ctime_ns), '读取期间文件变化')
    finally:
        os.close(fd)
    return raw, opened

def check(name, fn, exhaustive=False):
    row = {'name': name, 'status': 'FAIL', 'started_ns': time.time_ns()}
    result['checks'].append(row)
    try:
        row['value'] = fn()
        require(not isinstance(row['value'], dict) or row['value'].get('valid') is not False, '逐项检查有失败，保留完整结果')
        row['status'] = 'PASS'
        return row['value']
    except BaseException as error:
        row['error'] = repr(error)
        note_error(name, error)
        if not exhaustive:
            raise
    finally:
        row['finished_ns'] = time.time_ns()

def services(cleanup=False):
    prefix = 'after' if cleanup else 'before'
    argv = ['systemctl', 'show', *UNITS, '--property=Id,LoadState,ActiveState,SubState,MainPID']
    shown = check(prefix + '_service_show', lambda: command(argv, cleanup=cleanup)[1].decode(), cleanup)
    # child失败时仍用已保留的完整stdout逐unit核实；不能由此把命令失败改成PASS。
    retained = result['commands'][-1] if result['commands'] and result['commands'][-1]['argv'] == argv else {}
    raw_text = shown if shown is not None else retained.get('stdout', '')
    value = {'raw_show': raw_text, 'show_success': shown is not None, 'units': {}}
    blocks = raw_text.strip().split('\n\n')
    def unit(name):
        matches = [block for block in blocks if 'Id=' + name in block.splitlines()]
        require(len(matches) == 1, '服务Id缺失/重复：' + name)
        fields = {}
        for line in matches[0].splitlines():
            key, content = line.split('=', 1)
            require(key not in fields, '服务字段重复：' + name)
            fields[key] = content
        valid = (set(fields) == {'Id', 'LoadState', 'ActiveState', 'SubState', 'MainPID'}
                 and fields.get('LoadState') == 'loaded' and fields.get('ActiveState') == 'inactive'
                 and fields.get('SubState') == 'dead' and fields.get('MainPID') == '0')
        return {'fields': fields, 'valid': valid}
    for name in UNITS:
        value['units'][name] = check(prefix + '_service_' + name, lambda name=name: unit(name), cleanup)
    def complete_unit_set():
        ids = [line[3:] for block in blocks for line in block.splitlines() if line.startswith('Id=')]
        require(len(ids) == len(UNITS) and set(ids) == set(UNITS), '六服务清单缺失/多项')
        return ids
    value['exact_unit_set'] = check(prefix + '_service_exact_set', complete_unit_set, cleanup)
    value['valid'] = value['show_success'] and value['exact_unit_set'] is not None and all(v is not None for v in value['units'].values())
    return value

def device(side, cleanup=False):
    profile = PROFILES[side]
    row, raw = command(['udevadm', 'info', '--query=property', '--name', profile['device']], cleanup=cleanup)
    lines = raw.decode().splitlines()
    for key, value in {'ID_VENDOR_ID': '1a86', 'ID_MODEL_ID': '55d3', 'ID_SERIAL_SHORT': profile['serial'], 'ID_USB_DRIVER': 'cdc_acm'}.items():
        require([l for l in lines if l.startswith(key + '=')] == [key + '=' + value], 'USB身份错误')
    path = Path(profile['device'])
    link, m = path.lstat(), path.stat()
    require(stat.S_ISLNK(link.st_mode) and stat.S_ISCHR(m.st_mode) and os.access(path, os.R_OK | os.W_OK), 'USB类型/权限错误')
    return {'device': str(path), 'resolved': str(path.resolve()), 'rdev': m.st_rdev, 'mode': stat.S_IMODE(m.st_mode),
            'uid': m.st_uid, 'gid': m.st_gid, 'device_inode': m.st_ino, 'link_inode': link.st_ino,
            'link_target': os.readlink(path), 'udev_command': row}

def holder(path, elevated, cleanup=False):
    require(path.exists(), '持有者路径缺失：' + str(path))
    row, raw = command((['sudo', '-n'] if elevated else []) + ['fuser', str(path)], 1, cleanup=cleanup)
    require(raw == b'', '串口/锁有持有者')
    return row

def allowed_command(argv):
    devices = {p['device'] for p in PROFILES.values()}
    holder_paths = devices | {str(p['trust'] / name) for p in PROFILES.values() for name in ('rx_trust.lock', 'estop_latch.lock')}
    if argv[:2] == ['git', '-C'] and len(argv) >= 4 and argv[2] in (str(ROOT), str(FORMAL)):
        return (argv[3:] in (['rev-parse', 'HEAD'], ['status', '--porcelain=v1', '--untracked-files=all'])
                or len(argv) == 5 and argv[3] == 'show' and argv[4] in
                ('HEAD:scripts/run_post_e_h2.py', 'HEAD:scripts/post_e_h2_report.py', 'HEAD:scripts/post_e_h2_artifacts.py'))
    if argv == ['systemctl', 'show', *UNITS, '--property=Id,LoadState,ActiveState,SubState,MainPID']:
        return True
    if len(argv) == 4 and argv[:2] == ['systemctl', 'show'] and argv[2] in OLD_UNITS and argv[3] == '--property=Id,LoadState,ActiveState,SubState,MainPID':
        return True
    if len(argv) == 5 and argv[:4] == ['udevadm', 'info', '--query=property', '--name']:
        return argv[4] in devices
    if len(argv) == 2 and argv[0] == 'fuser':
        return argv[1] in holder_paths
    if len(argv) == 4 and argv[:3] == ['sudo', '-n', 'fuser']:
        return argv[3] in holder_paths
    return driver is not None and argv == ['sudo', '-n', '/usr/bin/python3', '-I', '-S', '-c', driver.PROC_PROBE_CODE]

def processes(cleanup=False):
    require(driver is not None, '既验driver未加载，进程门不能假称通过')
    def proc_probe(candidates):
        request = {'schema': 'P7_PROC_PROBE_V1', 'candidates': candidates}
        row, raw = command(['sudo', '-n', '/usr/bin/python3', '-I', '-S', '-c', driver.PROC_PROBE_CODE],
                           input_raw=json.dumps(request).encode(), cleanup=cleanup)
        return {'request': request, 'exit_code': row['exit_code'], 'response': json.loads(raw),
                'stdout': row['stdout'], 'stderr': row['stderr'], 'pid': row['pid'], 'reaped': row['reaped']}
    snap = driver.process_snapshot(-1, BASE / 'right-h2-run-02', binaries, probe_runner=proc_probe)
    require(snap['clean'], '控制/READ进程残留或身份不可读')
    return snap


def identity():
    value = {'hostname': os.uname().nodename, 'uid': os.getuid(), 'euid': os.geteuid(),
             'gid': os.getgid(), 'machine': os.uname().machine,
             'boot_id': Path('/proc/sys/kernel/random/boot_id').read_text().strip(),
             'python_executable': sys.executable}
    require(value['hostname'] == 'ubuntu' and value['machine'] == 'aarch64'
            and value['uid'] == value['euid'] == value['gid'] == 1000, 'Orin身份错误')
    return value

def bootstrap():
    global driver, binaries
    helper = BASE / 'bootstrap/control-v3/prelaunch_go.py'
    require(hashlib.sha256(read_regular(helper)[0]).hexdigest() ==
            '8121c8e8454d5a06dfa1f828ca85417917a0cdcd756d222717af89adf1024b77', '既验helper身份变化')
    sys.path.insert(0, str(helper.parent))
    import prelaunch_go
    prelaunch_go.git = lambda root, *args: command(['git', '-C', str(root), *args])[1]
    driver, hashes = prelaunch_go.tracked_driver(ROOT / 'scripts/run_post_e_h2.py', ROOT, HEAD)
    require(hashes == {'run_post_e_h2.py': '3b69527eb66115a3770b96ab55aa06d99716270399bb5cf2b0d84c1c9c51b9ae',
        'post_e_h2_report.py': 'bd35923146c3841ec5f4547b85b99494abbd93970cb1b805ce0fb7692b368387',
        'post_e_h2_artifacts.py': 'bd2b3f7bb8527cd9ecec73894171638e9cf378656b89e284a585c3baa37b8731'}, 'driver/helper身份变化')
    # 旧产物名册仅用于进程路径匹配，不读取旧 GO/现场回执，不产生动作授权。
    references = {
      'production': {'path': str(BASE / 'release-32d-r2/production.json'), 'sha256': 'bf61ac0a2cf16c959c7f970b9649a4cd68339a4f3d48605e778484d1e757a4ce'},
      'measurement': {'path': str(BASE / 'release-32d-r2/measurement.json'), 'sha256': '831464669486870c7180a6e7ed94c05352baf6981f0abed0b5089f7401a4115c'}}
    manifests = {k: prelaunch_go.reference(v) for k,v in references.items()}
    binaries = [Path(r['path']) for m in manifests.values() for r in m['artifacts'].values()]
    binaries += [Path(v['path']) for v in FORMAL_FILES.values()]
    binaries += [Path(v['path']) for v in TOOLS.values()]
    binaries += [ROOT / 'scripts/run_post_e_h2.py',
        Path('/home/loosqk/robot-checks/feetech-poke-raw-20261008-r1/artifact/feetech_poke')]
    require(driver.UNITS == UNITS, '服务白名单变化')
    return {'source_head': HEAD, 'driver_helpers': hashes, 'process_binary_paths': list(map(str,binaries)),
            'prior_manifest_use': 'PATH_MATCHING_ONLY_NOT_AUTHORIZATION'}

def files():
    rows = {}
    for name, expected in {**FORMAL_FILES, **TOOLS}.items():
        path = Path(expected['path'])
        raw, metadata = read_regular(path, allow_hardlink=name.startswith('installed:'))
        row = {'path': str(path), 'sha256': hashlib.sha256(raw).hexdigest(), 'bytes': len(raw),
               'uid': metadata.st_uid, 'gid': metadata.st_gid, 'mode': stat.S_IMODE(metadata.st_mode),
               'device': metadata.st_dev, 'inode': metadata.st_ino,
               'mtime_ns': metadata.st_mtime_ns, 'ctime_ns': metadata.st_ctime_ns,
               'elf_machine': struct.unpack_from('<H',raw,18)[0]}
        require(raw[:6] == b'\x7fELF\x02\x01' and row['elf_machine'] == 183
                and os.access(path,os.X_OK), 'ELF类型/权限变化')
        require(all(row[k] == expected[k] for k in expected if k != 'path'), '冻结文件身份变化：'+name)
        rows[name] = row
    return rows

try:
    for signum in (signal.SIGINT,signal.SIGTERM,signal.SIGHUP,signal.SIGQUIT):
        signal.signal(signum,handler)
    result['identity_before'] = check('identity',identity)
    result['bootstrap'] = check('bootstrap',bootstrap)
    result['formal_head'] = command(['git','-C',str(FORMAL),'rev-parse','HEAD'])[1].decode().strip()
    require(result['formal_head'] == 'ca14f0e6cf6df8ecc6baaaa8dff2dddb64abbd0a','正式HEAD变化')
    result['formal_status'] = command(['git','-C',str(FORMAL),'status','--porcelain=v1','--untracked-files=all'])[1].decode()
    require(result['formal_status'] == '', '正式源码非clean')
    result['files_before'] = check('file_identities_before',files)
    result['services'] = check('six_services',services)
    result['devices'] = {side: check(side+'_usb',lambda side=side:device(side)) for side in PROFILES}
    holder_paths = [Path(p['device']) for p in PROFILES.values()]
    holder_paths += [p['trust']/name for p in PROFILES.values() for name in ('rx_trust.lock','estop_latch.lock')]
    result['holders'] = [holder(path,elevated) for path in holder_paths for elevated in (False,True)]
    result['processes'] = check('known_control_and_readback_processes',processes)
    result['files_after'] = check('file_identities_after',files)
    result['identity_after'] = check('identity_after',identity)
    require(result['files_before'] == result['files_after'] and result['identity_before'] == result['identity_after'], '批次前后文件/boot/运行身份变化')
    require(not stop and within_budget() and all(row['reaped'] for row in result['commands']), '收到信号/预算或回收失败')
    result['status'] = 'PASS_NON_UART_CURRENT_FACTS'
except BaseException as error:
    note_error('probe',error)
    result['status'] = 'FAIL_NON_UART_CURRENT_FACTS'
finally:
    for child,row in children:
        if not row['reaped']:
            row['wait_returncode'] = child.wait()
            row['reaped'] = True
    result['finished_ns'] = time.time_ns()
    result['elapsed_ns'] = time.monotonic_ns()-result['started_monotonic_ns']
    print(json.dumps(result,ensure_ascii=False,allow_nan=False),flush=True)
raise SystemExit(0 if result['status'] == 'PASS_NON_UART_CURRENT_FACTS' else 1)

END_PY
