#!/bin/bash
set -eu
export PYTHONDONTWRITEBYTECODE=1
exec /home/loosqk/.local/share/uv/python/cpython-3.12.13-linux-aarch64-gnu/bin/python3 - <<'PYREMOTE'
import base64,hashlib,importlib.util,json,os,subprocess,time
from pathlib import Path
base=Path('/home/loosqk/robot-checks/position-return-20261010-r1');phase=base/'head-settle-r8'
expected={'head1_outward_observation_r8.py': ('11b86f6768359bc7f6f0063bd188868b08c8baf164a59d89a62acdb557d7fc5e', 9328), 'maintenance_bindings_head_settle_r8.json': ('43b6f0d3e75db611ec2e64299c4f654b4979fa888cebb5941e75de4bd13b2311', 25186), 'head1-outward-observation-plan-only.stdout': ('a760f6c3eb26e034e088f786687f3328f071cb41d4842bc557abcf6cb46d3e86', 32952), 'field_confirmation_r8.json': ('6c33829990f8db07a1027caf356166344c9c0d88cb6b7dbd12b066eecc63e8f6', 601), 'head1-outward-observation-r8.go.json': ('5dc195fffb9e1453547ae93476090a60bd29439e8c17857ede43d14f20d1350b', 1227)}
for name,(sha,size) in expected.items():
 path=phase/name;raw=path.read_bytes();assert path.is_file() and not path.is_symlink() and hashlib.sha256(raw).hexdigest()==sha and len(raw)==size
script=base/'software-facts-r1/scripts/run_hardware_maintenance.py'
assert hashlib.sha256(script.read_bytes()).hexdigest()=='d97e0da9b792d048681053054296de66e7f3ef37cf392852784587b51a8b1d41'
spec=importlib.util.spec_from_file_location('head1_i2_wire_start_binding',script);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
bindings=m.strict_json((phase/'maintenance_bindings_head_settle_r8.json').read_text())
for ref in bindings['refs']:m.verify_ref(ref)
for side,files in bindings['protection'].items():
 for name,ref in files.items():m.verify_protection_file(side,name,ref)
assert Path('/proc/sys/kernel/random/boot_id').read_text().strip()==bindings['host']['boot_id']
for side,ref in bindings['usb'].items():
 device=Path(ref['device']);assert str(device.resolve())==ref['resolved'] and device.stat().st_rdev==ref['rdev'] and device.stat().st_ino==ref['device_inode'] and device.lstat().st_ino==ref['link_inode']
plan=m.strict_json((phase/'head1-outward-observation-plan-only.stdout').read_text());assert plan['plan_sha256']=='2cdef1e26daf0a2dfd38c4fd83053e336cb849d61bc1f03be18fe7aa7f58e98d' and m.digest(plan['plan'])==plan['plan_sha256']
go_path=phase/'head1-outward-observation-r8.go.json';go_raw=go_path.read_bytes();assert go_path.is_file() and not go_path.is_symlink()
go=m.strict_json(go_raw.decode());now=time.time_ns();m.validate_go(go,plan['plan'],now)
assert 0<go['expires_at_ns']-go['issued_at_ns']<=600_000_000_000 and 0<=now-1791623442238412000<600_000_000_000
assert all(go['physical'][side]['confirmed_at_ns']==1791623442238412000 for side in ('left','right'))
output=phase/'head1-outward-observation-r8';record=phase/'head1-outward-observation-launch-r8';assert not output.exists() and not record.exists()
launcher=base64.b64decode('IyEvYmluL2Jhc2gKc2V0IC1ldQpleHBvcnQgUFlUSE9ORE9OVFdSSVRFQllURUNPREU9MQp0bXV4IHNldC1vcHRpb24gLXcgLXQgIiRUTVVYX1BBTkUiIHJlbWFpbi1vbi1leGl0IG9uCmV4ZWMgL2hvbWUvbG9vc3FrLy5sb2NhbC9zaGFyZS91di9weXRob24vY3B5dGhvbi0zLjEyLjEzLWxpbnV4LWFhcmNoNjQtZ251L2Jpbi9weXRob24zIC9ob21lL2xvb3Nxay9yb2JvdC1jaGVja3MvcG9zaXRpb24tcmV0dXJuLTIwMjYxMDEwLXIxL2hlYWQtc2V0dGxlLXI4L2hlYWQxX291dHdhcmRfb2JzZXJ2YXRpb25fcjgucHkgLS1oZWxwZXIgL2hvbWUvbG9vc3FrL3JvYm90LWNoZWNrcy9wb3NpdGlvbi1yZXR1cm4tMjAyNjEwMTAtcjEvcG9zaXRpb24tcmV0dXJuLXI2L3AyNF90cmlhbF9oZWFkMV93aXJlX3I2LnB5IC0tbWFpbnRlbmFuY2UgL2hvbWUvbG9vc3FrL3JvYm90LWNoZWNrcy9wb3NpdGlvbi1yZXR1cm4tMjAyNjEwMTAtcjEvc29mdHdhcmUtZmFjdHMtcjEvc2NyaXB0cy9ydW5faGFyZHdhcmVfbWFpbnRlbmFuY2UucHkgLS1iaW5kaW5ncyAvaG9tZS9sb29zcWsvcm9ib3QtY2hlY2tzL3Bvc2l0aW9uLXJldHVybi0yMDI2MTAxMC1yMS9oZWFkLXNldHRsZS1yOC9tYWludGVuYW5jZV9iaW5kaW5nc19oZWFkX3NldHRsZV9yOC5qc29uIC0tb3V0cHV0IC9ob21lL2xvb3Nxay9yb2JvdC1jaGVja3MvcG9zaXRpb24tcmV0dXJuLTIwMjYxMDEwLXIxL2hlYWQtc2V0dGxlLXI4L2hlYWQxLW91dHdhcmQtb2JzZXJ2YXRpb24tcjggLS1ydW4taWQgaGVhZDEtb3V0d2FyZC1vYnNlcnZhdGlvbi1yOCAtLWFydGlmYWN0LXJvb3QgL2hvbWUvbG9vc3FrL3JvYm90LWNoZWNrcy9wb3NpdGlvbi1yZXR1cm4tMjAyNjEwMTAtcjEgLS1leGVjdXRlIC0tYXBwcm92YWwgL2hvbWUvbG9vc3FrL3JvYm90LWNoZWNrcy9wb3NpdGlvbi1yZXR1cm4tMjAyNjEwMTAtcjEvaGVhZC1zZXR0bGUtcjgvaGVhZDEtb3V0d2FyZC1vYnNlcnZhdGlvbi1yOC5nby5qc29uID4gL2hvbWUvbG9vc3FrL3JvYm90LWNoZWNrcy9wb3NpdGlvbi1yZXR1cm4tMjAyNjEwMTAtcjEvaGVhZC1zZXR0bGUtcjgvaGVhZDEtb3V0d2FyZC1vYnNlcnZhdGlvbi1sYXVuY2gtcjgvZHJpdmVyLmxvZyAyPiYxCg==',validate=True)
assert hashlib.sha256(launcher).hexdigest()=='f526ffffc754cf2be0af5bf99fab59540393048b3b1ed597988aafbac6088285'
record.mkdir(mode=0o700)
with (record/'launch_head1_outward_observation_r8.sh').open('xb') as stream:stream.write(launcher);stream.flush();os.fsync(stream.fileno())
assert (record/'launch_head1_outward_observation_r8.sh').read_bytes()==launcher
argv=['tmux','new-session','-d','-s','position-head1-outward-observation-20261010-r8','-P','-F','#{session_name} #{window_id} #{pane_id} #{pane_pid}','bash '+str(record/'launch_head1_outward_observation_r8.sh')]
started=time.time_ns();child=subprocess.Popen(argv,stdin=subprocess.DEVNULL,stdout=subprocess.PIPE,stderr=subprocess.PIPE);stdout,stderr=child.communicate();code=child.wait()
result={'status':'STARTED_SINGLE_HEAD1_OUTWARD_OBSERVATION' if code==0 else 'TMUX_START_FAIL','tmux_identity':stdout.decode().strip(),'tmux_launch':{'argv':argv,'pid':child.pid,'started_ns':started,'finished_ns':time.time_ns(),'exit_code':code,'wait_returncode':code,'reaped':True,'stdout':stdout.decode(),'stderr':stderr.decode(),'signals_sent':[]},'go_sha256':hashlib.sha256(go_raw).hexdigest(),'go_bytes':len(go_raw),'launcher_sha256':hashlib.sha256(launcher).hexdigest(),'plan_sha256':go['plan_sha256']}
with (record/'start_receipt_r8.json').open('x') as stream:json.dump(result,stream,ensure_ascii=False,indent=2);stream.write('\n');stream.flush();os.fsync(stream.fileno())
print(json.dumps(result,ensure_ascii=False),flush=True)
assert code==0 and stderr==b''

PYREMOTE
