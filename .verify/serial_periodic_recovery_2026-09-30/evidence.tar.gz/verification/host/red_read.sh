set -eu
export PATH=/home/loosqk/.cargo/bin:/home/loosqk/.local/bin:$PATH
export CARGO_HOME=/home/loosqk/robot-checks/viz-orin-a6957cc-20260930-r1/cargo-home
export CARGO_TARGET_DIR=/home/loosqk/robot-checks/h2-nightly-v2-20260930-r1/build
export CARGO_BUILD_JOBS=2
cd /home/loosqk/robot-checks/serial-periodic-recovery-20260930-r1/source
git apply --check ../tests-only.diff
git apply ../tests-only.diff
sha256sum ../tests-only.diff crates/robot-s0/src/serial_tick.rs crates/robot-s0/src/post_e_diag_acceptance.rs
set +e
taskset -c 0-3 cargo +nightly test --offline --locked -p robot-s0 --lib --features test-comm-fault-hook post_e_diag_acceptance::periodic_ -- --test-threads=1 > ../red-read.log 2>&1
SERIAL_RESULT=$?
cat ../red-read.log
exit "$SERIAL_RESULT"
