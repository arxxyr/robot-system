set -eu
export PATH=/home/loosqk/.cargo/bin:/home/loosqk/.local/bin:$PATH
export CARGO_HOME=/home/loosqk/robot-checks/viz-orin-a6957cc-20260930-r1/cargo-home
export CARGO_TARGET_DIR=/home/loosqk/robot-checks/h2-nightly-v2-20260930-r1/build
export CARGO_BUILD_JOBS=2
cd /home/loosqk/robot-checks/serial-periodic-recovery-20260930-r1/source
sha256sum ../deadline-tests-only.diff crates/robot-s0/src/serial_io_thread.rs
set +e
taskset -c 0-3 cargo +nightly test --offline --locked -p robot-s0 --lib --features test-comm-fault-hook periodic_schedule_ -- --test-threads=1 > ../red-deadline-r2.log 2>&1
SERIAL_RESULT=$?
cat ../red-deadline-r2.log
exit "$SERIAL_RESULT"
