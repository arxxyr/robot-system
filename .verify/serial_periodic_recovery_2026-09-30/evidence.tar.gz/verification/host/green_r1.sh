set -eu
export PATH=/home/loosqk/.cargo/bin:/home/loosqk/.local/bin:$PATH
export CARGO_HOME=/home/loosqk/robot-checks/viz-orin-a6957cc-20260930-r1/cargo-home
export CARGO_TARGET_DIR=/home/loosqk/robot-checks/h2-nightly-v2-20260930-r1/build
export CARGO_BUILD_JOBS=2
cd /home/loosqk/robot-checks/serial-periodic-recovery-20260930-r1/source
git apply --check ../baseline_gate_diagnosis.implementation.diff
git apply ../baseline_gate_diagnosis.implementation.diff
git apply --check ../implementation.diff
git apply ../implementation.diff
sha256sum crates/robot-s0/src/serial_io_thread.rs crates/robot-s0/src/serial_tick.rs crates/robot-s0/src/post_e_diag_acceptance.rs
run_check() {
  SERIAL_PHASE="$1"
  shift
  set +e
  taskset -c 0-3 "$@" > "../$SERIAL_PHASE.log" 2>&1
  SERIAL_RESULT=$?
  set -e
  printf '%s exit=%s\n' "$SERIAL_PHASE" "$SERIAL_RESULT"
  if [ "$SERIAL_RESULT" -eq 0 ]; then tail -8 "../$SERIAL_PHASE.log"; else cat "../$SERIAL_PHASE.log"; fi
  return "$SERIAL_RESULT"
}
run_check fmt-r1 cargo +nightly fmt --all --check
run_check clippy-r1 cargo +nightly clippy --offline --locked --all --all-targets -- -D warnings
run_check green-deadline-r1 cargo +nightly test --offline --locked -p robot-s0 --lib --features test-comm-fault-hook periodic_schedule_ -- --test-threads=1
run_check green-read-r1 cargo +nightly test --offline --locked -p robot-s0 --lib --features test-comm-fault-hook post_e_diag_acceptance:: -- --test-threads=1
run_check s0-lib-r1 cargo +nightly test --offline --locked -p robot-s0 --lib --features rt_guard,test-comm-fault-hook -- --test-threads=1
run_check serial-e2e-r1 cargo +nightly test --offline --locked -p robot-s0 --test serial_rt_e2e --features rt_guard,test-comm-fault-hook -- --test-threads=1
sha256sum crates/robot-s0/src/serial_io_thread.rs crates/robot-s0/src/serial_tick.rs crates/robot-s0/src/post_e_diag_acceptance.rs
