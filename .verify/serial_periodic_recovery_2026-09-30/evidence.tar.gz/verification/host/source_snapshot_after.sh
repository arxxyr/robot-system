set -eu
export PATH=/home/loosqk/.cargo/bin:/home/loosqk/.local/bin:$PATH
cd /home/loosqk/robot-checks/serial-periodic-recovery-20260930-r1/source
H2_PYTHON="$(uv python find 3.12)"
exec "$H2_PYTHON" - <<'PY'
import json,subprocess,sys
from pathlib import Path
sys.dont_write_bytecode=True
sys.path.insert(0,str(Path('scripts').resolve()))
import post_e_h2_artifacts as a
inventory=subprocess.check_output(['git','ls-files','-z']).decode().split('\0')[:-1]
result=a.snapshot_source(Path.cwd(),inventory)
assert result['source_manifest_sha256']=='c03888074cbd4005837bc0291aafdf72fff4a59f473d75f52298b1da42182a96'
out=Path('../green-source-after.json')
assert not out.exists()
out.write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'files':len(result['files']),'sha256':result['source_manifest_sha256']}))
PY
