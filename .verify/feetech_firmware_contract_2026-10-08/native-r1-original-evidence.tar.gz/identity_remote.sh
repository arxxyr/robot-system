set -eu
export PATH=/home/loosqk/.cargo/bin:/home/loosqk/.local/bin:$PATH
export PYTHONDONTWRITEBYTECODE=1
uv run --no-project python - <<'PY_REMOTE'
import os,json,platform,shutil
from pathlib import Path
identity={'hostname':platform.node(),'arch':platform.machine(),'uid':os.getuid(),'gid':os.getgid(),'boot_id':Path('/proc/sys/kernel/random/boot_id').read_text().strip()}
expected={'hostname':'ubuntu','arch':'aarch64','uid':1000,'gid':1000,'boot_id':'6cf7ee3e-a3c5-4c91-80bc-4ca924818b53'}
assert identity==expected,identity
active=[]
for p in Path('/proc').iterdir():
 if not p.name.isdigit():continue
 try:
  if p.stat().st_uid!=1000:continue
  words=(p/'cmdline').read_bytes().replace(b'\0',b' ').decode(errors='replace')
  argv=(p/'cmdline').read_bytes().split(b'\0')
  name=Path(argv[0].decode(errors='replace')).name if argv and argv[0] else ''
  if name in {'cargo','rustc','clippy-driver','rustup'}:active.append({'pid':int(p.name),'argv':words,'stat':(p/'stat').read_text()})
 except (FileNotFoundError,PermissionError):pass
assert not active,active
print(json.dumps({'identity':identity,'active_cargo_compilers':active,'strace':shutil.which('strace'),'status':'PASS_IDENTITY_READONLY'},ensure_ascii=False))
PY_REMOTE
