"""主树只读导出591输入，逐项绑定已整合七源和完整候选输入。"""
import hashlib, importlib.util, io, json, os, stat, subprocess, tarfile, time
from pathlib import Path
HERE=Path(__file__).resolve().parent;ROOT=Path('/Users/loosqk/repo/rust/robot-system')
spec=importlib.util.spec_from_file_location('artifacts',HERE/'artifacts.py');a=importlib.util.module_from_spec(spec);spec.loader.exec_module(a)
records=[]
def git(args):
 argv=['git',*args];start=time.monotonic_ns();p=subprocess.Popen(argv,cwd=ROOT,stdout=subprocess.PIPE,stderr=subprocess.PIPE);out,err=p.communicate();records.append({'argv':argv,'pid':p.pid,'exit_code':p.returncode,'reaped':True,'started_monotonic_ns':start,'ended_monotonic_ns':time.monotonic_ns(),'stdout':out.decode(),'stderr':err.decode()});a.require(p.returncode==0,'Git只读失败');return out
integration=a.strict_json((HERE.parent/'root_integration_r1.json').read_text());candidate=a.strict_json(Path(integration['source_manifest']).read_text());a.require(a.sha256(Path(integration['source_manifest']))==integration['source_manifest_sha256']=='9ab552b9542a8ca95f53345ac4c39a489b601af846af9231b69a9cf4a6a7b13d','候选身份不同')
allowed={row['path'] for row in integration['changes']};a.require(len(allowed)==7,'不是批准七源')
head=git(['rev-parse','HEAD']).decode().strip();a.require(head==integration['head_before']=='bfad2015f7772557b884d3ea4f6218aaa2ae4062','主HEAD变化')
status=git(['status','--porcelain=v1','--untracked-files=all']).decode();a.require({row[3:] for row in status.splitlines()}==allowed,'主树变更超七源')
inventory=git(['ls-files','-z','--cached','--others','--exclude-standard']).decode().rstrip('\0').split('\0');expected=a.snapshot_source(ROOT,inventory);a.require(len(expected['files'])==591,'不是591输入')
original=a.strict_json(Path(candidate['source_manifest']['path']).read_text())['files'];a.require(set(original)==set(expected['files']),'完整候选输入集合不同')
for name,item in expected['files'].items():a.require({key:original[name][key] for key in ['bytes','sha256','executable']}==item,'主树输入不是候选逐字节原件')
for row in integration['changes']:a.require(expected['files'][row['path']]['sha256']==row['after_sha256'] and expected['files'][row['path']]['bytes']==row['bytes'],'七源整合后身份不同')
files={};archive=HERE/'source-inputs.tar.gz'
def ident(s):return(s.st_dev,s.st_ino,s.st_mode,s.st_size,s.st_mtime_ns,s.st_ctime_ns)
with tarfile.open(archive,'x:gz') as tar:
 for name,item in expected['files'].items():
  path=ROOT/name;info=path.lstat();a.require(stat.S_ISREG(info.st_mode) and path.resolve()==path,'非普通原文件')
  with os.fdopen(os.open(path,os.O_RDONLY|os.O_NOFOLLOW),'rb') as stream:first=os.fstat(stream.fileno());data=stream.read(item['bytes']+1);last=os.fstat(stream.fileno())
  a.require(ident(info)==ident(first)==ident(last)==ident(path.lstat()),'读取身份漂移')
  a.require(len(data)==item['bytes'] and hashlib.sha256(data).hexdigest()==item['sha256'] and bool(info.st_mode&stat.S_IXUSR)==item['executable'],'原文不符')
  row={**item,'mode':stat.S_IMODE(info.st_mode)};files[name]=row;member=tarfile.TarInfo(name);member.size=len(data);member.mode=row['mode'];tar.addfile(member,io.BytesIO(data))
a.require(git(['rev-parse','HEAD']).decode().strip()==head and git(['status','--porcelain=v1','--untracked-files=all']).decode()==status and a.snapshot_source(ROOT,inventory)==expected,'导出前后身份变化')
value={'schema':'FEETECH_SEVEN_SOURCE_INTEGRATION_EXPORT_V1','status':'PASS_EXPORT_ONLY','origin':{'main_root':str(ROOT),'main_head':head,'main_porcelain':status,'dirty_compilation_paths':sorted(allowed),'native_git_head':None,'source_kind':'exported compilation-input snapshot'},'root_integration':{'path':str(HERE.parent/'root_integration_r1.json'),'sha256':a.sha256(HERE.parent/'root_integration_r1.json')},'candidate_sha256':integration['source_manifest_sha256'],'source_manifest':expected,'files':files,'archive':{'sha256':a.sha256(archive),'bytes':archive.stat().st_size},'git_children':records,'artifacts_sha256':a.sha256(HERE/'artifacts.py')}
for name,data in [('expected_source.json',expected),('source_export.json',value)]:
 with (HERE/name).open('x') as f:json.dump(data,f,ensure_ascii=False,indent=2);f.write('\n')
print(json.dumps({'status':value['status'],'head':head,'files':len(files),'aggregate':expected['source_manifest_sha256'],'archive':value['archive']},ensure_ascii=False))
