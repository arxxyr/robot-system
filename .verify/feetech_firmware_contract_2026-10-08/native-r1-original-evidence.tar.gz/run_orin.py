"""七源整合的限定软件验证，不连接设备或修改正式安装/服务。"""
import importlib.util, json, os, platform, re, shutil, signal, stat
from pathlib import Path
from types import SimpleNamespace
BASE=Path('/home/loosqk/robot-checks/feetech-firmware-contract-quality-20261008-r1');SOURCE=BASE/'source';BOOT=BASE/'bootstrap';OUT=BASE/'qa'
def module(name,path):
 spec=importlib.util.spec_from_file_location(name,path);v=importlib.util.module_from_spec(spec);spec.loader.exec_module(v);return v
h=module('natural_runner',BOOT/'natural_runner.py');a=module('artifacts',BOOT/'artifacts.py');require=a.require
require(a.sha256(BOOT/'natural_runner.py')=='dad9bbc9405b8fac4d60d6efe794b36750e6a6f9ce9fdeba3debf7d3e1b9a471','原runner身份不同')
require(a.sha256(BOOT/'artifacts.py')=='bd2b3f7bb8527cd9ecec73894171638e9cf378656b89e284a585c3baa37b8731','原artifact helper身份不同')
expected=a.strict_json((BOOT/'expected_source.json').read_text());export=a.strict_json((BOOT/'source_export.json').read_text())
OUT.mkdir();release_target=BASE/'release-build';release_target.mkdir()
runner=h.Runner(SimpleNamespace(source=SOURCE,out=OUT,target=Path('/home/loosqk/robot-checks/xlerobot-velocity-foundation-20261008-r7/build')),a)
release_runner=h.Runner(SimpleNamespace(source=SOURCE,out=OUT,target=release_target),a)
result={'schema':'FEETECH_SEVEN_SOURCE_NATIVE_INTEGRATION_QA_R1','status':'FAIL','deployable':False,'origin':export['origin'],'scope':'仅591同源fmt/两根Clippy/Feetech171+poke6/独立release poke与有限软件拒写；不是完整workspace/release集合/H2/真实RPC/硬件','receipts':[],'tests':{}}
def source(label):
 require(not os.path.lexists(SOURCE/'.git'),'不能伪称原生Git checkout');names=[]
 for root,dirs,files in os.walk(SOURCE,followlinks=False):
  for name in dirs:require(not (Path(root)/name).is_symlink(),'源目录链接')
  for name in files:
   p=Path(root)/name;require(stat.S_ISREG(p.lstat().st_mode) and not p.is_symlink(),'非普通输入');names.append(p.relative_to(SOURCE).as_posix())
 require(set(names)==set(expected['files']) and len(names)==591,'591输入集合不同');v=a.snapshot_source(SOURCE,names);require(v==expected,'591输入SHA/bytes/exec不同');h.save(OUT/(label+'.json'),v);return v
def step(name,argv,budget=7200,selected=runner):
 source(name+'_source_before')
 try:return selected.command(name,argv,budget)
 finally:source(name+'_source_after')
def tests(name,argv,count):
 _,row=step(name,argv);text=Path(row['stdout']).read_text();counts=re.findall(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored;',text);names=re.findall(r'^test ([^ ]+) \.\.\. ok$',text,re.M)
 require(counts==[(str(count),'0','0')] and len(names)==len(set(names))==count,'定向测试数量/失败/ignored不同');result['tests'][name]={'count':count,'names':names,'failed':0,'ignored':0}
old={};before=compiler=cargo=frozen_identity=None
def interrupted(signum,frame):h.INTERRUPTED=signum
try:
 for sig in (signal.SIGINT,signal.SIGTERM,signal.SIGHUP):old[sig]=signal.signal(sig,interrupted)
 identity={'hostname':platform.node(),'arch':platform.machine(),'uid':os.getuid(),'gid':os.getgid(),'boot_id':Path('/proc/sys/kernel/random/boot_id').read_text().strip()}
 require(identity=={'hostname':'ubuntu','arch':'aarch64','uid':1000,'gid':1000,'boot_id':'6cf7ee3e-a3c5-4c91-80bc-4ca924818b53'},'主机身份不同');result['identity']=identity
 require(os.environ.get('CARGO_HOME')=='/home/loosqk/robot-checks/viz-orin-a6957cc-20260930-r1/cargo-home' and os.environ.get('CARGO_NET_OFFLINE')=='true','既有离线缓存环境不同')
 before=source('source_before');_,row=step('rustc_before',['rustc','-vV'],60);compiler=a.parse_rustc_identity(Path(row['stdout']).read_text());require(compiler['commit_hash']=='1d81eb4ad9cd207e3e638bd32b17ec4fce8412a6','nightly非实际1d81')
 _,row=step('cargo_before',['cargo','-V'],60);cargo=Path(row['stdout']).read_bytes();require(b'-nightly' in cargo,'cargo非nightly')
 step('fmt',['cargo','fmt','--all'],300)
 step('clippy_default',['cargo','clippy','--locked','--all','--all-targets','--','-D','warnings'])
 step('clippy_real_hw',['cargo','clippy','--locked','--all','--all-targets','--features','robot-adapter-feetech/real-hw','--','-D','warnings'])
 tests('feetech_lib',['cargo','test','--locked','-p','robot-adapter-feetech','--lib','--features','real-hw','--','--test-threads=1'],171)
 tests('poke_tests',['cargo','test','--locked','-p','robot-adapter-feetech','--example','feetech_poke','--features','real-hw','--','--test-threads=1'],6)
 release_ref,row=step('release_poke',['cargo','build','--locked','--release','-p','robot-adapter-feetech','--example','feetech_poke','--features','real-hw','--message-format=json-render-diagnostics'],selected=release_runner)
 messages=[json.loads(line) for line in Path(row['stdout']).read_text().splitlines() if line.strip()];arts=[m for m in messages if m.get('reason')=='compiler-artifact' and m.get('executable') and m.get('target',{}).get('name')=='feetech_poke']
 require(len(arts)==1 and arts[0]['target']['kind']==['example'] and 'real-hw' in arts[0]['features'] and arts[0]['profile']['opt_level']=='3' and not arts[0]['profile']['debug_assertions'] and not arts[0]['profile']['test'],'release Cargo实际产物/profile/features不同')
 actual=Path(arts[0]['executable']);require(actual==release_target/'release/examples/feetech_poke','release输出路径不同');original=a.elf_identity(actual);require(original['machine']==183,'产物不是aarch64')
 frozen_dir=OUT/'frozen';frozen_dir.mkdir();frozen=frozen_dir/'feetech_poke'
 with actual.open('rb') as incoming,frozen.open('xb') as outgoing:shutil.copyfileobj(incoming,outgoing)
 frozen.chmod(original['mode']);frozen_identity=a.elf_identity(frozen);require(frozen_identity==original==a.elf_identity(actual),'产物冻结前后身份不同')
 result['artifact']={'cargo_artifact':arts[0],'release_completion':release_ref,'cargo_path':str(actual),'frozen_path':str(frozen),'identity':frozen_identity,'source_aggregate':expected['source_manifest_sha256'],'compiler':compiler};h.save(frozen_dir/'feetech_poke.build.json',result['artifact'])
 for name in ['help','Firmware_Major_Version','Firmware_Minor_Version']:step('probe_'+name,['uv','run','--no-project','python',str(BOOT/'expected_exit2_probe.py'),name,frozen_identity['sha256']],60)
 require(a.elf_identity(frozen)==frozen_identity==a.elf_identity(actual),'探针后冻结/产物SHA改变');result['artifact_before_after']='PASS'
 result.update(status='PASS',compiler_before=compiler,cargo_before=cargo.decode(),source_files=591,aggregate=before['source_manifest_sha256'],test_method_count=177,new_method_subset=12,wire_samples_in_one_test=131072,syscall_trace='UNAVAILABLE_NOT_CLAIMED',no_subset_double_count=True)
except BaseException as error:result['error']=repr(error)
finally:
 try:
  _,row=step('rustc_after',['rustc','-vV'],60);value=a.parse_rustc_identity(Path(row['stdout']).read_text());require(compiler is not None and value==compiler,'rustc前后不符');_,row=step('cargo_after',['cargo','-V'],60);require(cargo is not None and Path(row['stdout']).read_bytes()==cargo,'cargo前后不符');result.update(compiler_after=value,compiler_window='PASS')
 except BaseException as error:result.update(status='FAIL',compiler_window_error=repr(error))
 try:require(before is not None and source('source_after')==before,'源首末漂移');result['source_before_after']='PASS'
 except BaseException as error:result.update(status='FAIL',source_after_error=repr(error))
 result['receipts']=runner.receipts+release_runner.receipts;h.save(OUT/'result.json',result)
 for sig,handler in old.items():signal.signal(sig,handler)
print(json.dumps({'status':result['status'],'error':result.get('error'),'receipts':len(result['receipts']),'source_before_after':result.get('source_before_after'),'compiler_window':result.get('compiler_window'),'artifact':result.get('artifact'),'tests':{k:v['count'] for k,v in result['tests'].items()}},ensure_ascii=False),flush=True)
raise SystemExit(0 if result['status']=='PASS' else 1)
