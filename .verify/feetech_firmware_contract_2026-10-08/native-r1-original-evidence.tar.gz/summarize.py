"""只读核已下载原件、591输入、release产物和预期exit2回执。"""
import importlib.util, json, re, subprocess, time
from pathlib import Path
HERE=Path(__file__).resolve().parent;ROOT=Path('/Users/loosqk/repo/rust/robot-system');NATIVE=HERE/'orin-originals'
spec=importlib.util.spec_from_file_location('artifacts',HERE/'artifacts.py');a=importlib.util.module_from_spec(spec);spec.loader.exec_module(a)
def identity(p):return {'path':str(p),'sha256':a.sha256(p),'bytes':p.stat().st_size}
def save(name,value):
 p=HERE/name
 with p.open('x') as f:json.dump(value,f,ensure_ascii=False,indent=2);f.write('\n')
 a.strict_json(p.read_text());return identity(p)
expected=a.strict_json((HERE/'expected_source.json').read_text());export=a.strict_json((HERE/'source_export.json').read_text());native=a.strict_json((NATIVE/'result.json').read_text())
a.require(native['status']=='PASS' and native['source_before_after']=='PASS' and native['compiler_window']=='PASS' and native['artifact_before_after']=='PASS','原生总结果非PASS')
snapshots=[p for p in NATIVE.glob('*.json') if p.name.startswith('source_') or '_source_' in p.name]
a.require(len(snapshots)==28 and all(a.strict_json(p.read_text())==expected for p in snapshots),'每步591源窗口不同或缺失')
children=[]
for ref in native['receipts']:
 relative=Path(ref['path']).relative_to('/home/loosqk/robot-checks/feetech-firmware-contract-quality-20261008-r1/qa');p=NATIVE/relative;row=a.strict_json(p.read_text())
 a.require(a.sha256(p)==ref['sha256'] and row['exit_code']==0 and row['reaped'] and row.get('runner_error') is None and not row['budget_exceeded'] and not row['signals'] and not row['session_residual_before_cleanup'] and not row['session_residual_after_cleanup'],'命令真实退出/回收/预算不同')
 for stream in ['stdout','stderr']:
  f=p.parent/(stream+'.log');a.require(a.sha256(f)==row[stream+'_sha256'] and f.stat().st_size==row[stream+'_bytes'],'stdout/stderr不同')
 children.append({'name':row['name'],'argv':row['argv'],'pid':row['pid'],'identity':row['identity'],'exit_code':0,'reaped':True,'budget_exceeded':False,'elapsed_ns':row['elapsed_ns'],'completion':identity(p),'environment':row['env']})
a.require(len(children)==13 and len({r['pid'] for r in children})==13,'十三自有命令回收缺失')
expected_argv={'fmt':['cargo','fmt','--all'],'clippy_default':['cargo','clippy','--locked','--all','--all-targets','--','-D','warnings'],'clippy_real_hw':['cargo','clippy','--locked','--all','--all-targets','--features','robot-adapter-feetech/real-hw','--','-D','warnings'],'feetech_lib':['cargo','test','--locked','-p','robot-adapter-feetech','--lib','--features','real-hw','--','--test-threads=1'],'poke_tests':['cargo','test','--locked','-p','robot-adapter-feetech','--example','feetech_poke','--features','real-hw','--','--test-threads=1'],'release_poke':['cargo','build','--locked','--release','-p','robot-adapter-feetech','--example','feetech_poke','--features','real-hw','--message-format=json-render-diagnostics']}
for row in children:
 if row['name'] in expected_argv:a.require(row['argv']==expected_argv[row['name']],'实际QA范围变化')
compiler=a.parse_rustc_identity((NATIVE/'rustc_before/stdout.log').read_text());a.require(compiler==a.parse_rustc_identity((NATIVE/'rustc_after/stdout.log').read_text()) and compiler['commit_hash']=='1d81eb4ad9cd207e3e638bd32b17ec4fce8412a6','nightly窗口不同')
a.require((NATIVE/'cargo_before/stdout.log').read_bytes()==(NATIVE/'cargo_after/stdout.log').read_bytes(),'cargo窗口不同')
test_names={}
for name,count in [('feetech_lib',171),('poke_tests',6)]:
 text=(NATIVE/name/'stdout.log').read_text();names=re.findall(r'^test ([^ ]+) \.\.\. ok$',text,re.M);counts=re.findall(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored;',text)
 a.require(counts==[(str(count),'0','0')] and len(names)==len(set(names))==count and names==native['tests'][name]['names'],'定向测试实际计数不同');test_names[name]=names
new=[('lib::'+n) for n in test_names['feetech_lib'] if n.startswith('velocity_profile::') or any(s in n for s in ['firmware_version','firmware_readonly'])]+[('poke::'+n) for n in test_names['poke_tests'] if 'firmware_version' in n];a.require(len(new)==12,'新方法子集不同')
frozen=NATIVE/'frozen/feetech_poke';a.require(a.elf_identity(frozen)==native['artifact']['identity'],'冻结ELF/SHA/bytes/mode不同');artifact=native['artifact']
a.require(artifact['source_aggregate']==expected['source_manifest_sha256'] and artifact['compiler']==compiler and artifact['cargo_path']=='/home/loosqk/robot-checks/feetech-firmware-contract-quality-20261008-r1/release-build/release/examples/feetech_poke','release来源/独立target不同')
probes=[]
for name in ['help','Firmware_Major_Version','Firmware_Minor_Version']:
 p=NATIVE/('expected_'+name)/'completion.json';row=a.strict_json(p.read_text());a.require(row['status']=='PASS_EXPECTED_EXIT2_EARLY_REFUSAL' and row['exit_code']==2 and row['reaped'] and not row['budget_exceeded'] and not row['session_residual'] and not row['signals'] and row['missing_device_before'] and row['missing_device_after'] and row['binary_same_after'],'预期2实际退出/回收/无设备前置不同')
 a.require(row['binary_sha256']==artifact['identity']['sha256'],'探针未执行冻结件')
 for stream in ['stdout','stderr']:
  f=p.parent/(stream+'.log');a.require(a.sha256(f)==row[stream+'_sha256'] and f.stat().st_size==row[stream+'_bytes'],'探针原输出不同')
 probes.append({'name':name,'pid':row['pid'],'identity':row['identity'],'actual_exit_code':2,'expected_exit_code':2,'reaped':True,'argv':row['argv'],'completion':identity(p),'zero_uart_evidence':row['zero_uart_evidence'],'syscall_trace':'UNAVAILABLE_NOT_CLAIMED'})
owners=[]
for folder in sorted(HERE.glob('*.owner')):
 row=a.strict_json((folder/'result.json').read_text());a.require(row['status']=='PASS' and row['reaped'] and row['wait_returncode']==0 and not row['owner_sent_signals'] and not row['errors'],'本机owner实际回收缺失');owners.append({'name':folder.name,'owner_pid':row['owner_pid'],'child_pid':row['pid'],'exit_code':0,'reaped':True,'result':identity(folder/'result.json')})
tool=a.strict_json((HERE/'tool_owner_wait.json').read_text());a.require(tool['result']['exit_code']==0,'工具owner未完成')
git_rows=[]
def git(args):
 start=time.monotonic_ns();p=subprocess.Popen(['git',*args],cwd=ROOT,stdout=subprocess.PIPE,stderr=subprocess.PIPE);out,err=p.communicate();git_rows.append({'argv':['git',*args],'pid':p.pid,'exit_code':p.returncode,'reaped':True,'stdout':out.decode(),'stderr':err.decode(),'started_monotonic_ns':start,'ended_monotonic_ns':time.monotonic_ns()});a.require(p.returncode==0,'Git只读失败');return out
head=git(['rev-parse','HEAD']).decode().strip();inventory=git(['ls-files','-z','--cached','--others','--exclude-standard']).decode().rstrip('\0').split('\0');current=a.snapshot_source(ROOT,inventory);a.require(current==expected and head==export['origin']['main_head'],'主树591/HEAD最终漂移')
source_review={'source_count':591,'aggregate':expected['source_manifest_sha256'],'root_integration':export['root_integration'],'candidate_sha256':export['candidate_sha256'],'every_591_current_file_same':True,'native_source_snapshots_same':len(snapshots)}
roster=save('test_roster_and_overlap.json',{'lib':171,'poke':6,'distinct_test_methods':177,'all_names':test_names,'new_method_subset':new,'new_subset_count':12,'wire_samples_in_one_test':131072,'not_added_again':'12为177子集，131072为一个测试内样本；Mac/Python历史不再次累计'})
summary={'schema':'FEETECH_SEVEN_SOURCE_INTEGRATION_NATIVE_SUMMARY_R1','status':'PASS_SCOPED_NATIVE_SOFTWARE_NOT_RUNTIME_HARDWARE','deployable':False,'origin':export['origin'],'source_binding':source_review,'compiler':compiler,'cargo':(NATIVE/'cargo_before/stdout.log').read_text().strip(),'root_fmt_two_clippy':'PASS','tests':{'lib':171,'poke':6,'failed':0,'ignored':0,'distinct':177,'new_subset':12,'wire_samples_in_one_test':131072,'roster':roster},'native_quality_children':sorted(children,key=lambda r:r['completion']['path']),'expected_exit2_children':probes,'distinct_native_children':16,'host_owners':owners,'tool_wait':identity(HERE/'tool_owner_wait.json'),'release_artifact':{**artifact,'local_download':identity(frozen),'elf_machine':183,'freeze_after_probes_same':True},'native_result':identity(NATIVE/'result.json'),'all_native_originals':[identity(p) for p in sorted(NATIVE.rglob('*')) if p.is_file()],'git_final_readonly_children':git_rows,'scope_limits':['非完整workspace/H2六配方/真实RPC/RT或硬件门','release只为未来READ候选，本轮没有连真实串口、UART或正式安装/服务','FW测试(1,2)虚拟；现场版本和文档适用性未由本件认证','原FAIL、旧r7 UNKNOWN、D15 OPEN_DEFERRED/deployable=false保持','Orin无strace，零UART证据为早退控制流/实际exit2/具体错误/不存在路径及mock/preflight测试，不声称syscall trace']}
ref=save('summary.json',summary);index=save('artifact_index.json',{'summary':ref,'files':[identity(p) for p in sorted(HERE.rglob('*')) if p.is_file() and p.name!='artifact_index.json'],'readback':'PASS_ALL_REFERENCES'})
print(json.dumps({'status':summary['status'],'summary':ref,'index':index,'quality_children':13,'expected_exit2_children':3,'lib':171,'poke':6,'artifact_sha':artifact['identity']['sha256'],'source':source_review},ensure_ascii=False))
