set -eu
export PATH=/home/loosqk/.cargo/bin:/home/loosqk/.local/bin:$PATH
export CARGO_HOME=/home/loosqk/robot-checks/viz-orin-a6957cc-20260930-r1/cargo-home
export CARGO_NET_OFFLINE=true
export RUSTUP_AUTO_INSTALL=0
export PYTHONDONTWRITEBYTECODE=1
cd /home/loosqk/robot-checks/feetech-firmware-contract-quality-20261008-r1/bootstrap
sha256sum -c - <<'SHA_INPUTS'
bd2b3f7bb8527cd9ecec73894171638e9cf378656b89e284a585c3baa37b8731  artifacts.py
dad9bbc9405b8fac4d60d6efe794b36750e6a6f9ce9fdeba3debf7d3e1b9a471  natural_runner.py
d1d3785637bca35772d978cd6d2a30ec66924fb754ab5b01ff8a4556a4bcb13a  run_orin_verified.py
7010118142d336a6bf744e995c8a007867de6dd6c5557064eeb5d3e1be53727d  receive_source.py
8d214eafab3967fcf2ebccc7433ee39ca4f783c05cb0bd1c9e2fe4a6acf9acac  expected_exit2_probe.py
ea85b41e5717c9a8cfac98c99a51f670defd83f9b121f4c6e5cafcdf3048b74d  source-inputs.tar.gz
c646ed5171bc9ddfa00190c8456d570a07290bf759b8b5e0a6c31d243b8461e8  expected_source.json
03efdf569ab4871b6d6a137c50544037f0357b595948200e34caef18d42e8269  source_export.json
SHA_INPUTS
uv run --no-project python receive_source.py
exec taskset -c 0-3 uv run --no-project python run_orin_verified.py
