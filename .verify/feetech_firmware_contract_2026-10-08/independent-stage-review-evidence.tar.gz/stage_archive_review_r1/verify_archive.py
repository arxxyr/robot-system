#!/usr/bin/env python3
"""只读独核阶段包和人工断电回执，不运行测试、编译或设备工具。"""
import datetime
import hashlib
import io
import json
import pathlib
import stat
import tarfile

ROOT = pathlib.Path('/Users/loosqk/repo/rust/robot-system')
STAGE = ROOT / '.verify/feetech_firmware_contract_2026-10-08'
BASE = ROOT / 'target/feetech_firmware_integration_2026-10-08/native-r1'
OUT = ROOT / 'target/feetech_firmware_integration_2026-10-08/stage_archive_review_r1'
REMOTE = '/home/loosqk/robot-checks/feetech-firmware-contract-quality-20261008-r1/'
CAND = pathlib.Path('/Users/loosqk/.codex/worktrees/feetech-wheel-firmware-contract/robot-system/target/firmware_contract_delivery_r2/candidate_manifest.json')


def sha(data):
    return hashlib.sha256(data).hexdigest()


def pairs(items):
    d = {}
    for key, value in items:
        assert key not in d
        d[key] = value
    return d


def loads(data):
    return json.loads(data, object_pairs_hook=pairs)


def load(path):
    return loads(path.read_bytes())


def ref(path):
    data = path.read_bytes()
    return {'path': str(path), 'bytes': len(data), 'sha256': sha(data)}


def identity(data, item):
    assert sha(data) == item['sha256']
    if 'bytes' in item:
        assert len(data) == item['bytes']


def typed_refs(value):
    if isinstance(value, dict):
        if isinstance(value.get('path'), str) and isinstance(value.get('sha256'), str) and len(value['sha256']) == 64:
            yield value
        for v in value.values():
            yield from typed_refs(v)
    elif isinstance(value, list):
        for v in value:
            yield from typed_refs(v)


def resolve_original(path):
    if path.startswith(REMOTE + 'qa/'):
        return str(BASE / 'orin-originals' / path.removeprefix(REMOTE + 'qa/'))
    if path.startswith(REMOTE + 'bootstrap/'):
        return str(BASE / path.removeprefix(REMOTE + 'bootstrap/'))
    return path


OUT.mkdir(exist_ok=True)
summary = load(STAGE / 'summary.json')
assert ref(STAGE / 'summary.json')['sha256'] == '0ecff5a1551404a2901c0de6d8c13b002cb9b4eeb02448712f475e1f320bbb97'
assert (STAGE / 'summary.json').stat().st_size == 17070
top = load(STAGE / 'artifact_index.json')
archived = {}
origin_to_location = {}
archive_checks = []
for archive_name, index_name, count, expected_sha, expected_size in [
    ('native-r1-original-evidence.tar.gz', 'native-r1-original-evidence.index.json', 145, '4645c597aa9bb48058917639c09a34be588e5d2682a5e332e1ca3a785182d515', 11032663),
    ('supporting-original-evidence.tar.gz', 'supporting-original-evidence.index.json', 177, '1798b824e81c0659df6f0969e5eb87f862e5be2e9c709e26f19cf053f6cd3a1a', 536290),
]:
    path = STAGE / archive_name
    data = path.read_bytes()
    assert sha(data) == expected_sha and len(data) == expected_size
    index = load(STAGE / index_name)
    identity(data, index['archive'])
    assert stat.S_IMODE(path.stat().st_mode) == index['archive']['mode']
    items = {v['name']: v for v in index['files']}
    assert len(items) == len(index['files']) == count
    with tarfile.open(fileobj=io.BytesIO(data), mode='r:gz') as archive:
        members = archive.getmembers()
        assert len(members) == len({m.name for m in members}) == count
        assert {m.name for m in members} == set(items)
        for member in members:
            assert member.isfile() and not pathlib.PurePosixPath(member.name).is_absolute() and '..' not in pathlib.PurePosixPath(member.name).parts
            item = items[member.name]
            body = archive.extractfile(member).read()
            identity(body, item)
            assert member.mode == item['mode']
            original = pathlib.Path(item['original_path'])
            identity(original.read_bytes(), item)
            assert stat.S_ISREG(original.lstat().st_mode) and stat.S_IMODE(original.stat().st_mode) == item['mode']
            archived[(archive_name, member.name)] = (body, member.mode)
            assert str(original) not in origin_to_location
            origin_to_location[str(original)] = {'archive': archive_name, 'member': member.name}
    if 'source_origin_map' in index:
        assert index['source_origin_map'] == {v['original_path']: {'archive': archive_name, 'member': v['name']} for v in index['files']}
    archive_checks.append({'reference': ref(path), 'index': ref(STAGE / index_name), 'members': count, 'exact_sha_bytes_mode_and_originals': True})
assert len(archived) == len(origin_to_location) == 322
assert top['native_original_member_origin_map'] == {v['original_path']: {'archive': 'native-r1-original-evidence.tar.gz', 'member': v['name']} for v in load(STAGE / 'native-r1-original-evidence.index.json')['files']}

# 顶层复制件和索引文件单独核对；自包含索引明确不含自身。
assert len(top['files']) == 14 and top['index_self_excluded'] is True
for item in top['files']:
    p = STAGE / item['name']
    identity(p.read_bytes(), item)
    assert stat.S_IMODE(p.stat().st_mode) == item['mode']
for item in top['copied_originals']:
    p = STAGE / item['name']
    identity(p.read_bytes(), item)
    identity(pathlib.Path(item['original_path']).read_bytes(), item)
    assert stat.S_IMODE(p.stat().st_mode) == item['mode']

# 重建六入口的结构化引用列表，逐项按封包位置取真实内容；七候选源码仅读取嵌套tar对应项。
entry_paths = [BASE / 'summary.json', BASE / 'artifact_index.json', BASE / 'source_export.json', BASE / 'orin-originals/result.json', BASE / 'orin-originals/frozen/feetech_poke.build.json', CAND]
closure = load(STAGE / 'typed-reference-archive-closure.json')
references = []
nested_bytes, _ = archived[('native-r1-original-evidence.tar.gz', 'source-inputs.tar.gz')]
source_archive_sha = sha(nested_bytes)
nested_members = {}
with tarfile.open(fileobj=io.BytesIO(nested_bytes), mode='r:gz') as source_archive:
    for row in closure['references']:
        location = row['archived_location']
        if 'nested_member' in location:
            assert location['archive'] == 'native-r1-original-evidence.tar.gz' and location['member'] == 'source-inputs.tar.gz'
            assert location['nested_archive_sha256'] == source_archive_sha
            name = location['nested_member']
            if name not in nested_members:
                member = source_archive.getmember(name)
                assert member.isfile()
                nested_members[name] = (source_archive.extractfile(member).read(), member.mode)
for path in entry_paths:
    loc = origin_to_location[str(path)]
    data, _ = archived[(loc['archive'], loc['member'])]
    for item in typed_refs(loads(data)):
        references.append((str(path), item, resolve_original(item['path'])))
assert len(references) == len(closure['references']) == closure['occurrences'] == 376
assert len({r[2] for r in references}) == closure['unique_resolved_files'] == 234
for (origin, item, resolved), row in zip(references, closure['references']):
    assert row['origin'] == origin and row['reference'] == item and row['resolved_original'] == resolved
    loc = row['archived_location']
    if 'nested_member' in loc:
        data, mode = nested_members[loc['nested_member']]
        assert loc['nested_member'] == pathlib.Path(resolved).relative_to(pathlib.Path('/Users/loosqk/.codex/worktrees/feetech-wheel-firmware-contract/robot-system')).as_posix()
    else:
        assert loc == origin_to_location[resolved]
        data, mode = archived[(loc['archive'], loc['member'])]
    identity(data, item)
    assert row['bytes'] == len(data) and row['sha256'] == sha(data) and row['mode'] == mode
assert len(nested_members) == 7

# 新断电记录不回填原停止失败，不假定已测到真实物理断电时间。
receipt_path = STAGE / 'manual-power-cut-receipt-r1.json'
receipt = load(receipt_path)
identity(receipt_path.read_bytes(), summary['human_power_cut_receipt'])
assert receipt['user_answer'] == '两个电机电源已切断，机械臂保持支撑'
assert receipt['received_at_utc'] == '2026-10-08 06:35:40 UTC'
assert receipt['physical_cut_timestamp'] is None and receipt['independent_power_telemetry'] is None
assert receipt['original_run_status'] == 'NEEDS_MANUAL_POWER_CUT' and receipt['original_position_and_stop_failures_preserved'] is True
assert receipt['current_motion_permission'] == 'ENDED' and receipt['new_hardware_go'] is False and receipt['new_uart_or_motion_after_receipt'] is False
assert receipt['deployable'] is False and receipt['d15'] == 'OPEN/DEFERRED'
stop_ref = receipt['related_original_stop']
stop_path = pathlib.Path(stop_ref['path'])
if not stop_path.is_absolute():
    stop_path = ROOT / stop_path
stop_loc = origin_to_location[str(stop_path)]
stop_data, _ = archived[(stop_loc['archive'], stop_loc['member'])]
identity(stop_data, stop_ref)
old_stop = loads(stop_data)
assert 'PENDING' in str(old_stop) and 'NEEDS_MANUAL_POWER_CUT' in str(old_stop)
old_hardware_ref = summary['historical_hardware_boundary']['old_package_summary']
identity(pathlib.Path(old_hardware_ref['path']).read_bytes(), old_hardware_ref)

# 仅验证阶段宣称边界，177方法的独审已封存，不重复运行或重算测试。
assert summary['deployable'] is False
assert summary['source_binding']['source_count'] == 591 and summary['source_binding']['aggregate'] == 'ddad9513566f51fecf915ac7f39e0cccc66b8ae93732847b70ac7c0315458294'
assert summary['software_validation']['count_policy']['distinct_rust_methods'] == 177 and summary['software_validation']['count_policy']['new_methods_subset'] == 12
assert summary['software_validation']['probe_actual_motor_id'] == 8
assert summary['software_validation']['new_linux_precommit_gate'] == 'SEPARATE_NEW_RECEIPT_PENDING_OUTSIDE_THIS_ARCHIVE'
assert summary['manufacturer_contract']['firmware_field_read_on_real_device'] == 'NOT_RUN' and summary['manufacturer_contract']['actual_phase12_changed'] is False
assert summary['historical_hardware_boundary']['right_h2'] == 'OVERALL_FAIL' and summary['historical_hardware_boundary']['old_stop'] == 'FAIL_NEEDS_MANUAL_POWER_CUT'
assert summary['historical_hardware_boundary']['d15'] == 'OPEN/DEFERRED'

# 四份文档新段精读后记录当前字节身份；历史FAIL正文保留。
docs = []
for name in ['CLAUDE.md', 'docs/CHANGELOG.md', 'docs/10_verification.md', 'team-swe/specs/post_e_comm_fault_hardening.HANDOFF.md']:
    p = ROOT / name
    text = p.read_text()
    assert '06:35:40UTC' in text or '06:35:40UTC' in text.replace(' ', '')
    assert '现场FW主/次未读' in text or '现场固件版本未读' in text
    assert 'deployable=false' in text and 'OPEN/DEFERRED' in text and 'NEEDS_MANUAL_POWER_CUT' in text
    assert '177' in text and 'bit3' in text and ('新GO' in text or '新硬件GO' in text)
    docs.append(ref(p))

result = {
    'schema': 'FEETECH_FIRMWARE_STAGE_ARCHIVE_INDEPENDENT_REVIEW_R1',
    'status': 'PASS_LOCAL_ARCHIVE_SUMMARY_WORDING_CORRECTIONS_REQUIRED',
    'created_at': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'stage_summary': ref(STAGE / 'summary.json'),
    'archive_checks': archive_checks,
    'top_level': {'indexed_artifacts': 14, 'copied_originals': 9, 'all_bytes_sha_mode_match': True, 'index_self_excluded': True, 'artifact_index': ref(STAGE / 'artifact_index.json')},
    'typed_archive_closure': {'entry_jsons': 6, 'occurrences': 376, 'unique_resolved_files': 234, 'nested_source_members': 7, 'all_closed_in_exact_archived_locations_sha_bytes_mode': True, 'report': ref(STAGE / 'typed-reference-archive-closure.json'), 'limit': '仅六入口结构化path/SHA，不概称任意字符串路径全局闭合。'},
    'human_receipt': {'receipt': ref(receipt_path), 'answer_matches_actual_user_reply': True, 'received_at': receipt['received_at_utc'], 'physical_cut_time_or_independent_telemetry': None, 'original_NEEDS_and_FAIL_preserved': True, 'old_pending_receipt_preserved': True, 'watch_session_ended': True, 'new_GO': False, 'subsequent_UART_or_motion': False},
    'documents': docs,
    'document_review': '四份新段准确区分原硬件FAIL、新人工断电收尾与纯软件门；没有宣称现场固件已读或完整B1，也不回填旧PENDING/FAIL。',
    'source_or_evidence_blockers': [],
    'summary_wording_corrections_required': [
        {'path': 'implemented[1]', 'original': 'Phase bit3=0 才有 Enable/Zero 构造正路径', 'correction': 'Phase bit3=0才有零停止数学合同构造正路径，不赋予Enable权限；没有Enable构造或API。'},
        {'path': 'software_validation.actual_probe_argv_and_wait[0].zero_uart_evidence', 'correction': 'help只返回usage和预期exit2；具体固件只读错误来自其余两个版本寄存器写探针，不套用于help。'},
    ],
    'accepted_scope': '仅该冻结阶段软件实现及归档闭合；177测试与七源码复核引用先前已封存独审，本轮不重复执行。',
    'limitations': ['新Linux提交前门仍待独立旁附件；原stage tar及summary不重封，不能在本包内宣称后续提交前检查已通过。', '现场固件0/1未读、Phase12未改；完整B1/runtime/真实RPC/wire期限/新硬件门/完整workspace未验。', '原头1、左腕、右H2与停止门FAIL不变，D15 OPEN/DEFERRED、deployable=false。', '预期exit2拒写未做strace；仅源前置门、实际错误和不存在设备路径证据。', '本轮仅读本机原件并写独审输出；没有SSH/UART/Cargo/测试/控制源码修改/重封原包。'],
}
p = OUT / 'review.json'
with p.open('x') as f:
    json.dump(result, f, ensure_ascii=False, indent=2)
    f.write('\n')
print(json.dumps({'status': result['status'], 'review': ref(p), 'original_members': 322, 'typed_refs': 376, 'unique_files': 234, 'docs': len(docs)}, ensure_ascii=False))
