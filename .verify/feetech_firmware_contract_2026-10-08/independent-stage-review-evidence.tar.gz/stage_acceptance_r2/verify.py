#!/usr/bin/env python3
"""定向复核更正汇总及提交前旁附件；不调用编译器、SSH或设备。"""
import datetime
import hashlib
import io
import json
import pathlib
import stat
import tarfile

ROOT = pathlib.Path('/Users/loosqk/repo/rust/robot-system')
AREA = ROOT / 'target/feetech_firmware_integration_2026-10-08'
STAGE = ROOT / '.verify/feetech_firmware_contract_2026-10-08'
PRE = AREA / 'precommit-r1'
OUT = AREA / 'stage_acceptance_r2'
REMOTE = '/home/loosqk/robot-checks/feetech-firmware-contract-precommit-20261008-r1/'
AGG = 'ddad9513566f51fecf915ac7f39e0cccc66b8ae93732847b70ac7c0315458294'


def sha(data):
    return hashlib.sha256(data).hexdigest()


def pairs(items):
    result = {}
    for key, value in items:
        assert key not in result
        result[key] = value
    return result


def load(path):
    return json.loads(path.read_bytes(), object_pairs_hook=pairs)


def ref(path):
    data = path.read_bytes()
    return {'path': str(path), 'bytes': len(data), 'sha256': sha(data)}


def identity(data, item):
    assert sha(data) == item['sha256']
    if 'bytes' in item:
        assert len(data) == item['bytes']


def file_identity(path, item):
    identity(path.read_bytes(), item)
    assert stat.S_ISREG(path.lstat().st_mode)
    if 'mode' in item:
        assert stat.S_IMODE(path.stat().st_mode) == item['mode']


def typed_refs(v):
    if isinstance(v, dict):
        if isinstance(v.get('path'), str) and isinstance(v.get('sha256'), str) and len(v['sha256']) == 64:
            yield v
        for child in v.values():
            yield from typed_refs(child)
    elif isinstance(v, list):
        for child in v:
            yield from typed_refs(child)


OUT.mkdir(exist_ok=True)
stage_summary = load(STAGE / 'summary.json')
assert ref(STAGE / 'summary.json') == {'path': str(STAGE / 'summary.json'), 'bytes': 17652, 'sha256': '1a3faf7918153c3dae11726adc0d7563707e9fbbb99248ecfda488a210a3f56b'}
revision = load(STAGE / 'summary-revision-r2.json')
assert revision['source_or_execution_changes'] is False and revision['original_packs_resealed'] is False
for item in revision['original_top_versions_preserved']:
    file_identity(STAGE / item['preserved_as'], item)
for name, item in revision['unchanged_original_artifacts'].items():
    file_identity(STAGE / name, item)
assert stage_summary['historical_summary_correction']['r1_sha256'] == '0ecff5a1551404a2901c0de6d8c13b002cb9b4eeb02448712f475e1f320bbb97'
old = load(STAGE / 'history_r1/summary.json')
old_projection = json.loads(json.dumps(old))
assert old_projection['schema'] == 'FEETECH_FIRMWARE_CONTRACT_STAGE_ARCHIVE_V1' and stage_summary['schema'] == 'FEETECH_FIRMWARE_CONTRACT_STAGE_ARCHIVE_V2'
old_projection['schema'] = stage_summary['schema']
old_projection['implemented'][1] = stage_summary['implemented'][1]
old_projection['software_validation']['actual_probe_argv_and_wait'][0]['zero_uart_evidence'] = stage_summary['software_validation']['actual_probe_argv_and_wait'][0]['zero_uart_evidence']
new_projection = {k: v for k, v in stage_summary.items() if k not in {'summary_revision', 'historical_summary_correction'}}
assert old_projection == new_projection
assert '零停止数学合同构造正路径，不赋予 Enable 能力' in stage_summary['implemented'][1]
assert 'Enable/Zero' not in stage_summary['implemented'][1]
help_description = stage_summary['software_validation']['actual_probe_argv_and_wait'][0]['zero_uart_evidence']
assert '实际 argv 仅 --help' in help_description and '用法' in help_description and '不是固件只读名称错误' in help_description
top = load(STAGE / 'artifact_index.json')
for item in top['files']:
    file_identity(STAGE / item['name'], item)
assert len(top['files']) == 18 and top['index_self_excluded'] is True
old_index = load(STAGE / 'history_r1/artifact_index.json')
for item in old_index['files']:
    p = STAGE / item['name']
    if item['name'] == 'summary.json':
        p = STAGE / 'history_r1/summary.json'
    file_identity(p, item)
current_verification = load(STAGE / 'archive-verification.json')
for key in ['artifact_index', 'summary', 'summary_revision_receipt']:
    item = current_verification[key]
    file_identity(STAGE / item['name'], item)
assert current_verification['original_packs_unchanged'] is True and current_verification['r1_top_bytes_preserved'] is True

# 提交前独立旁附件原件，逐项比包和本体，不执行其helper。
pre_summary = load(PRE / 'summary.json')
assert ref(PRE / 'summary.json')['sha256'] == '85f7f73ea659d65302424deab932a12ceff421e569b3e324d856810b3e7d6d95' and (PRE / 'summary.json').stat().st_size == 12617
index = load(AREA / 'precommit-r1-original-evidence.index.json')
archive_path = AREA / 'precommit-r1-original-evidence.tar.gz'
file_identity(archive_path, index['archive'])
assert archive_path.stat().st_size == 621104 and sha(archive_path.read_bytes()) == '956bf0f56d37d47586447002ad42adf0d8eb579092f50a1eaab010ee2c7e08c3'
members_by_original = {}
with tarfile.open(archive_path, 'r:gz') as archive:
    members = archive.getmembers()
    expected_items = {item['name']: item for item in index['files']}
    assert len(members) == len({m.name for m in members}) == len(expected_items) == 72
    assert {m.name for m in members} == set(expected_items)
    for member in members:
        assert member.isfile() and not pathlib.PurePosixPath(member.name).is_absolute() and '..' not in pathlib.PurePosixPath(member.name).parts
        item = expected_items[member.name]
        data = archive.extractfile(member).read()
        identity(data, item)
        assert member.mode == item['mode']
        file_identity(pathlib.Path(item['original_path']), item)
        members_by_original[item['original_path']] = {'member': member.name, 'bytes': len(data), 'sha256': sha(data), 'mode': member.mode}
archive_verification = load(AREA / 'precommit-r1-archive-verification.json')
for key in ['archive', 'index', 'summary']:
    file_identity(pathlib.Path(archive_verification[key]['path']), archive_verification[key])
assert archive_verification['members'] == 72

# 旁附件结构化引用按当前本体及原包核对；根fmt原件属于先前支持包，不冒称在72份本包中。
refs = []
for origin in [PRE / 'summary.json', PRE / 'orin-originals/result.json']:
    for item in typed_refs(load(origin)):
        original = pathlib.Path(item['path'])
        if item['path'].startswith(REMOTE + 'qa/'):
            original = PRE / 'orin-originals' / item['path'].removeprefix(REMOTE + 'qa/')
        file_identity(original, item)
        location = members_by_original.get(str(original))
        if location is None:
            assert str(original) == str(AREA / 'root_precommit_fmt_r2/result.json')
            supporting = load(STAGE / 'supporting-original-evidence.index.json')
            candidates = [v for v in supporting['files'] if v['original_path'] == str(original)]
            assert len(candidates) == 1
            entry = candidates[0]
            with tarfile.open(STAGE / 'supporting-original-evidence.tar.gz', 'r:gz') as archive:
                body = archive.extractfile(entry['name']).read()
                identity(body, item)
            location = {'archive': 'supporting-original-evidence.tar.gz', 'member': entry['name']}
        refs.append({'origin': str(origin), 'reference': item, 'resolved_original': str(original), 'archived_location': location})

# 真实六子进程回执、stdout/stderr、启动身份及执行时间顺序。
children = []
rows = {}
for path in sorted((PRE / 'orin-originals').glob('*/completion.json')):
    row = load(path)
    rows[path.parent.name] = row
    assert row['exit_code'] == 0 and row['reaped'] is True and row['signals'] == [] and row['budget_exceeded'] is False
    assert row['session_residual_before_cleanup'] == row['session_residual_after_cleanup'] == []
    assert 'runner_error' not in row and 'interrupted_signal' not in row
    assert row['identity']['pid'] == row['identity']['pgid'] == row['identity']['sid'] == row['pid']
    assert row['identity']['boot_id'] == '6cf7ee3e-a3c5-4c91-80bc-4ca924818b53'
    assert row['elapsed_ns'] == row['ended_monotonic_ns'] - row['started_monotonic_ns']
    assert row['exec_gate_released'] is True and row['env']['RUSTUP_TOOLCHAIN'] == 'nightly'
    launch = load(path.parent / 'launch.json')
    assert launch['argv'] == row['argv'] and launch['pid'] == row['pid'] and launch['identity'] == row['identity']
    for channel in ['stdout', 'stderr']:
        body = (path.parent / (channel + '.log')).read_bytes()
        assert sha(body) == row[channel + '_sha256'] and len(body) == row[channel + '_bytes']
    children.append({'name': path.parent.name, 'pid': row['pid'], 'argv': row['argv'], 'exit_code': 0, 'natural_reaped': True, 'completion': ref(path)})
assert len(children) == len({v['pid'] for v in children}) == 6
assert rows['fmt']['argv'] == ['cargo', '+nightly', 'fmt', '--all']
assert rows['clippy_default']['argv'] == ['cargo', '+nightly', 'clippy', '--all', '--all-targets', '--', '-D', 'warnings']
assert rows['fmt']['ended_monotonic_ns'] <= rows['clippy_default']['started_monotonic_ns']
assert (PRE / 'orin-originals/rustc_before/stdout.log').read_bytes() == (PRE / 'orin-originals/rustc_after/stdout.log').read_bytes()
assert (PRE / 'orin-originals/cargo_before/stdout.log').read_bytes() == (PRE / 'orin-originals/cargo_after/stdout.log').read_bytes()
rustc = (PRE / 'orin-originals/rustc_before/stdout.log').read_text()
assert 'commit-hash: 1d81eb4ad9cd207e3e638bd32b17ec4fce8412a6' in rustc and 'release: 1.101.0-nightly' in rustc and 'host: aarch64-unknown-linux-gnu' in rustc

# 仅源码身份比较，不重复七源码语义审或177测试。
expected = load(PRE / 'expected_source.json')
assert len(expected['files']) == 591 and expected['source_manifest_sha256'] == AGG
canonical = json.dumps(expected['files'], sort_keys=True, separators=(',', ':'), ensure_ascii=False, allow_nan=False).encode()
assert sha(canonical) == AGG
windows = sorted((PRE / 'orin-originals').glob('*source*.json'))
assert len(windows) == 14
for p in windows + [PRE / 'main_source_before.json', PRE / 'main_source_after.json']:
    assert load(p) == expected
for name, item in expected['files'].items():
    p = ROOT / name
    file_identity(p, item)
    assert bool(p.stat().st_mode & stat.S_IXUSR) == item['executable']
native = load(PRE / 'orin-originals/result.json')
assert native['status'] == 'PASS' and native['compiler_before'] == native['compiler_after'] == pre_summary['compiler']
assert native['source_aggregate'] == pre_summary['source_aggregate'] == AGG and native['source_count'] == pre_summary['source_count'] == 591
assert native['interrupted_signal'] is None
assert native['identity'] == {'hostname': 'ubuntu', 'arch': 'aarch64', 'uid': 1000, 'gid': 1000, 'boot_id': '6cf7ee3e-a3c5-4c91-80bc-4ca924818b53'}
for item in pre_summary['host_owners']:
    row = load(pathlib.Path(item['reference']['path']))
    assert row['wait_returncode'] == 0 and row['reaped'] is True and row['owner_sent_signals'] == [] and row['received_signals'] == {} and row['errors'] == []
    assert row['pid'] == item['pid'] and row['owner_pid'] == item['owner_pid']
assert len(pre_summary['host_owners']) == 4
wait = load(PRE / 'tool_owner_wait.json')
assert wait['final']['exit_code'] == 0 and json.loads(wait['final']['output']) == load(PRE / 'orin_precommit.owner/result.json')

result = {
    'schema': 'FEETECH_FIRMWARE_STAGE_ACCEPTANCE_INDEPENDENT_R2',
    'status': 'PASS_STAGE_CORRECTIONS_AND_PRECOMMIT_NO_BLOCKER',
    'created_at': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'stage_summary_r2': ref(STAGE / 'summary.json'),
    'two_wording_corrections': '已正确限定零停止数学合同、不赋Enable；help用法exit2与两固件名只读错误区分。',
    'only_two_semantic_wording_fields_plus_revision_metadata_changed': True,
    'r1_history_bytes': revision['original_top_versions_preserved'],
    'stage_current_top_index': {'reference': ref(STAGE / 'artifact_index.json'), 'indexed_entries': 18, 'all_actual_sha_bytes_mode_same': True},
    'original_stage_tar_bytes_unchanged': {name: item for name, item in revision['unchanged_original_artifacts'].items() if name.endswith('.tar.gz')},
    'precommit_summary': ref(PRE / 'summary.json'),
    'precommit_archive': {'reference': ref(archive_path), 'index': ref(AREA / 'precommit-r1-original-evidence.index.json'), 'members': 72, 'exact_set_and_bytes_sha_mode_and_originals_same': True},
    'precommit_typed_refs': {'occurrences': len(refs), 'unique_files': len({v['resolved_original'] for v in refs}), 'all_bodies_closed': True, 'root_fmt_ref_location': '先前支持包root/root_precommit_fmt_r2/result.json，不属于72份旁附件原件'},
    'precommit_children': children,
    'fmt_then_root_clippy_actual_natural_exit0': True,
    'source_identity': {'count': 591, 'aggregate': AGG, 'native_windows_exact': 14, 'main_before_after_and_current_same': True},
    'compiler': pre_summary['compiler'],
    'cargo_before_after_same': True,
    'all_six_children_no_signals_budget_violation_or_session_residual': True,
    'host_owners': {'count': 4, 'natural_wait_exit0': True, 'tool_session': wait['initial']['session_id'], 'tool_final_exit0': True},
    'blockers': [],
    'accepted_scope': '七源码阶段软件验收及新同源nightly提交前fmt→根默认Clippy；两措辞更正后归档可收口。177方法和release等前阶段结果只引用，不重新累计或声称本次重跑。',
    'physical_and_runtime_boundary': '原硬件NEEDS/FAIL不改；新人工断电已报告但不是硬件PASS或新GO。现场FW未读、Phase12未改；无完整B1、硬件/真实RPC/wire期限或完整workspace新验收，D15 OPEN/DEFERRED、deployable=false。',
    'review_operations': {'ssh': 0, 'uart': 0, 'cargo': 0, 'tests_rerun': 0, 'source_or_original_evidence_edits': 0},
    'r1_reviews_and_helper_failures': '原字节保留，本r2旁附件不覆盖。',
}
p = OUT / 'review.json'
with p.open('x') as f:
    json.dump(result, f, ensure_ascii=False, indent=2)
    f.write('\n')
print(json.dumps({'status': result['status'], 'review': ref(p), 'precommit_refs': result['precommit_typed_refs'], 'source_windows': 14, 'children': 6}, ensure_ascii=False))
