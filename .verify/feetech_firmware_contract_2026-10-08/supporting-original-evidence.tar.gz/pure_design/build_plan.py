"""仅生成设计与只读身份复核，不启动 Cargo/SSH/UART，不修改项目源码。"""
from pathlib import Path
import datetime
import hashlib
import json

ROOT = Path('/Users/loosqk/repo/rust/robot-system')
OUT = ROOT / 'target/xlerobot_b1_firmware_contract_20261008'
OFFICIAL = ROOT / 'target/feetech_firmware_contract_2026-10-08'
CANDIDATE = Path('/Users/loosqk/.codex/worktrees/xlerobot-wheel-profile/robot-system')


def identity(path):
    path = Path(path)
    raw = path.read_bytes()
    return {'path': str(path), 'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}


def anchor(relative_path, needle, meaning, root=ROOT):
    path = root / relative_path
    lines = path.read_text().splitlines()
    matches = [n for n, line in enumerate(lines, 1) if needle in line]
    assert matches, (str(path), needle)
    return {**identity(path), 'anchor': needle, 'lines': matches, 'meaning': meaning}


def write_json(name, value):
    path = OUT / name
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n')
    json.loads(path.read_text())
    return identity(path)


before = json.loads((OUT / 'source_snapshot_before.json').read_text())
after_rows = [identity(row['path']) for row in before['files']]
checks = [
    {'path': old['path'], 'before_sha256': old['sha256'], 'after_sha256': new['sha256'],
     'before_bytes': old['bytes'], 'after_bytes': new['bytes'],
     'same': old['sha256'] == new['sha256'] and old['bytes'] == new['bytes']}
    for old, new in zip(before['files'], after_rows)
]
assert all(row['same'] for row in checks), '本轮定位源码或一手证据身份改变，不生成通过结论'
source_after = write_json('source_snapshot_after.json', {
    'created_at': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'scope': before['scope'], 'files': after_rows, 'comparisons': checks,
    'all_same': True,
})

table = 'target/feetech_firmware_contract_2026-10-08/web/official-sms-sts-memory-table.md'
source_map = [
    anchor(table, '|0|0x00|固件主版本号|', '固件主版本0，1byte，只读'),
    anchor(table, '|1|0x01|固件次版本号|', '固件次版本1，1byte，只读'),
    anchor(table, '|18|0x12|相位|', 'Phase18，范围0..254，不自动写'),
    anchor(table, '|33|0x21|运行模式|', 'Mode33=1恒速'),
    anchor(table, '|46|0x2E|运行速度|', '目标46/47，bit15，-32767..32767，两RPM单位，细单位精度仍0.732RPM'),
    anchor(table, '|55|0x37|锁标志|', 'Lock0写EPROM掉电保存；Lock1写EPROM掉电不保存，未说一定拒收'),
    anchor(table, '|58|0x3A|当前速度|', '反馈58/59，bit15，单位由Phase决定'),
    anchor(table, '- BIT2（4）', '单位bit2=0/1为0.732/0.0146RPM'),
    anchor(table, '- BIT3（8）', 'bit3=0零停/1零最高'),
    anchor('crates/robot-adapters/feetech/src/registers.rs', 'Lock = 1', '当前绝对写保护注释与v181保存语义矛盾'),
    anchor('crates/robot-adapters/feetech/src/registers.rs', 'EEPROM (Lock=1', '当前分区注释与v181保存语义矛盾'),
    anchor('crates/robot-adapters/feetech/src/registers.rs', '条目在写之前需要', '当前文档把所有写前置Lock0，需澄清固件/保存语义'),
    anchor('crates/robot-adapters/feetech/examples/feetech_poke.rs', '否则**静默失败**', '当前poke绝对失败注释不受v181支持'),
    anchor('crates/robot-adapters/feetech/src/registers.rs', 'pub fn ensure_not_diagnostic_write', '原B0三诊断门保留'),
    anchor('crates/robot-adapters/feetech/src/bus.rs', 'ensure_not_diagnostic_write(reg_name)?;', '四具名write入口先原门，新增两个版本只读门随后零IO'),
    anchor('crates/robot-adapters/feetech/src/bus.rs', 'pub fn read(', '追加2版本READ沿原路径'),
    anchor('crates/robot-adapters/feetech/src/bus.rs', 'pub fn sync_read_by_id_into(', '固定ID无分配读回位置'),
    anchor('crates/robot-adapters/feetech/src/encoding.rs', 'pub fn encode_sign_magnitude', '复用有范围检查的整数signed-magnitude'),
    anchor('crates/robot-adapters/feetech/src/encoding.rs', 'pub fn decode_sign_magnitude', '复用方向幅度解码，保wire负零原件'),
    anchor('crates/robot-adapters/feetech/src/error.rs', 'DiagnosticRegisterWriteForbidden(&', '保原错误；新增2版本独立Readonly错误'),
    anchor('crates/robot-adapters/feetech/src/error.rs', 'impl From<FeetechError>', '新增错误需明确穷尽映射Argument'),
    anchor('crates/robot-adapters/feetech/src/diagnostic.rs', '| F::DiagnosticRegisterWriteForbidden(_)', '新增错误沿Argument=(8,1,0)'),
    anchor('crates/robot-adapters/feetech/examples/feetech_poke.rs', 'fn preflight_diagnostic_write', 'CLI新增2版本拒写在open前；原三门保留'),
    anchor('crates/robot-adapters/feetech/src/adapter.rs', 'out.velocities[i] = self.vel_raw[i] as f32;', '当前反馈raw未SI换算'),
    anchor('crates/robot-adapters/feetech/src/adapter.rs', 'fn write_command(', '当前只执行Position，pureprofile未接入'),
    anchor('crates/robot-adapters/feetech/src/adapter.rs', 'fn set_mode(', '当前遍历全joint_names，不可误用于混合总线'),
    anchor('crates/robot-adapters/feetech/src/adapter.rs', 'fn enable(', '当前Position同步序列不可冒用作Mode1防飞'),
    anchor('crates/robot-adapters/feetech/src/adapter.rs', 'pub fn safety_stop_fast(', '独立TorqueDisable必须始终可用'),
    anchor('crates/robot-core/src/adapter.rs', 'pub struct JointCommandView', '保持公共接口'),
    anchor('crates/robot-core/src/executor_ctrl.rs', 'ZeroCommand =', '仅软件输出策略，不证明固件零义'),
    anchor('crates/robot-s0/src/serial_tick.rs', 'Ok(PeriodicOutput::VelocityZero', '当前栈零切片不是现场固件验收'),
    anchor('crates/robot-s0/src/serial_tick.rs', 'adapter.write_command(&output)', '未来接入需profile/authority/wire截止门'),
]

candidate_relative = 'crates/robot-core/src/wheel_velocity_profile.rs'
candidate_text = (CANDIDATE / candidate_relative).read_text()
candidate_identity = identity(CANDIDATE / candidate_relative)
assert candidate_identity['sha256'] == 'ddad58c8fd185d1fdde3547a86c115ba5a8b3cbf14928c8e564782244fc08d66'
assert 'pub struct WheelVelocityProfile' in candidate_text
assert 'pub fn new(' in candidate_text
assert all(f'{name}: f64' in candidate_text and f'pub {name}:' not in candidate_text
           for name in ['wheel_radius_m', 'base_radius_m', 'max_wheel_rad_s'])
assert not any(word in candidate_text for word in ['impl Default', 'derive(Default', 'unimplemented!', 'todo!', 'unsafe', 'serde'])
assert all(f'!{name}.is_finite() || {name} <= 0.0' in candidate_text
           for name in ['wheel_radius_m', 'base_radius_m', 'max_wheel_rad_s'])

p1b = {
    'status': 'STATIC_GEOMETRY_CONTRACT_COMPATIBLE_NOT_FIRMWARE_PROFILE',
    'candidate_identity': candidate_identity,
    'checks': '当前实际文件与既有独审SHA相同；三私有f64/有限严格正/精确getter/无默认unchecked或运行副作用，已有4测试方法静态可见。本轮不重跑Cargo。',
    'current_main_tree_contains_module': (ROOT / candidate_relative).exists(),
    'use': '作为独立几何与max_wheel_rad_s配置值，getter可传原XLeRobotOmniKinematics::new；不修改该值合同加入Phase/Model/固件。',
    'firmware_profile': '新增feetech纯类型负责三轮role/ID、完整Phase、单位、signed-magnitude、固件身份，组合使用两类型；geometry成功不允许Enable。',
    'raw_limit_derivation': '若以后从max_wheel_rad_s推导raw_limit，先有限算术与表示范围检查，再向下取整不超过名义SI上限；结果不足1raw则具体错误，不抬高默认最小速度。直接raw_limit必须独立显式配置。厂家实际精度不受此算术证明。',
    'extremes': 'P1B允许最小正subnormal/f64MAX作为值；消费者计算溢出/下溢需各自拒绝，不通过加强core构造或硬件默认参数掩盖。',
    'existing_review': identity(ROOT / 'target/xlerobot_velocity_foundation/independent_p1a_p1b_dynamic_review_resume_r2.json'),
    'limits': '隔离Mac候选非主树集成、非Linux门、非固件/三轮实机证明；本轮仅静态适配核查，不新增动态通过计数。',
}
p1b_file = write_json('p1b_profile_fit_review.json', p1b)

response = json.loads((OFFICIAL / 'web/official-sms-sts-document-response.json').read_text())
assert response['data']['version'] == 181
assert response['data']['mdcontent'] == (OFFICIAL / 'web/official-sms-sts-memory-table.md').read_text()
numeric = json.loads((OUT / 'numeric_design_result.json').read_text())
assert numeric['status'] == 'PASS'
assert numeric['all_wire_words_both_units_roundtrip_samples'] == 131072
assert numeric['positive_role_unit_fixtures'] == 6

plan = {
    'schema': 'XLEROBOT_B1_STS3215_WHEEL_FIRMWARE_CONTRACT_DESIGN_R2',
    'created_at': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'status': 'DESIGN_R2_SCOPE_APPROVED_IMPLEMENTATION_TO_FOLLOW_SEPARATE_CANDIDATE' ,
    'observed_main_head': 'e8a5172963bcc9dddb943566e1fb453a8ec822c0',
    'scope': '仅本机target新增设计/数学oracle/只读审查，不SSH/Cargo/UART，不改Rust或父agent维护脚本',
    'operations': {'source_write': 0, 'cargo': 0, 'ssh': 0, 'uart': 0, 'firmware_write': 0, 'install': 0, 'commit': 0, 'push': 0},
    'actual_hardware_from_root_not_measured_by_this_agent': {
        'roles': {'front': 8, 'left': 7, 'right': 9}, 'bus': 'right',
        'model': 777, 'mode': 1, 'phase': 12, 'torque': 0,
        'goal_velocity': 0, 'present_velocity': 0, 'firmware_version': None,
        'meaning': '断扭读回0不证明使能后目标0语义；版本缺失是具体待READ缺口',
    },
    'primary_contract': {
        'human_page': 'http://doc.feetech.cn/#/prodinfodownload?srcType=FT-SMS-STS-emanual-229f4476422d4059abfb1cb0',
        'public_get': 'http://longbos.com:9009/workflow/yf-specification/getBysrcType/FT-SMS-STS-emanual-229f4476422d4059abfb1cb0',
        'platform_version': 181, 'is_firmware_version': False,
        'document': identity(OFFICIAL / 'web/official-sms-sts-memory-table.md'),
        'response': identity(OFFICIAL / 'web/official-sms-sts-document-response.json'),
        'prior_full_chain_review': identity(OFFICIAL / 'review.json'),
        'device_firmware_supported_range_published': False,
    },
    'typed_profile_proposed': {
        'module': 'crates/robot-adapters/feetech/src/velocity_profile.rs（新纯模块；未创建）',
        'type': 'Sts3215WheelProfile',
        'constructor': 'try_bind(ObservedWheelRegisters, ExpectedWheelIdentity, raw_limit)->Result<Self,WheelProfileError>',
        'positive_path': 'fixed front8/left7/right9+Model777+Mode1+version pair present/exact expected+phase0..254/exact expected+bit3clear+raw_limit1..32767',
        'actual_phase12_result': 'ZeroMeansMaximumSpeed；当前缺fw亦具体FirmwareMissing，确定性字段次序，不留永久Unverified占位',
        'units_rpm_per_raw': {'bit2_0': 0.732, 'bit2_1': 0.0146},
        'precision_rpm_per_manufacturer': 0.732,
        'command_address': 46, 'feedback_address': 58, 'width': 2,
        'encoding': 'signed-magnitude15；range-32767..32767；LE；不是two_complement_i16',
        'float_order': ['rejectNaNInf', 'multiply unitfactor/reject intermediate nonfinite', 'round nearest ties away zero', 'reject rounded abs>32767 before clamp', 'bounded int convert', 'reject abs>explicit rawlimit RawLimitExceeded/no clamp', 'encode bit15 canonical zero0000'],
        'decoded_negative_zero': '保wire8000原件，名义0，命令规范化0000；不宣称反馈非法',
        'position_armik_public_trait': '保持',
        'freshness': '未来调用方RobotClock/authority/供电与串口会话绑定，纯数学类型不是enable授权',
    },
    'firmware_read_small_piece_proposed': {
        'entries': {'Firmware_Major_Version': [0, 1], 'Firmware_Minor_Version': [1, 1]},
        'current_support': False,
        'new_guard': '仅2名字独立ReadonlyWriteForbidden，四API先原B0三门再新门，CLI open前拒；无TX/RX',
        'b0_three_gates': '保持Phase/CW_Dead_Zone/CCW_Dead_Zone拒写及原错误优先',
        'diagnostic_group': [8, 1, 0],
        'no_factory_register_expansion': True,
    },
    'lock55_design': {
        'manufacturer_semantics': {'0': 'EPROM writes persist across power-off', '1': 'EPROM writes do not persist across power-off'},
        'not_proven': '现场firmware下Lock1 Phase4临时生效、切回0保存细节尚未有实机证据；不能实现猜测为事实',
        'transition': {'roles_ids': {'front': 8, 'left': 7, 'right': 9}, 'old_phase': 12, 'new_phase': 4, 'clear_mask': 8, 'all_other_bits_preserved': True},
        'authorization': '尚未取得新Phase/Lock/EEPROM维护写授权；本件只方案，root以具体方案请求必要范围',
        'ordinary_diagnostic_write_gate': '不取消或绕过',
        'transient': '入口原Lock必须1并保持1，原Lock0具体拒绝；Torque0+备份→Phase4一次逐项ACK/readback；失败STOP，无自动Lock0/重试/enable。',
        'persistent': '另获EEPROM授权后Torque0+备份→Lock0 ACK/readback→Phase4 ACK/readback→原Lock ACK/readback；人工电机断电复电→新READ固件/Model/Mode/Phase4/Lock/Torque0；不自动enable。',
        'rollback': '先TorqueDisable/静止证据或立即人工切电；同设备3IDs按已授权保存语义还原备份Phase12/Lock+读回。Phase12后禁止Enable/Zero/Motion；失败STOP不循环补写。',
        'subsequent_stop_only': '配置PASS也不启扭；独立当次GO/冻结软件/profile/freshness/预算/真正停止与断扭门',
    },
    'source_map': source_map,
    'numeric_validation': {'result': identity(OUT / 'numeric_design_result.json'), 'oracle': identity(OUT / 'numeric_design_oracle.py'), 'status': numeric['status'], 'scope': numeric['meaning'], 'samples_not_rust_tests': 131072, 'positive_fixtures': 6},
    'p1b_fit_review': p1b_file,
    'source_identity': {'before': identity(OUT / 'source_snapshot_before.json'), 'after': source_after, 'same_file_count': len(checks), 'not_complete_workspace_freeze': True},
    'markdown': identity(OUT / 'plan.md'),
    'limitations': ['当前adapter仅Position/write、速度readraw未SI；pureprofile未接S0/S1', '本轮未编译Rust/未硬件WRITE/未完整workspace或release', 'P1B仅独立Mac几何候选未集成', 'H2/左腕FAIL，D15 OPEN/DEFERRED、deployable=false保持'],
}
plan_file = write_json('plan.json', plan)
artifact_paths = ['plan.md', 'plan.json', 'build_plan.py', 'numeric_design_oracle.py', 'numeric_design_result.json', 'source_snapshot_before.json', 'source_snapshot_after.json', 'p1b_profile_fit_review.json']
index = write_json('artifact_index.json', {
    'created_at': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'files': [identity(OUT / name) for name in artifact_paths],
    'status': 'READBACK_IDENTITIES_AND_JSON_PARSE_PASS',
    'source_identity_unchanged_count': len(checks),
    'plan': plan_file,
})
print(json.dumps({'plan': plan_file, 'index': index, 'source_same_count': len(checks), 'p1b': p1b['status'], 'numeric_model': numeric['status']}, ensure_ascii=False))
