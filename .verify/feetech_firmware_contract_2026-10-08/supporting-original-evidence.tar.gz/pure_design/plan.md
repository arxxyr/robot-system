# B1 三轮固件合同与 Phase 维护方案（2026-10-08，仅设计）

状态：**DESIGN_ONLY**。本文件提出纯软件小件及独立维护操作方案；本设计编制阶段未修改 Rust 源码、未编译、未访问 Orin/UART、未写固件、未使能电机。root后续已另授权独立managed worktree实施纯小件与本机QA，其结果以独立候选回执为准。基础 adapter 尚未执行 Velocity，当前速度反馈仍为 raw。本文件不把纯函数模型或隔离 P1B 候选称为 B1 接入完成。

## 当前事实与一手合同

总管本轮实际只读事实：底盘 front8、left7、right9 均 Model777、Mode1、Phase12、Torque0，目标/反馈速度为0；17个电机 Phase 均为12。固件版本0/1尚未读到。断扭状态下反馈0不能证明使能后的目标0语义。

厂家页面：[磁编码 STS 内存表](http://doc.feetech.cn/#/prodinfodownload?srcType=FT-SMS-STS-emanual-229f4476422d4059abfb1cb0)。公开 HTML→JS→GET 链、原始响应和下载身份均在 [review.json](/Users/loosqk/repo/rust/robot-system/target/feetech_firmware_contract_2026-10-08/review.json)。响应的平台字段 version181、lastModifiedDate=2026-08-27T12:08:28Z，不是现场固件版本。它未列出适配固件版本白名单，因此读到相同版本对只完成身份绑定，仍不能冒称厂家已认证该现场固件。

原表精确行号见本目录 plan.json.source_map。原表18/19行：固件主版本0、次版本1，各1byte，只读；38行 Phase18、0..254；51行 Mode33=1恒速；66行 GoalVelocity46/47，-32767..32767，bit15方向；75行 PresentVelocity58/59，bit15方向。102行 Phase bit2=0为0.732RPM/raw、bit2=1为0.0146RPM/raw；103行 bit3=0速度0停止、bit3=1速度0最高速度。厂家还写明：细单位0.0146RPM的实际精度仍为0.732RPM。不能把细单位字面值当精确编码器 steps/s，也不能把 dimos 的6rad/s↔1023经验比例当实机标定。

Phase12=0x0c 有 bit2、bit3：按当前厂家合同为细单位且目标0最高速度。它必须得到具体错误 ZeroMeansMaximumSpeed，拒绝 Enable、ZeroCommand 和该纯 profile 的 Motion 构造。Phase4=0x04只清 bit3，保留 bit2；原驱动方向、桥模式、反馈、PWM等位不改变。

## 小件一：有限固件版本 READ

当前 STS3215_CONTROL_TABLE 没有固件版本名字。追加 Firmware_Major_Version=(0,1)、Firmware_Minor_Version=(1,1)，raw unsigned，无符号位；不扩展工厂82/83等地址解释，不添加 EEPROM 写授权。

仅追加表项会让现有四个具名 write API 接受它们，因此必须同时增加仅针对这两个名字的独立拒写门与 ReadOnlyRegisterWriteForbidden 错误。write/sync_write/sync_write_by_id/sync_write_by_id_into 仍先走原 ensure_not_diagnostic_write，使 Phase/CW/CCW 三门及错误优先级完全保留，再走新只读门，且都在参数查表、连接/通信之前拒绝。feetech_poke 在打开串口前对新增两名 write 拒绝；read 可走原 read 逻辑。错误分类与 From 穷尽映射沿原 Argument=(8,1,0)，不误归通信 Unknown。

必要软件验证：两字段各1byte原始 READ 帧/解码；两名×四写入口无 TX/RX 且具体错误；CLI 两名 write 在打开 transport 前拒绝；旧三诊断门全部保留；未知名、原允许写名字及原错误顺序回归。纯软件验收后，由总管另行新产物绑定进行有限硬件 READ，保留每轮版本对、Model、Mode、Phase 与 USB/bus/ID 身份。此处没有串口操作。

## 小件二：三轮 typed profile 与数学正路径

建议新增 feetech/velocity_profile.rs（独立纯模块）和 lib.rs 导出；不向通用 core geometry 类型塞设备固件语义，不改 Position/ArmIK 或现有公共 adapter trait。所有字段私有，不提供 Default、unchecked 构造、可写 getter 或允许跳过验证的 verified/live_allowed 布尔值。

具体值类型：WheelRole={Front,Left,Right}；FirmwareIdentity={major:u8,minor:u8}；VelocityUnit={Rpm0_732,Rpm0_0146}；ObservedWheelRegisters 持 Model、Mode、完整 Phase、版本对、角色/ID；ExpectedWheelIdentity 持明确的 rightbus/USB 身份、front8/left7/right9映射、期望版本对和完整 Phase。Sts3215WheelProfile::try_bind(observed,expected,raw_limit) 的每个成功出口都校验：角色与ID固定、Model777、Mode1、版本存在且逐项匹配、Phase为0..254并与完整期望值匹配、bit3=0、raw_limit为1..32767。bit2决定单位。成功 profile 不保存动态 permission、不声称 EEPROM 修改或真实停止验收；可复制的数学参数不能跨串口重新打开/电机复位复用旧现场证明。

具体错误至少区分 WrongWheelRole/Id、WrongModel、WrongMode、FirmwareMissing/Mismatch、PhaseOutOfRange/Mismatch、ZeroMeansMaximumSpeed、InvalidRawLimit、NonFiniteVelocity、ArithmeticOverflow、WireMagnitudeOutOfRange、RawLimitExceeded。构造验证按固定字段次序报告，Phase12不会落入永久 Unverified 占位。当前现场缺固件版本，真实 profile 构造具体 FirmwareMissing；虚拟版本(1,2)+Phase0/4可验证三轮×两单位正路径，不能回填现场版本。

try_encode_rad_s 的顺序固定：

1. 请求 omega 必须有限，NaN/±Inf直接拒绝。
2. raw_float=omega×60/(TAU×rpm_per_raw)。两个明确厂家名义单位分别732/1000、146/10000 RPM；中间非有限拒绝 ArithmeticOverflow。
3. 最近整数舍入，精确半值远离0（Rust f64::round）；先校验舍入结果的绝对值≤32767。32768或更大直接拒绝，不用配置限幅掩盖表示溢出，再做有界整数转换。
4. 对可表示结果再校验显式 raw_limit；绝对值超限直接返回 RawLimitExceeded，不进行单轮限幅。三轮同比限速统一由既有上层处理；profile只验证表示范围和边界，不另改比例。0与负0统一命令0x0000。
5. signed-magnitude15：abs(raw) | (negative ? 0x8000 : 0)，复用现有编码帮助函数。+60=0x003c、-60=0x803c；不使用 i16 二补码；-32768拒绝。

decode_velocity_word 按 bit15方向与15位幅度解码，再乘 rpm_per_raw×TAU/60 得到名义 rad/s，同时保留原 word。0x8000反馈名义为0，保留原始字节，不自行宣称非法；后续命令规范化为0x0000。方向符号不等于机器人轮安装方向，后者保留具名 role/配置层独立校验。

纯模块不依赖时钟、IO、heap、锁或运行时；现场观察的 freshness/authority 由未来非RT初始化/配置调用方使用 RobotClock 与既有授权代次绑定，成功数学构造不能绕过当轮 authority、截止时间、RT门或串口 writer 唯一性。复位、USB替换、Mode/Phase/固件变化必须失效重建；不在 RT 路径动态分配或读取配置。

独立 numeric_design_oracle.py 已实际 exit0：两单位×全部65536 wire words 的131072次解码/再编码模型样本，六个 role/unit 正路径，signed60、±0、舍入、配置超限拒绝、非有限/表示溢出、角色/型号/模式/版本/Phase拒绝。其 PASS **仅为 Python 数学与条件模型**，不是 Rust 测试、编译或硬件验收。源文件/结果身份见 plan.json。后续实现需在浮动最新 nightly 真实 fmt→根 Clippy→相关测试并绑定完整源码/编译器与真实回收；本轮不启动 Cargo。

## 接入边界与尚未通过的门

当前 adapter.rs:575 write_command 仅执行 Position；567速度raw as f32未换算SI；612 set_mode会遍历全joint_names；640 enable沿 Position同步GoalPos再上扭。不能把后两方法直接用于混合右总线三轮，使手臂/头部误改模式，或让旧 GoalVelocity 在上扭时生效。

未来三轮专用 adapter 分支必须只选择三轮role并绑定 profile；启扭前先具名写三轮 GoalVelocity0、逐项读回、再上扭，且 bit3=0为必要条件。零反馈不能替代零语义验证。普通零命令必须拒绝 Phase12，独立 fast TorqueDisable 必须始终可用，不能被 profile拒绝阻断。当前 serial_tick.rs 的 VelocityZero只是有界栈零切片，不能当作现场固件安全合同。

本纯小件不修改 SerialIo 唯一writer、RPC权限、S0/S1或ZeroCommand运行路径。集成时还需 wire截止门、观测freshness、配置代次、Enable/Disarm责任账本、停止读回和当次硬件GO；不是完整 workspace/release/B1。H2、左腕原FAIL和D15 OPEN/DEFERRED、deployable=false不因本设计改变。

旧维护脚本 raw±20/150ms 的名义细单位位移约2.99008ticks，且厂家精度仍0.732RPM，不能保证跨过旧delta≥3门。未来动作/单位标定另定清晰预算与原始判据；不沿用经验steps/s、不悄悄放宽旧门。先验证 stop-only，并明确停电保护仍D15未闭合。

## Phase12→4：只有独立维护设计，没有写授权

一手原表69行 Lock55 的逐字定义：写0关闭写入锁，写入EPROM地址的值掉电保存；写1打开写入锁，写入EPROM地址的值掉电不保存。它描述掉电保存语义，不能从名字“锁”推断 Lock1 一定拒收写入。

矛盾现有注释：registers.rs:6–8、71、166–167把Lock1描述为写保护/写前必须Lock0；feetech_poke.rs:54–55写“不先Lock0则静默失败”。一手v181不支持它们对所有固件的绝对结论，后续应更正说明并保留“普通Phase/CW/CCW禁止写”的项目策略。本轮未改这些注释。

独立维护入口若将来获明确授权，只接受固定 rightbus/front8,left7,right9 的 12→4，mask=0x08；禁止任意地址/值/批量17电机。普通 B0 三诊断拒写门和维护脚本原 allowlist 不取消、不扩展。专用维护能力不来自 Motion/Enable 权限，也不从 skill 推定授权。不是一条可直接执行的 poke 命令。

操作前由总管冻结新软件/设备身份，唯一串口所有者清场，持续人工看护/立即断电事实确认，支撑与空间条件满足；三轮逐项新 READ Model777、固件0/1、Mode1、Phase12、Lock55、Torque0及Goal/Present原始速度。不得用Torque0时Present0证明未来0停。备份必须落盘并读回SHA，包括USB/bus、ID/role、时间、原字节、应答级别/预算与读回原件，支持失败还原。缺任一字段或身份漂移拒绝；ACK策略沿原有限预算，不自行增加重试或变更应答级别。

**临时方案**：入口仅接受原Lock=1并保持1；原Lock=0默认返回具体 TemporaryLockNotAlreadyEnabled，不切0→1→0，不实现未经验证的保存语义，必要时由总管另行维护决策。保持 Torque0并完成备份，每轮只写Phase18=4一次，逐项ACK/Phase读回必须精确为4，Lock仍1，确认其它位未变。没有回执、错误、超预算或读回仍12/其它值立即停止，先断扭/人工断电；不自动转Lock0、不持久化、不重试掩盖原FAIL。这个 Lock1 写入是否现场临时生效必须由这些原件证明，当前尚未实现。同会话回滚可在Torque0、Lock1恢复备份Phase12并读回；断电后仍须新READ验证原值，不复用 profile。

**持久方案（另需EEPROM明确授权）**：Torque0与完整备份后，逐项Lock0 ACK/读回→Phase4 ACK/读回→恢复原Lock ACK/读回；不改Mode、CW/CCW、ID、波特率或其它Phase位。最后仍Torque0且不自动启扭。真正电机断电/复电由现场人执行，再新 READ 三轮固件/Model/Mode/Phase4/Lock/Torque0及Goal/Present，Phase持久读回通过才结束配置阶段。软件重启不替代电机电源循环。若不能确认供电分域或断电结果，配置验收保持具体待确认，不将其写成PASS。

**回滚**：先真实TorqueDisable并核读回/静止，无法证断扭则立即人工切电；在相同设备/三ID身份下按已获授权的保存语义恢复备份Phase12和Lock并读回。只在持久写已获授权时用Lock0保存恢复；临时会话优先关闭供电并新READ原值，避免擅自持久操作。恢复Phase12后仍禁止Enable/Zero/Motion。回滚任何ACK/读回失败保留原件并停止，不循环补写。备份不是自动恢复授权。

配置成功也不自动启扭。总管须另行给出受监督 stop-only具体动作/预算并取得当次GO，fresh profile身份/Phase4有效，验证目标0的启扭前后读回、无运动与断扭收尾；只有此实机阶段可增加相应硬件结论。正反轮运动/轮速单位与安装方向标定为后续独立门。


## root评审后纯软件实施范围（r2）

包A：registers.rs追加0/1两READ表与独立只读拒写门并澄清Lock注释；bus.rs四write API在原三门后新零IO门与有限READ/拒写测试；error.rs、diagnostic.rs新增具名错误沿Argument；feetech_poke.rs开串口前拒两名write并保原三门。包B：新feetech/velocity_profile.rs纯值模块与lib.rs导出，具体try_bind/try_encode_rad_s/decode_velocity_word正路径与错误边界。无adapter、运行时、Phasewrite、EEPROM副作用、依赖/锁文件或Position/ArmIK改动。

在独立managed worktree从当前提交e8a5172实施，与主树/P1A/P1B隔离。本机浮动nightly更新/身份、fmt与crate lib/example Clippy、相关库与poke测试的自然完成原件另封候选manifest；本设计不把未来执行提前记为PASS。root要求超raw_limit直接RawLimitExceeded，不限幅；临时维护仅原Lock1，原Lock0拒绝。r1原方案与模型完整保留在history_r1。
