"""B1数值方案独立模型：只验证数学及边界，不代替Rust构建或固件实测。"""
from datetime import datetime, timezone
from pathlib import Path
import json
import math

ROOT = Path(__file__).resolve().parent
UNITS = {"rpm_0_732": 732 / 1000, "rpm_0_0146": 146 / 10000}

def round_away(value):
    return math.copysign(math.floor(abs(value) + 0.5), value)

def encode(omega, unit, limit=32767):
    if type(limit) is not int or not 1 <= limit <= 32767:
        raise ValueError("InvalidRawLimit")
    if not math.isfinite(omega):
        raise ValueError("NonFiniteVelocity")
    factor = 60 / (math.tau * UNITS[unit])
    raw_float = omega * factor
    if not math.isfinite(raw_float):
        raise ValueError("ArithmeticOverflow")
    rounded = round_away(raw_float)
    if abs(rounded) > 32767:
        raise ValueError("RawRepresentationOutOfRange")
    if abs(rounded) > limit:
        raise ValueError("RawLimitExceeded")
    signed = int(rounded)
    return abs(signed) | (0x8000 if signed < 0 else 0)

def decode(word, unit):
    if type(word) is not int or not 0 <= word <= 0xffff:
        raise ValueError("InvalidWireWord")
    magnitude = word & 0x7fff
    signed = -magnitude if word & 0x8000 else magnitude
    return signed * UNITS[unit] * math.tau / 60

def profile(role, motor_id, model, mode, phase, firmware_observed, expected_firmware):
    if {"front": 8, "left": 7, "right": 9}.get(role) != motor_id:
        raise ValueError("WrongWheelIdentity")
    if model != 777 or mode != 1:
        raise ValueError("WrongModelOrMode")
    if firmware_observed is None or firmware_observed != expected_firmware:
        raise ValueError("FirmwareObservationMissingOrMismatch")
    if type(phase) is not int or not 0 <= phase <= 254:
        raise ValueError("InvalidPhase")
    if phase & 8:
        raise ValueError("ZeroMeansMaximumSpeed")
    return "rpm_0_0146" if phase & 4 else "rpm_0_732"

def refused(call, expected):
    try:
        call()
    except ValueError as error:
        assert str(error) == expected, (str(error), expected)
        return
    raise AssertionError("该负控被错误放行")

roundtrip = 0
for unit in UNITS:
    for word in range(65536):
        rebuilt = encode(decode(word, unit), unit)
        assert rebuilt == (0 if word == 0x8000 else word), (unit, word, rebuilt)
        roundtrip += 1
    assert encode(0.0, unit) == 0
    assert encode(-0.0, unit) == 0
    omega60 = 60 * UNITS[unit] * math.tau / 60
    assert encode(omega60, unit) == 60
    assert encode(-omega60, unit) == 0x803c
    refused(lambda: encode(omega60, unit, 20), "RawLimitExceeded")
    refused(lambda: encode(-omega60, unit, 20), "RawLimitExceeded")
    for value in [math.nan, math.inf, -math.inf]:
        refused(lambda: encode(value, unit), "NonFiniteVelocity")
    refused(lambda: encode(1e308, unit), "ArithmeticOverflow")
    for sign in [1, -1]:
        omega32768 = sign * 32768 * UNITS[unit] * math.tau / 60
        refused(lambda: encode(omega32768, unit, 20), "RawRepresentationOutOfRange")
    for limit in [0, -1, 32768, True, math.nan]:
        refused(lambda: encode(0, unit, limit), "InvalidRawLimit")

for value, expected in [(0.5, 1), (-0.5, -1), (1.5, 2), (-1.5, -2), (0.49, 0), (-0.49, 0)]:
    assert round_away(value) == expected
positive = 0
for role, motor_id in [("front", 8), ("left", 7), ("right", 9)]:
    for phase, expected in [(0, "rpm_0_732"), (4, "rpm_0_0146")]:
        assert profile(role, motor_id, 777, 1, phase, (1, 2), (1, 2)) == expected
        positive += 1
    refused(lambda: profile(role, motor_id, 777, 1, 12, (1, 2), (1, 2)), "ZeroMeansMaximumSpeed")
    refused(lambda: profile(role, motor_id, 777, 1, 4, None, (1, 2)), "FirmwareObservationMissingOrMismatch")
    refused(lambda: profile(role, motor_id, 777, 1, 4, (1, 3), (1, 2)), "FirmwareObservationMissingOrMismatch")
refused(lambda: profile("arm", 8, 777, 1, 4, (1, 2), (1, 2)), "WrongWheelIdentity")
refused(lambda: profile("front", 7, 777, 1, 4, (1, 2), (1, 2)), "WrongWheelIdentity")
refused(lambda: profile("front", 8, 777, 0, 4, (1, 2), (1, 2)), "WrongModelOrMode")
refused(lambda: profile("front", 8, 778, 1, 4, (1, 2), (1, 2)), "WrongModelOrMode")
refused(lambda: profile("front", 8, 777, 1, 255, (1, 2), (1, 2)), "InvalidPhase")

result = {
    "created_at": datetime.now(timezone.utc).isoformat(), "status": "PASS",
    "meaning": "独立Python数学模型与方案条件验证，不是Rust编译/单测通过，也不是现场固件PASS",
    "all_wire_words_both_units_roundtrip_samples": roundtrip,
    "negative_zero_wire_handling": "0x8000反馈解码为0但原始方向字节应保留；重新命令规范化为0x0000，未假设反馈0x8000非法。",
    "positive_role_unit_fixtures": positive, "firmware_fixture": "(1,2)仅虚拟输入，不能回填现场版本",
    "rounding": "nearest，exact-half远离0；浮点近half不冒充数学exact-half",
    "finite_wire_range_then_rawlimit_rejection_without_clamp": True,
    "manufacturer_nominal_unit_rad_per_sec": {k: v * math.tau / 60 for k, v in UNITS.items()},
    "fine_unit_relative_difference_from_exact_encoder_step_per_second": (UNITS['rpm_0_0146'] * math.tau / 60) / (math.tau / 4096) - 1,
    "legacy_raw20_nominal_ticks_in_150ms": 20 * UNITS['rpm_0_0146'] / 60 * 4096 * 0.150,
    "hardware_read": 0, "hardware_write": 0, "cargo": 0,
}
(ROOT / "numeric_design_result.json").write_text(json.dumps(result, ensure_ascii=False, indent=2) + "\n")
print(json.dumps(result, ensure_ascii=False))
