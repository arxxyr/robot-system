#!/usr/bin/env python3
"""只读取既有软件原件，生成独立核对结果；不执行原件代码或接触设备。"""
import datetime
import hashlib
import json
import pathlib
import re
import stat
import tarfile

ROOT = pathlib.Path('/Users/loosqk/repo/rust/robot-system')
AREA = ROOT / 'target/feetech_firmware_integration_2026-10-08'
BASE = AREA / 'native-r1'
OUT = AREA / 'independent_review_r1'
CAND = pathlib.Path('/Users/loosqk/.codex/worktrees/feetech-wheel-firmware-contract/robot-system/target/firmware_contract_delivery_r2/candidate_manifest.json')
AGGREGATE = 'ddad9513566f51fecf915ac7f39e0cccc66b8ae93732847b70ac7c0315458294'
COMPILER_HASH = '1d81eb4ad9cd207e3e638bd32b17ec4fce8412a6'
REMOTE = '/home/loosqk/robot-checks/feetech-firmware-contract-quality-20261008-r1/'


def sha(data):
    return hashlib.sha256(data).hexdigest()


def strict_pairs(items):
    result = {}
    for key, value in items:
        assert key not in result, ('重复JSON键', key)
        result[key] = value
    return result


def load(path):
    return json.loads(path.read_bytes(), object_pairs_hook=strict_pairs)


def ref(path):
    data = path.read_bytes()
    return {'path': str(path), 'sha256': sha(data), 'bytes': len(data)}


def canonical(value):
    return json.dumps(value, sort_keys=True, separators=(',', ':'), ensure_ascii=False, allow_nan=False).encode()


def same_bytes(data, item):
    assert len(data) == item['bytes'], ('字节数', item)
    assert sha(data) == item['sha256'], ('SHA', item)


def resolve_ref(path):
    if path.startswith(REMOTE + 'qa/'):
        return BASE / 'orin-originals' / path.removeprefix(REMOTE + 'qa/')
    if path.startswith(REMOTE + 'bootstrap/'):
        return BASE / path.removeprefix(REMOTE + 'bootstrap/')
    return pathlib.Path(path)


def typed_refs(value):
    if isinstance(value, dict):
        if isinstance(value.get('path'), str) and re.fullmatch(r'[0-9a-f]{64}', str(value.get('sha256'))):
            yield value
        for child in value.values():
            yield from typed_refs(child)
    elif isinstance(value, list):
        for child in value:
            yield from typed_refs(child)


OUT.mkdir(exist_ok=True)
summary = load(BASE / 'summary.json')
candidate = load(CAND)
index = load(AREA / 'native-r1-original-evidence.index.json')
export = load(BASE / 'source_export.json')
expected = load(BASE / 'expected_source.json')
native_result = load(BASE / 'orin-originals/result.json')
checks = {}

# 封包逐项核对，不解包、不执行任何包内文件。
archive_path = AREA / 'native-r1-original-evidence.tar.gz'
archive_bytes = archive_path.read_bytes()
same_bytes(archive_bytes, index['archive'])
assert len(archive_bytes) == 11032663 and sha(archive_bytes) == '4645c597aa9bb48058917639c09a34be588e5d2682a5e332e1ca3a785182d515'
assert stat.S_IMODE(archive_path.stat().st_mode) == index['archive']['mode']
entries = {item['name']: item for item in index['files']}
assert len(entries) == len(index['files']) == 145
with tarfile.open(archive_path, 'r:gz') as archive:
    members = archive.getmembers()
    assert len(members) == len({m.name for m in members}) == 145
    assert {m.name for m in members} == set(entries)
    for member in members:
        name = pathlib.PurePosixPath(member.name)
        assert member.isfile() and not name.is_absolute() and '..' not in name.parts
        item = entries[member.name]
        data = archive.extractfile(member).read()
        same_bytes(data, item)
        assert member.mode == item['mode']
        original = pathlib.Path(item['original_path'])
        assert original.is_relative_to(BASE) and original.relative_to(BASE).as_posix() == member.name
        same_bytes(original.read_bytes(), item)
        assert stat.S_ISREG(original.lstat().st_mode)
        assert stat.S_IMODE(original.stat().st_mode) == item['mode']
checks['archive'] = {'entries': 145, 'exact_set_sha_bytes_mode_original_and_tar': True, 'reference': ref(archive_path), 'index': ref(AREA / 'native-r1-original-evidence.index.json')}

# 结构化引用逐项查本体，远端qa路径映射到下载的原件而非猜测远端现状。
references = []
for origin in [BASE / 'summary.json', BASE / 'artifact_index.json', BASE / 'source_export.json', BASE / 'orin-originals/result.json', BASE / 'orin-originals/frozen/feetech_poke.build.json', CAND]:
    for item in typed_refs(load(origin)):
        path = resolve_ref(item['path'])
        data = path.read_bytes()
        assert sha(data) == item['sha256'], ('引用SHA', origin, item)
        if 'bytes' in item:
            assert len(data) == item['bytes'], ('引用字节数', origin, item)
        assert stat.S_ISREG(path.lstat().st_mode), ('引用不是普通文件', path)
        references.append({'origin': str(origin), 'reference': item, 'resolved': str(path)})
checks['typed_references'] = {'occurrences': len(references), 'unique_files': len({v['resolved'] for v in references}), 'all_closed_sha_and_declared_bytes': True}

# 七源码与候选准确一致；整批编译输入及源tar独立核对。
changed = []
for item in candidate['changed_sources']:
    relative = pathlib.Path(item['path']).relative_to(pathlib.Path(candidate['worktree']))
    path = ROOT / relative
    same_bytes(path.read_bytes(), item)
    changed.append({'relative_path': relative.as_posix(), **ref(path)})
assert len(changed) == len({v['relative_path'] for v in changed}) == 7
assert len(expected['files']) == 591
assert sha(canonical(expected['files'])) == expected['source_manifest_sha256'] == AGGREGATE
assert export['source_manifest'] == expected
for name, item in expected['files'].items():
    path = ROOT / name
    same_bytes(path.read_bytes(), item)
    assert stat.S_ISREG(path.lstat().st_mode)
    assert bool(path.stat().st_mode & stat.S_IXUSR) == item['executable']
source_tar = BASE / 'source-inputs.tar.gz'
same_bytes(source_tar.read_bytes(), export['archive'])
with tarfile.open(source_tar, 'r:gz') as archive:
    members = archive.getmembers()
    assert len(members) == len({m.name for m in members}) == 591
    assert {m.name for m in members} == set(expected['files'])
    for member in members:
        assert member.isfile()
        same_bytes(archive.extractfile(member).read(), expected['files'][member.name])
        assert member.mode == export['files'][member.name]['mode']
snapshots = sorted((BASE / 'orin-originals').glob('*source*.json'))
assert len(snapshots) == 28
for path in snapshots:
    assert load(path) == expected, ('源窗口漂移', path)
assert native_result['source_files'] == 591 and native_result['aggregate'] == AGGREGATE
checks['source'] = {'changed_sources': changed, 'compilation_input_count': 591, 'aggregate': AGGREGATE, 'main_bytes_and_exec_current': True, 'source_tar_entries_and_modes': 591, 'native_source_snapshots_exact': 28, 'source_tar': ref(source_tar), 'candidate': ref(CAND)}

# 十三质量命令与三个真实ELF子进程分别计数，直接child自然回收。
children = []
for path in sorted((BASE / 'orin-originals').glob('*/completion.json')):
    row = load(path)
    assert row['reaped'] is True and row['signals'] == []
    assert row['budget_exceeded'] is False and row['identity']['pid'] == row['pid']
    assert row['identity']['sid'] == row['identity']['pgid'] == row['pid']
    assert row['identity']['boot_id'] == '6cf7ee3e-a3c5-4c91-80bc-4ca924818b53'
    assert row['ended_monotonic_ns'] >= row['started_monotonic_ns']
    assert 'runner_error' not in row and 'interrupted_signal' not in row
    if path.parent.name.startswith('expected_'):
        assert row['exit_code'] == row['expected_exit_code'] == 2
        assert row['session_residual'] == [] and row['binary_same_after'] is True
    else:
        assert row['exit_code'] == 0 and row['exec_gate_released'] is True
        assert row['session_residual_before_cleanup'] == row['session_residual_after_cleanup'] == []
        assert row['elapsed_ns'] == row['ended_monotonic_ns'] - row['started_monotonic_ns']
    for channel in ['stdout', 'stderr']:
        data = (path.parent / (channel + '.log')).read_bytes()
        assert len(data) == row[channel + '_bytes'] and sha(data) == row[channel + '_sha256']
    launch = load(path.parent / 'launch.json')
    assert launch['pid'] == row['pid'] and launch['argv'] == row['argv'] and launch['identity'] == row['identity']
    children.append({'name': path.parent.name, 'pid': row['pid'], 'exit_code': row['exit_code'], 'reaped': True, 'signals': [], 'argv': row['argv'], 'completion': ref(path)})
assert len(children) == len({v['pid'] for v in children}) == 16
assert len([v for v in children if v['exit_code'] == 2]) == 3
for item in summary['host_owners']:
    row = load(pathlib.Path(item['result']['path']))
    assert row['reaped'] is True and row['wait_returncode'] == 0
    assert row['owner_sent_signals'] == [] and row['received_signals'] == {} and row['errors'] == []
    assert row['pid'] == item['child_pid'] and row['owner_pid'] == item['owner_pid']
wait = load(BASE / 'tool_owner_wait.json')
assert wait['result']['exit_code'] == 0
wait_embedded = json.loads(wait['result']['output'])
assert wait_embedded == load(BASE / 'orin_quality.owner/result.json')
checks['lifecycle'] = {'native_distinct_children': 16, 'native_quality_children_exit0': 13, 'actual_elf_children_expected_exit2': 3, 'all_owned_natural_wait_no_signals_no_budget_violations': True, 'host_owner_count': 7, 'host_children_actual_wait0_no_signals': True, 'main_tool_session': wait['session_id'], 'tool_completion_exit0': True, 'children': children}

# 直接从测试原始stdout提取测试名及终计数，不将新方法或样本再次累计。
roster = load(BASE / 'test_roster_and_overlap.json')
all_names = {}
for name, count in [('feetech_lib', 171), ('poke_tests', 6)]:
    text = (BASE / 'orin-originals' / name / 'stdout.log').read_text()
    names = re.findall(r'^test ([^ ]+) \.\.\. ok$', text, re.M)
    assert len(names) == len(set(names)) == count
    assert re.findall(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored;', text) == [(str(count), '0', '0')]
    assert names == roster['all_names'][name] == native_result['tests'][name]['names']
    all_names[name] = names
union = {'lib::' + v for v in all_names['feetech_lib']} | {'poke::' + v for v in all_names['poke_tests']}
assert len(union) == 177
assert len(roster['new_method_subset']) == len(set(roster['new_method_subset'])) == 12
assert set(roster['new_method_subset']) <= union
assert len([v for v in roster['new_method_subset'] if v.startswith('lib::')]) == 11
checks['tests'] = {'lib': 171, 'poke': 6, 'distinct': 177, 'new_methods_subset': 12, 'new_lib_subset': 11, 'new_poke_subset': 1, 'failed': 0, 'ignored': 0, 'wire_samples_in_one_method': 131072, 'all_names_sha256': sha(canonical(sorted(union))), 'roster': ref(BASE / 'test_roster_and_overlap.json')}

# 实际命令顺序、编译器原始文本与release Cargo消息及封存ELF。
command_rows = {v['name']: v for v in children}
for name in ['fmt', 'clippy_default', 'clippy_real_hw', 'feetech_lib', 'poke_tests', 'release_poke']:
    row = load(BASE / 'orin-originals' / name / 'completion.json')
    assert row['env']['RUSTUP_TOOLCHAIN'] == 'nightly'
fmt_row = load(BASE / 'orin-originals/fmt/completion.json')
default_row = load(BASE / 'orin-originals/clippy_default/completion.json')
real_row = load(BASE / 'orin-originals/clippy_real_hw/completion.json')
assert fmt_row['argv'] == ['cargo', 'fmt', '--all']
assert default_row['argv'] == ['cargo', 'clippy', '--locked', '--all', '--all-targets', '--', '-D', 'warnings']
assert real_row['argv'] == ['cargo', 'clippy', '--locked', '--all', '--all-targets', '--features', 'robot-adapter-feetech/real-hw', '--', '-D', 'warnings']
assert fmt_row['ended_monotonic_ns'] <= default_row['started_monotonic_ns'] and default_row['ended_monotonic_ns'] <= real_row['started_monotonic_ns']
rustc_before = (BASE / 'orin-originals/rustc_before/stdout.log').read_bytes()
assert rustc_before == (BASE / 'orin-originals/rustc_after/stdout.log').read_bytes()
assert b'release: 1.101.0-nightly\n' in rustc_before and COMPILER_HASH.encode() in rustc_before and b'host: aarch64-unknown-linux-gnu\n' in rustc_before
assert (BASE / 'orin-originals/cargo_before/stdout.log').read_bytes() == (BASE / 'orin-originals/cargo_after/stdout.log').read_bytes()
build = load(BASE / 'orin-originals/frozen/feetech_poke.build.json')
messages = [json.loads(line) for line in (BASE / 'orin-originals/release_poke/stdout.log').read_text().splitlines() if line]
finished = [v for v in messages if v.get('reason') == 'build-finished']
assert len(finished) == 1 and finished[0]['success'] is True
artifacts = [v for v in messages if v.get('reason') == 'compiler-artifact' and v.get('target', {}).get('name') == 'feetech_poke' and v.get('executable')]
assert artifacts == [build['cargo_artifact']]
artifact = artifacts[0]
assert artifact['fresh'] is False and artifact['target']['kind'] == ['example'] and artifact['features'] == ['default', 'real-hw']
assert artifact['profile']['opt_level'] == '3' and artifact['profile']['test'] is False and artifact['profile']['debug_assertions'] is False
assert artifact['executable'] == REMOTE + 'release-build/release/examples/feetech_poke'
binary_path = BASE / 'orin-originals/frozen/feetech_poke'
binary = binary_path.read_bytes()
same_bytes(binary, build['identity'])
assert binary[:6] == b'\x7fELF\x02\x01' and int.from_bytes(binary[18:20], 'little') == build['identity']['elf_machine'] == 183
assert stat.S_IMODE(binary_path.stat().st_mode) == build['identity']['mode'] == 509
assert build['source_aggregate'] == AGGREGATE and build['compiler'] == summary['compiler'] == native_result['compiler_before'] == native_result['compiler_after']
checks['quality_and_artifact'] = {'fmt_then_default_root_clippy_then_real_hw_root_clippy': True, 'nightly_actual_commit': COMPILER_HASH, 'compiler_before_after_exact': True, 'cargo_before_after_exact': True, 'release_cargo_fresh_unique_example': True, 'release_source_aggregate': AGGREGATE, 'frozen_elf': ref(binary_path), 'frozen_elf_mode': 509, 'elf_machine': 183, 'source_build_sidecar': ref(BASE / 'orin-originals/frozen/feetech_poke.build.json'), 'remote_build_to_frozen_copy_and_post_probe_equality': '原回执与下载helper逻辑支持；本轮独审不SSH重新观察远端文件'}

# 实际拒写argv ID为8，而不是规划文字9；前置拒写不依赖电机身份。
probes = []
for name in ['Firmware_Major_Version', 'Firmware_Minor_Version']:
    folder = BASE / 'orin-originals' / ('expected_' + name)
    row = load(folder / 'completion.json')
    assert row['argv'] == [REMOTE + 'qa/frozen/feetech_poke', '/dev/robot-checks-feetech-firmware-nonexistent', '8', 'write', name, '1']
    assert row['missing_device_before'] is True and row['missing_device_after'] is True and row['binary_sha256'] == sha(binary)
    assert row['syscall_trace'] == 'UNAVAILABLE_NOT_CLAIMED'
    assert (folder / 'stderr.log').read_text() == 'error: 固件版本只读寄存器禁止写入：' + name + '\n'
    probes.append({'register': name, 'motor_id_actual': 8, 'exit_code_actual': 2, 'specific_error': True, 'nonexistent_device_before_after': True, 'completion': ref(folder / 'completion.json')})
cli = (ROOT / 'crates/robot-adapters/feetech/examples/feetech_poke.rs').read_text()
main = cli[cli.index('fn main()'):cli.index('#[cfg(test)]')]
assert main.index('preflight_diagnostic_write(&args)') < main.index('RealSerialTransport::open')
checks['cli_readonly_refusal'] = {'two_probes': probes, 'same_source_main_preflight_before_serial_open': True, 'four_bus_named_write_apis_zero_tx_and_lease_test': True, 'syscall_trace': '未做，不能宣称系统调用级零UART观测'}

result = {
    'schema': 'FEETECH_FIRMWARE_SOFTWARE_INDEPENDENT_REVIEW_R1',
    'status': 'PASS_SCOPED_SOFTWARE_NO_BLOCKER',
    'created_at': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'summary': ref(BASE / 'summary.json'),
    'head_observed_from_prior_actual_git_read': 'bfad2015f7772557b884d3ea4f6218aaa2ae4062',
    'checks': checks,
    'blockers': [],
    'source_review': {
        'readonly_registers': '新增0/1各1字节无符号读取；四具名写API在查表、连接、lease及I/O前拒绝；原Phase/CW/CCW拒写不变。',
        'diagnostic': '具名只读错误映射参数Argument(8,1,0)，未改通信错误分类。',
        'pure_profile': '私有合法实例；固定front8/left7/right9及Model777/Mode1/期望固件/完整Phase/raw_limit检查，无默认认证或运行能力。',
        'phase': 'bit3置位含Phase12拒绝；bit2仅厂家名义0.732/0.0146RPM，不当精确steps/s；Phase255拒绝。',
        'numeric': '有限rad/s→半值远离0量化→15位表示门→明确raw上限门→bit15符号幅度；超限拒绝，不单轮clamp；编码负零归零，反馈原负零word保留。',
        'rt_and_runtime': 'profile纯值无分配/I/O；未接RT/adapter/S0/S1/RPC运行链；现有adapter非Position命令仍不下发速度。',
        'lock': '注释区分Lock0保存/Lock1不保存与现场固件接收性；未新增配置写入口或改变Phase写禁令。'
    },
    'claimable': ['七源码同源软件实现通过独立评审。', 'Orin同591输入fmt/默认及real-hw根Clippy、177独立测试方法、独立release poke和两次具体前置拒写通过。', '12新方法为177子集；131072线字样本为一个测试内循环。'],
    'limits': ['未跑完整workspace测试/H2六配方/真实RPC/完整B1/真实速度下发/线级deadline。', '现场固件0/1未读；期望固件匹配及纯profile成功不证明厂家合同适用于现场设备。', '拒写未做strace/syscall跟踪；不存在设备前后加具体错误、同源顺序和四API零TX/lease测试不扩大为syscall证明。', '本独审未SSH/UART/硬件动作/部署/正式安装/push，也未重新观测当前远端服务或正式安装。', '原硬件NEEDS_MANUAL_POWER_CUT及原FAIL保留；用户随后确认两个电机电源已切断、机械臂有支撑，只关闭人工收尾待答，非硬件PASS或新GO。', 'D15 OPEN/DEFERRED、deployable=false；旧r1 Clippy失败等原件不改写。'],
    'review_operations': {'ssh': 0, 'uart': 0, 'hardware_actions': 0, 'controlled_source_edits': 0, 'original_evidence_edits': 0}
}
output = OUT / 'review.json'
with output.open('x') as stream:
    json.dump(result, stream, ensure_ascii=False, indent=2, allow_nan=False)
    stream.write('\n')
print(json.dumps({'status': result['status'], 'review': ref(output), 'typed_refs': checks['typed_references'], 'archive_entries': 145, 'source_inputs': 591, 'source_snapshots': 28, 'native_children': 16, 'distinct_tests': 177}, ensure_ascii=False))
