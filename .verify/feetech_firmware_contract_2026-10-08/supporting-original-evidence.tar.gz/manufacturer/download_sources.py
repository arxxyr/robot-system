"""仅保存公开一手源码快照，不运行下载内容。"""
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime, timezone
from pathlib import Path
import hashlib
import json
import subprocess

ROOT = Path(__file__).resolve().parent
WEB = ROOT / "web"

def fetch(row):
    name, url = row
    path = WEB / name
    start = datetime.now(timezone.utc).isoformat()
    child = subprocess.Popen([
        "curl", "--fail", "--location", "--connect-timeout", "8", "--max-time", "15",
        "--silent", "--show-error", "--output", str(path), url,
    ], stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    stdout, stderr = child.communicate()
    record = {"name": name, "url": url, "started_at": start,
              "ended_at": datetime.now(timezone.utc).isoformat(), "pid": child.pid,
              "wait_exit_code": child.returncode, "reaped": True,
              "stdout": stdout.decode(), "stderr": stderr.decode()}
    if child.returncode == 0:
        data = path.read_bytes()
        record.update(bytes=len(data), sha256=hashlib.sha256(data).hexdigest())
    return record

refs = list(ThreadPoolExecutor(max_workers=2).map(fetch, [
    ("xlerobot-ref.json", "https://api.github.com/repos/Vector-Wangel/XLeRobot/git/ref/heads/main"),
    ("ftservo-linux-ref.json", "https://api.github.com/repos/ftservo/FTServo_Linux/git/ref/heads/main"),
]))
assert all(row["wait_exit_code"] == 0 for row in refs)
pins = {}
for key, name in [("xlerobot", "xlerobot-ref.json"), ("ftservo_linux", "ftservo-linux-ref.json"),
                  ("ftservo_python", "ftservo-python-ref.json"), ("lerobot", "lerobot-ref.json")]:
    obj = json.loads((WEB / name).read_text())["object"]
    assert obj["type"] == "commit"
    pins[key] = obj["sha"]

files = []
for label, repo, paths in [
    ("ftservo_python", "ftservo/FTServo_Python", ["scservo_sdk/sms_sts.py", "scservo_sdk/protocol_packet_handler.py", "sms_sts/wheel.py"]),
    ("ftservo_linux", "ftservo/FTServo_Linux", ["src/SMS_STS.h", "src/SMS_STS.cpp", "examples/SMS_STS/WriteSpe/WriteSpe.cpp"]),
    ("lerobot", "huggingface/lerobot", ["src/lerobot/motors/feetech/tables.py", "src/lerobot/motors/feetech/feetech.py"]),
    ("xlerobot", "Vector-Wangel/XLeRobot", ["software/src/robots/xlerobot/__init__.py", "software/src/robots/xlerobot/config_xlerobot.py", "software/src/robots/xlerobot/xlerobot.py", "software/src/robots/xlerobot/xlerobot_host.py", "software/src/robots/xlerobot/xlerobot_client.py"]),
]:
    for path in paths:
        files.append((label + "--" + path.replace("/", "--"),
                      f"https://raw.githubusercontent.com/{repo}/{pins[label]}/{path}"))
rows = list(ThreadPoolExecutor(max_workers=3).map(fetch, files))
manifest = {"created_at": datetime.now(timezone.utc).isoformat(), "pins": pins,
            "scope": "公开一手代码只读下载，不执行内容", "records": refs + rows,
            "all_natural_exit_zero_reaped": all(r["wait_exit_code"] == 0 for r in refs + rows)}
(ROOT / "download_manifest.json").write_text(json.dumps(manifest, ensure_ascii=False, indent=2) + "\n")
print(json.dumps({"pins": pins, "downloads": len(rows), "all_zero": manifest["all_natural_exit_zero_reaped"]}, ensure_ascii=False))
assert manifest["all_natural_exit_zero_reaped"]
