"""生成固件合同只读调查记录；不接触串口或修改项目源。"""
from datetime import datetime, timezone
from pathlib import Path
import hashlib
import json
import subprocess

ROOT = Path(__file__).resolve().parent
WEB = ROOT / "web"
UPSTREAM = Path("/Users/loosqk/repo/robot/dimos")

def identity(path):
    before = path.stat()
    data = path.read_bytes()
    after = path.stat()
    assert (before.st_dev, before.st_ino, before.st_size, before.st_mtime_ns) == (after.st_dev, after.st_ino, after.st_size, after.st_mtime_ns)
    return {"path": str(path), "dev": before.st_dev, "inode": before.st_ino,
            "bytes": len(data), "mtime_ns": before.st_mtime_ns,
            "sha256": hashlib.sha256(data).hexdigest()}

def hit_lines(path, needle):
    return [n for n, line in enumerate(path.read_text(encoding="utf-8-sig").splitlines(), 1) if needle in line]

local_paths = sorted(set((UPSTREAM / "src/xlerobot_dimos/common").rglob("*.py")) | {UPSTREAM / "src/xlerobot_dimos/adapters/bus2_base.py"})
local_before = [identity(p) for p in local_paths]
head = subprocess.run(["git", "rev-parse", "HEAD"], cwd=UPSTREAM, capture_output=True, text=True, check=True).stdout.strip()
downloads = json.loads((ROOT / "download_manifest.json").read_text())
response = json.loads((WEB / "official-sms-sts-document-response.json").read_text())
assert response["status"] == 200
doc = response["data"]
assert doc["code"] == "FT-STS-emanual" and doc["model"] == "STS" and doc["version"] == 181
assert (WEB / "official-sms-sts-memory-table.md").read_text() == doc["mdcontent"]
assert "BIT2（4）：速度单位；(0)0.732RPM，(1)0.0146RPM" in doc["mdcontent"]
assert "BIT3（8）：速度模式；(0)速度0表示停止，(1)速度0表示最高速度" in doc["mdcontent"]

def src(label, path, local_name, needles):
    sha = downloads["pins"][label]
    repo = {"ftservo_python": "ftservo/FTServo_Python", "ftservo_linux": "ftservo/FTServo_Linux", "lerobot": "huggingface/lerobot", "xlerobot": "Vector-Wangel/XLeRobot"}[label]
    snapshot = WEB / local_name
    return {"repository": repo, "commit": sha, "repository_path": path,
            "source_url": f"https://github.com/{repo}/blob/{sha}/{path}",
            "snapshot": str(snapshot), "identity": identity(snapshot),
            "line_hits": {n: hit_lines(snapshot, n) for n in needles}}

sources = [
    src("ftservo_linux", "src/SMS_STS.h", "ftservo_linux--src--SMS_STS.h", ["SMS_STS_MODE", "SMS_STS_ACC", "SMS_STS_GOAL_SPEED", "SMS_STS_PRESENT_SPEED"]),
    src("ftservo_linux", "src/SMS_STS.cpp", "ftservo_linux--src--SMS_STS.cpp", ["WheelMode", "WriteSpe", "ReadSpeed", "1<<15", "genWrite(ID, SMS_STS_ACC, bBuf, 7)"]),
    src("ftservo_linux", "examples/SMS_STS/WriteSpe/WriteSpe.cpp", "ftservo_linux--examples--SMS_STS--WriteSpe--WriteSpe.cpp", ["WriteSpe(1, 0", "0.732", "WheelMode"]),
    src("ftservo_python", "scservo_sdk/sms_sts.py", "ftservo_python--scservo_sdk--sms_sts.py", ["WheelMode", "WriteSpec", "scs_toscs(speed, 15)", "ReadSpeed"]),
    src("ftservo_python", "scservo_sdk/protocol_packet_handler.py", "ftservo_python--scservo_sdk--protocol_packet_handler.py", ["def scs_tohost", "def scs_toscs", "1<<b"]),
    src("ftservo_python", "sms_sts/wheel.py", "ftservo_python--sms_sts--wheel.py", ["WriteSpec(1, 0", "0.732", "WheelMode"]),
    src("lerobot", "src/lerobot/motors/feetech/feetech.py", "lerobot--src--lerobot--motors--feetech--feetech.py", ["Clear bit 4", 'self.write("Phase"', "VELOCITY = 1", "_read_firmware_version"]),
    src("lerobot", "src/lerobot/motors/feetech/tables.py", "lerobot--src--lerobot--motors--feetech--tables-r2.py", ["FIRMWARE_MAJOR_VERSION", '"Phase"', '"Goal_Velocity"', '"Present_Velocity"', '"sts3215": 777']),
    src("xlerobot", "software/src/robots/xlerobot/xlerobot.py", "xlerobot--software--src--robots--xlerobot--xlerobot.py", ["configure_motors", "OperatingMode.VELOCITY", "def _degps_to_raw", "4096.0 / 360.0", "def stop_base", "Goal_Velocity", "Phase"]),
]

local_findings = []
for rel, findings, needles in [
    ("src/xlerobot_dimos/common/feetech_io/registers.py", "仅列使用的寄存器，没有Phase项；Mode1及速度bit15符号幅度与官方SDK一致。", ["MODEL_NUMBER_STS3215", '"Operating_Mode"', '"Goal_Velocity"', '"Present_Velocity"', '"Goal_Velocity":    15', "VELOCITY = 1"]),
    ("src/xlerobot_dimos/common/feetech_io/encoding.py", "符号幅度最大32767；小端拆装。", ["def encode_sign_magnitude", "max_magnitude", "return (direction_bit", "def decode_sign_magnitude"]),
    ("src/xlerobot_dimos/common/config.py", "6rad/s对应1023是注释明确的经验假设，非厂商单位标定。", ["经验值", "max_wheel_rad_per_sec", "raw_at_max_speed"]),
    ("src/xlerobot_dimos/common/units.py", "按配置比例换算SI，不读取Phase选择单位。", ["def rad_per_sec_to_raw_velocity", "raw_at_max_speed", "def raw_velocity_to_rad_per_sec"]),
    ("src/xlerobot_dimos/adapters/bus2_base.py", "连接时断扭/解锁/Mode1/重新锁；使能前写GoalVelocity0，停止也写0，未显式Phase读取或写入。", ["OperatingMode.VELOCITY", 'sync_write("Goal_Velocity", zeros)', 'write("Torque_Enable", motor_name, target_value)', "def write_enable", "def write_stop"]),
]:
    p = UPSTREAM / rel
    local_findings.append({"path": str(p), "identity": identity(p), "finding": findings, "line_hits": {n: hit_lines(p, n) for n in needles}})

record = {
    "schema": 1,
    "created_at": datetime.now(timezone.utc).isoformat(),
    "status": "PRIMARY_CONTRACT_FOUND_DEVICE_FIRMWARE_BINDING_PENDING",
    "scope": {"mode": "仅公开主来源和本地上游只读调查", "ssh": 0, "uart": 0, "cargo": 0, "hardware_writes": 0, "hardware_enable": 0, "eeprom_writes": 0, "formal_install": 0, "project_source_changes_by_this_task": 0},
    "hardware_observations": {"origin": "总管本次17舵机实际只读结果转交；本子任务没有自行测量", "count": 17, "model": 777, "phase_raw": 12, "cw_dead_zone": 1, "ccw_dead_zone": 1, "base_ids": {"front": 8, "left": 7, "right": 9}, "base_mode": 1, "base_torque_enable": 0, "base_goal_velocity_raw": 0, "base_present_velocity_raw": 0, "firmware_version": None, "limit": "断扭时的零反馈不能证明使能后的零命令是停止；型号号也不能代替固件版本。"},
    "manufacturer_provenance": {
        "public_page": "http://doc.feetech.cn/#/prodinfodownload?srcType=FT-SMS-STS-emanual-229f4476422d4059abfb1cb0",
        "chain": [
            {"url": "http://doc.feetech.cn/", "artifact": "web/official-http-portal.html", "role": "公开厂家门户HTML引入app和manifest"},
            {"url": "http://doc.feetech.cn/static/js/app.561305a3bb73c0bdfd0d.js", "artifact": "web/official-app.js", "role": "公开axios baseURL=http://longbos.com:9009；公开prodinfodownload路线加载chunk11"},
            {"url": "http://doc.feetech.cn/static/js/manifest.a56f0d86ca317255e14f.js", "artifact": "web/official-manifest.js", "role": "chunk11映射e46da6449684fbc4f792"},
            {"url": "http://doc.feetech.cn/static/js/11.e46da6449684fbc4f792.js", "artifact": "web/official-doc-page.js", "role": "srcType读取调用公开GET workflow/yf-specification/getBysrcType/{srcType}；响应data.mdcontent是展示内容"},
            {"url": "http://longbos.com:9009/workflow/yf-specification/getBysrcType/FT-SMS-STS-emanual-229f4476422d4059abfb1cb0", "artifact": "web/official-sms-sts-document-response.json", "role": "无登录/令牌/认证头的公开GET，原JSON保留，status200"},
        ],
        "metadata": {k: doc.get(k) for k in ["id", "code", "name", "model", "srcType", "version", "attribute", "enable"]},
        "last_modified_at": datetime.fromtimestamp(doc["lastModifiedDate"] / 1000, timezone.utc).isoformat(),
        "version_meaning": "181是门户响应version字段，不冒充固件版本或第三方所写文档v1.1。",
        "markdown": {"path": str(WEB / "official-sms-sts-memory-table.md"), "identity": identity(WEB / "official-sms-sts-memory-table.md"), "derived_exactly_from_response_mdcontent": True},
        "response_identity": identity(WEB / "official-sms-sts-document-response.json"),
        "transport": "按厂商公开HTTP路线取证；HTTPS入口SSL失败，Web工具不能解析HTTP/9009。源自厂家页面实际JS接口链，非第三方转载；未使用登录、auth或绕过访问控制。",
    },
    "manufacturer_contract": {
        "phase": {"address_dec": 18, "address_hex": "0x12", "bytes": 1, "source_lines": [38, 102, 103], "bit2": {"mask": 4, "zero": "0.732 RPM/raw", "one": "0.0146 RPM/raw"}, "bit3": {"mask": 8, "zero": "目标速度0为停止", "one": "目标速度0为最高速度"}},
        "mode": {"address_dec": 33, "mode1": "电机恒速模式", "source_lines": [51, 55, 57], "limit": "当前通用STS内存表没有将bit3说明限定为Mode0；Mode1在同表使用速度环与46速度目标。因此必须按Phase决定零值，不能用旧SDK例子覆盖原表。尚未读取现场0/1固件版本，不能宣称特定固件已通过使能验证。"},
        "goal_velocity": {"address_dec": 46, "bytes": 2, "signed_range": [-32767, 32767], "direction_bit": 15, "units_follow_phase": True, "precision_rpm_even_when_fine_unit": 0.732, "source_lines": [66]},
        "present_velocity": {"address_dec": 58, "bytes": 2, "direction_bit": 15, "units_follow_phase": True, "source_lines": [75]},
        "torque": {"address_dec": 40, "off_value": 0, "on_value": 1, "source_lines": [62]},
        "lock": {"address_dec": 55, "zero": "EPROM地址写入掉电保存", "one": "EPROM地址写入掉电不保存", "source_lines": [69], "limit": "不得继续把Lock1描述为必然拒收EEPROM地址写；是否支持临时RAM变更仍需现场固件绑定与单次读回证明。"},
        "units_limit": "厂家字面合同是0.0146RPM，不能据此宣称精确1step/s；XLeRobot的4096steps/rev换算是上游实现假设。精度也不等于该最小命令单位。",
    },
    "primary_code_sources": sources,
    "code_findings": [
        "厂家Linux/Python SDK：负速度转正幅度并置bit15，读回反向还原；不是i16二补码。+60编码0x003c，-60编码0x803c；-32768超出原表范围。",
        "厂家WheelMode写33=1；WriteSpe/WriteSpec从41写连续7字节，同时写Acceleration/GoalPosition/GoalTime/GoalVelocity，不能作为只写46的维护动作代用。",
        "厂家旧wheel示例采用0.732RPM/raw并注释0停，但不读/设置Phase或绑定固件。只能作为缺前提对比，不能推翻当前厂家原表bit3合同。",
        "LeRobot configure_motors只清Phase bit4(0x10)来设位置反馈单圈，保留其他位；对raw12没有Phase写入。Phase bit2/bit3没有由该配置解决。",
        "XLeRobot三轮源调用LeRobot configure_motors、写Mode1、上扭；自身5个xlerobot源文件没有Phase出现。速度按4096/360转steps/s；stop_base直接写GoalVelocity0。该代码仅证明其实现策略，不证明现场Phase12的零目标安全。",
    ],
    "local_upstream": {"root": str(UPSTREAM), "head": head, "findings": local_findings, "read_scope_files": local_before, "phase_register_observation": "本地common/feetech_io源码没有Phase项或Phase配置；其他Phase2字符串是开发阶段注释。"},
    "deductions": {
        "phase12": {"raw": 12, "hex": "0x0c", "bit2": 1, "bit3": 1, "nominal_unit": "0.0146RPM/raw", "zero_contract": "按厂家当前STS合同为最高速度，不是停止", "status": "具体厂家合同已找到，禁止把断扭零反馈充当上扭停转证明"},
        "positive_software_gate": "Model777/Mode1且新鲜Phase已读、bit3=0，才允许Enable与ZeroCommand；Phase12和未知/过期Phase均须拒绝。速度Motion同样要绑定明确单位/上下限。独立TorqueDisable安全收尾入口应保留，不以零命令合同阻断断扭。",
        "hardware_claim": "本任务没有上扭/动作，因此不宣称硬件停止/速度标定PASS。", "deployment": "deployable=false；D15仍OPEN/DEFERRED；H2和左腕历史FAIL不变。",
    },
    "maintenance_proposal_not_execution": {
        "authorization": "仅方案；本任务没有获得或执行Phase/EEPROM/上扭新写授权。",
        "targets": {"right_bus_only": True, "ids": [8, 7, 9], "count": 3, "exclude_arm_and_head": True},
        "transform": {"expression": "new_phase = original_phase & ~0x08", "expected_before": 12, "expected_after": 4, "preserves_bit2_and_all_other_bits": True, "only_changed_bit": 3},
        "preconditions": [
            "先将本次READ原件绑定每轮bus/USB/model/ID/固件0、1/Phase/Mode/CW/CCW/Lock/扭矩/目标及当前速度；固件版本与该STS表适用关系明确后再决定维护写。",
            "新执行仍需明确Phase维护写范围及现场看护/立即手动断电事实；所有17舵机断扭、底盘静止且目标0；独占UART与原严格时限/回收门。",
            "对3目标逐项保存原始寄存器字节及文件SHA备份（不是下发硬件Backup指令）；固化预计raw12。每笔写前重读仍为同一设备/Mode1/Torque0/Phase12，漂移即停。",
        ],
        "preferred_reversible_trial": [
            "可优先评估原Lock1下仅Phase18临时RAM写4的单次断扭维护：依据厂家Lock合同掉电不保存；不解锁、不自动上扭、不顺带改Mode/单位位/PID/校准。若固件不支持或读回不同，立即停止，不自动转为EEPROM写。",
            "读回Phase必须精确4且只有bit3变化，再确认Torque0/Mode1/Goal0/Present0及其他寄存器没有漂移；可再次独立READ复核。读回通过也不等于已经做了上扭停转测试。",
        ],
        "persistent_followup_separate_scope": [
            "只有后续明确授权持久Phase修正时，断扭状态保存原Lock并按表解锁0，只写18=4，逐项读回，恢复原Lock，保留每笔回执/原件；不能借原Mode1或硬件运动授权自动扩为EEPROM写。",
            "通过人工断电重启后新只读核Phase4/Mode1/model/firmware、扭矩0/目标0/反馈0，证明掉电保存；不得软件重启或改服务代替真实电机断电。",
        ],
        "stop_and_motion_gate": [
            "在Phase12或未知Phase时停止链走独立TorqueDisable，不下发可能最高速的GoalVelocity0；Phase4新鲜读回通过后才允许使用ZeroCommand。",
            "后续受监督最小上扭零目标测试与小幅正/反速度测试各需独立GO及现场条件，按已有严格预算/停止/终读/真实回收门执行；需要实测停止和单位标定才能关闭硬件合同，D15不会因此关闭。",
        ],
        "rollback": [
            "失败先断扭并确认静止；只在相同3目标/固件身份匹配且Torque0时依据备份恢复原Phase12（临时或持久路径按已授权范围），再精确读回/恢复原Lock。",
            "回滚到12后保持使能/Motion/ZeroCommand门拒绝；不能为了恢复旧运行状态顺带上扭。断扭未证实或回读失败时要求现场手动断电，并保留失败，不循环重试。",
        ],
        "final_evidence": "保留全部成功/失败原件；17舵机扭矩/目标/速度与逐项身份后验、UART锁释放、自有child真实回收分别判定，旧marker/latch与正式安装不修改。",
    },
    "third_party_hypotheses": {"state": "第三方bit2/bit3说法现已由公开厂家原表单独证实；结论主证据只引用厂家原JSON/MD。", "not_relied_on": ["Scribd转载", "钜犀科技转载", "microduck第三方整理"]},
    "retrieval_limits_and_preserved_failures": [
        "Web工具官方PDF/HTTPS门户/Gitee显示Internal Error；HTTPS curl门户exit35，HTTP公开门户及其JS/公开GET均成功，不重复循环失败路线。",
        "13源下载首轮1个LeRobot tables TLS失败exit35，下载helper真实exit1原download_manifest保留；另存tables-r2文件已获取并按pin/source内容复核。该shell最终exit0不单独充当curl wait证据，不把首轮改写为全成功。",
    ],
}
local_after = [identity(p) for p in local_paths]
assert local_before == local_after
record["local_upstream"]["before_after_identical"] = True
record["local_upstream"]["after"] = local_after
evidence = [identity(p) for p in sorted(ROOT.rglob("*")) if p.is_file() and p.name not in {"review.json", "evidence_index.json"}]
(ROOT / "evidence_index.json").write_text(json.dumps({"files": evidence}, ensure_ascii=False, indent=2) + "\n")
record["evidence_index"] = identity(ROOT / "evidence_index.json")
(ROOT / "review.json").write_text(json.dumps(record, ensure_ascii=False, indent=2) + "\n")
assert evidence == [identity(Path(r["path"])) for r in evidence]
print(json.dumps({"review": identity(ROOT / "review.json"), "evidence_files": len(evidence), "local_source_files_unchanged": len(local_before), "status": record["status"]}, ensure_ascii=False))
