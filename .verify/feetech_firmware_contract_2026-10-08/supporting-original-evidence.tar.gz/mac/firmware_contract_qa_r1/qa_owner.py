"""自有本机QA顺序执行，保存真实退出/回收和原件，不运行硬件。"""
from pathlib import Path
import datetime
import hashlib
import json
import os
import signal
import subprocess
import time

ROOT = Path('/Users/loosqk/.codex/worktrees/feetech-wheel-firmware-contract/robot-system')
OUT = Path(__file__).resolve().parent
BASE = Path('/Users/loosqk/repo/rust/robot-system/target/xlerobot_velocity_foundation/expected_source_r7.json')
EXPECTED_CHANGED = {
    'crates/robot-adapters/feetech/src/registers.rs',
    'crates/robot-adapters/feetech/src/bus.rs',
    'crates/robot-adapters/feetech/src/error.rs',
    'crates/robot-adapters/feetech/src/diagnostic.rs',
    'crates/robot-adapters/feetech/examples/feetech_poke.rs',
    'crates/robot-adapters/feetech/src/lib.rs',
    'crates/robot-adapters/feetech/src/velocity_profile.rs',
}
ENV = dict(os.environ, RUSTUP_TOOLCHAIN='nightly', CARGO_TARGET_DIR=str(OUT / 'cargo-target'), CARGO_BUILD_JOBS='2')
OWNER = {'pid': os.getpid(), 'ppid': os.getppid(), 'cwd': str(ROOT), 'started_at': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'hardware': 0, 'ssh': 0}


def write(name, value):
    path = OUT / name
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n')


def digest(path):
    raw = path.read_bytes()
    return {'path': str(path), 'sha256': hashlib.sha256(raw).hexdigest(), 'bytes': len(raw)}


def snapshot(name):
    names = set(json.loads(BASE.read_text())['files']) | {'crates/robot-adapters/feetech/src/velocity_profile.rs'}
    rows = {}
    for rel in sorted(names):
        p = ROOT / rel
        rows[rel] = {**digest(p), 'executable': bool(p.stat().st_mode & 0o111)}
    canonical = json.dumps(rows, sort_keys=True, separators=(',', ':')).encode()
    data = {'files': rows, 'count': len(rows), 'manifest_sha256': hashlib.sha256(canonical).hexdigest(), 'base_inventory': digest(BASE)}
    write(name, data)
    return data


def run(index, label, argv, budget_s=300):
    stdout = OUT / f'{index:02d}_{label}.stdout'
    stderr = OUT / f'{index:02d}_{label}.stderr'
    began = time.monotonic_ns()
    with stdout.open('wb') as so, stderr.open('wb') as se:
        child = subprocess.Popen(argv, cwd=ROOT, env=ENV, stdout=so, stderr=se, start_new_session=True)
        write('status.json', {'state': 'RUNNING', 'owner': OWNER, 'child_pid': child.pid, 'label': label, 'argv': argv})
        timed_out = False
        try:
            exit_code = child.wait(timeout=budget_s)
        except subprocess.TimeoutExpired:
            timed_out = True
            os.killpg(child.pid, signal.SIGTERM)
            try:
                exit_code = child.wait(timeout=15)
            except subprocess.TimeoutExpired:
                os.killpg(child.pid, signal.SIGKILL)
                exit_code = child.wait()
    row = {'label': label, 'argv': argv, 'cwd': str(ROOT), 'pid': child.pid, 'owner_pid': OWNER['pid'], 'budget_s': budget_s, 'started_monotonic_ns': began, 'ended_monotonic_ns': time.monotonic_ns(), 'exit_code': exit_code, 'timed_out': timed_out, 'wait_reaped': True, 'natural_completion': not timed_out, 'stdout': digest(stdout), 'stderr': digest(stderr)}
    write(f'{index:02d}_{label}.result.json', row)
    print(json.dumps({'label': label, 'exit_code': exit_code, 'wait_reaped': True, 'timed_out': timed_out}), flush=True)
    return row


write('owner.json', OWNER)
before = snapshot('source_before_fmt.json')
commands = [
    ('latest_nightly_update', ['rustup', 'update', 'nightly']),
    ('rustc_before', ['rustc', '-Vv']),
    ('cargo_before', ['cargo', '-V']),
    ('fmt', ['cargo', 'fmt', '--all']),
    ('diff_check', ['git', 'diff', '--check']),
    ('crate_all_target_clippy', ['cargo', 'clippy', '--locked', '-p', 'robot-adapter-feetech', '--all-targets', '--features', 'real-hw', '--', '-D', 'warnings']),
    ('crate_lib_tests', ['cargo', 'test', '--locked', '-p', 'robot-adapter-feetech', '--lib', '--features', 'real-hw', '--', '--test-threads=1']),
    ('poke_tests', ['cargo', 'test', '--locked', '-p', 'robot-adapter-feetech', '--example', 'feetech_poke', '--features', 'real-hw', '--', '--test-threads=1']),
    ('rustc_after', ['rustc', '-Vv']),
    ('cargo_after', ['cargo', '-V']),
]
results = []
after_fmt = None
for index, (label, argv) in enumerate(commands, 1):
    row = run(index, label, argv)
    results.append(row)
    if label == 'fmt':
        after_fmt = snapshot('source_after_fmt_before_qa.json')
        diff = run(0, 'scoped_status', ['git', 'status', '--porcelain=v1', '-z'])
        raw_status = Path(diff['stdout']['path']).read_bytes().decode()
        actual = {part[3:] for part in raw_status.split('\0') if part}
        if actual != EXPECTED_CHANGED:
            write('scope_failure.json', {'expected': sorted(EXPECTED_CHANGED), 'actual': sorted(actual)})
            results.append({**diff, 'scope_ok': False})
            break
    if row['exit_code'] != 0 or row['timed_out']:
        break
after = snapshot('source_after_qa.json')
same = after_fmt is not None and after['files'] == after_fmt['files']
compiler_same = all((OUT / f'{a}_{label}.stdout').exists() for a, label in [('02', 'rustc_before'), ('09', 'rustc_after')]) and (OUT / '02_rustc_before.stdout').read_bytes() == (OUT / '09_rustc_after.stdout').read_bytes()
cargo_same = (OUT / '10_cargo_after.stdout').exists() and (OUT / '03_cargo_before.stdout').read_bytes() == (OUT / '10_cargo_after.stdout').read_bytes()
passed = len(results) == len(commands) and all(row['exit_code'] == 0 and not row['timed_out'] for row in results) and same and compiler_same and cargo_same
final = {'status': 'PASS' if passed else 'FAIL', 'owner': OWNER, 'commands': results, 'source_count': after['count'], 'after_fmt_matches_after_qa': same, 'compiler_same': compiler_same, 'cargo_same': cargo_same, 'source_manifest_sha256': after['manifest_sha256'], 'scope': '本机单crate real-hw软件库与poke；不是完整workspace/release/硬件，无SSH/UART/Phase写', 'qa_owner_local_wait': '调用方exec session需另行真实wait；本文件仅记录此owner对子进程实际wait'}
write('result.json', final)
write('status.json', {'state': 'COMPLETED', 'status': final['status'], 'owner': OWNER})
print(json.dumps({'status': final['status'], 'commands': len(results), 'source_count': after['count'], 'source_same': same, 'compiler_same': compiler_same, 'cargo_same': cargo_same}), flush=True)
raise SystemExit(0 if passed else 1)
