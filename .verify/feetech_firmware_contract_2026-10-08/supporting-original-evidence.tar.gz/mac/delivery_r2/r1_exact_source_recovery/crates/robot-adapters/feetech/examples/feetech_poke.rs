//! One-shot Feetech wire-level 命令：读/写单个寄存器 / handshake ping。
//!
//! 用途：bring-up / 下使能手动测试 / 单寄存器诊断 —— 比开整个 `s0_daemon`
//! 轻，比改 `mock_s1` 通用。当前 S0 架构（见 `rt_thread.rs:148` 注释）里
//! `state_machine` **未接通** adapter enable/disable 执行链路（Part 2 TODO），
//! 本 example 是这个缺口补上之前的"手动下使能"入口。
//!
//! ## 编译
//!
//! 本 example 依赖 `real-hw` feature（拉 `serialport` crate + libudev）。
//!
//! ```bash
//! cargo build --release --example feetech_poke \
//!   -p robot-adapter-feetech --features real-hw
//! ```
//!
//! ## 用法
//!
//! ```bash
//! feetech_poke <address> <motor_id> ping
//! feetech_poke <address> <motor_id> read  <register>
//! feetech_poke <address> <motor_id> write <register> <value>
//! ```
//!
//! - `<address>`：串口绝对路径，推荐 `/dev/serial/by-id/usb-1a86_..._if00`
//! - `<motor_id>`：1..=253（0 = broadcast 不支持；254/255 保留）
//! - `<register>`：Feetech 寄存器名，参考 `src/registers.rs`（如
//!   `Goal_Position` / `Present_Position` / `Torque_Enable` / `Operating_Mode` /
//!   `Homing_Offset`）
//! - `<value>`：`i32`。sign-magnitude 编码由 bus 内部处理
//!
//! ## 实例
//!
//! ```bash
//! # 读当前位置
//! feetech_poke /dev/serial/by-id/usb-...5A7C121427-if00 6 read Present_Position
//!
//! # 把左夹爪推到闭合位（range_min raw=1408，dimos left_arm.json 标定）
//! feetech_poke /dev/serial/by-id/usb-...5A7C121427-if00 6 write Goal_Position 1408
//!
//! # 下使能（手动掰电机前做；注意此时电机会在重力 / 外力作用下自由运动）
//! feetech_poke /dev/serial/by-id/usb-...5A7C121427-if00 6 write Torque_Enable 0
//!
//! # 使能（危险！不配合 follow-current 防飞序列，motor 会直接追当前 Goal 寄存器值）
//! feetech_poke /dev/serial/by-id/usb-...5A7C121427-if00 6 write Torque_Enable 1
//! ```
//!
//! ## 安全警告
//!
//! - 本工具是**裸 wire**，不走 `FeetechAdapter` 的防飞序列（`sync Goal=Present →
//!   sleep 50ms → Torque_Enable=1`）。手动 `write Torque_Enable 1` 前一定要先
//!   `write Goal_Position <当前 Present>`，否则 motor 会追寄存器里残留的旧 Goal。
//! - 写 EEPROM 区寄存器（`Homing_Offset` / `Min_Position_Limit` / `Max_Position_
//!   Limit` / `Operating_Mode` / `Lock`）的保存语义须独立确认。厂家表公开版本181
//!   规定Lock0写EPROM掉电保存、Lock1不保存；不能从中推定现场临时写一定生效。
//!   配置写入需断扭、明确授权及逐项读回；Phase与死区仍为本项目诊断只读。
//! - 大幅度 `Goal_Position` 跳变（超过 Goal Acceleration 能追上的范围）可能引起
//!   机械冲击 —— bring-up 阶段尽量小步推进。

#![cfg(feature = "real-hw")]

use std::collections::HashMap;
use std::path::Path;
use std::process::ExitCode;

use robot_adapter_feetech::registers::{
    STS3215_CONTROL_TABLE, ensure_not_diagnostic_write, ensure_not_firmware_readonly_write,
};
use robot_adapter_feetech::transport::real::RealSerialTransport;
use robot_adapter_feetech::{DEFAULT_BAUDRATE, FeetechBus, FeetechError, Motor};

/// 把用户输入的 register 名对齐到 `STS3215_CONTROL_TABLE` 里的 `&'static str`。
///
/// `FeetechBus::read/write` 签名要求 `reg_name: &'static str`（编译期常量 API），
/// 而 CLI 拿到的是 `String`。查表 → 返回静态引用，顺带完成拼写校验。
fn static_register_name(name: &str) -> Option<&'static str> {
    STS3215_CONTROL_TABLE
        .iter()
        .find(|(n, _)| *n == name)
        .map(|(n, _)| *n)
}

/// 纯参数预检，在打开串口前保留三个诊断拒写门并拒绝两个固件版本write。
/// 其他名称与参数继续由原分发处理；本门放行不表示写入合法。
fn preflight_diagnostic_write(args: &[String]) -> Result<(), FeetechError> {
    match args.get(3).map(String::as_str) {
        Some("write") => match args.get(4).and_then(|name| static_register_name(name)) {
            Some(name @ ("Phase" | "CW_Dead_Zone" | "CCW_Dead_Zone")) => {
                ensure_not_diagnostic_write(name)
            }
            Some(name @ ("Firmware_Major_Version" | "Firmware_Minor_Version")) => {
                ensure_not_firmware_readonly_write(name)
            }
            _ => Ok(()),
        },
        _ => Ok(()),
    }
}

fn usage(prog: &str) -> String {
    format!(
        "usage:\n  \
         {prog} <address> <motor_id> ping\n  \
         {prog} <address> <motor_id> read  <register>\n  \
         {prog} <address> <motor_id> write <register> <value>\n"
    )
}

fn do_read<T: robot_adapter_feetech::SerialTransport>(
    bus: &mut FeetechBus<T>,
    motor_id: u8,
    args: &[String],
    prog: &str,
) -> ExitCode {
    if args.len() != 5 {
        eprint!("{}", usage(prog));
        return ExitCode::from(2);
    }
    let register = &args[4];
    let Some(reg_static) = static_register_name(register) else {
        eprintln!("error: unknown register '{register}'");
        return ExitCode::from(2);
    };
    match bus.read(reg_static, "m") {
        Ok(v) => {
            println!("read {register}@{motor_id} = {v}");
            ExitCode::SUCCESS
        }
        Err(e) => {
            eprintln!("error: read {register}@{motor_id}: {e}");
            ExitCode::from(1)
        }
    }
}

fn do_write<T: robot_adapter_feetech::SerialTransport>(
    bus: &mut FeetechBus<T>,
    motor_id: u8,
    args: &[String],
    prog: &str,
) -> ExitCode {
    if args.len() != 6 {
        eprint!("{}", usage(prog));
        return ExitCode::from(2);
    }
    let register = &args[4];
    let Some(reg_static) = static_register_name(register) else {
        eprintln!("error: unknown register '{register}'");
        return ExitCode::from(2);
    };
    let value: i32 = match args[5].parse() {
        Ok(v) => v,
        Err(e) => {
            eprintln!("error: value '{}' 解析失败: {e}", args[5]);
            return ExitCode::from(2);
        }
    };
    match bus.write(reg_static, "m", value) {
        Ok(()) => {
            println!("write {register}@{motor_id} <- {value} ok");
            ExitCode::SUCCESS
        }
        Err(e) => {
            eprintln!("error: write {register}@{motor_id} <- {value}: {e}");
            ExitCode::from(1)
        }
    }
}

fn main() -> ExitCode {
    // task-32：统一 tracing subscriber 初始化。
    let _ = robot_logging::init();

    let args: Vec<String> = std::env::args().collect();
    let prog = args
        .first()
        .cloned()
        .unwrap_or_else(|| "feetech_poke".into());

    if args.len() < 4 {
        eprint!("{}", usage(&prog));
        return ExitCode::from(2);
    }
    let address = &args[1];
    let motor_id: u8 = match args[2].parse() {
        Ok(id) => id,
        Err(e) => {
            eprintln!("error: motor_id '{}' 解析失败: {e}", args[2]);
            return ExitCode::from(2);
        }
    };
    let action = args[3].as_str();

    if let Err(error) = preflight_diagnostic_write(&args) {
        eprintln!("error: {error}");
        return ExitCode::from(2);
    }

    // 构造 bus：单 motor 名统一叫 "m"（本工具不关心名字语义）
    let transport = match RealSerialTransport::open(Path::new(address), DEFAULT_BAUDRATE) {
        Ok(t) => t,
        Err(e) => {
            eprintln!("error: open serial '{address}': {e}");
            return ExitCode::from(1);
        }
    };
    let mut motors = HashMap::new();
    let motor = match Motor::new(motor_id) {
        Ok(m) => m,
        Err(e) => {
            eprintln!("error: motor_id {motor_id}: {e}");
            return ExitCode::from(2);
        }
    };
    motors.insert("m".to_string(), motor);
    let mut bus = match FeetechBus::new(transport, motors) {
        Ok(b) => b,
        Err(e) => {
            eprintln!("error: FeetechBus::new: {e}");
            return ExitCode::from(1);
        }
    };

    // handshake=true 统一走：验证 motor_id 在线 + Model_Number=STS3215
    if let Err(e) = bus.connect(true) {
        eprintln!("error: bus.connect (handshake) motor_id={motor_id}: {e}");
        return ExitCode::from(1);
    }

    match action {
        "ping" => {
            // connect(true) 已经 handshake 过了，走到这里就是 ping 成功
            println!("ping ok: motor_id={motor_id} on {address} (Model_Number=STS3215 777)");
            ExitCode::SUCCESS
        }
        "read" => do_read(&mut bus, motor_id, &args, &prog),
        "write" => do_write(&mut bus, motor_id, &args, &prog),
        other => {
            eprintln!("error: unknown action '{other}'\n{}", usage(&prog));
            ExitCode::from(2)
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    fn arguments(action: &str, register: &str, value: Option<&str>) -> Vec<String> {
        let mut args = vec![
            "feetech_poke".to_string(),
            "/dev/never-open".to_string(),
            "1".to_string(),
            action.to_string(),
            register.to_string(),
        ];
        if let Some(value) = value {
            args.push(value.to_string());
        }
        args
    }

    #[test]
    fn diagnostic_write_preflight_denies_even_missing_or_invalid_values() {
        for name in ["Phase", "CW_Dead_Zone", "CCW_Dead_Zone"] {
            for value in [None, Some("bad-value"), Some("255"), Some("2147483648")] {
                let args = arguments("write", name, value);
                assert!(matches!(
                    preflight_diagnostic_write(&args),
                    Err(FeetechError::DiagnosticRegisterWriteForbidden(got)) if got == name
                ));
            }
        }
    }

    #[test]
    fn firmware_version_preflight_rejects_write_and_preserves_read_before_open() {
        for name in ["Firmware_Major_Version", "Firmware_Minor_Version"] {
            assert_eq!(static_register_name(name), Some(name));
            for value in [None, Some("bad-value"), Some("255"), Some("2147483648")] {
                assert!(
                    matches!(preflight_diagnostic_write(&arguments("write", name, value)), Err(FeetechError::ReadOnlyRegisterWriteForbidden(got)) if got == name)
                );
            }
            assert!(preflight_diagnostic_write(&arguments("read", name, None)).is_ok());
        }
    }

    #[test]
    fn existing_write_preflight_keeps_supported_arguments() {
        for (register, value) in [
            ("Goal_Position", "-100"),
            ("Goal_Velocity", "20"),
            ("Torque_Enable", "0"),
            ("Operating_Mode", "1"),
            ("Model_Number", "777"),
        ] {
            assert!(preflight_diagnostic_write(&arguments("write", register, Some(value))).is_ok());
        }
    }

    #[test]
    fn existing_missing_invalid_and_unknown_arguments_remain_for_original_dispatch() {
        for register in ["Goal_Position", "Unknown_Register"] {
            for value in [None, Some("bad-value"), Some("2147483648")] {
                assert!(preflight_diagnostic_write(&arguments("write", register, value)).is_ok());
            }
        }
        let args: Vec<String> = ["feetech_poke", "/dev/never-open", "1", "write"]
            .into_iter()
            .map(str::to_string)
            .collect();
        assert!(preflight_diagnostic_write(&args).is_ok());
    }

    #[test]
    fn original_do_write_still_rejects_bad_arguments_without_mock_io() {
        let (transport, handle) = robot_adapter_feetech::transport::MockTransport::new();
        let mut motors = HashMap::new();
        motors.insert("m".to_string(), Motor::new(1).unwrap());
        let mut bus = FeetechBus::new(transport, motors).unwrap();
        for args in [
            arguments("write", "Goal_Position", None),
            arguments("write", "Goal_Position", Some("bad-value")),
            arguments("write", "Goal_Position", Some("2147483648")),
            arguments("write", "Unknown_Register", Some("1")),
        ] {
            assert!(preflight_diagnostic_write(&args).is_ok());
            assert_eq!(
                do_write(&mut bus, 1, &args, "feetech_poke"),
                ExitCode::from(2)
            );
        }
        assert_eq!(handle.peek_tx(), [0_u8; 0]);
    }

    #[test]
    fn read_and_ping_preflight_preserve_existing_dispatch() {
        for name in ["Phase", "CW_Dead_Zone", "CCW_Dead_Zone", "Present_Position"] {
            assert!(preflight_diagnostic_write(&arguments("read", name, None)).is_ok());
        }
        let args: Vec<String> = ["feetech_poke", "/dev/never-open", "1", "ping"]
            .into_iter()
            .map(str::to_string)
            .collect();
        assert!(preflight_diagnostic_write(&args).is_ok());
    }
}
