"""XLeRobotBus2BaseAdapter — 三轮全向底盘（TwistBaseAdapter）。

dimos 虚拟 joint（3 个）：
  base_vx  (m/s, 前为正)
  base_vy  (m/s, 左为正)
  base_wz  (rad/s, 逆时针为正)

内部映射：body velocity → 三轮角速度 → Goal_Velocity raw。

里程计：100Hz 调 read_velocities 时顺带积分 (dt, body_vel) → world frame (x, y, θ)。
起点 (0, 0, 0)，world frame 定义为首次启动时的机身朝向。

与 bus2_arm 共享 `/dev/ttyACM1`（通过 SharedBusRegistry）。
"""

from __future__ import annotations

import logging
import math
import time
from dataclasses import dataclass, field

import numpy as np

from xlerobot_dimos.common.config import BUS2_CONFIG, OmniBaseConfig
from xlerobot_dimos.common.errors import ErrorCode
from xlerobot_dimos.common.feetech_io import OperatingMode, TorqueMode
from xlerobot_dimos.common.shared_bus import (
    SharedBusHandle,
    SharedBusRegistry,
    connect_handle_with_retry,
)
from xlerobot_dimos.common.units import (
    body_velocity_to_wheel_rad_per_sec,
    build_kinematic_matrix,
    raw_velocity_to_rad_per_sec,
    rad_per_sec_to_raw_velocity,
    saturate_wheel_velocities,
    wheel_rad_per_sec_to_body_velocity,
)

logger = logging.getLogger(__name__)


@dataclass
class SimpleOdometry:
    """极简里程计：假设 read_velocities 被周期性调用，按 dt 积分。"""

    x: float = 0.0
    y: float = 0.0
    theta: float = 0.0
    last_update_ns: int = field(default_factory=time.monotonic_ns)

    def reset(self) -> None:
        self.x = 0.0
        self.y = 0.0
        self.theta = 0.0
        self.last_update_ns = time.monotonic_ns()

    def update(self, vx: float, vy: float, wz: float) -> None:
        """用当前 body velocity 积分一步。"""
        now = time.monotonic_ns()
        dt_ns = now - self.last_update_ns
        self.last_update_ns = now
        if dt_ns <= 0:
            return
        dt = dt_ns / 1e9

        # body frame → world frame
        c = math.cos(self.theta)
        s = math.sin(self.theta)
        self.x += (vx * c - vy * s) * dt
        self.y += (vx * s + vy * c) * dt
        self.theta += wz * dt
        # 规范化 theta 到 (-π, π]
        self.theta = (self.theta + math.pi) % (2.0 * math.pi) - math.pi


class XLeRobotBus2BaseAdapter:
    """三轮全向底盘 TwistBaseAdapter 实现。"""

    DOF = 3  # vx, vy, wz

    def __init__(self, dof: int = 3, address: str | None = None, **_ignored: object) -> None:
        if dof != self.DOF:
            raise ValueError(f"xlerobot_bus2_base 只支持 dof=3，收到 {dof}")
        if address is not None and address != BUS2_CONFIG.port:
            raise ValueError(
                f"xlerobot_bus2_base address 不匹配: 期望 {BUS2_CONFIG.port}, 收到 {address}"
            )

        self._bus_config = BUS2_CONFIG
        if self._bus_config.base is None:
            raise ValueError("bus2 配置缺少 base 段")
        self._base_config: OmniBaseConfig = self._bus_config.base

        # 电机名顺序（front, left, right），运动学矩阵行顺序一致
        self._wheel_motor_names: tuple[str, str, str] = (
            self._base_config.front.motor_name,
            self._base_config.left.motor_name,
            self._base_config.right.motor_name,
        )

        # 预计算运动学矩阵及其逆
        self._K = build_kinematic_matrix(self._base_config.base_radius_m)
        self._K_inv = np.linalg.inv(self._K)

        self._handle: SharedBusHandle | None = None
        self._connected: bool = False
        self._enabled: bool = False

        self._odometry = SimpleOdometry()
        self._cached_body_velocity = np.zeros(3, dtype=np.float64)

        self._last_error_code: int = 0
        self._last_error_message: str = ""

    # ── 工具 ─────────────────────────────────────

    def _set_error(self, code: ErrorCode, message: str) -> None:
        self._last_error_code = int(code)
        self._last_error_message = message

    # ── 连接 ─────────────────────────────────────

    def connect(self) -> bool:
        try:
            self._handle = SharedBusRegistry.acquire(self._bus_config)
            connect_handle_with_retry(self._handle)

            bus = self._handle.bus
            with self._handle.lock:
                # EEPROM 解锁: Operating_Mode 在 EEPROM 区
                for motor_name in self._wheel_motor_names:
                    bus.write("Torque_Enable", motor_name, TorqueMode.DISABLED.value)
                    bus.write("Lock", motor_name, 0)

                try:
                    # 三轮切到 VELOCITY 模式
                    for motor_name in self._wheel_motor_names:
                        bus.write(
                            "Operating_Mode", motor_name, OperatingMode.VELOCITY.value
                        )
                finally:
                    # 重新上锁
                    for motor_name in self._wheel_motor_names:
                        try:
                            bus.write("Lock", motor_name, 1)
                        except Exception:
                            pass

            self._odometry.reset()
            self._connected = True
            self._set_error(ErrorCode.OK, "")
            logger.info("xlerobot_bus2_base 已连接")
            return True
        except Exception as exc:
            logger.exception("bus2_base connect 失败")
            self._set_error(ErrorCode.OPEN_PORT_FAILED, str(exc))
            if self._handle is not None:
                SharedBusRegistry.release(self._bus_config.port)
                self._handle = None
            self._connected = False
            return False

    def disconnect(self) -> None:
        if self._handle is not None:
            try:
                with self._handle.lock:
                    for motor_name in self._wheel_motor_names:
                        try:
                            self._handle.bus.write("Goal_Velocity", motor_name, 0)
                            self._handle.bus.write("Torque_Enable", motor_name, 0)
                        except Exception:
                            pass
            except Exception:
                pass
            SharedBusRegistry.release(self._bus_config.port)
            self._handle = None
        self._connected = False
        self._enabled = False

    def is_connected(self) -> bool:
        return self._connected

    # ── 信息 ─────────────────────────────────────

    def get_dof(self) -> int:
        return self.DOF

    # ── 状态读取 ─────────────────────────────────

    def _read_wheel_rad_per_sec(self) -> np.ndarray:
        """从 Feetech 读取三轮当前角速度 (rad/s)，顺序 (front, left, right)。"""
        assert self._handle is not None
        raw = self._handle.bus.sync_read(
            "Present_Velocity", list(self._wheel_motor_names)
        )
        return np.array(
            [
                raw_velocity_to_rad_per_sec(int(raw[name]), self._base_config)
                for name in self._wheel_motor_names
            ],
            dtype=np.float64,
        )

    def read_velocities(self) -> list[float]:
        """返回当前 body velocity [vx, vy, wz]。"""
        if self._handle is None or not self._connected:
            self._set_error(ErrorCode.NOT_CONNECTED, "not connected")
            return self._cached_body_velocity.tolist()
        try:
            wheel_rad = self._read_wheel_rad_per_sec()
            body = wheel_rad_per_sec_to_body_velocity(
                wheel_rad, self._base_config, K_pinv=self._K_inv
            )
            self._cached_body_velocity = body
            self._odometry.update(float(body[0]), float(body[1]), float(body[2]))
            self._set_error(ErrorCode.OK, "")
            return body.tolist()
        except Exception as exc:
            logger.exception("read_velocities 失败")
            self._set_error(ErrorCode.READ_FAILED, str(exc))
            return self._cached_body_velocity.tolist()

    def read_odometry(self) -> list[float] | None:
        """返回 [x, y, theta]（world frame, 米/米/弧度）。"""
        return [self._odometry.x, self._odometry.y, self._odometry.theta]

    # ── 控制 ─────────────────────────────────────

    def write_velocities(self, velocities: list[float]) -> bool:
        """接收 [vx, vy, wz] 并写入三轮 Goal_Velocity。"""
        if self._handle is None or not self._connected:
            self._set_error(ErrorCode.NOT_CONNECTED, "not connected")
            return False
        if not self._enabled:
            self._set_error(ErrorCode.NOT_ENABLED, "not enabled")
            return False
        if len(velocities) != self.DOF:
            self._set_error(
                ErrorCode.INVALID_ARGUMENT,
                f"velocities 长度不匹配: 期望 {self.DOF}, 收到 {len(velocities)}",
            )
            return False

        try:
            body = np.asarray(velocities, dtype=np.float64)
            wheel_rad = body_velocity_to_wheel_rad_per_sec(
                body, self._base_config, K=self._K
            )
            wheel_rad, _scale = saturate_wheel_velocities(
                wheel_rad, self._base_config.max_wheel_rad_per_sec
            )
            raw_values: dict[str, int] = {}
            for motor_name, rad in zip(self._wheel_motor_names, wheel_rad, strict=True):
                raw_values[motor_name] = rad_per_sec_to_raw_velocity(float(rad), self._base_config)

            self._handle.bus.sync_write("Goal_Velocity", raw_values)
            self._set_error(ErrorCode.OK, "")
            return True
        except Exception as exc:
            logger.exception("write_velocities 失败")
            self._set_error(ErrorCode.WRITE_FAILED, str(exc))
            return False

    def write_stop(self) -> bool:
        if self._handle is None or not self._connected:
            return False
        try:
            zeros = {name: 0 for name in self._wheel_motor_names}
            self._handle.bus.sync_write("Goal_Velocity", zeros)
            self._cached_body_velocity[:] = 0.0
            return True
        except Exception as exc:
            logger.exception("write_stop 失败")
            self._set_error(ErrorCode.STOP_FAILED, str(exc))
            return False

    # ── 使能 ─────────────────────────────────────

    def write_enable(self, enable: bool) -> bool:
        if self._handle is None or not self._connected:
            self._set_error(ErrorCode.NOT_CONNECTED, "not connected")
            return False

        target_value = 1 if enable else 0
        max_attempts = 3
        retry_delay_s = 0.15

        try:
            with self._handle.lock:
                if enable:
                    # 上电前先把目标速度置零
                    zeros = {name: 0 for name in self._wheel_motor_names}
                    self._handle.bus.sync_write("Goal_Velocity", zeros)
                    time.sleep(0.05)

                failed: list[tuple[str, Exception]] = []
                for motor_name in self._wheel_motor_names:
                    last_exc: Exception | None = None
                    for attempt in range(1, max_attempts + 1):
                        try:
                            self._handle.bus.write("Torque_Enable", motor_name, target_value)
                            last_exc = None
                            break
                        except Exception as exc:
                            last_exc = exc
                            logger.warning(
                                "Torque_Enable %s=%d 尝试 %d/%d 失败: %s",
                                motor_name, target_value, attempt, max_attempts, exc,
                            )
                            if attempt < max_attempts:
                                time.sleep(retry_delay_s)
                    if last_exc is not None:
                        failed.append((motor_name, last_exc))

                if failed:
                    names = ", ".join(n for n, _ in failed)
                    raise RuntimeError(f"Torque_Enable 失败的轮子: {names}")

            self._enabled = bool(enable)
            self._set_error(ErrorCode.OK, "")
            return True
        except Exception as exc:
            logger.exception("write_enable(%s) 失败", enable)
            self._set_error(ErrorCode.WRITE_FAILED, str(exc))
            return False

    def read_enabled(self) -> bool:
        return self._enabled
