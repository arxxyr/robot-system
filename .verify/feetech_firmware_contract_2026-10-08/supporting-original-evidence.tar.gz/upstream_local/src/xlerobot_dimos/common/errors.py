"""错误码与异常定义。

与 dimos 约定对齐：adapter 读接口失败时返回缓存值或 None，
写接口失败时返回 False；异常只在构造或配置期抛出。
"""

from __future__ import annotations

from enum import IntEnum


class ErrorCode(IntEnum):
    """adapter 统一错误码。"""

    OK = 0
    UNKNOWN_ERROR = 1
    NOT_CONNECTED = 2
    TIMEOUT = 3
    INVALID_ARGUMENT = 4
    UNSUPPORTED = 5
    HARDWARE_FAULT = 6
    STATE_STALE = 7
    NOT_ENABLED = 8
    LIMIT_VIOLATION = 9

    OPEN_PORT_FAILED = 100
    HANDSHAKE_FAILED = 101
    DEVICE_NOT_FOUND = 102
    CALIBRATION_FAILED = 103

    WRITE_FAILED = 200
    READ_FAILED = 201
    STOP_FAILED = 202
    CLEAR_ERROR_FAILED = 203


class XLeRobotError(Exception):
    """配置或启动期的致命错误。运行期错误走错误码返回，不抛异常。"""

    def __init__(self, code: ErrorCode, message: str) -> None:
        self.code = code
        self.message = message
        super().__init__(f"[{code.name}] {message}")
