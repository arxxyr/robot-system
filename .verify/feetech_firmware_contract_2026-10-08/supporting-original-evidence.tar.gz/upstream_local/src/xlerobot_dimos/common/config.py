"""硬件配置数据类与固定常量。

所有 BusConfig 在这里硬编码，adapter 构造时按串口 address 查表。
不通过 HardwareComponent 传配置（保持 blueprint 简洁）。
"""

from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path

# lerobot 的 MotorNormMode 在真正构造 Motor 时才需要，这里只保存它的名字。
# shared_bus._build_motor_dict() 会根据这些字符串 getattr(MotorNormMode, name)。
NORM_MODE_M100_100 = "RANGE_M100_100"
NORM_MODE_0_100 = "RANGE_0_100"


# ── 路径 ──────────────────────────────────────────────

# 默认校准目录（Orin 上的绝对路径；本地开发时可用环境变量覆盖）
DEFAULT_CALIBRATION_DIR = Path("/home/loosqk/repo/dimensional-applications/calibration")


# ── 关节通道 ──────────────────────────────────────────

@dataclass(slots=True, frozen=True)
class JointChannel:
    """单个关节电机的映射配置。"""

    joint_name: str           # dimos 侧语义名（如 "left_arm_shoulder_pan"）
    motor_name: str           # FeetechMotorsBus 里的 motor key（通常等于 joint_name）
    motor_id: int             # 总线上的电机 ID
    # lerobot MotorNormMode 的成员名（大写），运行时转枚举
    norm_mode: str = NORM_MODE_M100_100
    direction: float = 1.0    # +1 或 -1
    zero_offset_rad: float = 0.0

    # 简化的 norm → rad 线性映射：rad = norm * norm_to_rad_scale + norm_to_rad_bias
    # norm 是 lerobot 返回的归一化值（-100~+100 或 0~100）
    # Phase 2 默认 norm 100 ≈ π rad (≈ 57°)，精度不高但链路通
    norm_to_rad_scale: float = 3.14159265358979 / 100.0
    norm_to_rad_bias: float = 0.0


# ── 底盘 ──────────────────────────────────────────────

@dataclass(slots=True, frozen=True)
class WheelChannel:
    """底盘单轮的电机映射。"""

    motor_name: str
    motor_id: int


@dataclass(slots=True, frozen=True)
class OmniBaseConfig:
    """三轮全向底盘配置。

    物理布局：一前二后。Front 是物理最前方的单轮，
    Left/Right 是后面两个轮子（命名跟物理左右一致，与电机
    的角度不直接对应——运动学矩阵会处理映射）。
    """

    front: WheelChannel
    left: WheelChannel
    right: WheelChannel

    wheel_radius_m: float = 0.05
    base_radius_m: float = 0.125

    # 每个轮子的最大角速度（rad/s），对应 Goal_Velocity raw 值的满量程
    # 经验值：raw=700 顺滑，raw=1023 是 10-bit 上限。假设满量程 = 6.0 rad/s
    max_wheel_rad_per_sec: float = 6.0
    raw_at_max_speed: int = 1023


# ── 总线配置 ──────────────────────────────────────────

@dataclass(slots=True, frozen=True)
class BusConfig:
    """一条 Feetech 串口总线的完整配置。"""

    name: str                               # "bus1" / "bus2"
    port: str                               # "/dev/ttyACM0" / "/dev/ttyACM1"

    arm_joints: tuple[JointChannel, ...] = ()
    gripper: JointChannel | None = None
    head_joints: tuple[JointChannel, ...] = ()
    base: OmniBaseConfig | None = None

    # Feetech STS3215 的 PID（位置模式）
    p_coefficient: int = 16
    i_coefficient: int = 0
    d_coefficient: int = 43

    def all_motor_ids(self) -> list[int]:
        ids: list[int] = [j.motor_id for j in self.arm_joints]
        if self.gripper is not None:
            ids.append(self.gripper.motor_id)
        ids.extend(j.motor_id for j in self.head_joints)
        if self.base is not None:
            ids.extend([self.base.front.motor_id, self.base.left.motor_id, self.base.right.motor_id])
        return ids


# ── 具体硬件定义 ──────────────────────────────────────

_ARM_NORM_MODE = NORM_MODE_M100_100
_GRIPPER_NORM_MODE = NORM_MODE_0_100


def _arm_joint(prefix: str, name_suffix: str, motor_id: int) -> JointChannel:
    full = f"{prefix}_{name_suffix}"
    return JointChannel(
        joint_name=full,
        motor_name=full,
        motor_id=motor_id,
        norm_mode=_ARM_NORM_MODE,
    )


def _gripper_channel(prefix: str, motor_id: int) -> JointChannel:
    full = f"{prefix}_gripper"
    return JointChannel(
        joint_name=full,
        motor_name=full,
        motor_id=motor_id,
        norm_mode=_GRIPPER_NORM_MODE,
        norm_to_rad_scale=1.0 / 100.0,  # 0~100 → 0~1（占位，夹爪不按弧度）
    )


# bus1: /dev/ttyACM0 — 左臂 5 + 夹爪 + 头部 2
BUS1_CONFIG = BusConfig(
    name="bus1",
    port="/dev/ttyACM0",
    arm_joints=(
        _arm_joint("left_arm", "shoulder_pan", 1),
        _arm_joint("left_arm", "shoulder_lift", 2),
        _arm_joint("left_arm", "elbow_flex", 3),
        _arm_joint("left_arm", "wrist_flex", 4),
        _arm_joint("left_arm", "wrist_roll", 5),
    ),
    gripper=_gripper_channel("left_arm", 6),
    head_joints=(
        JointChannel(
            joint_name="head_pan",
            motor_name="head_motor_1",
            motor_id=7,
            norm_mode=_ARM_NORM_MODE,
        ),
        JointChannel(
            joint_name="head_tilt",
            motor_name="head_motor_2",
            motor_id=8,
            norm_mode=_ARM_NORM_MODE,
        ),
    ),
)

# bus2: /dev/ttyACM1 — 右臂 5 + 夹爪 + 底盘 3
_BUS2_BASE = OmniBaseConfig(
    front=WheelChannel(motor_name="base_front_wheel", motor_id=8),
    left=WheelChannel(motor_name="base_left_wheel", motor_id=7),
    right=WheelChannel(motor_name="base_right_wheel", motor_id=9),
)

BUS2_CONFIG = BusConfig(
    name="bus2",
    port="/dev/ttyACM1",
    arm_joints=(
        _arm_joint("right_arm", "shoulder_pan", 1),
        _arm_joint("right_arm", "shoulder_lift", 2),
        _arm_joint("right_arm", "elbow_flex", 3),
        _arm_joint("right_arm", "wrist_flex", 4),
        _arm_joint("right_arm", "wrist_roll", 5),
    ),
    gripper=_gripper_channel("right_arm", 6),
    base=_BUS2_BASE,
)


# 按 address / name 查询
BUS_CONFIGS_BY_PORT: dict[str, BusConfig] = {
    BUS1_CONFIG.port: BUS1_CONFIG,
    BUS2_CONFIG.port: BUS2_CONFIG,
}

BUS_CONFIGS_BY_NAME: dict[str, BusConfig] = {
    BUS1_CONFIG.name: BUS1_CONFIG,
    BUS2_CONFIG.name: BUS2_CONFIG,
}


def get_bus_config(address: str | None = None, name: str | None = None) -> BusConfig:
    """按串口路径或名称获取 BusConfig。"""
    if address is not None and address in BUS_CONFIGS_BY_PORT:
        return BUS_CONFIGS_BY_PORT[address]
    if name is not None and name in BUS_CONFIGS_BY_NAME:
        return BUS_CONFIGS_BY_NAME[name]
    raise KeyError(f"未知 bus: address={address!r} name={name!r}")


# ── 部位 → 关节名列表（blueprint 用）─────────────────

LEFT_ARM_JOINT_NAMES: tuple[str, ...] = tuple(j.joint_name for j in BUS1_CONFIG.arm_joints)
RIGHT_ARM_JOINT_NAMES: tuple[str, ...] = tuple(j.joint_name for j in BUS2_CONFIG.arm_joints)
HEAD_JOINT_NAMES: tuple[str, ...] = tuple(j.joint_name for j in BUS1_CONFIG.head_joints)
