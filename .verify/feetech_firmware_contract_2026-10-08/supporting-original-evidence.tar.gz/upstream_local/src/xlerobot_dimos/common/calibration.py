"""校准文件加载。

直接复用 `scripts/calibrate.py` 写出的 JSON 格式（不改格式，保证数据兼容）：

    {
      "left_arm_shoulder_pan": {
        "id": 1,
        "drive_mode": 0,
        "homing_offset": -428,
        "range_min": 620,
        "range_max": 3301
      },
      ...
    }

一条总线可能跨越多个 JSON 文件（例如 bus1 = left_arm.json + head.json），
`load_all_for_bus()` 负责合并成一个 `{motor_name: MotorCalibration}` 字典。
"""

from __future__ import annotations

import json
import logging
from pathlib import Path

from xlerobot_dimos.common.config import BusConfig, DEFAULT_CALIBRATION_DIR
from xlerobot_dimos.common.errors import ErrorCode, XLeRobotError
from xlerobot_dimos.common.feetech_io import MotorCalibration

logger = logging.getLogger(__name__)


# bus_name → 这条总线会涉及的校准文件 stem
_BUS_PARTS: dict[str, tuple[str, ...]] = {
    "bus1": ("left_arm", "head"),
    "bus2": ("right_arm", "base"),
}


def load_calibration_file(path: Path) -> dict[str, MotorCalibration]:
    """读取单个 calibration JSON 文件。"""
    if not path.exists():
        raise XLeRobotError(
            ErrorCode.CALIBRATION_FAILED,
            f"校准文件不存在: {path}",
        )

    with path.open("r", encoding="utf-8") as f:
        data = json.load(f)

    result: dict[str, MotorCalibration] = {}
    for motor_name, entry in data.items():
        try:
            result[motor_name] = MotorCalibration(
                id=int(entry["id"]),
                drive_mode=int(entry.get("drive_mode", 0)),
                homing_offset=int(entry["homing_offset"]),
                range_min=int(entry["range_min"]),
                range_max=int(entry["range_max"]),
            )
        except (KeyError, ValueError, TypeError) as exc:
            raise XLeRobotError(
                ErrorCode.CALIBRATION_FAILED,
                f"校准文件 {path} 的 {motor_name} 字段不合法: {exc}",
            ) from exc

    return result


def load_all_for_bus(
    bus_config: BusConfig,
    calibration_dir: Path | None = None,
) -> dict[str, MotorCalibration]:
    """加载一条总线需要的全部校准数据，合并后返回。

    缺失的 part 会打 warning 但不会报错，允许只有部分校准的情况
    （例如底盘 base.json 未来才会启用）。
    """
    directory = calibration_dir or DEFAULT_CALIBRATION_DIR
    parts = _BUS_PARTS.get(bus_config.name, ())
    if not parts:
        raise XLeRobotError(
            ErrorCode.INVALID_ARGUMENT,
            f"未知 bus name: {bus_config.name}",
        )

    merged: dict[str, MotorCalibration] = {}
    for part in parts:
        path = directory / f"{part}.json"
        if not path.exists():
            logger.warning("校准文件缺失: %s（跳过）", path)
            continue
        part_data = load_calibration_file(path)
        overlap = set(merged).intersection(part_data)
        if overlap:
            logger.warning("校准文件存在重复电机名: %s", overlap)
        merged.update(part_data)
        logger.info("已加载 %d 个电机的校准: %s", len(part_data), path.name)

    return merged
