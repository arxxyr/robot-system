"""单位转换与运动学。

- 关节角度: lerobot normalized → 弧度（简化线性映射，Phase 2 够用）
- 底盘:     body velocity (vx, vy, ω) ↔ 三轮角速度（numpy 矩阵运算）
- 底盘:     轮角速度 ↔ Feetech Goal_Velocity raw 值

三轮全向运动学基向量（实验验证，按 (front, left, right)）：

    前进   (vx>0): (0, +1, -1)
    左横移 (vy>0): (+2, -1, -1)
    逆时针 (ω>0):  (+1, +1, +1)

物理几何：前轮在 θ=0°（机身 +X 方向），左电机在 θ=240°，右电机在 θ=120°。
矩阵 K 满足 `wheel_rad/s = (1/r) * K @ [vx, vy, ω]`。
"""

from __future__ import annotations

import math
from typing import TYPE_CHECKING

import numpy as np

if TYPE_CHECKING:
    from xlerobot_dimos.common.config import JointChannel, OmniBaseConfig


# ── 关节角度 ──────────────────────────────────────────

# STS3215 编码器分辨率：12-bit，4096 tick = 1 圈 = 2π rad
STS3215_TICKS_PER_REV = 4096
STS3215_CENTER_TICK = 2047    # 半转标零后中点对应的 raw 值
RAD_PER_TICK = 2.0 * math.pi / STS3215_TICKS_PER_REV
TICKS_PER_RAD = 1.0 / RAD_PER_TICK


def raw_to_rad(raw_value: int, channel: "JointChannel") -> float:
    """原始编码器 tick → 弧度。

    基于物理常量: raw=2047 对应 0 rad，每 1 tick = 2π/4096 ≈ 0.00153 rad。
    方向系数 direction 允许反转电机方向。zero_offset_rad 是软偏移（标定后用）。
    """
    centered = raw_value - STS3215_CENTER_TICK
    return centered * RAD_PER_TICK * channel.direction + channel.zero_offset_rad


def rad_to_raw(rad_value: float, channel: "JointChannel") -> int:
    """弧度 → 原始编码器 tick（用于 Goal_Position, normalize=False）。"""
    adjusted = (rad_value - channel.zero_offset_rad) * channel.direction
    return int(round(STS3215_CENTER_TICK + adjusted * TICKS_PER_RAD))


def clamp_raw(raw_value: int, lower: int, upper: int) -> int:
    """把 raw 值夹到 [lower, upper]（软限位，用校准得到的 range_min/max）。"""
    return max(lower, min(upper, raw_value))


# ── 兼容旧 API（过渡期保留）────────────────────────

def norm_to_rad(norm_value: float, channel: "JointChannel") -> float:
    """【过渡期】lerobot 归一化值 → 弧度（简化线性映射）。

    新代码应使用 raw_to_rad。本函数仅供 gripper 这类没有物理角度语义的通道，
    或向后兼容。
    """
    return (norm_value * channel.norm_to_rad_scale + channel.norm_to_rad_bias) * channel.direction


def rad_to_norm(rad_value: float, channel: "JointChannel") -> float:
    """【过渡期】弧度 → lerobot 归一化值。新代码应使用 rad_to_raw。"""
    adjusted = rad_value * channel.direction
    return (adjusted - channel.norm_to_rad_bias) / channel.norm_to_rad_scale


# ── 底盘运动学 ────────────────────────────────────────

# 电机在极坐标中的角度（CCW from +X body axis）
# 实验证据：前进基 (0, +1, -1) 对应 -sin(θ_i) 列 → θ_front=0, θ_left=240°, θ_right=120°
_WHEEL_ANGLES_RAD = np.array([
    0.0,                     # front → 0°
    math.radians(240.0),     # left → 240°
    math.radians(120.0),     # right → 120°
])


def build_kinematic_matrix(base_radius_m: float) -> np.ndarray:
    """
    构建逆运动学矩阵 K（不含 1/r 缩放）：

        [v1, v2, v3]^T = K @ [vx, vy, ω]^T

    其中 v_i 是第 i 个轮子的线速度（m/s），
    K[i] = [-sin(θ_i), cos(θ_i), L]。

    返回 shape (3, 3) 的 numpy 矩阵，行顺序是 (front, left, right)。
    """
    K = np.empty((3, 3), dtype=np.float64)
    K[:, 0] = -np.sin(_WHEEL_ANGLES_RAD)  # vx 列
    K[:, 1] = np.cos(_WHEEL_ANGLES_RAD)   # vy 列
    K[:, 2] = base_radius_m               # ω 列
    return K


def body_velocity_to_wheel_rad_per_sec(
    body_velocity: np.ndarray,   # shape (3,): [vx_m/s, vy_m/s, wz_rad/s]
    base_config: "OmniBaseConfig",
    K: np.ndarray | None = None,
) -> np.ndarray:
    """
    反解：body velocity → 三个轮子的角速度（rad/s）。

    返回 shape (3,) 数组，顺序 (front, left, right)。
    """
    if K is None:
        K = build_kinematic_matrix(base_config.base_radius_m)
    wheel_linear = K @ body_velocity      # m/s（轮子接地点线速度）
    return wheel_linear / base_config.wheel_radius_m


def wheel_rad_per_sec_to_body_velocity(
    wheel_velocity: np.ndarray,  # shape (3,): [front, left, right] rad/s
    base_config: "OmniBaseConfig",
    K_pinv: np.ndarray | None = None,
) -> np.ndarray:
    """
    正解：三个轮子角速度 → body velocity。

    用 Moore-Penrose 伪逆（K 是方阵时退化为真正的逆），
    三轮全向系统通常是 3x3 可逆。
    """
    if K_pinv is None:
        K = build_kinematic_matrix(base_config.base_radius_m)
        K_pinv = np.linalg.inv(K)
    wheel_linear = wheel_velocity * base_config.wheel_radius_m  # rad/s → m/s
    return K_pinv @ wheel_linear


# ── Feetech 速度原始值 ←→ rad/s ────────────────────

def rad_per_sec_to_raw_velocity(rad_per_sec: float, base_config: "OmniBaseConfig") -> int:
    """
    轮子角速度 → Goal_Velocity 的有符号整数。

    lerobot 内部会对 Goal_Velocity 做 sign-magnitude 编码（bit 15 符号位），
    直接传有符号 int 即可，幅度会被限制在 [-raw_at_max_speed, +raw_at_max_speed]。
    """
    ratio = rad_per_sec / base_config.max_wheel_rad_per_sec
    raw = int(round(ratio * base_config.raw_at_max_speed))
    max_raw = base_config.raw_at_max_speed
    return max(-max_raw, min(max_raw, raw))


def raw_velocity_to_rad_per_sec(raw: int, base_config: "OmniBaseConfig") -> float:
    """Present_Velocity 的有符号整数 → 轮子角速度 (rad/s)。"""
    return (raw / base_config.raw_at_max_speed) * base_config.max_wheel_rad_per_sec


# ── body velocity 饱和保护 ─────────────────────────

def saturate_wheel_velocities(
    wheel_rad_per_sec: np.ndarray,
    max_wheel_rad_per_sec: float,
) -> tuple[np.ndarray, float]:
    """
    整体等比缩放：如果任一轮子超过最大速度，三轮同比缩小以保持方向。

    返回 (缩放后的 wheel_rad_per_sec, 缩放系数 ∈ (0, 1])
    """
    peak = float(np.max(np.abs(wheel_rad_per_sec)))
    if peak <= max_wheel_rad_per_sec or peak == 0.0:
        return wheel_rad_per_sec, 1.0
    scale = max_wheel_rad_per_sec / peak
    return wheel_rad_per_sec * scale, scale
