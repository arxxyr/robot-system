"""进程级 FeetechBus 单例。

两个 bus2 adapter（右臂 + 底盘）物理上共享 /dev/ttyACM1。两个 adapter 连接时
都调 `acquire(bus_config)`，内部按 BusConfig 构建完整电机字典，
首次 acquire 创建 FeetechBus，之后的 acquire 只做校验（电机列表必须一致）。

FeetechBus 自己就有 RLock（我们实现里内置的），所以 SharedBusHandle 直接
复用它作为 lock 属性。sync_read/write 不需要外层再加锁。

使用方式：

    handle = SharedBusRegistry.acquire(bus2_config)
    handle.bus.sync_read("Present_Position", ["right_arm_shoulder_pan"])
    # 用完：
    SharedBusRegistry.release("/dev/ttyACM1")
"""

from __future__ import annotations

import logging
import threading
import time
from dataclasses import dataclass, field
from typing import TYPE_CHECKING

from xlerobot_dimos.common.feetech_io import FeetechBus, Motor

if TYPE_CHECKING:
    from xlerobot_dimos.common.config import BusConfig

logger = logging.getLogger(__name__)

# 握手重试参数
CONNECT_MAX_ATTEMPTS = 3
CONNECT_RETRY_DELAY_S = 0.4


@dataclass
class SharedBusHandle:
    """持有 FeetechBus 实例和保护锁。"""

    bus: FeetechBus
    port: str
    motor_names: list[str] = field(default_factory=list)
    _ref_count: int = 0

    @property
    def lock(self) -> threading.RLock:
        """暴露底层 FeetechBus 的 RLock，兼容旧接口。"""
        return self.bus.lock

    def is_connected(self) -> bool:
        return self.bus.is_connected


def _build_motor_dict(bus_config: "BusConfig") -> dict[str, Motor]:
    """从 BusConfig 构建 {name: Motor(id=...)} 字典。"""
    motors: dict[str, Motor] = {}

    for joint in bus_config.arm_joints:
        motors[joint.motor_name] = Motor(id=joint.motor_id)

    if bus_config.gripper is not None:
        motors[bus_config.gripper.motor_name] = Motor(id=bus_config.gripper.motor_id)

    for joint in bus_config.head_joints:
        motors[joint.motor_name] = Motor(id=joint.motor_id)

    if bus_config.base is not None:
        base = bus_config.base
        motors[base.front.motor_name] = Motor(id=base.front.motor_id)
        motors[base.left.motor_name] = Motor(id=base.left.motor_id)
        motors[base.right.motor_name] = Motor(id=base.right.motor_id)

    return motors


class SharedBusRegistry:
    """按 port 去重的单例注册表。线程安全。"""

    _instances: dict[str, SharedBusHandle] = {}
    _registry_lock = threading.Lock()

    @classmethod
    def acquire(cls, bus_config: "BusConfig") -> SharedBusHandle:
        """获取或创建 handle。

        每次调用都传完整的 BusConfig。两次 acquire 同一个 port 必须给出
        一致的电机列表，否则抛错。
        """
        port = bus_config.port
        motors = _build_motor_dict(bus_config)
        expected_names = sorted(motors)

        with cls._registry_lock:
            handle = cls._instances.get(port)
            if handle is None:
                logger.info(
                    "创建 FeetechBus: port=%s motors=%s", port, expected_names
                )
                bus = FeetechBus(port=port, motors=motors)
                handle = SharedBusHandle(
                    bus=bus,
                    port=port,
                    motor_names=expected_names,
                )
                cls._instances[port] = handle
            else:
                if sorted(handle.motor_names) != expected_names:
                    raise RuntimeError(
                        f"SharedBus port={port} 电机列表冲突:\n"
                        f"  已有: {sorted(handle.motor_names)}\n"
                        f"  新传: {expected_names}"
                    )

            handle._ref_count += 1
            return handle

    @classmethod
    def release(cls, port: str) -> None:
        """引用计数 -1，归零时断开串口。"""
        with cls._registry_lock:
            handle = cls._instances.get(port)
            if handle is None:
                return
            handle._ref_count -= 1
            if handle._ref_count <= 0:
                logger.info("断开 FeetechBus: port=%s", port)
                try:
                    if handle.is_connected():
                        handle.bus.disconnect()
                except Exception:
                    logger.exception("断开 %s 失败", port)
                del cls._instances[port]

    @classmethod
    def peek(cls, port: str) -> SharedBusHandle | None:
        """只读访问（不递增 ref_count）。"""
        with cls._registry_lock:
            return cls._instances.get(port)


def connect_handle_with_retry(
    handle: SharedBusHandle,
    max_attempts: int = CONNECT_MAX_ATTEMPTS,
    delay_s: float = CONNECT_RETRY_DELAY_S,
) -> None:
    """连接 handle.bus，失败时自动重试。幂等：已连接则直接返回。

    FeetechBus 的握手偶发失败（sync_read 包错位），重试通常能解决。
    """
    if handle.is_connected():
        return

    last_exc: BaseException | None = None
    for attempt in range(1, max_attempts + 1):
        try:
            handle.bus.connect()
            if attempt > 1:
                logger.info("%s: 第 %d 次尝试连接成功", handle.port, attempt)
            return
        except Exception as exc:
            last_exc = exc
            logger.warning(
                "%s: bus.connect() 尝试 %d/%d 失败: %s",
                handle.port,
                attempt,
                max_attempts,
                exc,
            )
            try:
                if handle.is_connected():
                    handle.bus.disconnect()
            except Exception:
                pass
            if attempt < max_attempts:
                time.sleep(delay_s)

    assert last_exc is not None
    raise last_exc
