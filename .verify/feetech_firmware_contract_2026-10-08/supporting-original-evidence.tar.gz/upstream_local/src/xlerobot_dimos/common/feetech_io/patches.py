"""对 scservo_sdk 的 monkey-patch。

抄自 lerobot v0.5.1 feetech.py 的 patch_setPacketTimeout。
修复 scservo_sdk 官方 timeout 计算 bug：
    https://gitee.com/ftservo/SCServoSDK/issues/IBY2S6

Feetech 官方 repo 已经修了这个 bug，但 PyPI 上的 scservo-sdk
是一个未官方版本，所以需要 patch。

不打这个 patch 的症状：所有 write 操作的 timeout 计算过短，
偶发 "There is no status packet" 错误。
"""

from __future__ import annotations

from typing import Any


def _patched_setPacketTimeout(self: Any, packet_length: int) -> None:  # noqa: N802
    """修正后的 setPacketTimeout 实现。"""
    self.packet_start_time = self.getCurrentTime()
    self.packet_timeout = (
        (self.tx_time_per_byte * packet_length)
        + (self.tx_time_per_byte * 3.0)
        + 50
    )


def apply_port_handler_patch(port_handler: Any) -> None:
    """把 _patched_setPacketTimeout 绑到一个 PortHandler 实例上。"""
    import scservo_sdk as scs

    port_handler.setPacketTimeout = _patched_setPacketTimeout.__get__(
        port_handler, scs.PortHandler
    )
