"""电机和校准的数据类。

对应 lerobot 的 Motor / MotorCalibration / MotorNormMode。
我们只用 STS3215，不需要 model 字段（默认就是 sts3215）。
"""

from __future__ import annotations

from dataclasses import dataclass


@dataclass(slots=True, frozen=True)
class Motor:
    """电机总线上的一个节点。"""

    id: int  # 1-254, 0 和 255 保留
    # 我们只用 STS3215，不存 model 字段
    # 归一化模式也不在这里存（我们自己做 raw 转换）

    def __post_init__(self) -> None:
        if not (1 <= self.id <= 253):
            raise ValueError(f"Motor id 必须在 [1, 253]，收到 {self.id}")


@dataclass(slots=True)
class MotorCalibration:
    """单个电机的校准数据。

    - homing_offset: 写入 Homing_Offset 寄存器（12-bit sign-magnitude）
    - range_min / range_max: 写入 Min_Position_Limit / Max_Position_Limit
    - drive_mode: 0 或 1，用于反转方向（Feetech 原生支持）
    """

    id: int
    drive_mode: int = 0
    homing_offset: int = 0
    range_min: int = 0
    range_max: int = 4095

    def __post_init__(self) -> None:
        if abs(self.homing_offset) > 2047:
            raise ValueError(
                f"homing_offset {self.homing_offset} 超出 STS3215 sign-magnitude 11-bit 范围 [-2047, +2047]"
            )
        if not (0 <= self.range_min <= 4095):
            raise ValueError(f"range_min {self.range_min} 超出 [0, 4095]")
        if not (0 <= self.range_max <= 4095):
            raise ValueError(f"range_max {self.range_max} 超出 [0, 4095]")
