"""FeetechBus —— 自研的 STS3215 串口总线。

替代 lerobot.motors.feetech.FeetechMotorsBus。

核心方法：
    connect()                                      # 打开串口 + 握手
    disconnect()
    is_connected 属性
    ping(motor_id) -> model_number | None
    read(reg_name, motor_name) -> int              # 单电机读（带 ACK）
    write(reg_name, motor_name, value)             # 单电机写（带 ACK）
    sync_read(reg_name, motor_names) -> dict       # 批量读
    sync_write(reg_name, {name: value})            # 批量写

所有有符号寄存器的 encode/decode 由本模块内部处理，调用者传入/拿到的
都是带符号 int。

线程安全：每个 FeetechBus 实例内部有一个 RLock，所有方法自动加锁。
"""

from __future__ import annotations

import logging
import threading
import time
from typing import TYPE_CHECKING, Any

from xlerobot_dimos.common.feetech_io.encoding import (
    combine_bytes_le,
    decode_sign_magnitude,
    encode_sign_magnitude,
    split_bytes_le,
)
from xlerobot_dimos.common.feetech_io.patches import apply_port_handler_patch
from xlerobot_dimos.common.feetech_io.registers import (
    DEFAULT_BAUDRATE,
    DEFAULT_PROTOCOL,
    DEFAULT_TIMEOUT_MS,
    MODEL_NUMBER_STS3215,
    STS3215_SIGN_BIT,
    get_register,
)
from xlerobot_dimos.common.feetech_io.types import Motor

if TYPE_CHECKING:
    pass

logger = logging.getLogger(__name__)


WRITE_NUM_RETRY = 2         # 单次 write 的 packet 重试次数（含首次）
SYNC_READ_NUM_RETRY = 2


class FeetechBus:
    """一条 Feetech 串口总线。"""

    def __init__(self, port: str, motors: dict[str, Motor]) -> None:
        """
        Args:
            port: 串口设备路径，例如 /dev/ttyACM0
            motors: {motor_name: Motor(id=...)}
        """
        self.port = port
        self.motors: dict[str, Motor] = dict(motors)
        # name ↔ id 双向索引
        self._name_by_id: dict[int, str] = {m.id: name for name, m in motors.items()}
        if len(self._name_by_id) != len(motors):
            raise ValueError(f"motor id 冲突: {list(motors.values())}")

        self._lock = threading.RLock()
        self._connected = False

        # scservo_sdk 对象，connect 时创建
        self._port_handler: Any = None
        self._packet_handler: Any = None
        # 复用同一个 GroupSyncRead/Write 实例（每次 clearParam 重置）
        self._sync_read_cache: dict[tuple[int, int], Any] = {}
        self._sync_write_cache: dict[tuple[int, int], Any] = {}

    # ── 属性 ──────────────────────────────────────

    @property
    def is_connected(self) -> bool:
        return self._connected

    @property
    def lock(self) -> threading.RLock:
        """外部访问 sync 操作时可以直接用这个锁（兼容 SharedBusRegistry 的模式）。"""
        return self._lock

    # ── 生命周期 ──────────────────────────────────

    def connect(self, handshake: bool = True) -> None:
        """打开串口。握手阶段会 ping 每个 motor 并校验 model=777。"""
        import scservo_sdk as scs

        with self._lock:
            if self._connected:
                return

            self._port_handler = scs.PortHandler(self.port)
            apply_port_handler_patch(self._port_handler)

            if not self._port_handler.openPort():
                raise ConnectionError(f"Failed to open port {self.port}")

            self._port_handler.setBaudRate(DEFAULT_BAUDRATE)
            self._packet_handler = scs.PacketHandler(DEFAULT_PROTOCOL)
            self._port_handler.setPacketTimeoutMillis(DEFAULT_TIMEOUT_MS)

            if handshake:
                try:
                    self._handshake()
                except Exception:
                    self._port_handler.closePort()
                    self._port_handler = None
                    self._packet_handler = None
                    raise

            self._connected = True
            logger.info("FeetechBus connected: %s (%d motors)", self.port, len(self.motors))

    def disconnect(self) -> None:
        with self._lock:
            if not self._connected:
                return
            try:
                if self._port_handler is not None:
                    self._port_handler.closePort()
            except Exception:
                logger.exception("closePort failed")
            self._port_handler = None
            self._packet_handler = None
            self._sync_read_cache.clear()
            self._sync_write_cache.clear()
            self._connected = False
            logger.info("FeetechBus disconnected: %s", self.port)

    def _handshake(self) -> None:
        """ping 每个 motor，校验 model=777。"""
        missing: list[tuple[str, int]] = []
        wrong: list[tuple[str, int, int]] = []

        for name, motor in self.motors.items():
            model = self.ping(motor.id)
            if model is None:
                missing.append((name, motor.id))
            elif model != MODEL_NUMBER_STS3215:
                wrong.append((name, motor.id, model))

        if missing or wrong:
            lines = [f"FeetechBus handshake 失败 on {self.port}:"]
            if missing:
                lines.append("  缺失/无响应的电机:")
                for name, mid in missing:
                    lines.append(f"    - {name} (id={mid})")
            if wrong:
                lines.append("  model 不匹配的电机（期望 777）:")
                for name, mid, model in wrong:
                    lines.append(f"    - {name} (id={mid}) → {model}")
            raise RuntimeError("\n".join(lines))

    # ── 底层 ──────────────────────────────────────

    def _ensure_connected(self) -> None:
        if self._port_handler is None or not self._port_handler.is_open:
            raise ConnectionError(f"FeetechBus {self.port} not connected")

    def _id(self, motor_name: str) -> int:
        try:
            return self.motors[motor_name].id
        except KeyError as exc:
            raise KeyError(f"未知 motor: {motor_name}") from exc

    def _name(self, motor_id: int) -> str:
        return self._name_by_id[motor_id]

    def _encode(self, reg_name: str, value: int) -> int:
        """如果寄存器需要 sign-magnitude，编码后返回无符号值。"""
        sign_bit = STS3215_SIGN_BIT.get(reg_name)
        if sign_bit is None:
            return value
        return encode_sign_magnitude(value, sign_bit)

    def _decode(self, reg_name: str, raw: int) -> int:
        sign_bit = STS3215_SIGN_BIT.get(reg_name)
        if sign_bit is None:
            return raw
        return decode_sign_magnitude(raw, sign_bit)

    # ── ping ──────────────────────────────────────

    def ping(self, motor_id: int, num_retry: int = 1) -> int | None:
        """ping 一个 motor，返回 model_number，失败返回 None。"""
        import scservo_sdk as scs

        with self._lock:
            self._ensure_connected()
            for _ in range(1 + num_retry):
                model, comm, _err = self._packet_handler.ping(
                    self._port_handler, motor_id
                )
                if comm == scs.COMM_SUCCESS:
                    return int(model)
            return None

    # ── 单电机 read / write（带 ACK，可靠但慢）─────

    def read(self, reg_name: str, motor_name: str, num_retry: int = 1) -> int:
        """读单个电机的某个寄存器。"""
        import scservo_sdk as scs

        addr, length = get_register(reg_name)
        motor_id = self._id(motor_name)

        with self._lock:
            self._ensure_connected()
            raw = 0
            last_comm = scs.COMM_TX_FAIL
            for _ in range(1 + num_retry):
                if length == 1:
                    raw, comm, err = self._packet_handler.read1ByteTxRx(
                        self._port_handler, motor_id, addr
                    )
                elif length == 2:
                    raw, comm, err = self._packet_handler.read2ByteTxRx(
                        self._port_handler, motor_id, addr
                    )
                elif length == 4:
                    raw, comm, err = self._packet_handler.read4ByteTxRx(
                        self._port_handler, motor_id, addr
                    )
                else:
                    raise NotImplementedError(f"不支持 length={length}")
                last_comm = comm
                if comm == scs.COMM_SUCCESS:
                    if err != 0:
                        raise RuntimeError(
                            f"read {reg_name} on {motor_name}: "
                            + self._packet_handler.getRxPacketError(err)
                        )
                    return self._decode(reg_name, int(raw))

            raise ConnectionError(
                f"read {reg_name} on {motor_name} (id={motor_id}) 失败: "
                + self._packet_handler.getTxRxResult(last_comm)
            )

    def write(
        self,
        reg_name: str,
        motor_name: str,
        value: int,
        num_retry: int = WRITE_NUM_RETRY,
    ) -> None:
        """写单个电机的某个寄存器（等待 ACK）。"""
        import scservo_sdk as scs

        addr, length = get_register(reg_name)
        motor_id = self._id(motor_name)
        encoded = self._encode(reg_name, int(value))
        data = split_bytes_le(encoded, length)

        with self._lock:
            self._ensure_connected()
            last_comm = scs.COMM_TX_FAIL
            last_err = 0
            for _ in range(1 + num_retry):
                comm, err = self._packet_handler.writeTxRx(
                    self._port_handler, motor_id, addr, length, bytearray(data)
                )
                last_comm = comm
                last_err = err
                if comm == scs.COMM_SUCCESS:
                    if err != 0:
                        raise RuntimeError(
                            f"write {reg_name}={value} on {motor_name}: "
                            + self._packet_handler.getRxPacketError(err)
                        )
                    return

            raise ConnectionError(
                f"write {reg_name}={value} on {motor_name} (id={motor_id}) "
                f"after {num_retry + 1} tries: "
                + self._packet_handler.getTxRxResult(last_comm)
            )

    # ── 批量 sync_read / sync_write ─────────────────

    def _get_sync_reader(self, addr: int, length: int) -> Any:
        """GroupSyncRead 实例缓存。每个 (addr,length) 对用一个实例。"""
        import scservo_sdk as scs

        key = (addr, length)
        reader = self._sync_read_cache.get(key)
        if reader is None:
            reader = scs.GroupSyncRead(
                self._port_handler, self._packet_handler, addr, length
            )
            self._sync_read_cache[key] = reader
        return reader

    def _get_sync_writer(self, addr: int, length: int) -> Any:
        import scservo_sdk as scs

        key = (addr, length)
        writer = self._sync_write_cache.get(key)
        if writer is None:
            writer = scs.GroupSyncWrite(
                self._port_handler, self._packet_handler, addr, length
            )
            self._sync_write_cache[key] = writer
        return writer

    def sync_read(
        self,
        reg_name: str,
        motor_names: list[str],
        num_retry: int = SYNC_READ_NUM_RETRY,
    ) -> dict[str, int]:
        """批量读同一寄存器。返回 {motor_name: value}。"""
        import scservo_sdk as scs

        addr, length = get_register(reg_name)
        ids = [self._id(n) for n in motor_names]

        with self._lock:
            self._ensure_connected()
            reader = self._get_sync_reader(addr, length)
            reader.clearParam()
            for id_ in ids:
                reader.addParam(id_)

            last_comm = scs.COMM_TX_FAIL
            for _ in range(1 + num_retry):
                comm = reader.txRxPacket()
                last_comm = comm
                if comm == scs.COMM_SUCCESS:
                    break

            if last_comm != scs.COMM_SUCCESS:
                raise ConnectionError(
                    f"sync_read {reg_name} on {motor_names} 失败: "
                    + self._packet_handler.getTxRxResult(last_comm)
                )

            result: dict[str, int] = {}
            for name, id_ in zip(motor_names, ids, strict=True):
                raw = reader.getData(id_, addr, length)
                result[name] = self._decode(reg_name, int(raw))
            return result

    def sync_write(self, reg_name: str, values: dict[str, int]) -> None:
        """批量写同一寄存器。**不等 ACK**，高频命令用。

        critical 操作（Torque_Enable, Operating_Mode, 写校准）应该用 `write`
        而不是 `sync_write`，避免丢包无感知。
        """
        import scservo_sdk as scs

        addr, length = get_register(reg_name)

        with self._lock:
            self._ensure_connected()
            writer = self._get_sync_writer(addr, length)
            writer.clearParam()

            for motor_name, value in values.items():
                motor_id = self._id(motor_name)
                encoded = self._encode(reg_name, int(value))
                data = split_bytes_le(encoded, length)
                writer.addParam(motor_id, bytearray(data))

            comm = writer.txPacket()
            if comm != scs.COMM_SUCCESS:
                raise ConnectionError(
                    f"sync_write {reg_name} 失败: "
                    + self._packet_handler.getTxRxResult(comm)
                )

    # ── 工具 ──────────────────────────────────────

    def all_motor_names(self) -> list[str]:
        return list(self.motors.keys())
