"""sign-magnitude 编码 + 字节序打包。

Feetech STS 系列用的是 sign-magnitude 编码（不是二补码）：
    https://en.wikipedia.org/wiki/Signed_number_representations#Sign%E2%80%93magnitude

字节序是 little-endian。
"""

from __future__ import annotations


def encode_sign_magnitude(value: int, sign_bit_index: int) -> int:
    """把带符号整数编码成 Feetech 的 sign-magnitude 无符号整数。

    Args:
        value: 带符号整数
        sign_bit_index: 符号位的位置
            - 例: Homing_Offset 用 bit 11（→ magnitude 上限 2047）
            - 例: Goal_Velocity 用 bit 15（→ magnitude 上限 32767）

    Returns:
        无符号整数，可以直接写到寄存器字节。

    Raises:
        ValueError: magnitude 超出 sign_bit 限制
    """
    max_magnitude = (1 << sign_bit_index) - 1
    magnitude = abs(value)
    if magnitude > max_magnitude:
        raise ValueError(
            f"Magnitude {magnitude} exceeds {max_magnitude} "
            f"(max for sign_bit_index={sign_bit_index})"
        )
    direction_bit = 1 if value < 0 else 0
    return (direction_bit << sign_bit_index) | magnitude


def decode_sign_magnitude(encoded: int, sign_bit_index: int) -> int:
    """sign-magnitude 反向解码。"""
    direction_bit = (encoded >> sign_bit_index) & 1
    magnitude_mask = (1 << sign_bit_index) - 1
    magnitude = encoded & magnitude_mask
    return -magnitude if direction_bit else magnitude


# ── 字节序 ─────────────────────────────────────────

def split_bytes_le(value: int, length: int) -> list[int]:
    """把无符号整数拆成 little-endian 字节列表。

    value 必须 >= 0。对于有符号寄存器应先用 `encode_sign_magnitude` 编码。
    """
    if value < 0:
        raise ValueError(f"split_bytes_le 不接受负数: {value}. 先用 encode_sign_magnitude")
    if length == 1:
        if value > 0xFF:
            raise ValueError(f"value {value} exceeds 1 byte")
        return [value & 0xFF]
    if length == 2:
        if value > 0xFFFF:
            raise ValueError(f"value {value} exceeds 2 bytes")
        return [value & 0xFF, (value >> 8) & 0xFF]
    if length == 4:
        if value > 0xFFFFFFFF:
            raise ValueError(f"value {value} exceeds 4 bytes")
        return [
            value & 0xFF,
            (value >> 8) & 0xFF,
            (value >> 16) & 0xFF,
            (value >> 24) & 0xFF,
        ]
    raise NotImplementedError(f"不支持的字节长度: {length}")


def combine_bytes_le(data: list[int] | bytes, length: int) -> int:
    """把 little-endian 字节列表/串组合成无符号整数。"""
    if len(data) != length:
        raise ValueError(f"期望 {length} 字节，收到 {len(data)}")
    result = 0
    for i, byte in enumerate(data):
        result |= (byte & 0xFF) << (i * 8)
    return result
