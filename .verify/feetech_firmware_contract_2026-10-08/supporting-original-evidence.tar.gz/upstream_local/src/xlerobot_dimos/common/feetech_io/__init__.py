"""Feetech STS3215 裸协议 I/O。

替代 lerobot.motors.feetech 的自研实现。直接包装 scservo_sdk，
不依赖 lerobot。只支持 STS3215 一种电机（我们只用这一种）。

使用方式：

    from xlerobot_dimos.common.feetech_io import FeetechBus, Motor

    bus = FeetechBus(
        port="/dev/ttyACM1",
        motors={
            "right_arm_shoulder_pan": Motor(id=1),
            ...
        },
    )
    bus.connect()  # 打开串口 + 握手
    positions = bus.sync_read("Present_Position", ["right_arm_shoulder_pan"])
    bus.sync_write("Goal_Position", {"right_arm_shoulder_pan": 2100})
    bus.disconnect()
"""

from xlerobot_dimos.common.feetech_io.bus import FeetechBus
from xlerobot_dimos.common.feetech_io.calibration import (
    record_ranges_of_motion,
    reset_calibration,
    set_half_turn_homings,
    write_calibration,
)
from xlerobot_dimos.common.feetech_io.encoding import (
    decode_sign_magnitude,
    encode_sign_magnitude,
)
from xlerobot_dimos.common.feetech_io.registers import (
    MODEL_NUMBER_STS3215,
    STS3215_CONTROL_TABLE,
    STS3215_MAX_POSITION,
    STS3215_RESOLUTION,
    STS3215_SIGN_BIT,
    OperatingMode,
    TorqueMode,
)
from xlerobot_dimos.common.feetech_io.types import Motor, MotorCalibration

__all__ = [
    # Bus
    "FeetechBus",
    # Calibration
    "reset_calibration",
    "set_half_turn_homings",
    "record_ranges_of_motion",
    "write_calibration",
    # Encoding
    "decode_sign_magnitude",
    "encode_sign_magnitude",
    # Registers
    "MODEL_NUMBER_STS3215",
    "OperatingMode",
    "STS3215_CONTROL_TABLE",
    "STS3215_MAX_POSITION",
    "STS3215_RESOLUTION",
    "STS3215_SIGN_BIT",
    "TorqueMode",
    # Types
    "Motor",
    "MotorCalibration",
]
