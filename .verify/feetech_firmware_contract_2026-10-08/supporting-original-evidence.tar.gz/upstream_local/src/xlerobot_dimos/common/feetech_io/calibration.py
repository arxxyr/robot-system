"""校准流程：write_calibration / reset / set_half_turn_homings / record_ranges_of_motion。

**关键：EEPROM 写保护**
Homing_Offset / Min_Position_Limit / Max_Position_Limit 都在 EEPROM 区，
写之前必须先把 Torque_Enable 清零 **并且** 把 Lock 清零（Lock=1 会阻塞 EEPROM 写）。
写完后可以重新 Lock=1 + Torque_Enable=1 恢复运行状态。

lerobot 把 Lock=0 / Lock=1 隐式绑在 disable_torque / enable_torque 里；
我们在这里显式做，避免忘记。
"""

from __future__ import annotations

import logging
import time
from typing import TYPE_CHECKING

from xlerobot_dimos.common.feetech_io.registers import (
    STS3215_MAX_POSITION,
    STS3215_RESOLUTION,
    TorqueMode,
)
from xlerobot_dimos.common.feetech_io.types import MotorCalibration

if TYPE_CHECKING:
    from xlerobot_dimos.common.feetech_io.bus import FeetechBus

logger = logging.getLogger(__name__)


# ── 底层：EEPROM 解锁/上锁 ────────────────────────

def _unlock_eeprom(bus: "FeetechBus", motor_names: list[str]) -> None:
    """对每个电机: Torque_Enable=0, Lock=0。写入 EEPROM 区前必须先做这个。"""
    for name in motor_names:
        bus.write("Torque_Enable", name, TorqueMode.DISABLED.value)
        bus.write("Lock", name, 0)


def _lock_eeprom(bus: "FeetechBus", motor_names: list[str]) -> None:
    """对每个电机: Lock=1（不动 Torque_Enable，让上层决定是否上电）。"""
    for name in motor_names:
        bus.write("Lock", name, 1)


# ── reset_calibration ─────────────────────────────

def reset_calibration(bus: "FeetechBus", motor_names: list[str]) -> None:
    """把 Homing_Offset 清零，Min/Max 设回全范围。

    调用方必须已经持有 bus.lock。内部会自动 unlock EEPROM，
    做完后重新 lock EEPROM。
    """
    _unlock_eeprom(bus, motor_names)
    try:
        for name in motor_names:
            bus.write("Homing_Offset", name, 0)
            bus.write("Min_Position_Limit", name, 0)
            bus.write("Max_Position_Limit", name, STS3215_RESOLUTION - 1)
    finally:
        _lock_eeprom(bus, motor_names)


# ── write_calibration ─────────────────────────────

def write_calibration(
    bus: "FeetechBus",
    calibration_dict: dict[str, MotorCalibration],
) -> None:
    """把 calibration_dict 里的 homing_offset / range_min / range_max 写到电机 EEPROM。

    调用方应该已经持有 bus.lock（这是典型用法，因为通常在 connect 流程里调用）。
    """
    motor_names = list(calibration_dict.keys())
    _unlock_eeprom(bus, motor_names)
    try:
        for name, cal in calibration_dict.items():
            bus.write("Homing_Offset", name, int(cal.homing_offset))
            bus.write("Min_Position_Limit", name, int(cal.range_min))
            bus.write("Max_Position_Limit", name, int(cal.range_max))
        logger.info("write_calibration: 写入 %d 个电机的校准到 EEPROM", len(motor_names))
    finally:
        _lock_eeprom(bus, motor_names)


# ── set_half_turn_homings ─────────────────────────

def set_half_turn_homings(
    bus: "FeetechBus",
    motor_names: list[str],
) -> dict[str, int]:
    """半转标零：让每个电机当前的物理位置对应到 Present_Position=2047。

    算法（来自 lerobot）:
        Present_Position = Actual_Position - Homing_Offset
        想让 Present 读到 2047，所以 Homing_Offset = Actual - 2047

    步骤:
        1. reset_calibration（先把旧 Homing_Offset=0，range 全开）
        2. sync_read Present_Position → 此时 Present = Actual
        3. 算 offset = current - 2047
        4. 把 offset 写到 Homing_Offset

    返回 {motor_name: offset}

    **注意**：调用方要确保电机处于"用户想要的半转中点"物理位置
    （通常断扭矩手动摆到中间）。
    """
    reset_calibration(bus, motor_names)

    # 读取（此时 Present = Actual）
    positions = bus.sync_read("Present_Position", motor_names)

    offsets: dict[str, int] = {}
    half = STS3215_MAX_POSITION  # 2047
    for name, pos in positions.items():
        offsets[name] = int(pos) - half

    # 写入 Homing_Offset（需要 EEPROM 解锁）
    _unlock_eeprom(bus, motor_names)
    try:
        for name, offset in offsets.items():
            bus.write("Homing_Offset", name, offset)
    finally:
        _lock_eeprom(bus, motor_names)

    return offsets


# ── record_ranges_of_motion ───────────────────────

def record_ranges_of_motion(
    bus: "FeetechBus",
    motor_names: list[str],
    display_values: bool = True,
    sample_interval_s: float = 0.02,
) -> tuple[dict[str, int], dict[str, int]]:
    """交互式记录运动范围。调用前应该已经 disable_torque（用户手动掰关节）。

    操作：
        - 循环 sync_read Present_Position
        - 持续更新 min/max
        - 实时打印（可选）
        - **按 Enter 结束**

    返回: (mins, maxes) 两个 {motor_name: value} 字典
    """
    from xlerobot_dimos.common.feetech_io._ranges_input import enter_pressed, move_cursor_up

    start = bus.sync_read("Present_Position", motor_names)
    mins: dict[str, int] = dict(start)
    maxes: dict[str, int] = dict(start)

    first_draw = True
    try:
        while not enter_pressed():
            positions = bus.sync_read("Present_Position", motor_names)
            for name, pos in positions.items():
                if pos < mins[name]:
                    mins[name] = pos
                if pos > maxes[name]:
                    maxes[name] = pos

            if display_values:
                if not first_draw:
                    move_cursor_up(len(motor_names) + 3)
                first_draw = False

                print("\n-------------------------------------------")
                print(f"{'NAME':<25} | {'MIN':>6} | {'POS':>6} | {'MAX':>6}")
                for name in motor_names:
                    print(
                        f"{name:<25} | {mins[name]:>6} | "
                        f"{positions[name]:>6} | {maxes[name]:>6}"
                    )

            time.sleep(sample_interval_s)
    except KeyboardInterrupt:
        logger.info("record_ranges_of_motion 被用户中断")

    # 检查是否所有电机都动了
    stuck = [n for n in motor_names if mins[n] == maxes[n]]
    if stuck:
        logger.warning("以下电机在录制期间没有移动过: %s", stuck)

    return mins, maxes
