"""STS3215 寄存器控制表 + 常量。

来源：lerobot v0.5.1 的 STS_SMS_SERIES_CONTROL_TABLE + STS_SMS_SERIES_ENCODINGS_TABLE
Feetech 官方手册：http://doc.feetech.cn/#/prodinfodownload?srcType=FT-SMS-STS-emanual
"""

from __future__ import annotations

from enum import IntEnum


# ── STS3215 基础参数 ────────────────────────────────

MODEL_NUMBER_STS3215 = 777
STS3215_RESOLUTION = 4096        # 一圈 tick 数（12-bit 编码器）
STS3215_MAX_POSITION = 2047      # 半转中点（(4096-1)//2）
DEFAULT_BAUDRATE = 1_000_000
DEFAULT_PROTOCOL = 0
DEFAULT_TIMEOUT_MS = 1000


# ── 控制表 ──────────────────────────────────────────
#
# 每项: "name": (address, size_bytes)
# 只列我们用到的寄存器。完整表见 lerobot 源码 feetech/tables.py
#
# 分区:
#   EEPROM (永久存储，Lock=1 时写保护)：addr 0-39
#   SRAM   (RAM，不受 Lock 影响)：       addr 40-69
#   只读                                :Present_*, Model_Number

STS3215_CONTROL_TABLE: dict[str, tuple[int, int]] = {
    # EEPROM (需要 Lock=0 才能写入)
    "Model_Number":        (3,  2),   # read-only
    "ID":                  (5,  1),
    "Baud_Rate":           (6,  1),
    "Min_Position_Limit":  (9,  2),   # 软下限
    "Max_Position_Limit":  (11, 2),   # 软上限
    "P_Coefficient":       (21, 1),
    "D_Coefficient":       (22, 1),
    "I_Coefficient":       (23, 1),
    "Homing_Offset":       (31, 2),   # sign-magnitude, bit 11 符号
    "Operating_Mode":      (33, 1),
    # SRAM
    "Torque_Enable":       (40, 1),
    "Goal_Position":       (42, 2),   # sign-magnitude, bit 15 符号
    "Goal_Velocity":       (46, 2),   # sign-magnitude, bit 15 符号
    "Lock":                (55, 1),   # EEPROM 写保护: 0=解锁, 1=锁定
    "Present_Position":    (56, 2),   # read-only, sign-magnitude, bit 15
    "Present_Velocity":    (58, 2),   # read-only, sign-magnitude, bit 15
}


# ── sign-magnitude 编码表 ──────────────────────────
#
# 值 = 符号位位置。这些寄存器不是二补码，而是
# 「最高位表示方向，其余位表示大小」的编码。
#
# 例: Homing_Offset 的 sign_bit=11 意味着:
#   - 最大 magnitude = 2^11 - 1 = 2047
#   - -1 编码成 0x801 = 2049, 不是 0xFFFF

STS3215_SIGN_BIT: dict[str, int] = {
    "Homing_Offset":    11,   # 12-bit signed, range [-2047, +2047]
    "Goal_Position":    15,   # 16-bit signed（虽然物理范围 [0, 4095]，但 Present = Actual - Homing_Offset 可能为负）
    "Goal_Velocity":    15,
    "Present_Position": 15,
    "Present_Velocity": 15,
}


# ── 枚举值 ──────────────────────────────────────────

class OperatingMode(IntEnum):
    """Operating_Mode 寄存器的值。"""

    POSITION = 0   # 位置模式
    VELOCITY = 1   # 轮子/速度模式
    PWM = 2
    STEP = 3


class TorqueMode(IntEnum):
    """Torque_Enable 寄存器的值。"""

    DISABLED = 0
    ENABLED = 1


# ── 预计算属性 ──────────────────────────────────────

# 写 EEPROM 区的寄存器（需要 Lock=0）
EEPROM_REGISTERS: frozenset[str] = frozenset({
    "ID",
    "Baud_Rate",
    "Min_Position_Limit",
    "Max_Position_Limit",
    "P_Coefficient",
    "D_Coefficient",
    "I_Coefficient",
    "Homing_Offset",
    "Operating_Mode",
})


def is_eeprom_register(name: str) -> bool:
    """判断是否是 EEPROM 区寄存器（写入前需要解锁）。"""
    return name in EEPROM_REGISTERS


def get_register(name: str) -> tuple[int, int]:
    """查询寄存器 (address, length)。"""
    try:
        return STS3215_CONTROL_TABLE[name]
    except KeyError as exc:
        raise KeyError(f"未知 STS3215 寄存器: {name}") from exc
