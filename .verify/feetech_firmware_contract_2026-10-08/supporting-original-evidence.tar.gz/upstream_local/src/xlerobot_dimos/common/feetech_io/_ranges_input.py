"""record_ranges_of_motion 要用的终端交互工具。

- enter_pressed(): 非阻塞检测用户是否按了 Enter
- move_cursor_up(n): 终端光标上移 n 行（ANSI 转义）

抄自 lerobot 的 utils.py，简化后只保留我们需要的。
"""

from __future__ import annotations

import select
import sys


def move_cursor_up(lines: int) -> None:
    """ANSI: 光标上移 N 行。"""
    sys.stdout.write(f"\033[{lines}A")
    sys.stdout.flush()


def enter_pressed() -> bool:
    """非阻塞: 看 stdin 缓冲里有没有 Enter（换行符）。

    只支持 Linux/macOS（需要 select.select 支持文件描述符）。
    """
    if not sys.stdin.isatty():
        return False
    try:
        ready, _, _ = select.select([sys.stdin], [], [], 0)
    except (OSError, ValueError):
        return False
    if ready:
        try:
            line = sys.stdin.readline()
            return bool(line)  # 空行也算按了 Enter
        except Exception:
            return False
    return False
