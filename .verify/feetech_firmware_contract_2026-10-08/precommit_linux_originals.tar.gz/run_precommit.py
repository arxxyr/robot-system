"""同源提交前单次纯软件门；不启动测试、release、服务或设备 IO。"""
import importlib.util
import json
import os
import platform
import signal
import stat
from pathlib import Path
from types import SimpleNamespace

BASE = Path('/home/loosqk/robot-checks/feetech-firmware-contract-precommit-20261008-r1')
BOOT = BASE / 'bootstrap'
SOURCE = Path('/home/loosqk/robot-checks/feetech-firmware-contract-quality-20261008-r1/source')
OUT = BASE / 'qa'


def module(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    result = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(result)
    return result


h = module('natural_runner', BOOT / 'natural_runner.py')
a = module('artifacts', BOOT / 'artifacts.py')
require = a.require
require(a.sha256(BOOT / 'natural_runner.py') == 'dad9bbc9405b8fac4d60d6efe794b36750e6a6f9ce9fdeba3debf7d3e1b9a471', 'runner 身份不同')
require(a.sha256(BOOT / 'artifacts.py') == 'bd2b3f7bb8527cd9ecec73894171638e9cf378656b89e284a585c3baa37b8731', 'artifact helper 身份不同')
expected = a.strict_json((BOOT / 'expected_source.json').read_text())
OUT.mkdir()
runner = h.Runner(SimpleNamespace(source=SOURCE, out=OUT, target=Path('/home/loosqk/robot-checks/xlerobot-velocity-foundation-20261008-r7/build')), a)
result = {'schema': 'FEETECH_FIRMWARE_NATIVE_PRECOMMIT_R1', 'status': 'FAIL', 'deployable': False, 'scope': '同源591输入仅nightly fmt→默认根Clippy；无rustup变更/测试/release/UART/服务/安装', 'receipts': []}


def source(label):
    require(not os.path.lexists(SOURCE / '.git'), '导出源码不冒称 Git checkout')
    names = []
    for root, dirs, files in os.walk(SOURCE, followlinks=False):
        for name in dirs:
            require(not (Path(root) / name).is_symlink(), '源目录含符号链接')
        for name in files:
            path = Path(root) / name
            require(stat.S_ISREG(path.lstat().st_mode) and not path.is_symlink(), '输入不是普通文件')
            names.append(path.relative_to(SOURCE).as_posix())
    require(len(names) == 591 and set(names) == set(expected['files']), '输入集合不是批准591项')
    value = a.snapshot_source(SOURCE, names)
    require(value == expected, '输入 bytes/SHA/exec 与批准快照不同')
    h.save(OUT / (label + '.json'), value)
    return value


def step(name, argv, budget=60):
    source(name + '_source_before')
    try:
        return runner.command(name, argv, budget)
    finally:
        source(name + '_source_after')


before = compiler = cargo = None
old = {}


def interrupted(signum, frame):
    h.INTERRUPTED = signum


try:
    for sig in (signal.SIGINT, signal.SIGTERM, signal.SIGHUP):
        old[sig] = signal.signal(sig, interrupted)
    identity = {'hostname': platform.node(), 'arch': platform.machine(), 'uid': os.getuid(), 'gid': os.getgid(), 'boot_id': Path('/proc/sys/kernel/random/boot_id').read_text().strip()}
    require(identity == {'hostname': 'ubuntu', 'arch': 'aarch64', 'uid': 1000, 'gid': 1000, 'boot_id': '6cf7ee3e-a3c5-4c91-80bc-4ca924818b53'}, 'Orin 身份不同')
    require(os.environ.get('CARGO_HOME') == '/home/loosqk/robot-checks/viz-orin-a6957cc-20260930-r1/cargo-home' and os.environ.get('CARGO_NET_OFFLINE') == 'true', '离线缓存环境不同')
    result['identity'] = identity
    before = source('source_before')
    _, row = step('rustc_before', ['rustc', '+nightly', '-vV'])
    compiler = a.parse_rustc_identity(Path(row['stdout']).read_text())
    require(compiler['commit_hash'] == '1d81eb4ad9cd207e3e638bd32b17ec4fce8412a6', '实际nightly不是批准1d81')
    _, row = step('cargo_before', ['cargo', '+nightly', '-V'])
    cargo = Path(row['stdout']).read_bytes()
    require(b'-nightly' in cargo, 'cargo不是nightly')
    step('fmt', ['cargo', '+nightly', 'fmt', '--all'], 300)
    step('clippy_default', ['cargo', '+nightly', 'clippy', '--all', '--all-targets', '--', '-D', 'warnings'], 7200)
    result.update(status='PASS', compiler_before=compiler, cargo_before=cargo.decode(), source_count=591, source_aggregate=before['source_manifest_sha256'])
except BaseException as error:
    result['error'] = repr(error)
finally:
    try:
        _, row = step('rustc_after', ['rustc', '+nightly', '-vV'])
        after_compiler = a.parse_rustc_identity(Path(row['stdout']).read_text())
        require(compiler is not None and after_compiler == compiler, '编译器前后身份不同或初始缺失')
        _, row = step('cargo_after', ['cargo', '+nightly', '-V'])
        after_cargo = Path(row['stdout']).read_bytes()
        require(cargo is not None and after_cargo == cargo, 'Cargo前后身份不同或初始缺失')
        result.update(compiler_after=after_compiler, cargo_after=after_cargo.decode(), compiler_window='PASS')
    except BaseException as error:
        result.update(status='FAIL', compiler_window_error=repr(error))
    try:
        require(before is not None and source('source_after') == before, '源码首尾不同或初始缺失')
        result['source_window'] = 'PASS'
    except BaseException as error:
        result.update(status='FAIL', source_window_error=repr(error))
    result['receipts'] = runner.receipts
    result['interrupted_signal'] = h.INTERRUPTED
    h.save(OUT / 'result.json', result)
    for sig, handler in old.items():
        signal.signal(sig, handler)
print(json.dumps({'status': result['status'], 'error': result.get('error'), 'receipts': len(result['receipts']), 'source_window': result.get('source_window'), 'compiler_window': result.get('compiler_window')}, ensure_ascii=False), flush=True)
raise SystemExit(0 if result['status'] == 'PASS' else 1)
