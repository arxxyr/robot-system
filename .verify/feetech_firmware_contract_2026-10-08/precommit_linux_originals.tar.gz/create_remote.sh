set -eu
export PATH=/home/loosqk/.cargo/bin:/home/loosqk/.local/bin:$PATH
export PYTHONDONTWRITEBYTECODE=1
uv run --no-project python - <<'PY_REMOTE'
import os, json, platform, stat
from pathlib import Path
identity={'hostname':platform.node(),'arch':platform.machine(),'uid':os.getuid(),'gid':os.getgid(),'boot_id':Path('/proc/sys/kernel/random/boot_id').read_text().strip()}
assert identity=={'hostname':'ubuntu','arch':'aarch64','uid':1000,'gid':1000,'boot_id':'6cf7ee3e-a3c5-4c91-80bc-4ca924818b53'},identity
active=[]
for p in Path('/proc').iterdir():
 if not p.name.isdigit():continue
 try:
  if p.stat().st_uid!=1000:continue
  argv=(p/'cmdline').read_bytes().split(b'\0');name=Path(argv[0].decode(errors='replace')).name if argv and argv[0] else ''
  if name in {'cargo','rustc','clippy-driver','rustup'}:active.append({'pid':int(p.name),'argv':argv[0].decode(errors='replace'),'stat':(p/'stat').read_text()})
 except (FileNotFoundError,PermissionError):pass
assert not active,active
base=Path('/home/loosqk/robot-checks/feetech-firmware-contract-precommit-20261008-r1')
assert base.parent.resolve()==base.parent and stat.S_ISDIR(base.parent.lstat().st_mode)
assert not os.path.lexists(base)
base.mkdir();(base/'bootstrap').mkdir()
print(json.dumps({'status':'PASS_IDENTITY_CREATED_NEW_PRECOMMIT_DIRECTORY','identity':identity,'active_cargo_compilers':active,'base':str(base)},ensure_ascii=False))
PY_REMOTE
