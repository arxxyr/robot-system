set -eu
export PATH=/home/loosqk/.cargo/bin:/home/loosqk/.local/bin:$PATH
export CARGO_HOME=/home/loosqk/robot-checks/viz-orin-a6957cc-20260930-r1/cargo-home
export CARGO_NET_OFFLINE=true
export RUSTUP_AUTO_INSTALL=0
export PYTHONDONTWRITEBYTECODE=1
cd /home/loosqk/robot-checks/feetech-firmware-contract-precommit-20261008-r1/bootstrap
sha256sum -c - <<'SHA_INPUTS'
bd2b3f7bb8527cd9ecec73894171638e9cf378656b89e284a585c3baa37b8731  artifacts.py
dad9bbc9405b8fac4d60d6efe794b36750e6a6f9ce9fdeba3debf7d3e1b9a471  natural_runner.py
c646ed5171bc9ddfa00190c8456d570a07290bf759b8b5e0a6c31d243b8461e8  expected_source.json
7d0f6a1b49c936b144b8007a6df96b014a8ae347b582b3686c4a92a75bcc15e0  run_precommit.py
SHA_INPUTS
exec taskset -c 0-3 uv run --no-project python run_precommit.py
