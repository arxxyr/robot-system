#!/bin/bash
set -eu
export PYTHONDONTWRITEBYTECODE=1
tmux set-option -p remain-on-exit on
exec /home/loosqk/.local/share/uv/python/cpython-3.12.13-linux-aarch64-gnu/bin/python3 /home/loosqk/robot-checks/base-zero-r4-quality/boot/commit_quality_once_base_zero_r4.py > /home/loosqk/robot-checks/base-zero-r4-quality/boot/base-zero-r4-quality-driver.log 2>&1
