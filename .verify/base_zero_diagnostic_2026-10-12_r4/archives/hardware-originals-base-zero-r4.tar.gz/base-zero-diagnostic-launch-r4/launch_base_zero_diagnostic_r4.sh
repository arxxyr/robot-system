#!/bin/bash
# 爸爸，保持stdin连接tmux的PTY，只有本轮全部pins绑定后才执行；正文/电机入口保持。
set -eu
export PYTHONDONTWRITEBYTECODE=1
exec /home/loosqk/.local/share/uv/python/cpython-3.12.13-linux-aarch64-gnu/bin/python3 -c 'import os,subprocess
FIELD_STAMP=1791785581689362000
FIELD_EXPECTED=('"'"'17d1e866fa2717d6ffe5d1149f84bde8034b145a82ecbba3c03c074e7efaa6a7'"'"', 1545)
GO_EXPECTED=('"'"'23df442acb35668d1e5f9c5dd64190e7f3e2c597fd3322c26299a04e865d0cd1'"'"', 1754)
BINDING_EXPECTED=('"'"'347a65dbfe0b3d553f7df06b413507b1491c073ced8a283f498bf7a81f51be86'"'"', 30051)
PLAN_EXPECTED=('"'"'489beb14a275f472a8306f27660daeb89a7770e66beb4fc04935f9d91bb6640b'"'"', 38231)
PLAN_CANONICAL_SHA='"'"'3fc25e07d637bad4e1c5c2e683d4211fdeb5cdc04dba5f1b690040916f82facb'"'"'
NATIVE_PREPARATION_EXPECTED=('"'"'678f557e23142fcf5d249f5edf669eebc88dda9bed97af4fabaef85c5509b000'"'"', 5035)
assert type(FIELD_STAMP) is int and FIELD_STAMP>0 and all(v is not None for v in (FIELD_EXPECTED,GO_EXPECTED,BINDING_EXPECTED,PLAN_EXPECTED,NATIVE_PREPARATION_EXPECTED)) and type(PLAN_CANONICAL_SHA) is str and len(PLAN_CANONICAL_SHA)==64, '"'"'爸爸，零目标launcher未绑定本轮现场/GO/软件准备，零I/O拒绝。'"'"'
log=os.open('"'"'/home/loosqk/robot-checks/position-return-20261010-r1/base-zero-diagnostic-r1/base-zero-diagnostic-launch-r4/driver.log'"'"',os.O_WRONLY|os.O_CREAT|os.O_EXCL,0o600)
os.dup2(log,1);os.dup2(log,2);os.close(log)
subprocess.run(['"'"'tmux'"'"','"'"'set-option'"'"','"'"'-p'"'"','"'"'-t'"'"',os.environ['"'"'TMUX_PANE'"'"'],'"'"'remain-on-exit'"'"','"'"'on'"'"'],check=True)
os.execv('"'"'/home/loosqk/.local/share/uv/python/cpython-3.12.13-linux-aarch64-gnu/bin/python3'"'"',['"'"'/home/loosqk/.local/share/uv/python/cpython-3.12.13-linux-aarch64-gnu/bin/python3'"'"','"'"'/home/loosqk/robot-checks/position-return-20261010-r1/base-zero-diagnostic-r1/base_zero_diagnostic_r1.py'"'"','"'"'--raw-helper'"'"','"'"'/home/loosqk/robot-checks/position-return-20261010-r1/base-zero-diagnostic-r1/helpers/raw_right9_from_r14_r1.py'"'"','"'"'--maintenance'"'"','"'"'/home/loosqk/robot-checks/position-return-20261010-r1/software-facts-r1/scripts/run_hardware_maintenance.py'"'"','"'"'--bindings'"'"','"'"'/home/loosqk/robot-checks/position-return-20261010-r1/base-zero-diagnostic-r1/maintenance_bindings_base_zero_diagnostic_r4.json'"'"','"'"'--output'"'"','"'"'/home/loosqk/robot-checks/position-return-20261010-r1/base-zero-diagnostic-r1/base-zero-diagnostic-r4'"'"','"'"'--artifact-root'"'"','"'"'/home/loosqk/robot-checks/position-return-20261010-r1'"'"','"'"'--execute'"'"','"'"'--approval'"'"','"'"'/home/loosqk/robot-checks/position-return-20261010-r1/base-zero-diagnostic-r1/base-zero-diagnostic-r4.go.json'"'"'])'
