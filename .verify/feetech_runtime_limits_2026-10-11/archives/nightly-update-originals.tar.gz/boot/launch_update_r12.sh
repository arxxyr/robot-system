#!/bin/bash
set -eu
umask 077
export PYTHONDONTWRITEBYTECODE=1
export PATH=/home/loosqk/.cargo/bin:/home/loosqk/.local/bin:$PATH
tmux set-option -p remain-on-exit on
exec /home/loosqk/.local/share/uv/python/cpython-3.12.13-linux-aarch64-gnu/bin/python3 /home/loosqk/robot-checks/position-return-20261011-r12/native-toolchain/boot/update_once_r12.py > /home/loosqk/robot-checks/position-return-20261011-r12/native-toolchain/boot/update-owner.log 2>&1
