"""R12 最小原生软件验收；不接触 UART、GO、服务或正式安装。"""

import hashlib
import importlib.util
import json
import os
from pathlib import Path
import re
import subprocess
import tarfile
import time
from types import SimpleNamespace

BASE = Path('/home/loosqk/robot-checks/position-return-20261011-r12/native-quality')
SOURCE = Path('/home/loosqk/robot-checks/position-return-20261010-r1/position-return-r7/source')
TARGET = Path('/home/loosqk/robot-checks/xlerobot-velocity-foundation-20261008-r7/build')
OUT = BASE / 'quality'
HEAD = '894084738d95a7239611c2b8fbecfe081d3a7fc9'
OLD = '3a4cc12e5e28f9c9164b8e7cdf9e2861b7127d7536ab291e7db8cced6d7aa4e9'
NEW = '068277d843b191bc8283bab38e667b0f6a4d30e296e8c5a99a97cfe19654fcf8'
COMPILER = '6f5da406b56c2db6607202b63daee73aa8c61297'
FIVE = ['crates/robot-adapters/feetech/examples/feetech_poke.rs',
        'crates/robot-adapters/feetech/src/bus.rs',
        'crates/robot-adapters/feetech/src/bus_raw_read_tests.rs',
        'crates/robot-adapters/feetech/src/diagnostic.rs',
        'crates/robot-adapters/feetech/src/registers.rs']


def module(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    value = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(value)
    return value


a = module('r12_existing_artifacts', Path('/home/loosqk/robot-checks/h2-exit-observation-20261009-r1/source/scripts/post_e_h2_artifacts.py'))
r = module('r12_existing_runner', Path('/home/loosqk/robot-checks/h2-right-ready-20261009-r1/bootstrap/run_release_v2.py'))
assert a.sha256(Path(r.__file__)) == 'd6b20da28de8d5ae077a93cb2fb5ba7f27a66b8145df9e7e91951cb14ac0b12b'
assert a.sha256(Path(a.__file__)) == 'bd2b3f7bb8527cd9ecec73894171638e9cf378656b89e284a585c3baa37b8731'
expected = a.strict_json((BASE / 'boot/host_source_final_r12.json').read_text())
assert expected['source_manifest_sha256'] == NEW and len(expected['files']) == 597
OUT.mkdir()
runner = r.Runner(SimpleNamespace(source=SOURCE, target=TARGET, out=OUT, build_head=HEAD), a)
runner.env['CARGO_HOME'] = '/home/loosqk/robot-checks/viz-orin-a6957cc-20260930-r1/cargo-home'
runner.shown['CARGO_HOME'] = runner.env['CARGO_HOME']
runner.env['PATH'] = '/home/loosqk/.cargo/bin:/home/loosqk/.local/bin:' + runner.env['PATH']
runner.shown['PATH'] = runner.env['PATH']
for key in ('ALL_PROXY', 'all_proxy', 'http_proxy', 'https_proxy', 'HTTP_PROXY', 'HTTPS_PROXY', 'LD_PRELOAD'):
    runner.env.pop(key, None)
runner.env.update(HTTP_PROXY='http://10.0.1.80:10808', HTTPS_PROXY='http://10.0.1.80:10808', PYTHONDONTWRITEBYTECODE='1')
runner.shown.update(HTTP_PROXY=runner.env['HTTP_PROXY'], HTTPS_PROXY=runner.env['HTTPS_PROXY'])
raw_receipts = []
result = {'schema': 'R12_MINIMAL_NATIVE_QUALITY_V1', 'status': 'FAIL', 'started_at': r.utc(),
          'scope': 'fmt→两根Clippy→feetech real-hw库/单例测试→仅poke release/help/两名拒写；无全workspace测试/控制ELF/安装/UART/GO/服务',
          'native_git_head': HEAD, 'native_worktree': 'five changed sources; not clean',
          'source_before_install_expected': OLD, 'source_expected': NEW, 'compiler_expected': COMPILER}


def text(name, argv, timeout=7200):
    _, row = runner.command(name, argv, timeout)
    return Path(row['stdout']).read_text()


def snapshot(label, digest):
    head = text(label + '_head', ['git', 'rev-parse', 'HEAD'])
    status = text(label + '_status', ['git', 'status', '--porcelain=v1', '--untracked-files=all'])
    names = text(label + '_files', ['git', 'ls-files', '-z', '--cached', '--others', '--exclude-standard'])
    assert head.strip() == HEAD and status == ''.join(' M ' + name + '\n' for name in sorted(FIVE))
    value = a.snapshot_source(SOURCE, names.rstrip('\0').split('\0'))
    assert len(value['files']) == 597 and value['source_manifest_sha256'] == digest
    r.save(OUT / (label + '.json'), value)
    return value


def raw_cli(name, argv, expected_fragment=None):
    directory = OUT / name
    directory.mkdir()
    row = {'name': name, 'argv': argv, 'cwd': str(SOURCE), 'started_at': r.utc(),
           'started_monotonic_ns': time.monotonic_ns(), 'reaped': False,
           'wait_returncode': None, 'signals_sent': []}
    child = subprocess.Popen(argv, cwd=SOURCE, env=runner.env, stdin=subprocess.DEVNULL,
                             stdout=subprocess.PIPE, stderr=subprocess.PIPE, start_new_session=True)
    row['pid'] = child.pid
    r.save(directory / 'launch.json', row)
    stdout, stderr = child.communicate()
    code = child.wait()
    row.update(reaped=True, wait_returncode=code, exit_code=code, finished_at=r.utc(),
               ended_monotonic_ns=time.monotonic_ns())
    for suffix, raw in [('stdout', stdout), ('stderr', stderr)]:
        path = directory / (suffix + '.log')
        with path.open('xb') as stream:
            stream.write(raw)
        row[suffix] = {'path': str(path), 'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}
    r.save(directory / 'completion.json', row)
    raw_receipts.append(row)
    print(json.dumps({'name': name, 'pid': child.pid, 'exit_code': code, 'reaped': True}, ensure_ascii=False), flush=True)
    assert code == 2 and stdout == b'' and expected_fragment.encode() in stderr
    assert b'open serial' not in stderr


try:
    old = snapshot('source_before_install', OLD)
    compiler = a.parse_rustc_identity(text('rustc_before', ['rustc', '-vV']))
    assert compiler['commit_hash'] == COMPILER and compiler['host'] == 'aarch64-unknown-linux-gnu'
    backup = OUT / 'source-backup'
    backup.mkdir()
    for name in FIVE:
        path = SOURCE / name
        original = path.read_bytes()
        assert hashlib.sha256(original).hexdigest() == old['files'][name]['sha256']
        original_copy = backup / Path(name).name
        with original_copy.open('xb') as stream:
            stream.write(original)
            stream.flush()
            os.fsync(stream.fileno())
        assert original_copy.read_bytes() == original
    assert {name for name in expected['files'] if expected['files'][name] != old['files'][name]} == set(FIVE)
    for name in FIVE:
        path = SOURCE / name
        incoming = (BASE / 'boot/incoming' / Path(name).name).read_bytes()
        assert len(incoming) == expected['files'][name]['bytes'] and hashlib.sha256(incoming).hexdigest() == expected['files'][name]['sha256']
        temporary = path.with_name(path.name + '.r12-new')
        with temporary.open('xb') as stream:
            stream.write(incoming)
            stream.flush()
            os.fsync(stream.fileno())
        temporary.chmod(path.stat().st_mode & 0o777)
        os.replace(temporary, path)
    before = snapshot('source_before', NEW)
    assert before == expected
    with tarfile.open(OUT / 'source-inputs.tar.gz', 'x:gz') as archive:
        for name in sorted(expected['files']):
            archive.add(SOURCE / name, arcname=name, recursive=False)
    runner.command('fmt', ['cargo', 'fmt', '--all'], 300)
    fmt_after = a.snapshot_source(SOURCE, list(expected['files']))
    r.save(OUT / 'fmt_after.json', fmt_after)
    assert fmt_after == before
    runner.command('clippy', ['cargo', 'clippy', '--all', '--all-targets', '--', '-D', 'warnings'], 7200)
    runner.command('clippy_real_hw', ['cargo', 'clippy', '--all', '--all-targets', '--features', 'robot-adapter-feetech/real-hw', '--', '-D', 'warnings'], 7200)
    lib = text('feetech_lib', ['cargo', 'test', '--locked', '-p', 'robot-adapter-feetech', '--features', 'real-hw', '--lib'])
    example = text('feetech_poke_tests', ['cargo', 'test', '--locked', '-p', 'robot-adapter-feetech', '--features', 'real-hw', '--example', 'feetech_poke'])
    counts = {}
    for label, output in [('lib', lib), ('example', example)]:
        names = re.findall(r'^test (\S+) \.\.\. ok$', output, re.MULTILINE)
        assert len(names) == len(set(names)) and '0 failed' in output
        counts[label] = {'passed': len(names), 'names': names, 'result_line': [line for line in output.splitlines() if line.startswith('test result:')]}
    result['tests'] = counts
    result['unique_tests'] = sum(v['passed'] for v in counts.values())
    runner.command('poke_release', ['cargo', 'build', '--locked', '--release', '--message-format=json', '-p', 'robot-adapter-feetech', '--features', 'real-hw', '--example', 'feetech_poke'], 7200)
    output = TARGET / 'release/examples/feetech_poke'
    original = a.elf_identity(output)
    frozen_root = BASE.parent / 'readback-tool-r12'
    frozen_root.mkdir()
    frozen = frozen_root / 'feetech_poke'
    with frozen.open('xb') as stream:
        stream.write(output.read_bytes())
        stream.flush()
        os.fsync(stream.fileno())
    frozen.chmod(0o700)
    identity = a.elf_identity(frozen)
    assert identity['sha256'] == original['sha256'] and identity['bytes'] == original['bytes'] and identity['elf_machine'] == 183 and identity['mode'] == 0o700
    sidecar = {'native_git_head': HEAD, 'native_worktree': result['native_worktree'], 'source_manifest_sha256': NEW,
               'compiler': compiler, 'original': original, 'frozen': identity, 'frozen_path': str(frozen), 'deployment': False}
    r.save(OUT / 'frozen-tool.json', sidecar)
    raw_cli('poke_help', [str(frozen), '--help'], 'usage:')
    for name in ['Acceleration', 'Torque_Limit']:
        raw_cli('reject_write_' + name, [str(frozen), '/nonexistent-r12-serial-port', '7', 'write', name, '1'], '本项目诊断专用寄存器禁止写入：' + name)
    after = snapshot('source_after', NEW)
    assert after == before
    compiler_after = a.parse_rustc_identity(text('rustc_after', ['rustc', '-vV']))
    assert compiler_after == compiler and a.elf_identity(frozen) == identity and a.elf_identity(output) == original
    result.update(status='PASS', compiler=compiler, source_before_after='PASS', compiler_before_after='PASS', frozen_tool=sidecar)
except BaseException as error:
    result['error'] = repr(error)
finally:
    result.update(finished_at=r.utc(), receipts=runner.receipts, cli_receipts=raw_receipts)
    r.save(OUT / 'result.json', result)
    print(json.dumps(result, ensure_ascii=False), flush=True)
raise SystemExit(0 if result['status'] == 'PASS' else 1)
