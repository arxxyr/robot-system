#!/bin/bash
set -eu
export PYTHONDONTWRITEBYTECODE=1
tmux set-option -p remain-on-exit on
exec /home/loosqk/.local/share/uv/python/cpython-3.12.13-linux-aarch64-gnu/bin/python3 /home/loosqk/robot-checks/position-return-20261010-r1/base-firmware-read-r15/boot/prepare_base_firmware_read6_r15.py > /home/loosqk/robot-checks/position-return-20261010-r1/base-firmware-read-r15/boot/driver.log 2>&1
