"""独占归档本轮本机原件，核验当前编译输入与已验原生来源一致。"""
import gzip
import hashlib
import importlib.util
import io
import json
from pathlib import Path
import shutil
import subprocess
import sys
import tarfile

ROOT = Path('/Users/loosqk/repo/rust/robot-system')
WORK = ROOT / 'target/post_e_h2_rt/s52'
OUT = ROOT / '.verify/h2_serial_recovery_2026-09-30'
sys.dont_write_bytecode = True

def sha(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()

def read(path):
    return json.loads(path.read_text())

def save(path, value):
    with path.open('x') as stream:
        json.dump(value, stream, ensure_ascii=False, indent=2)
        stream.write('\n')

accepted = ['static_review.json', 'collector_static_review.json',
            'reused_software_review.json', 'helper_upload_review.json',
            'native_dynamic_review_r2.json', 'native_archive_review_r2.json',
            'final_evidence_binding_review.json']
for name in accepted:
    report = read(WORK / 'reviews' / name)
    assert report['status'] == 'PASS' and not report.get('blocking_findings')
assert read(WORK / 'host/formal_during_after_comparison.json')['status'] == 'PASS'
assert read(WORK / 'docs_draft/application.json')['status'] == 'APPLIED_NOT_COMMITTED'

spec = importlib.util.spec_from_file_location('artifacts', ROOT / 'scripts/post_e_h2_artifacts.py')
api = importlib.util.module_from_spec(spec)
spec.loader.exec_module(api)
names = subprocess.check_output(['git', '-C', str(ROOT), 'ls-files', '-z', '--cached', '--others', '--exclude-standard']).decode().rstrip('\0').split('\0')
current = api.snapshot_source(ROOT, names)
native = read(WORK / 'native-extracted/release-r1/source_before.json')
assert current == native and len(current['files']) == 589
save(WORK / 'host/precommit_source_comparison.json', {
    'status': 'PASS', 'files': 589,
    'source_manifest_sha256': current['source_manifest_sha256'],
    'scope': '文档与证据变更后的全部编译输入逐项等于本轮fmt/Clippy及六配方来源',
    'native_source_sha256': sha(WORK / 'native-extracted/release-r1/source_before.json')})

excluded_parts = {'__pycache__', 'native-extracted', 'early_native'}
excluded_names = {'source.bundle', 'native-evidence.tar.gz',
                  'native-evidence.tar.gz.index.json', 'native-evidence.tar.gz.metadata.json'}
paths = sorted(p for p in WORK.rglob('*') if p.is_file()
               and not any(x in excluded_parts for x in p.relative_to(WORK).parts)
               and p.name not in excluded_names)
rows = []
archive = OUT / 'host-evidence.tar.gz'
with tarfile.open(archive, 'x:gz') as tar:
    for path in paths:
        assert not path.is_symlink()
        raw = path.read_bytes()
        name = path.relative_to(WORK).as_posix()
        item = tarfile.TarInfo(name)
        item.size, item.mode = len(raw), 0o644
        tar.addfile(item, io.BytesIO(raw))
        rows.append({'path': name, 'sha256': hashlib.sha256(raw).hexdigest(), 'bytes': len(raw)})
    raw = (json.dumps(rows, ensure_ascii=False, indent=2) + '\n').encode()
    item = tarfile.TarInfo('index.json')
    item.size = len(raw)
    tar.addfile(item, io.BytesIO(raw))
with tarfile.open(archive) as tar:
    assert len(tar.getmembers()) == len(rows) + 1
    assert json.load(tar.extractfile('index.json')) == rows
    for row in rows:
        raw = tar.extractfile(row['path']).read()
        assert len(raw) == row['bytes'] and hashlib.sha256(raw).hexdigest() == row['sha256']
with gzip.open(archive, 'rb') as stream:
    while stream.read(1024 * 1024):
        pass
save(OUT / 'host.index.json', rows)
metadata = {'status': 'PASS', 'archive': 'host-evidence.tar.gz',
            'archive_sha256': sha(archive), 'archive_bytes': archive.stat().st_size,
            'index_sha256': sha(OUT / 'host.index.json'), 'indexed_files': len(rows),
            'readback_verified': True}
save(OUT / 'host.metadata.json', metadata)
review_dir = OUT / 'reviews'
review_dir.mkdir()
for name in accepted:
    shutil.copyfile(WORK / 'reviews' / name, review_dir / name)
print(json.dumps(metadata, ensure_ascii=False))
