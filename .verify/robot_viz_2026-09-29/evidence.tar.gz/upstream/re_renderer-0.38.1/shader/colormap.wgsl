#import <./types.wgsl>
#import <./utils/srgb.wgsl>

// NOTE: Keep in sync with `colormap.rs`!
const COLORMAP_GRAYSCALE:      u32 = 1u; // sRGB gradient = perceptually even
const COLORMAP_INFERNO:        u32 = 2u;
const COLORMAP_MAGMA:          u32 = 3u;
const COLORMAP_PLASMA:         u32 = 4u;
const COLORMAP_TURBO:          u32 = 5u;
const COLORMAP_VIRIDIS:        u32 = 6u;
const COLORMAP_CYAN_TO_YELLOW: u32 = 7u;
const COLORMAP_SPECTRAL:       u32 = 8u;
const COLORMAP_TWILIGHT:       u32 = 9u;
const COLORMAP_RVIZ_MAP:       u32 = 10u;
const COLORMAP_RVIZ_COSTMAP:   u32 = 11u;
const COLORMAP_COSTMAP:        u32 = 12u;

/// Returns a gamma-space sRGBA in 0-1 range.
///
/// The input will be saturated to [0, 1] range.
fn colormap_srgba(which: u32, t_unsaturated: f32) -> vec4f {
    let t = saturate(t_unsaturated);
    if which == COLORMAP_GRAYSCALE {
        // A linear gray gradient in sRGB gamma space is supposed to be perceptually even as-is!
        // Easy to get confused: A linear gradient in sRGB linear space is *not* perceptually even.
        return vec4f(vec3f(t), 1.0);
    } else if which == COLORMAP_INFERNO {
        return colormap_inferno_srgba(t);
    } else if which == COLORMAP_MAGMA {
        return colormap_magma_srgba(t);
    } else if which == COLORMAP_PLASMA {
        return colormap_plasma_srgba(t);
    } else if which == COLORMAP_TURBO {
        return colormap_turbo_srgba(t);
    } else if which == COLORMAP_VIRIDIS {
        return colormap_viridis_srgba(t);
    } else if which == COLORMAP_CYAN_TO_YELLOW {
        return colormap_cyan_to_yellow_srgba(t);
    } else if which == COLORMAP_SPECTRAL {
        return colormap_spectral_srgba(t);
    } else if which == COLORMAP_TWILIGHT {
        return colormap_twilight_srgba(t);
    } else if which == COLORMAP_RVIZ_MAP {
        return colormap_rviz_map_srgba(t);
    } else if which == COLORMAP_RVIZ_COSTMAP {
        return colormap_rviz_costmap_srgba(t);
    } else if which == COLORMAP_COSTMAP {
        return colormap_costmap_srgba(t);
    } else {
        return ERROR_RGBA;
    }
}

/// Returns a linear-space RGBA in 0-1 range.
///
/// The input will be saturated to [0, 1] range.
fn colormap_linear(which: u32, t: f32) -> vec4f {
    let color = colormap_srgba(which, t);
    return vec4f(linear_from_srgb(color.rgb), color.a);
}

// --- Turbo color map ---

// Polynomial approximation in GLSL for the Turbo colormap.
// Taken from https://gist.github.com/mikhailov-work/0d177465a8151eb6ede1768d51d476c7.
// Original LUT: https://gist.github.com/mikhailov-work/ee72ba4191942acecc03fe6da94fc73f.
//
// Copyright 2019 Google LLC.
// SPDX-License-Identifier: Apache-2.0
//
// Authors:
//   Colormap Design: Anton Mikhailov (mikhailov@google.com)
//   GLSL Approximation: Ruofei Du (ruofei@google.com)

/// Returns a gamma-space sRGBA in 0-1 range.
/// This is a polynomial approximation from Turbo color map, assuming `t` is
/// normalized (it will be saturated no matter what).
fn colormap_turbo_srgba(t: f32) -> vec4f {
    let r4 = vec4f(0.13572138, 4.61539260, -42.66032258, 132.13108234);
    let g4 = vec4f(0.09140261, 2.19418839, 4.84296658, -14.18503333);
    let b4 = vec4f(0.10667330, 12.64194608, -60.58204836, 110.36276771);
    let r2 = vec2f(-152.94239396, 59.28637943);
    let g2 = vec2f(4.27729857, 2.82956604);
    let b2 = vec2f(-89.90310912, 27.34824973);

    let v4 = vec4f(1.0, t, t * t, t * t * t);
    let v2 = v4.zw * v4.z;

    return vec4f(vec3f(
        dot(v4, r4) + dot(v2, r2),
        dot(v4, g4) + dot(v2, g2),
        dot(v4, b4) + dot(v2, b2)
    ), 1.0);
}

// --- Matplotlib color maps ---

// Polynomials fitted to matplotlib colormaps, taken from https://www.shadertoy.com/view/WlfXRN.
//
// License CC0 (public domain)
//   https://creativecommons.org/share-your-work/public-domain/cc0/
//
// Similar to https://www.shadertoy.com/view/XtGGzG but with a couple small differences:
//  - use degree 6 instead of degree 5 polynomials
//  - use nested horner representation for polynomials
//  - polynomials were fitted to minimize maximum error (as opposed to least squares)
//
// Data fitted from https://github.com/BIDS/colormap/blob/bc549477db0c12b54a5928087552ad2cf274980f/colormaps.py (CC0).

/// Returns a gamma-space sRGBA in 0-1 range.
/// This is a polynomial approximation from Viridis color map, assuming `t` is
/// normalized (it will be saturated no matter what).
fn colormap_viridis_srgba(t: f32) -> vec4f {
    let c0 = vec3f(0.2777273272234177, 0.005407344544966578, 0.3340998053353061);
    let c1 = vec3f(0.1050930431085774, 1.404613529898575, 1.384590162594685);
    let c2 = vec3f(-0.3308618287255563, 0.214847559468213, 0.09509516302823659);
    let c3 = vec3f(-4.634230498983486, -5.799100973351585, -19.33244095627987);
    let c4 = vec3f(6.228269936347081, 14.17993336680509, 56.69055260068105);
    let c5 = vec3f(4.776384997670288, -13.74514537774601, -65.35303263337234);
    let c6 = vec3f(-5.435455855934631, 4.645852612178535, 26.3124352495832);
    return vec4f(c0 + t * (c1 + t * (c2 + t * (c3 + t * (c4 + t * (c5 + t * c6))))), 1.0);
}

/// Returns a gamma-space sRGBA in 0-1 range.
/// This is a polynomial approximation from Plasma color map, assuming `t` is
/// normalized (it will be saturated no matter what).
fn colormap_plasma_srgba(t: f32) -> vec4f {
    let c0 = vec3f(0.05873234392399702, 0.02333670892565664, 0.5433401826748754);
    let c1 = vec3f(2.176514634195958, 0.2383834171260182, 0.7539604599784036);
    let c2 = vec3f(-2.689460476458034, -7.455851135738909, 3.110799939717086);
    let c3 = vec3f(6.130348345893603, 42.3461881477227, -28.51885465332158);
    let c4 = vec3f(-11.10743619062271, -82.66631109428045, 60.13984767418263);
    let c5 = vec3f(10.02306557647065, 71.41361770095349, -54.07218655560067);
    let c6 = vec3f(-3.658713842777788, -22.93153465461149, 18.19190778539828);
    return vec4f(c0 + t * (c1 + t * (c2 + t * (c3 + t * (c4 + t * (c5 + t * c6))))), 1.0);
}

/// Returns a gamma-space sRGBA in 0-1 range.
/// This is a polynomial approximation from Magma color map, assuming `t` is
/// normalized (it will be saturated no matter what).
fn colormap_magma_srgba(t: f32) -> vec4f {
    let c0 = vec3f(-0.002136485053939582, -0.000749655052795221, -0.005386127855323933);
    let c1 = vec3f(0.2516605407371642, 0.6775232436837668, 2.494026599312351);
    let c2 = vec3f(8.353717279216625, -3.577719514958484, 0.3144679030132573);
    let c3 = vec3f(-27.66873308576866, 14.26473078096533, -13.64921318813922);
    let c4 = vec3f(52.17613981234068, -27.94360607168351, 12.94416944238394);
    let c5 = vec3f(-50.76852536473588, 29.04658282127291, 4.23415299384598);
    let c6 = vec3f(18.65570506591883, -11.48977351997711, -5.601961508734096);
    return vec4f(c0 + t * (c1 + t * (c2 + t * (c3 + t * (c4 + t * (c5 + t * c6))))), 1.0);
}

/// Returns a gamma-space sRGBA in 0-1 range.
/// This is a polynomial approximation from Inferno color map, assuming `t` is
/// normalized (it will be saturated no matter what).
fn colormap_inferno_srgba(t: f32) -> vec4f {
    let c0 = vec3f(0.0002189403691192265, 0.001651004631001012, -0.01948089843709184);
    let c1 = vec3f(0.1065134194856116, 0.5639564367884091, 3.932712388889277);
    let c2 = vec3f(11.60249308247187, -3.972853965665698, -15.9423941062914);
    let c3 = vec3f(-41.70399613139459, 17.43639888205313, 44.35414519872813);
    let c4 = vec3f(77.162935699427, -33.40235894210092, -81.80730925738993);
    let c5 = vec3f(-71.31942824499214, 32.62606426397723, 73.20951985803202);
    let c6 = vec3f(25.13112622477341, -12.24266895238567, -23.07032500287172);
    return vec4f(c0 + t * (c1 + t * (c2 + t * (c3 + t * (c4 + t * (c5 + t * c6))))), 1.0);
}

// --- rasmusgo's color maps ---

// Designed by Rasmus Brönnegård (rasmusgo) adapted from https://www.shadertoy.com/view/lfByRh.
//
// License CC0 (public domain)
//   https://creativecommons.org/share-your-work/public-domain/cc0/

/// Returns a gamma-space sRGBA in 0-1 range.
/// This is a perceptually uniform colormap which is robust to color blindness.
/// It is especially suited for visualizing signed values.
/// It interpolates from cyan to blue to dark gray to brass to yellow.
fn colormap_cyan_to_yellow_srgba(t: f32) -> vec4f {
    let u = t * 2. - 1.;
    return vec4f(saturate(vec3f(1. + 3. * u, (1. + 3. * u * u) , 1. - 3. * u) / 4.), 1.0);
}

/// Returns a gamma-space sRGBA in 0-1 range.
/// The input (`t`) must be in the 0-1 range.
/// This is a polynomial approximation from Spectral color map.
fn colormap_spectral_srgba(t: f32) -> vec4f {
    let c0 = vec3f(0.584384543712538, 0.006424432561482, 0.231061410304836);
    let c1 = vec3f(3.768572852617221, 2.487082885717158, 2.821174312084977);
    let c2 = vec3f(-16.262574054760623, -6.243215992229093, -37.292187460541960);
    let c3 = vec3f(39.821464952234010, 39.932449794574126, 186.340471613899751);
    let c4 = vec3f(-46.140976850412727, -99.423798167148249, -388.532539629914481);
    let c5 = vec3f(12.716626092708825, 96.954180217298671, 360.627239851094203);
    let c6 = vec3f(5.942343111972585, -33.440386037285862, -123.635206049211334);
    return vec4f(c0 + t * (c1 + t * (c2 + t * (c3 + t * (c4 + t * (c5 + t * c6))))), 1.0);
}

/// Returns a gamma-space sRGBA in 0-1 range.
/// The input (`t`) must be in the 0-1 range.
/// This is a polynomial approximation from Twilight color map.
/// This is a perceptually uniform cyclic colormap from Matplotlib.
/// It is useful for visualizing periodic or cyclic data such as phase angles or time of day.
/// It interpolates from light purple through blue to black, then through red back to light purple.
/// Data from https://github.com/matplotlib/matplotlib (matplotlib's twilight colormap).
fn colormap_twilight_srgba(t: f32) -> vec4f {
    let c0 = vec3f(0.99435322698120177, 0.85170793387210064, 0.93942033498486266);
    let c1 = vec3f(-6.61774273956635106, -0.23133259259568750, -3.96704343424284378);
    let c2 = vec3f(41.78124131041812461, -7.61851602599826982, 38.98566990464263426);
    let c3 = vec3f(-158.29764239605322018, 3.73408709288658525, -170.02538195370874519);
    let c4 = vec3f(301.70954078396789555, 25.04157831823896174, 319.73628266524258379);
    let c5 = vec3f(-265.16454480601146315, -30.83148395246298179, -271.62226902484138691);
    // Adjusted c6 to ensure f(0) = f(1) for true cyclicity
    let c6 = vec3f(86.58914784721200531, 9.90660484718943267, 86.89294583380010456);
    return vec4f(c0 + t * (c1 + t * (c2 + t * (c3 + t * (c4 + t * (c5 + t * c6))))), 1.0);
}

/// Reimplements the "Map" color palette from `RViz`.
///
/// An occupancy grid stores signed-char cell values that `RViz` interprets as:
/// - `0..=100`: occupancy probability in percent, mapped to grayscale (`0` free -> white, `100` occupied -> black).
/// - `101..=127`: illegal positive values, drawn bright green to flag bad data.
/// - `128..=254`: illegal values (a signed `-128..=-2` reinterpreted as `u8`), on a red -> yellow ramp.
/// - `255`: the legal `-1` value ("unknown"), drawn teal-gray.
///
/// `t` is the normalized cell value, i.e. `raw_value / 255`.
///
/// Reference: <https://github.com/ros-visualization/rviz/blob/26bbf0a1819253d7515c096a71f1f5cd58f88748/src/rviz/default_plugin/map_display.cpp#L285>
fn colormap_rviz_map_srgba(t: f32) -> vec4f {
    let value = floor((saturate(t) * 255.0) + 0.5);

    if value <= 100.0 {
        // Occupancy probability: white (free) -> black (occupied).
        let x = (255.0 - (value * 255.0) / 100.0) / 255.0;
        return vec4f(vec3f(x), 1.0);
    } else if value < 128.0 {
        // 101..=127: illegal positive values.
        return vec4f(0.0, 1.0, 0.0, 1.0);
    } else if value < 255.0 {
        // 128..=254: illegal (negative) values, on a red -> yellow ramp.
        let x = ((255.0 * (value - 128.0)) / (254.0 - 128.0)) / 255.0;
        return vec4f(1.0, x, 0.0, 1.0);
    } else {
        // 255 == -1: unknown.
        return vec4f(112.0 / 255.0, 137.0 / 255.0, 134.0 / 255.0, 1.0);
    }
}

/// Reimplements the "Costmap" color palette from `RViz`.
///
/// A costmap stores signed-char cell values that `RViz` interprets as:
/// - `0`: free space (zero cost), drawn fully transparent.
/// - `1..=98`: increasing cost, on a blue (low) -> red (high) ramp.
/// - `99`: inscribed obstacle (the robot's footprint would collide), drawn cyan.
/// - `100`: lethal obstacle (definitely occupied), drawn magenta.
/// - `101..=127`: illegal positive values, drawn bright green to flag bad data.
/// - `128..=254`: illegal values (a signed `-128..=-2` reinterpreted as `u8`), on a red -> yellow ramp.
/// - `255`: the legal `-1` value ("unknown"), drawn teal-gray.
///
/// `t` is the normalized cell value, i.e. `raw_value / 255`.
///
/// Reference: <https://github.com/ros-visualization/rviz/blob/26bbf0a1819253d7515c096a71f1f5cd58f88748/src/rviz/default_plugin/map_display.cpp#L323>
fn colormap_rviz_costmap_srgba(t: f32) -> vec4f {
    let value = floor((saturate(t) * 255.0) + 0.5);

    if value == 0.0 {
        // Free space (zero cost).
        return vec4f(0.0, 0.0, 0.0, 0.0);
    } else if value < 99.0 {
        // 1..=98: cost ramp from blue (low) to red (high).
        let x = (value * 255.0 / 100.0) / 255.0;
        return vec4f(x, 0.0, 1.0 - x, 1.0);
    } else if value == 99.0 {
        // Inscribed obstacle.
        return vec4f(0.0, 1.0, 1.0, 1.0);
    } else if value == 100.0 {
        // Lethal obstacle.
        return vec4f(1.0, 0.0, 1.0, 1.0);
    } else if value < 128.0 {
        // 101..=127: illegal positive values.
        return vec4f(0.0, 1.0, 0.0, 1.0);
    } else if value < 255.0 {
        // 128..=254: illegal (negative) values, on a red -> yellow ramp.
        let x = ((255.0 * (value - 128.0)) / (254.0 - 128.0)) / 255.0;
        return vec4f(1.0, x, 0.0, 1.0);
    } else {
        // 255 == -1: unknown.
        return vec4f(112.0 / 255.0, 137.0 / 255.0, 134.0 / 255.0, 1.0);
    }
}

const RERUN_RED: vec3f = vec3f(215.0, 47.0, 33.0) / 255.0; // #D72F21
const RERUN_BLUE: vec3f = vec3f(24.0, 106.0, 221.0) / 255.0; // #186ADD
const RERUN_GREEN: vec3f = vec3f(134.0, 217.0, 166.0) / 255.0; // #86D9A6
const RERUN_YELLOW: vec3f = vec3f(246.0, 218.0, 117.0) / 255.0; // #F6DA75

/// Semantically equivalent to the `RViz` cost map but with a more pleasing color palette.
///
/// See `colormap_rviz_costmap_srgba` for the meaning of each value range.
///
/// We use selected colors from the Rerun gradient palette here, see also: https://rerun.io/media
fn colormap_costmap_srgba(t: f32) -> vec4f {
    let value = floor((saturate(t) * 255.0) + 0.5);

    // Values 101+ are illegal/unknown and rare in practice, but we still map them to match RViz semantics.
    if value == 0.0 {
        return vec4f(0.0, 0.0, 0.0, 0.0); // free space (zero cost)
    } else if value < 99.0 {
        return vec4f(mix(RERUN_GREEN, RERUN_YELLOW, value / 98.0), 1.0); // 1-98: cost ramp
    } else if value == 99.0 {
        return vec4f(RERUN_RED, 1.0); // inscribed obstacle
    } else if value == 100.0 {
        return vec4f(RERUN_BLUE, 1.0); // lethal obstacle
    } else if value < 128.0 {
        return vec4f(RERUN_GREEN, 1.0); // 101-127 (illegal positive)
    } else if value < 255.0 {
        // 128-254 (illegal negative): red -> ramp yellow
        return vec4f(mix(RERUN_RED, RERUN_YELLOW, (value - 128.0) / (254.0 - 128.0)), 1.0);
    } else {
        return vec4f(112.0 / 255.0, 137.0 / 255.0, 134.0 / 255.0, 1.0); // 255 == -1: teal-gray (unknown, matches RViz)
    }
}
