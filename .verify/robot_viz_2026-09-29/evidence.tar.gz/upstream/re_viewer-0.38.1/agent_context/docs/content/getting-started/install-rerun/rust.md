---
title: Rust SDK
order: 300
description: Setting up the Rust SDK
---

Add the [Rerun crate](https://crates.io/crates/rerun) using `cargo add rerun`.

You'll additionally need to install the [Viewer](./viewer.md).

## Next steps

[Set up a Rust project](../../getting-started/project-setup/rust.md), then walk through the [Log and Ingest](../../getting-started/data-in.md) tutorial.

-   [Rust API docs](https://docs.rs/rerun/latest/rerun/)
