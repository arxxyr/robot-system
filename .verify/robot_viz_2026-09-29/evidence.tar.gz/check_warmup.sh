#!/usr/bin/env bash
set -euo pipefail
export PATH="$HOME/.cargo/bin:$HOME/.local/bin:$PATH"
dest_dir="$HOME/robot-checks/viz-warmup-r1"
test ! -e "$dest_dir"
mkdir -p "$dest_dir"
tar xzf /Users/loosqk/repo/rust/robot-system/target/robot_viz_20260929/warmup-r1/source.tar.gz -C "$dest_dir"
cd "$dest_dir"
export CARGO_TARGET_DIR="$HOME/robot-checks/build"
export CARGO_BUILD_JOBS=4
export RUSTC_WRAPPER=""
export CARGO_BUILD_RUSTC_WRAPPER=""
uv run --no-project python verify_source.py > linux_source_before.json
uv run --no-project python gate.py linux_check -- cargo +nightly-2026-09-29 check --locked -p robot-viz --all-targets
uv run --no-project python verify_source.py > linux_source_after.json
