#!/usr/bin/env bash
# r4 全仓停在 S1 旧测试断言后，独立执行尚未运行的生产软件门。
set -euo pipefail
export PATH="$HOME/.cargo/bin:$HOME/.local/bin:$PATH"
cd "$HOME/robot-checks/viz-final-r4"
export CARGO_TARGET_DIR="$HOME/robot-checks/build"
export CARGO_BUILD_JOBS=4
export RUSTC_WRAPPER=""
export CARGO_BUILD_RUSTC_WRAPPER=""
uv run --no-project python gate.py linux_s0_shutdown -- cargo +nightly-2026-09-29 test --locked -p robot-s0 --features test-comm-fault-hook --test comm_fault_startup -- --test-threads=1 --nocapture
uv run --no-project python gate.py linux_rt_guard -- cargo +nightly-2026-09-29 test --locked -p robot-s0 --lib --features rt_guard
uv run --no-project python gate.py linux_tools_release -- cargo +nightly-2026-09-29 build --locked --profile release-tools -p robot-viz --jobs 2
uv run --no-project python verify_source.py > linux_source_after.json
