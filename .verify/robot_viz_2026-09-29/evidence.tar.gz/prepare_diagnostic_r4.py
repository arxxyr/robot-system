"""冻结诊断第四轮源码；仅叠加两处 Linux nightly lint 等价修正。"""
import hashlib
import io
import json
import tarfile
from pathlib import Path

root = Path.cwd()
base = root / 'target/hardware_smoke_20260929/diagnosis'
output = base / 'source_r4.tar.gz'
assert not output.exists()
manifest_path = base / 'source_manifest_r3.json'
manifest = json.loads(manifest_path.read_text())
changed = 'crates/robot-s0/src/bin/s0_daemon.rs'
data = (root / changed).read_bytes()
digest = hashlib.sha256(data).hexdigest()
assert digest == 'ba2f8c5a0fb183670b32adc432bc00238332339b23b6f13ff0fbb4283fcb64c7'
old = next(row for row in manifest['files'] if row['path'] == changed)
manifest['source_revision'] = 'diagnostic-linux-r4'
manifest['prior_manifest_sha256'] = hashlib.sha256(manifest_path.read_bytes()).hexdigest()
manifest['delta'] = {'path': changed, 'before_sha256': old['sha256'], 'after_sha256': digest,
                     'reason': '两处 map/unwrap_or_default 等价改成 map_or_else；r3 Clippy FAIL 保留'}
old.update(sha256=digest, bytes=len(data))
encoded = (json.dumps(manifest, ensure_ascii=False, indent=2) + '\n').encode()
(base / 'source_manifest_r4.json').write_bytes(encoded)
replacements = {changed: data, 'source_manifest.json': encoded}
with tarfile.open(base / 'source_r3.tar.gz', 'r:gz') as src, tarfile.open(output, 'w:gz') as dst:
    seen = set()
    for member in src.getmembers():
        name = member.name.removeprefix('./')
        if name in replacements:
            payload = replacements[name]
            member.size = len(payload)
            dst.addfile(member, io.BytesIO(payload))
            seen.add(name)
        else:
            dst.addfile(member, src.extractfile(member) if member.isfile() else None)
    assert seen == set(replacements)
script = (root / 'target/robot_viz_20260929/check_diagnostics_linux_r3.sh').read_text()
script = script.replace('diagnostics-20260929-r3', 'diagnostics-20260929-r4').replace('source_r3.tar.gz', 'source_r4.tar.gz')
(root / 'target/robot_viz_20260929/check_diagnostics_linux_r4.sh').write_text(script)
print(json.dumps({'manifest_sha256': hashlib.sha256(encoded).hexdigest(),
                  'source_archive_sha256': hashlib.sha256(output.read_bytes()).hexdigest(),
                  'files': len(manifest['files'])}))
