#!/usr/bin/env bash
# 首轮 Ubuntu 镜像下载 503 后重试，复用已校验的软件包缓存。
set -euo pipefail
sudo env DEBIAN_FRONTEND=noninteractive apt-get -o Acquire::Retries=3 install -y \
  build-essential pkg-config libudev-dev libssl-dev clang cmake git curl \
  ca-certificates rsync python3
curl --proto '=https' --tlsv1.2 -fsSL https://sh.rustup.rs -o /tmp/robot-viz-rustup-init.sh
sh /tmp/robot-viz-rustup-init.sh -y --profile minimal \
  --default-toolchain nightly-2026-09-29 --component clippy --component rustfmt
"$HOME/.cargo/bin/rustc" +nightly-2026-09-29 --version
"$HOME/.cargo/bin/cargo" +nightly-2026-09-29 --version
