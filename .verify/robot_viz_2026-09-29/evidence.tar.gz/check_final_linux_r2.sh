#!/usr/bin/env bash
# 冻结合并源码的 Linux ARM 软件门；不访问机器人或真实串口。
set -euo pipefail
revision="$1"
case "$revision" in final-r[0-9]) ;; *) exit 2 ;; esac
export PATH="$HOME/.cargo/bin:$HOME/.local/bin:$PATH"
host_inputs="/Users/loosqk/repo/rust/robot-system/target/robot_viz_20260929/$revision"
dest_dir="$HOME/robot-checks/viz-$revision"
test ! -e "$dest_dir"
mkdir -p "$dest_dir"
tar xzf "$host_inputs/source.tar.gz" -C "$dest_dir"
cd "$dest_dir"
export CARGO_TARGET_DIR="$HOME/robot-checks/build"
export CARGO_BUILD_JOBS=4
export RUSTC_WRAPPER=""
export CARGO_BUILD_RUSTC_WRAPPER=""
uv run --no-project python verify_source.py > linux_source_before.json
uv run --no-project python gate.py linux_fmt -- cargo +nightly-2026-09-29 fmt --all
uv run --no-project python gate.py linux_clippy -- cargo +nightly-2026-09-29 clippy --locked --all --all-targets -- -D warnings
export ROBOT_VIZ_TEST_ARTIFACTS="$PWD/artifacts"
uv run --no-project python gate.py linux_viz_integration -- cargo +nightly-2026-09-29 test --locked -p robot-viz --test observer_roundtrip -- --ignored --test-threads=1 --nocapture
uv run --no-project python gate.py linux_viz_units -- cargo +nightly-2026-09-29 test --locked -p robot-viz --lib
uv run --no-project python gate.py linux_transport -- cargo +nightly-2026-09-29 test --locked -p robot-transport -- --test-threads=1
uv run --no-project python gate.py linux_transport_mock -- cargo +nightly-2026-09-29 test --locked -p robot-transport --no-default-features --features mock
uv run --no-project python gate.py linux_peer_build -- cargo +nightly-2026-09-29 build --locked -p robot-s0 -p robot-s1 -p robot-rpc -p robot-cli --bins --features robot-s1/test-fault-backend,robot-rpc/client --message-format=json
mkdir native_peers
for name in s0_daemon s1_daemon robot_rpc_gateway robotctl; do
  cp "$CARGO_TARGET_DIR/debug/$name" "native_peers/$name"
done
uv run --no-project python - <<'PY'
import hashlib,json
from pathlib import Path
rows={}
for path in sorted(Path('native_peers').iterdir()):
    rows[path.name]={'path':str(path.resolve()),'sha256':hashlib.sha256(path.read_bytes()).hexdigest(),'bytes':path.stat().st_size}
Path('linux_peers.json').write_text(json.dumps(rows,indent=2)+'\n')
PY
export B4_E2E_BIN_S0_DAEMON="$PWD/native_peers/s0_daemon"
export B4_E2E_BIN_S1_DAEMON="$PWD/native_peers/s1_daemon"
export B4_E2E_BIN_ROBOT_RPC_GATEWAY="$PWD/native_peers/robot_rpc_gateway"
export B4_E2E_BIN_ROBOTCTL="$PWD/native_peers/robotctl"
uv run --no-project python gate.py linux_workspace -- cargo +nightly-2026-09-29 test --locked --workspace --features robot-s1/test-fault-backend -- --test-threads=1
uv run --no-project python gate.py linux_s0_shutdown -- cargo +nightly-2026-09-29 test --locked -p robot-s0 --features test-comm-fault-hook --test comm_fault_startup -- --test-threads=1 --nocapture
uv run --no-project python gate.py linux_rt_guard -- cargo +nightly-2026-09-29 test --locked -p robot-s0 --lib --features rt_guard
uv run --no-project python gate.py linux_tools_release -- cargo +nightly-2026-09-29 build --locked --profile release-tools -p robot-viz --jobs 2
uv run --no-project python verify_source.py > linux_source_after.json
