# r4 lifecycle 测试差异独立审查

日期：2026-09-29。审查者：baseline_gate_diagnosis。结论：本次测试判据调整未发现实质阻断；保留原压力与回收门，并补齐镜像 worker 引入后的实际 Node 生命周期。此为只读源码及来源审查，不是 r4 原生运行通过回执。

## 来源绑定

独立解析并比较 `final-r3/source_manifest.json` 与 `final-r4/source_manifest.json` 的全部 620 项：路径集合相同，唯一变化为 `crates/robot-rpc/src/events_subscribe.rs`。结果与 `final-r4/source_delta.json` 一致。

| 输入 | SHA-256 |
|---|---|
| r3 manifest | `9d06debc169d92e3b9ba99a84f0c7e6e82d0ce70bf289692c44d72f5ee5ae103` |
| r4 manifest | `87884e0e69a6eb87ffc973f72ca585b2021df117ee7eb50c938c1fb12c311340` |
| r4 source_delta | `a6b6af3470f102e94ec24c5d6152508ded67ee04b623f5cf24d2925533f72a3e` |
| HEAD/r3 测试文件 | `b8fcd935d9a502eb8519c2d8e1995f2a63bf1f85141470bc800f997497f39bdf` |
| 当前/r4 测试文件 | `b5731dcf572db395dc41f7360d419e157dc7b54405163f11eafd32dffb7a9bf0` |

HEAD 文件确实匹配 r3，当前文件确实匹配 r4。独立字节比较确认 `#[cfg(test)]` 之前的生产内容完全不变；diff 仅发生在 Linux 专有 `tests::node_lifetime` 中。

## 判据保留与增强

下列行号均针对上述 r4 文件。

| 判据 | 源码证据 | 审查结论 |
|---|---|---|
| 隔离与原压力 | 620–676、786–844 | 独立子进程、继承 FD 哨兵关闭验证、NOFILE 软/硬上限 128、256 轮均保留；父进程仍以 30 秒为上限，超时 kill 后真实 wait 并判 FAIL，stdout/stderr 双管道读取和线程 join 未删除。 |
| 实际 Node 识别 | 747–779 | 仍仅从本进程 `/proc/self/fd` 的真实 `iox2_node.details` 取得完整父目录；数量精确匹配，目录当时必须存在；退出后逐个检查 `!path.exists()`，空目录残留也失败，没有调用全局删除来制造通过。 |
| 镜像真实初始化 | 852–874 | 先记唯一主 Node；等待镜像 monitor.ready，初始化失败或过早 finished 均失败，保持 2 秒有界等待；再取得主/镜像两 Node 并验证集合包含关系，差集恰为镜像 Node。 |
| subscriber 真实入口与数据 | 875–909 | 仍从真实 `spawn_events_subscribe_thread` 创建 subscriber，并取得第三个 Node；真实 publish→gateway 事件的 action_id/request_id/时间戳/Started 类型与 2 秒可达性判据未变。 |
| subscriber 回收 | 911–915 | request_stop 后真实 join，再 drop rx；剩余集合必须精确等于原两个 publisher Node，subscriber 差集目录必须消失。 |
| 镜像回收与预约归零 | 916–928 | drop publisher 后要求 finished/reaped 均真，初始化与 join 错误均零，pending_frames/pending_bytes/estimated_shm_bytes 均零；剩余集合精确等于主 Node，镜像目录真实消失。 |
| 最后主 Node 回收 | 929–931、842–844 | drop 主 Node 后实际观察数为零，原全部三 Node 目录逐一不存在；256 轮结束后的 FD 数仍不得超过初始 baseline。 |

生产入口的 ready 握手在该文件 222–248 行：subscriber 构造完成后发送 ready，spawn 返回前接收成功，所以第三 Node 的采样未使用睡眠猜测初始化完成。镜像侧交叉核对 `crates/robot-transport/src/iceoryx2/observer.rs:561–585`：ready 在真实 Node、SHM 预约和 publisher 创建成功之后写入。

交叉核对同一 observer 文件 498–515：reaped 在真实 `JoinHandle::join()` 返回后设置，panic 同时增加 join_failures，因此测试不能仅以 finished 代替真实回收；worker 退出 RAII 同时释放 worker 预约。376–384、637–644 的 RAII 分别归还队列与 SHM 预约，测试在 publisher Drop 返回后检查本发布者三项计数为零。

## 宣称边界

- “资源归零”在本门具体指本轮 Node 目录、累计 FD 基线，以及该镜像发布者的排队帧/字节/估算 SHM 预约；不是测量操作系统全部映射字节或整个系统资源。
- 镜像是有损观察通道，此门验证创建/真实回收及原 gateway 事件仍可达，不新增镜像逐帧必达保证。
- 父进程原 30 秒监督预算未放宽；256 轮新增镜像创建/回收是否在该预算内完成，以 root 当前 r4 原生流水线实测为准。
- 未运行 Cargo，未访问或修改 VM，未修改生产/测试代码；仅新建本审查文件。r1/r2/r3 旧失败与原日志不覆盖，r4 结果等待真实回执。
