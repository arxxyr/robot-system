"""只以实际回执封口软件验收；不将未运行或失败的门改写成成功。"""
import hashlib
import json
import re
from pathlib import Path

root=Path('target/robot_viz_20260929')
linux=root/'linux_extracted'
def digest(path):
    data=path.read_bytes()
    return {'path':str(path.relative_to(root)),'sha256':hashlib.sha256(data).hexdigest(),'bytes':len(data)}
def json_read(path):
    return json.loads(path.read_text())
gates={}
for rev in ['r1','r2','r3','r4','r5','r6']:
    rows=[]
    for path in sorted((linux/f'viz-final-{rev}').glob('*.json')):
        receipt=json_read(path)
        if not isinstance(receipt,dict) or not {'command','wait_returncode','log_sha256'} <= receipt.keys():
            continue
        log=path.with_suffix('.log')
        data=log.read_bytes()
        assert hashlib.sha256(data).hexdigest()==receipt['log_sha256']
        assert len(data)==receipt['log_bytes'] and receipt['reaped']
        groups=[{'result':m[1],'passed':int(m[2]),'failed':int(m[3]),'ignored':int(m[4])}
                for m in re.finditer(r'test result: (\w+)\. (\d+) passed; (\d+) failed; (\d+) ignored;',data.decode(errors='replace'))]
        rows.append({'gate':path.stem,'returncode':receipt['wait_returncode'],'reaped':receipt['reaped'],'elapsed_seconds':receipt['elapsed_ns']/1e9,'groups':groups,'receipt':digest(path)})
    gates[rev]=rows
def gate(rev,name):
    return next(v for v in gates[rev] if v['gate']==name)
for name in ['linux_fmt','linux_clippy','linux_viz_integration','linux_viz_units','linux_transport','linux_transport_mock','linux_peer_build']:
    assert gate('r3',name)['returncode']==0,name
for name in ['linux_fmt','linux_clippy','linux_node_lifecycle','linux_rt_guard','linux_tools_release','linux_release_help']:
    assert gate('r4',name)['returncode']==0,name
for name in ['linux_fmt','linux_clippy','linux_s1_node_lifecycle','linux_s0_shutdown','linux_workspace']:
    assert gate('r6',name)['returncode']==0,name
assert gate('r3','linux_workspace')['returncode']!=0
manifest=json_read(root/'final-r6/source_manifest.json')
host_differences=[]
for item in manifest['files']:
    path=Path(item['path'])
    if 'link' in item:
        assert str(path.readlink())==item['link']
    elif hashlib.sha256(path.read_bytes()).hexdigest()!=item['sha256']:
        host_differences.append(str(path))
assert set(host_differences) <= {'CLAUDE.md'},host_differences
assert '17 passed; 0 failed' in (root/'logs/viz_units_r3.log').read_text()
assert '6 passed; 0 failed' in (root/'logs/observer_roundtrip_r2.log').read_text()
assert json_read(root/'viewer_r2/rrd_verify.json')['wait_returncode']==0
for mode in ['live_normal_r2','live_disconnect_r2']:
    assert json_read(root/mode/'rrd_verify.json')['wait_returncode']==1
    assert 'Missing RRD footer' in (root/mode/'rrd_verify.log').read_text()
for name in ['linux_source_before.json','linux_source_after.json']:
    proof=json_read(linux/'viz-final-r6'/name)
    assert proof['source_matches'] and proof['files']==620
    assert proof['manifest_sha256']==digest(root/'final-r6/source_manifest.json')['sha256']
peer_baseline=json_read(linux/'viz-final-r3/linux_peers.json')
for revision in ['r3','r4','r6']:
    rows=json_read(linux/f'viz-final-{revision}/peer_readback.json')
    assert len(rows)==4
    for row in rows:
        original=peer_baseline[Path(row['path']).name]
        assert row['sha256']==original['sha256'] and row['bytes']==original['bytes']
assert json_read(linux/'processes_after.json')['empty']
source_proof={'checked_files':len(manifest['files']),'manifest':digest(root/'final-r6/source_manifest.json'),'r3_to_r4':json_read(root/'final-r4/source_delta.json'),'r4_to_r5':json_read(root/'final-r5/source_delta.json'),'r5_to_r6':json_read(root/'final-r6/source_delta.json'),'host_document_only_differences':host_differences,'linux_before':json_read(linux/'viz-final-r6/linux_source_before.json'),'linux_after':json_read(linux/'viz-final-r6/linux_source_after.json')}
result={'status':'SOFTWARE_ACCEPTED','date':'2026-09-29','base_commit':manifest['base_commit'],
    'scope':'Rerun 0.38.1 独立只读观测桥及有界隔离镜像；macOS和隔离Linux ARM软件验收；无Orin部署或新硬件动作',
    'sources':source_proof,'linux_gates':gates,
    'linux_release':{'source_revision':'final-r4','identity':json_read(linux/'release_tool_identity.json'),'boundary':'相较r3累计只有三个 Linux 测试模块修订，生产/依赖输入相同，优化产物在 VM 保留，未安装 Orin'},
    'macos':{'viz_units':17,'explicit_shm_integration':6,'observer_mirror_integration':9,'targeted_clippy':'PASS','root_workspace_clippy':'NOT_APPLICABLE_EXISTING_LINUX_ONLY_S0_API','cargo_deny':'PASS_WITH_RECORDED_EXACT_EXCEPTIONS_AND_EXISTING_DUPLICATE_WARNINGS'},
    'viewer':json_read(root/'viewer_final_result.json'),
    'ci':{'actionlint_and_structure':'PASS','remote_workflow':'NOT_RUN_NO_PUSH','evidence':digest(root/'ci_static_final_result.json')},
    'review':[digest(root/name) for name in ['static_review_r3.md','dynamic_review_r3.md','lifecycle_review_r4.md','lifecycle_review_r5.md','lifecycle_r6_delta_review.json','shutdown_review_r5.md','dependency_review.md']],
    'known_limits':['镜像有损，单topic多publisher首连接持续饱和可能饿死后来者；未见实例不计gap，不是完整审计','本次GUI80帧10类含67gap；另一次正常文件1000帧10类11实例gap/drop/reject为0，不外推无丢失','512MiB仅活跃worker估算SHM预约；持有loan可晚于credit释放，不是常驻内存绝对上限','CPU Tensor无损转f64；GPU预览有f32范围限制、色阶逐帧变化，中文原文字体可能缺字','两份接收端中断捕获缺footer，verify真实FAIL；桥正常save文件verify PASS','Viewer实时新Recording初始化时一次Timeline警告保留；随后画面/时间线通过','静态媒体夹具不代表生产相机/点云接入；无FK/外参/物理单位推测','Linux完整workspace使用串行与明确绑定peer；不关闭既有S1默认并行超时根因','Orin SSH信任仍待核，未安装；右H2整体FAIL、D15 OPEN、deployable=false保持'],
    'historical_failures_preserved':['Mac早轮Clippy与依赖审计','Linux r1 trybuild上下文、r2双publisher夹具、r3 RPC和r4 S1旧Node数量oracle','r4退出11pass2fail：ANSI日志匹配、父监督从READY计时早于真实arm+原收尾预算','r5 S1测试新增零尺寸引用参数Clippy失败，r6仅等价按值修订','首次Viewer异步加载错误页、Tensor自动色阶','GUI SIGINT r1日志重名前置失败','两份live接收端RRD缺footer'],
    'frozen_design_changed':False,'pushed':False,
    'archive_layout':{'paths':'均相对证据包解包根目录','linux_extracted':'Linux原件只存一份于 linux_evidence.tar.gz；将其解到 linux_extracted/ 即与本摘要逻辑路径一致','source_archives':'各 final-rN/source.tar.gz 保存当轮完整构建输入；早期FAIL不覆盖'},
    'cleanup':{'vm_state':'Stopped','vm_stop_receipt':'vm_stop.json','vm_snapshot':'vm_after.json','viewer':'viewer_r2/cleanup.json','linux_process_snapshot':'linux_extracted/processes_after.json'}}
assert json_read(root/'vm_after.json')['state']['status']=='Stopped'
assert json_read(root/'vm_stop.json')['wait_returncode']==0
with (root/'final_result.json').open('x') as file:
    json.dump(result,file,ensure_ascii=False,indent=2);file.write('\n')
with (root/'linux_gate_summary.json').open('x') as file:
    json.dump(gates,file,ensure_ascii=False,indent=2);file.write('\n')
print(json.dumps({'status':result['status'],'final_workspace':gate('r6','linux_workspace'),'final_shutdown':gate('r6','linux_s0_shutdown'),'final_rt_guard':gate('r4','linux_rt_guard')},ensure_ascii=False))
