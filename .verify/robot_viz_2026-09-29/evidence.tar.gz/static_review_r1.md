# Rerun 静态独审 r1：动态验收待完成

审查时间：2026-09-29T21:08:44.148378+00:00。独立评审 next_step_review；本次未执行 Cargo、SSH 或硬件操作。

**结论：这份源码未发现尚未解决的生产代码阻断；仅认可静态结构，不宣称 Rerun 动态验收完成。**

来源绑定：`final-r1/source_manifest.json`，SHA256 `655e7a3e813364da15ec38a121daaed8bd74462787722937ceacbd5f7fe1779e`，基线提交 `46981c27364a176f913876c28808e873560c36a5`。下列 20 项已独立逐件检查内容 SHA 与清单完全一致。清单涵盖文件内容，不能替代编译、运行或 Viewer 证据。

静态认可范围：

- 原 pub/sub QoS、原始 wire、主发布返回和 recipients 保留；非 RT 发布成功后仅将已有 owned wire 交给有界队列。独立 mirror worker 承担创建、连接、发送，失败只影响观测。
- 8 帧队列、每 schema 字节预算、32 MiB 全局 owned wire、32 worker；Static SHM 8 slots/worker 的 512 MiB 是含余量的估算预约，不能称整个进程的精确内存上限。失败、丢弃及退出使用 RAII 退预算；Drop 真 join，不 detach。
- 只 open 既有镜像；观测 Node 禁全局 dead-node 清扫。SDK 创建等待有限，DiscardData 路径不无限背压；不声称任意内核/SDK 永久卡死都可有界退出。
- 十类 pub/sub schema 转换；配置/广播布局按 robot/hardware 校验。header 零/未来时间在布局插入前拒绝，body stamp 用于新鲜度；成功 receive 后才取接收时刻。Unknown、EStop 事件字段、陈旧与无数据均不等同物理安全确认。
- 实例独立实体与序号/丢帧窗口；拒绝镜像序号重复/倒退及累计丢帧回退。attach 前累计值只保留 metadata；实例淘汰后新建的是计数窗口，不能称全生命周期精确去重。
- 5 秒无帧后 Drop 观察订阅，允许重新发现；保留旧 RRD 历史和有界报告，退订不代表任务结束。SDK worker 由父进程监督，早退有子进程 RAII，正常/故障结果只在真实 wait 后报告回收。

已回修的重要问题：原通道慢观察者背压；多发布者交替误判重启；receive 前取时钟误拒合法新样本；被拒布局广播副作用；历史 Action topic 累计占满 64 个槽位；监督器早退遗留子进程。新增“拒绝布局仍未知”和“超过 f64 精确整数范围的 SDK 纳秒/序号”两项纯测已只读核对结构，尚未据此计 PASS。

当前证据与待验责任：

1. `logs/clippy_r6.log` 显示本轮定向 Clippy 正常完成；旧 r1–r5 失败日志保留。根 workspace/Linux 门和最终运行结果仍须对应清单核验。
2. main 统一执行转换/实例/时间纯测，以及 `observer_roundtrip` 六个显式 ignored 真 SHM 黑盒：十类数据加双合法 EStop 实例、三类坏输入拒绝、输出初始化失败、不可响应 Viewer、SIGINT 父到 worker、累计 72 个短命 Action topic 回收再发现。RRD 须由官方 Arrow 解码确认实际标量/像素/坐标/张量/事件，并核 mirror 真实 join 与预算归零。
3. baseline 提供 target-only `live_viewer_check.py`；root 唯一执行同版 Viewer 实连、成功后断开、官方 RRD verify 与真实渲染。文件增长和报告不能替代 RRD 完整性/画面证据；不可响应端口测试不能替代成功连接后的断开。
4. root 完成 Linux ARM 原生质量门、已有 S0/S1 监督退出定向回归和证据归档。单独 transport join 测试不能替代既定退出预算回归。

部署/安全边界：transport 的非 RT publisher 行为确有新增 worker，不能写“生产运行时完全未变”；Rerun SDK 保持独立工具进程。本轮未重部署 Orin 正式冻结二进制，未做硬件 RT 再测，不关闭通信硬化硬件缺项或 D15，不构成正式退役、无人值守或物理安全验收。

## 已绑定文件

| 文件 | SHA256 |
|---|---|
| `crates/robot-transport/src/iceoryx2/attributes.rs` | `91a0f4b60b8105a58e4c50b230deb6ff20e4985786a204f38369fecba7d4b9fe` |
| `crates/robot-transport/src/iceoryx2/mod.rs` | `e15110c8fbf1c7facb865b2063e361a556fe5bb265f9b6926e60e10a86901e65` |
| `crates/robot-transport/src/iceoryx2/observer.rs` | `9ab4abb36a8fcaaa114c80ecde5a4b651709e60e624c328a182c37e614aa6216` |
| `crates/robot-transport/src/iceoryx2/publisher.rs` | `c1b18c6bd00a3161dbadc1c87440b610745754635ca6816a97148127b919a4e6` |
| `crates/robot-transport/src/iceoryx2/qos.rs` | `afb7fa743ac78f97c9844a4d754e4cd3a9d53dccff74f05635b86364261e2a2b` |
| `crates/robot-transport/src/iceoryx2/request_response.rs` | `98ad737ee194e8fdebcaad185506731c8bc4f6817e7196d08fac85400260ca00` |
| `crates/robot-transport/src/iceoryx2/service_name.rs` | `6df9b5eb4bc2d7f080915234cb7b920a6cab28249b5d79a479a81a2bf10a082c` |
| `crates/robot-transport/src/iceoryx2/subscriber.rs` | `98c86e1e76717cea638c2c7cd1fee2d5cd3028aef50ee62d3755b73ee3e3ac37` |
| `crates/robot-viz/Cargo.toml` | `7f7efdec4435b844cc02350530b4f9a7ece797014daa8208e8fde99f7c21e11a` |
| `crates/robot-viz/src/config.rs` | `c9e6326f24c67bb4e74a5c0857ca9160ec7c3d19973ba41c3e94aab539122478` |
| `crates/robot-viz/src/decode.rs` | `f7761dd703496780c63c9e761be972c4095095fbdda1e825f5c6374e8192d948` |
| `crates/robot-viz/src/input.rs` | `76797e4828dc7c1c05590a45772eae18d20061c4e55eb2118d21644cc1c96aee` |
| `crates/robot-viz/src/lib.rs` | `aa363e3dbefd58c33fb88166c90964e9b86a542db72ee5ee00039978a820ea27` |
| `crates/robot-viz/src/main.rs` | `a11cf8fe5a21a4c8593544c846de8c32d55aaef794e592a27000202896cad9ac` |
| `crates/robot-viz/src/media.rs` | `42adbaa45ba4e26db2bc5abe96b09943976deface8813c3135e79f5e6add90e2` |
| `crates/robot-viz/src/output.rs` | `9ed85240af022c8a365ca264864e87aa376a43f482635d8e877d04de603e9bc2` |
| `crates/robot-viz/src/runtime.rs` | `83ae6432f198321e5f0e3cbac2e6eb044c2310b7d8853eebd3bca3b130acf9de` |
| `crates/robot-viz/src/supervisor.rs` | `d209b399696a6afe07bddfa7e0e2a87b8c111cb5891b002ff49eaf5d659fba5a` |
| `crates/robot-viz/tests/observer_roundtrip.rs` | `321cd78ab48364d74ccadb20eb4b9c1c80f6e9658c6cd17dc0c3286549f879e4` |
| `crates/robot-viz/tests/support/fixtures.rs` | `c0c1db56265ea343a26efb4cf78270533d3d32e8ba7d5a358248977d51ebd98b` |
