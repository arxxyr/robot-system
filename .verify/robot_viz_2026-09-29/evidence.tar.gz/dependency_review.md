# Rerun 依赖审计独立核查

核查日期：2026-09-29。核查者：baseline_gate_diagnosis；root 采纳精确例外并授权落盘。
范围：本地锁文件、Cargo manifests、已下载 crate 许可证与源码、首次 deny 日志、上游官方资料。
本核查未运行 Cargo，未变更任何依赖版本、源码或硬件。配置验收由主开发统一执行。

## 输入身份与原始失败

- 比较基线：`46981c27364a176f913876c28808e873560c36a5` 的 `Cargo.lock`。
- 本轮锁文件 SHA-256：`44bebebce3f2042e4be87ae61426c5cfa745eeb1d5bf4dbe1fa44a795050700a`。
- 原件：`target/robot_viz_20260929/logs/deny_r1.log`，SHA-256：`0f35ca80f89585144e9052778587f81100414b83e28990ccd4625622336596e5`。
- 该原件包含四项许可证拒绝、`paste` unmaintained、`serialport` yanked；汇总为 `advisories FAILED, bans ok, licenses FAILED, sources ok`。原 FAIL 留存；重复版本警告不属于这六项硬失败。
- `Cargo.toml:117` 原有 `serialport = "4"`；`:141` 本轮 SDK 精确固定为 Rerun 0.38.1、关闭默认 features、仅启用 sdk。关闭 analytics feature 不等于依赖图没有 `re_analytics`：认证链仍传递引入该包。

## 新增与既有依赖的区分

通过 Python `tomllib` 分别解析上述基线与当前锁文件，不调用 Cargo。前五包在基线中均不存在；serialport 的版本与 checksum 完全相同。

| 包 | 本轮来源或使用域 | 核实的许可证/公告 | 处理范围 |
|---|---|---|---|
| indent 0.1.1 | re_chunk_store / re_query → Rerun → robot-viz | MPL-2.0 | 仅该包精确版本许可证例外 |
| option-ext 0.2.0 | dirs-sys → directories → re_auth / re_analytics → re_redap_client → Rerun | MPL-2.0 | 同上 |
| webpki-roots 1.0.9 | ureq → ehttp → 认证/分析客户端 → Rerun | CDLA-Permissive-2.0 | 同上 |
| xxhash-rust 0.8.19 | re_log_encoding / re_log_types → Rerun；viz 测试也使用编码包 | BSL-1.0 | 同上 |
| paste 1.0.15 | re_query / re_string_interner → Rerun | MIT OR Apache-2.0；RUSTSEC-2024-0436 | 仅此停止维护公告 ID 例外 |
| serialport 4.10.0 | robot-adapter-feetech 的 real-hw → S0 / robot-tests | MPL-2.0；版本已撤回 | 仅 serialport@4.10.0 撤回版本例外 |

serialport 的旧/新 checksum 均为 `6a2f4ac56b5d3af3c40fbbee17be96d532cba02fa5853926aacdb77d926272ab`。新增五包的维护与许可证审计成本归于本轮 SDK 引入；serialport 撤回版本风险是既有锁文件风险。

本地 registry 根为 `/Users/loosqk/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/`。已核各包 `Cargo.toml` 声明，并定位许可证原文：`indent-0.1.1/LICENSES/MPL-2.0.txt`、`option-ext-0.2.0/LICENSE.txt`、`webpki-roots-1.0.9/LICENSE`、`xxhash-rust-0.8.19/LICENSE`；paste 有 MIT/Apache 双文件，serialport 为 `LICENSE.txt`。依赖路径见原 deny 日志 1–109、1810–1919、1922–1934 行。

## paste 公告边界

[RustSec 官方公告](https://rustsec.org/advisories/RUSTSEC-2024-0436.html) 将该包归为停止维护，上游已归档，未列出修复版本，并给出 pastey / with_builtin_macros 等替代方向。本地 `paste-1.0.15/Cargo.toml` 的 `lib.proc-macro=true`；它在编译期展开宏，但生成代码进入消费者，不因此宣称零风险。

本轮接受当前维护风险，不把公告写成已修复漏洞，也不把潜在替代当作已完成迁移。替代需要复核上游 SDK 使用与构建结果，不在本轮直接替换。按[官方 cargo-deny 配置](https://embarkstudios.github.io/cargo-deny/checks/advisories/cfg.html)仅登记公告 ID，配置本身不提供对该 ID 的精确版本约束；reason 与 CHANGELOG 绑定当前 paste/SDK 版本。SDK/paste、路径、公告变化及下次发布审计时复审，有可采用替代或移除依赖后删除豁免。

## serialport 撤回与后续版本证据

只读 [crates.io 官方版本 API](https://crates.io/api/v1/crates/serialport/versions) 时，4.10.0 为 yanked=true，更新时刻 2026-09-08T19:46:37.960739Z；4.10.1 为 yanked=false，发布时刻 2026-09-08T19:44:43.072187Z。API 没有直接给出撤回理由，因此不将两个事件的接近时间等同于维护者说明。

[上游 issue #375](https://github.com/serialport/serialport-rs/issues/375) 的后续讨论将编译问题缩小至 Linux PowerPC；[修复 PR #376](https://github.com/serialport/serialport-rs/pull/376) 和 [4.10.1 发布 PR #377](https://github.com/serialport/serialport-rs/pull/377)确认该补丁发布修复这一问题。只读[官方标签差异](https://github.com/serialport/serialport-rs/compare/v4.10.0...v4.10.1)及对应 GitHub compare API，生产源码只改 `src/posix/tty.rs` 两个 baud 分支，从裸整数改为 `Ok(...)`；另有 CI、版本与 changelog 变更，manifest 没有新增依赖。

本地 4.10.0 `src/posix/tty.rs:454–460` 对该函数仅启用 illumos 或 Linux powerpc/powerpc64；`:494–497` 的两个待修分支又限 Linux，当前 Linux aarch64 不编译此路径。它证明本次已知编译缺陷的平台边界，不证明撤回没有其他原因，也不代替升级后项目回归。

本轮保留串口版本；后续独立采用 4.10.1 或其他已审版本时须同步许可证例外、执行 real-hw 软件与 S0 串口/退出回归，并按实际变更决定额外硬件门。本轮不预先授予升级或硬件通过结论。版本、目标平台、相关公告变化及下次发布审计时复审；完成替换即移除精确撤回例外。

## 已落地范围与验证状态

先在 `docs/CHANGELOG.md` 紧随 Rerun 段登记偏离，再在 `deny.toml` 增加四项精确许可证例外、两项带 reason 的公告/包版本例外。全局 `yanked="deny"`、全局许可证 allow、bans/sources 规则不变，原有 assert_no_alloc 与 serialport 许可证例外保留。

使用 `uv run --no-project python` 完成 TOML 解析、旧新锁比较、例外范围和全局规则断言，并用 `git diff --check` 检查两个跟踪文件，均通过。Cargo.lock SHA 在修改后与输入相同。没有运行 cargo deny 或其他 Cargo；配置语法和实际门禁是否接受这些例外，仍以主开发后续复验原件为准，不预填通过。

本说明属于工程依赖来源与门禁范围核查；不扩大现有硬件验收边界，不关闭右 H2、D15 或 deployable=false 的限制。后续归档应同时保留首次 FAIL、配置与锁文件身份、复验日志及该说明，不覆盖旧原件。
