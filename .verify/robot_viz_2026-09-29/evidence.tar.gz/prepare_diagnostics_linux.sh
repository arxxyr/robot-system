#!/usr/bin/env bash
set -euo pipefail
source_dir=/Users/loosqk/repo/rust/robot-system/target/hardware_smoke_20260929/diagnosis
dest_dir="$HOME/robot-checks/diagnostics-20260929"
test ! -e "$dest_dir"
mkdir -p "$dest_dir"
tar xzf "$source_dir/source.tar.gz" -C "$dest_dir"
curl --proto '=https' --tlsv1.2 -fsSL https://astral.sh/uv/install.sh -o /tmp/robot-viz-uv-install.sh
sh /tmp/robot-viz-uv-install.sh
"$HOME/.local/bin/uv" --version
