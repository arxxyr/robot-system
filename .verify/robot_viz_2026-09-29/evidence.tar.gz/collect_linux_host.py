import datetime,hashlib,json,subprocess,tarfile
from pathlib import Path
root=Path('target/robot_viz_20260929')
archive=root/'linux_evidence.tar.gz'
log=root/'linux_collect.stderr.log'
command=['limactl','shell','robot-viz-check','--','/home/loosqk.guest/.local/bin/uv','run','--no-project','python','/Users/loosqk/repo/rust/robot-system/target/robot_viz_20260929/collect_viz_linux.py','viz-final-r1','viz-final-r2','viz-final-r3','viz-final-r4','viz-final-r5','viz-final-r6']
with archive.open('xb') as out,log.open('xb') as err:
    proc=subprocess.Popen(command,stdout=out,stderr=err)
    rc=proc.wait(timeout=60)
assert rc==0,rc
with tarfile.open(archive,'r:gz') as tar:
    rows=json.load(tar.extractfile('index.json'))
    assert set(tar.getnames())=={r['path'] for r in rows}|{'index.json'}
    for row in rows:
        data=tar.extractfile(row['path']).read()
        assert len(data)==row['bytes'] and hashlib.sha256(data).hexdigest()==row['sha256'],row['path']
    # 仅解包已核验的相对普通文件，用于证据汇总。
    for member in tar.getmembers():
        assert member.isfile() and not member.name.startswith('/') and '..' not in Path(member.name).parts
    tar.extractall(root/'linux_extracted',filter='data')
receipt={'command':command,'pid':proc.pid,'wait_returncode':rc,'reaped':True,'files':len(rows),'sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'bytes':archive.stat().st_size,'verified':True}
(root/'linux_collect.json').write_text(json.dumps(receipt,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(receipt,ensure_ascii=False))
