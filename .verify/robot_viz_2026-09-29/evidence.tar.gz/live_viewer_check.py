#!/usr/bin/env python3
"""Mac 纯软件实连验收；只启动显式产物、自有测试 fixture 与本机 Viewer。

使用 uv run --no-project python live_viewer_check.py --test-binary /绝对路径/测试实件
  --robot-viz /绝对路径/robot-viz --output /全新目录 [--disconnect-viewer]

先由 root 预装/缓存 uvx 的 rerun-sdk==0.38.1；首次下载也计入本脚本 50 秒预算。
不调用 Cargo，不启动 S0/S1，不读取机器人配置或串口。RRD 完整性和渲染由 root
另行官方 verify/截图；这里的文件增长和机器报告不能替代它们。

参数依据官方 rerun 0.38.1 commands/entrypoint.rs：--bind/--port/--serve-grpc/
--save 均为 CLI 参数；--save 分支自行启动 gRPC 接收并写盘。该分支 Ctrl-C 的
非零退出如实保留，不冒充 exit 0。运行时再次用同版 --help/--version 核实。
"""

from __future__ import annotations

import argparse
import datetime
import hashlib
import json
import os
from pathlib import Path
import shutil
import signal
import socket
import subprocess
import sys
import time
import tomllib


CASE = "all_pubsub_schemas_reach_rerun_recording_without_cross_robot_leakage"
SCHEMAS = (1, 2, 3, 0x100, 0x200, 0x201, 0x202, 0x300, 0x301, 0x40A)
TOTAL_SECONDS = 50.0
# 普通工作截止后仍为 SIGTERM、SIGKILL、真实 wait 和证据落盘保留时间。
WORK_SECONDS = 34.0


class CheckFailed(RuntimeError):
    pass


def utc() -> str:
    return datetime.datetime.now(datetime.timezone.utc).isoformat()


def sha(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


class OwnedProcess:
    """直接子进程由 Popen 持有；终止信号与实际 wait 结果分别记录。"""

    def __init__(self, label: str, argv: list[str], root: Path, env: dict[str, str]):
        self.stdout_path = root / f"{label}.stdout.log"
        self.stderr_path = root / f"{label}.stderr.log"
        self.row = {
            "label": label, "command": argv, "started_utc": utc(),
            "started_monotonic_ns": time.monotonic_ns(), "signals": [],
            "reaped": False, "wait_returncode": None,
            "stdout": self.stdout_path.name, "stderr": self.stderr_path.name,
        }
        with self.stdout_path.open("xb") as out, self.stderr_path.open("xb") as err:
            self.child = subprocess.Popen(
                argv, stdin=subprocess.DEVNULL, stdout=out, stderr=err,
                env=env, start_new_session=True,
            )
        self.sid = self.child.pid
        self.retired = False
        self.row.update(pid=self.child.pid, session_id=self.sid)

    def status(self) -> int | None:
        result = self.child.poll()
        if result is not None and not self.row["reaped"]:
            self.record_wait(self.child.wait(timeout=0))
        return result

    def record_wait(self, result: int) -> int:
        self.row.update(
            wait_returncode=result, reaped=True, finished_utc=utc(),
            finished_monotonic_ns=time.monotonic_ns(),
        )
        return result

    def wait(self, seconds: float) -> int:
        return self.record_wait(self.child.wait(timeout=max(0.0, seconds)))


class Harness:
    def __init__(self, root: Path):
        self.root = root
        self.started = time.monotonic()
        self.deadline = self.started + TOTAL_SECONDS
        self.work_deadline = self.started + WORK_SECONDS
        self.processes: list[OwnedProcess] = []
        self.scopes: list[OwnedProcess] = []
        self.errors: list[str] = []
        self.audit: list[dict] = []
        self.env = os.environ.copy()
        self.env.pop("ROBOT_VIZ_INTERNAL_WORKER", None)
        self.env["RERUN_ANALYTICS_ENABLED"] = "false"
        self.env["ROBOT_LOG_FORMAT"] = "json"

    def remaining(self, deadline: float | None = None) -> float:
        return max(0.0, (self.work_deadline if deadline is None else deadline) - time.monotonic())

    def require_time(self) -> None:
        if self.remaining() <= 0:
            raise CheckFailed("普通工作超过 34 秒；保留原失败并进入有界清场")

    def start(self, label: str, argv: list[str], extra_env: dict[str, str] | None = None) -> OwnedProcess:
        self.require_time()
        env = self.env | (extra_env or {})
        proc = OwnedProcess(label, argv, self.root, env)
        self.processes.append(proc)
        self.scopes.append(proc)
        return proc

    def wait(self, proc: OwnedProcess, bound: float) -> int:
        self.require_time()
        try:
            return proc.wait(min(bound, self.remaining()))
        except subprocess.TimeoutExpired as error:
            raise CheckFailed(f"{proc.row['label']} 未在原预算内退出") from error

    def inspect_sessions(self) -> dict[int, list[dict[str, int]]]:
        """只取 PID/PPID/PGID；以 start_new_session 的自有 SID 限定后代范围。"""
        left = self.remaining(self.deadline - 1.0)
        if left <= 0:
            raise CheckFailed("已无进程目录检查预算；不能声称清场")
        label = f"process_inventory_{len(self.audit):02d}"
        proc = OwnedProcess(label, ["/bin/ps", "-axo", "pid=,ppid=,pgid="], self.root, self.env)
        self.processes.append(proc)
        try:
            code = proc.wait(min(0.8, left))
        except subprocess.TimeoutExpired:
            # 该直接子进程尚未回收，PID 仍由 Popen 持有。
            proc.child.kill()
            proc.row["signals"].append({"signal": "SIGKILL", "target": "own_pid", "at": utc()})
            try:
                proc.wait(min(0.3, self.remaining(self.deadline)))
            except subprocess.TimeoutExpired:
                pass
            raise CheckFailed("进程目录读取超时，清场证据不完整") from None
        if code != 0:
            raise CheckFailed(f"进程目录读取失败：{code}")
        owned = {scope.sid: [] for scope in self.scopes}
        active_ids = {scope.sid for scope in self.scopes if not scope.retired}
        for line in proc.stdout_path.read_text().splitlines():
            pid, ppid, pgid = map(int, line.split())
            try:
                sid = os.getsid(pid)
                # 同一快照中的旧 PID/PGID 不直接用于信号；发送前还会再次确认。
                if sid in active_ids and os.getpgid(pid) == pgid:
                    owned[sid].append({"pid": pid, "ppid": ppid, "pgid": pgid})
            except ProcessLookupError:
                continue
        for scope in self.scopes:
            if scope.row["reaped"] and not owned[scope.sid]:
                # 已确认消失的会话不再按旧 SID 查询/发信号，避免重用旧身份。
                scope.retired = True
        self.audit.append({"at": utc(), "sessions": owned})
        return owned

    def signal_scope(self, proc: OwnedProcess, signum: int, expected: bool = False) -> None:
        # fixture 自行新建 bridge 进程组；只杀测试根组会漏掉它，故按自有 session 清点。
        members = self.inspect_sessions()[proc.sid]
        for pgid in sorted({entry["pgid"] for entry in members}):
            witnesses = [entry["pid"] for entry in members if entry["pgid"] == pgid]
            live = []
            for pid in witnesses:
                try:
                    if os.getsid(pid) == proc.sid and os.getpgid(pid) == pgid:
                        live.append(pid)
                except ProcessLookupError:
                    pass
            if not live:
                continue
            event = {"signal": signal.Signals(signum).name, "pgid": pgid,
                     "session_id": proc.sid, "witness_pids": live,
                     "expected_injection": expected, "at": utc(),
                     "at_monotonic_ns": time.monotonic_ns()}
            try:
                os.killpg(pgid, signum)
                event["sent"] = True
            except ProcessLookupError:
                event["sent"] = False
                event["reason"] = "发送前进程组已经退出"
            proc.row["signals"].append(event)

    def stop_viewer(self, viewer: OwnedProcess) -> None:
        if viewer.status() is not None:
            raise CheckFailed("Viewer 在预定停止信号之前已退出")
        self.signal_scope(viewer, signal.SIGINT, expected=True)
        code = self.wait(viewer, 2.0)
        viewer.row["stop_classification"] = (
            "clean_exit_after_requested_sigint" if code == 0
            else "requested_sigint_exit" if code in (-signal.SIGINT, 128 + signal.SIGINT)
            else "unexpected_exit_after_sigint"
        )
        if code not in (0, -signal.SIGINT, 128 + signal.SIGINT):
            raise CheckFailed(f"Viewer SIGINT 后出现非预期退出码：{code}")

    def cleanup(self) -> bool:
        # 所有 scope 均是本 harness 新建 session；不按进程名扫描或操作外部进程。
        for signum, grace in ((signal.SIGTERM, 8.0), (signal.SIGKILL, 2.0)):
            try:
                inventory = self.inspect_sessions()
                active = [scope for scope in self.scopes if inventory[scope.sid]]
                if not active:
                    break
                if not self.errors and signum == signal.SIGTERM:
                    self.errors.append("验收主体结束后仍有自有进程，需要额外终止；不作为正常退出通过")
                for scope in active:
                    self.signal_scope(scope, signum)
                until = min(time.monotonic() + grace, self.deadline - 1.5)
                while time.monotonic() < until:
                    for scope in active:
                        scope.status()
                    if all(scope.row["reaped"] for scope in active):
                        break
                    time.sleep(0.02)
            except Exception as error:
                self.errors.append(f"清场步骤失败：{error}")
        # 直接 children 都真实 wait；后代是否消失由最终独立 session 快照另记。
        for proc in self.processes:
            try:
                proc.wait(min(0.1, self.remaining(self.deadline - 1.0)))
            except subprocess.TimeoutExpired:
                self.errors.append(f"未回收直接子进程：{proc.row['label']} pid={proc.child.pid}")
        try:
            final = self.inspect_sessions()
            clear = not any(final.values())
            if not clear:
                self.errors.append(f"自有 session 尚有残留：{final}")
            return clear and all(proc.row["reaped"] for proc in self.processes)
        except Exception as error:
            self.errors.append(f"无法证明最终清场：{error}")
            return False


def wait_ready(h: Harness, viewer: OwnedProcess, port: int) -> None:
    until = min(time.monotonic() + 6.0, h.work_deadline)
    while time.monotonic() < until:
        if viewer.status() is not None:
            raise CheckFailed("Viewer 监听就绪前退出；检查 viewer 日志")
        try:
            with socket.create_connection(("127.0.0.1", port), timeout=0.05):
                # 空闲端口选择与 bind 并非原子；必须证明监听属于本次 Viewer。
                probe = h.start("viewer_listener_owner", ["/usr/sbin/lsof", "-nP",
                    f"-iTCP:{port}", "-sTCP:LISTEN", "-Fp"])
                if h.wait(probe, 2.0) != 0:
                    raise CheckFailed("无法核验本次 Viewer 的监听 PID")
                pids = [int(line[1:]) for line in probe.stdout_path.read_text().splitlines()
                        if line.startswith("p")]
                try:
                    owned = bool(pids) and all(os.getsid(pid) == viewer.sid for pid in pids)
                except ProcessLookupError:
                    owned = False
                if not owned:
                    raise CheckFailed("监听端口不属于本次 Viewer session，拒绝连接")
                viewer.row["listener_owner_pids"] = pids
                return
        except OSError:
            time.sleep(0.02)
    raise CheckFailed("Viewer 未在 6 秒内监听本次端口")


def wait_config(h: Harness, producer: OwnedProcess, root: Path) -> tuple[Path, str]:
    until = min(time.monotonic() + 7.0, h.work_deadline)
    while time.monotonic() < until:
        if producer.status() is not None:
            raise CheckFailed("fixture 写出配置前已退出")
        candidates = list(root.glob("*/robot.toml"))
        if len(candidates) > 1:
            raise CheckFailed("全新 producer 目录出现多个配置，拒绝猜选")
        if candidates:
            config = candidates[0]
            try:
                value = tomllib.loads(config.read_text())
                robot_id = value["robot"]["id"]
                if not robot_id.startswith("viz_all_") or config.parent.name != robot_id:
                    raise CheckFailed("fixture robot_id 与隔离目录身份不一致")
                if len(value["hardware"]) == 2:
                    return config, robot_id
            except (tomllib.TOMLDecodeError, KeyError):
                pass  # 文件名可先于 fs::write 完成可见，不能把半写文件交给桥。
        time.sleep(0.005)
    raise CheckFailed("fixture 未在 7 秒内给出完整配置；不延长原源发布时窗")


def require_report(path: Path, robot_id: str, disconnect: bool) -> dict:
    report = json.loads(path.read_text())
    wanted = "error" if disconnect else "success"
    if report.get("output_status") != wanted or report.get("worker_reaped") is not True:
        raise CheckFailed(f"live report 未证明 {wanted} 与 worker_reaped=true")
    missing = [schema for schema in SCHEMAS
               if report.get("per_schema", {}).get(str(schema), {}).get("logged", 0) < 1]
    if missing:
        raise CheckFailed(f"live report 缺少实际 logged 的 schema：{missing}")
    if report.get("frames_rejected") != 0:
        raise CheckFailed("有效 fixture 在 live report 中出现 rejected 帧")
    if any(not topic.startswith(f"/{robot_id}/") for topic in report.get("topics_seen", [])):
        raise CheckFailed("live report 混入其他 robot topic")
    return report


def exercise(h: Harness, args: argparse.Namespace, receipt: dict) -> None:
    uvx = shutil.which("uvx")
    if uvx is None:
        raise CheckFailed("未找到 uvx；不得退回全局 pip")
    prefix = [uvx, "--from", "rerun-sdk==0.38.1", "rerun"]
    for label, flag in (("viewer_help", "--help"), ("viewer_version", "--version")):
        proc = h.start(label, prefix + [flag])
        if h.wait(proc, 8.0) != 0:
            raise CheckFailed(f"{label} 失败")
        text = proc.stdout_path.read_text() + proc.stderr_path.read_text()
        required = ("--serve-grpc", "--bind", "--port", "--save") if flag == "--help" else ("0.38.1",)
        if any(word not in text for word in required):
            raise CheckFailed(f"{label} 未确认预期版本/参数")
    with socket.socket() as reservation:
        reservation.bind(("127.0.0.1", 0))
        port = reservation.getsockname()[1]
    # bind 到启动间有固有竞争；只尝试这个端口，失败记录并停止，不猜另一个服务。
    rrd = h.root / "live.rrd"
    viewer = h.start("viewer", prefix + ["--serve-grpc", "--bind", "127.0.0.1",
                                       "--port", str(port), "--save", str(rrd)])
    wait_ready(h, viewer, port)
    receipt["viewer_tcp_ready_monotonic_ns"] = time.monotonic_ns()
    receipt["connect_url"] = f"rerun+http://127.0.0.1:{port}/proxy"
    baseline_size = rrd.stat().st_size if rrd.exists() else 0
    producer_dir = h.root / "producer"
    producer_dir.mkdir()
    producer = h.start("producer", [str(args.test_binary), CASE, "--ignored", "--exact", "--nocapture"],
                       {"ROBOT_VIZ_TEST_ARTIFACTS": str(producer_dir)})
    config, robot_id = wait_config(h, producer, producer_dir)
    receipt["fixture"] = {"config": str(config), "config_sha256": sha(config), "robot_id": robot_id}
    duration = "20000" if args.disconnect_viewer else "2500"
    live = h.start("live_bridge", [str(args.robot_viz), "--connect", receipt["connect_url"],
                                    "--config", str(config), "--duration-ms", duration,
                                    "--report", str(h.root / "live_report.json")])
    receipt["live_started_monotonic_ns"] = live.row["started_monotonic_ns"]
    if args.disconnect_viewer:
        # 必须真实连接且至少跨一秒持续写入，不能拿仅监听或 RRD 空头当已连接。
        first = None
        until = min(time.monotonic() + 5.0, h.work_deadline)
        while time.monotonic() < until:
            if live.status() is not None or viewer.status() is not None:
                raise CheckFailed("断开注入前 bridge 或 Viewer 提前退出")
            size = rrd.stat().st_size if rrd.exists() else 0
            if size >= baseline_size + 1024 and first is None:
                first = (time.monotonic(), size)
            if first and time.monotonic() - first[0] >= 1.0 and size > first[1]:
                receipt["connected_before_injection"] = {
                    "initial_rrd_bytes": baseline_size, "first_data_bytes": first[1],
                    "final_data_bytes": size, "growth_seconds": time.monotonic() - first[0],
                    "bridge_alive": True, "at_monotonic_ns": time.monotonic_ns(),
                }
                break
            time.sleep(0.01)
        else:
            raise CheckFailed("未证明真实连接后的连续一秒文件增长；拒绝注入断开")
        receipt["disconnect_requested_monotonic_ns"] = time.monotonic_ns()
        h.stop_viewer(viewer)
        receipt["viewer_reaped_monotonic_ns"] = time.monotonic_ns()
        code = h.wait(live, 18.0)
        if code == 0:
            raise CheckFailed("Viewer 断开后桥返回成功，不能将此故障验收记通过")
        receipt["bridge_expected_error_returncode"] = code
    else:
        if h.wait(live, 14.0) != 0:
            raise CheckFailed("正常实连桥非零退出")
    if h.wait(producer, 8.0) != 0:
        raise CheckFailed("原 observer_roundtrip fixture 失败")
    receipt["live_report"] = require_report(h.root / "live_report.json", robot_id, args.disconnect_viewer)
    if not args.disconnect_viewer:
        if not rrd.exists() or rrd.stat().st_size <= baseline_size + 1024:
            raise CheckFailed("Viewer 未实际写出数据文件")
        h.stop_viewer(viewer)
    receipt["rrd_verify_status"] = "PENDING_OFFICIAL_VERIFY"
    receipt["render_status"] = "NOT_RUN"
    receipt["checks_status"] = "PASS"


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--test-binary", required=True, type=Path)
    parser.add_argument("--robot-viz", required=True, type=Path)
    parser.add_argument("--output", required=True, type=Path)
    parser.add_argument("--disconnect-viewer", action="store_true")
    args = parser.parse_args()
    if sys.platform != "darwin":
        parser.error("此轮 harness 只接受已授权的 Mac 实件验收")
    for name in ("test_binary", "robot_viz"):
        path = getattr(args, name).resolve(strict=True)
        if not path.is_file() or not os.access(path, os.X_OK):
            parser.error(f"{name} 必须是可执行文件")
        setattr(args, name, path)
    args.output = args.output.resolve()
    args.output.mkdir(parents=True, exist_ok=False)
    h = Harness(args.output)
    receipt = {
        "schema": 1, "mode": "disconnect_viewer" if args.disconnect_viewer else "normal",
        "started_utc": utc(), "budget_seconds": TOTAL_SECONDS, "checks_status": "FAIL",
        "scope": "自有 fixture 的真实 SHM 双观察者到同版 Viewer；无机器人或硬件",
        "test_binary": {"path": str(args.test_binary), "sha256": sha(args.test_binary)},
        "robot_viz": {"path": str(args.robot_viz), "sha256": sha(args.robot_viz)},
        "harness_sha256": sha(Path(__file__)),
        "producer_embedded_binary_note": "fixture 的内置 save 桥路径为编译时绑定，由 root 确认与本轮来源一致",
    }

    def interrupted(signum: int, _frame: object) -> None:
        raise CheckFailed(f"harness 收到 {signal.Signals(signum).name}，保留失败并清场")

    signal.signal(signal.SIGINT, interrupted)
    signal.signal(signal.SIGTERM, interrupted)
    try:
        exercise(h, args, receipt)
    except BaseException as error:
        h.errors.append(f"{type(error).__name__}: {error}")
        receipt["checks_status"] = "FAIL"
    finally:
        # 清场期间的新停止信号只记事实；第一次停止已经触发清场，不打断责任回收。
        def cleanup_interrupted(signum: int, _frame: object) -> None:
            h.errors.append(f"清场期间收到 {signal.Signals(signum).name}")

        signal.signal(signal.SIGINT, cleanup_interrupted)
        signal.signal(signal.SIGTERM, cleanup_interrupted)
        receipt["owned_sessions_empty_and_direct_children_reaped"] = h.cleanup()
        receipt["processes"] = [proc.row for proc in h.processes]
        receipt["session_audits"] = h.audit
        receipt["artifacts"] = [
            {"path": str(path.relative_to(h.root)), "bytes": path.stat().st_size, "sha256": sha(path)}
            for path in sorted(h.root.rglob("*")) if path.is_file()
        ]
        receipt["finished_utc"] = utc()
        receipt["elapsed_seconds"] = time.monotonic() - h.started
        if receipt["elapsed_seconds"] >= TOTAL_SECONDS:
            h.errors.append("超过 50 秒总预算")
        receipt["errors"] = h.errors
        good = (receipt["checks_status"] == "PASS" and not h.errors
                and receipt["owned_sessions_empty_and_direct_children_reaped"])
        receipt["status"] = "CHECKS_PASS_RRD_VERIFY_PENDING" if good else "FAIL"
        result = h.root / "receipt.json"
        result.write_text(json.dumps(receipt, ensure_ascii=False, indent=2) + "\n")
        print(json.dumps({"status": receipt["status"], "receipt": str(result),
                          "receipt_sha256": sha(result)}, ensure_ascii=False), flush=True)
    return 0 if good else 1


if __name__ == "__main__":
    raise SystemExit(main())
