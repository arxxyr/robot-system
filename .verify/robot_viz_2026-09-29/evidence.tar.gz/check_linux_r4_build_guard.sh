#!/usr/bin/env bash
# 与退出测试独立的 RT 分配门与最终生产输入优化构建。
set -euo pipefail
export PATH="$HOME/.cargo/bin:$HOME/.local/bin:$PATH"
cd "$HOME/robot-checks/viz-final-r4"
export CARGO_TARGET_DIR="$HOME/robot-checks/build"
export CARGO_BUILD_JOBS=4
export RUSTC_WRAPPER=""
export CARGO_BUILD_RUSTC_WRAPPER=""
uv run --no-project python gate.py linux_rt_guard -- cargo +nightly-2026-09-29 test --locked -p robot-s0 --lib --features rt_guard
uv run --no-project python gate.py linux_tools_release -- cargo +nightly-2026-09-29 build --locked --profile release-tools -p robot-viz --jobs 2
uv run --no-project python verify_source.py > linux_source_after.json
