"""只汇总真实 gate 回执及测试日志，不把 ignored 或预热计为通过。"""
import hashlib
import json
import re
import sys
from pathlib import Path

directory=Path(sys.argv[1])
rows=[]
for path in sorted(directory.glob('*.json')):
    try:
        item=json.loads(path.read_text())
    except (ValueError,UnicodeError):
        continue
    if not isinstance(item,dict) or not {'command','wait_returncode','log_sha256'} <= item.keys():
        continue
    log=path.with_suffix('.log')
    if not log.exists():
        continue
    data=log.read_bytes()
    assert hashlib.sha256(data).hexdigest()==item['log_sha256'], log
    assert len(data)==item['log_bytes'], log
    groups=[]
    for result in re.finditer(r'test result: (\w+)\. (\d+) passed; (\d+) failed; (\d+) ignored;',data.decode(errors='replace')):
        groups.append({'result':result[1], 'passed':int(result[2]), 'failed':int(result[3]), 'ignored':int(result[4])})
    rows.append({'gate':path.stem, 'wait_returncode':item['wait_returncode'], 'reaped':item['reaped'],
                 'elapsed_seconds':round(item['elapsed_ns']/1e9,3), 'groups':groups,
                 'log_sha256':item['log_sha256']})
print(json.dumps(rows,ensure_ascii=False,indent=2))
