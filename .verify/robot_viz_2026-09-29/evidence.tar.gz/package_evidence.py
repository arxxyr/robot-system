"""归档本轮可视化软件证据；逐件核验，拒绝覆盖，原始失败也保留。"""
import hashlib
import io
import json
import shutil
import tarfile
from pathlib import Path

source = Path('target/robot_viz_20260929')
output = Path('.verify/robot_viz_2026-09-29')
output.mkdir(exist_ok=False)
archive_path = output / 'evidence.tar.gz'
rows = []
with tarfile.open(archive_path, 'w:gz') as archive:
    for path in sorted(source.rglob('*')):
        if not path.is_file() or '__pycache__' in path.parts or 'linux_extracted' in path.parts:
            continue
        assert not path.is_symlink(), path
        data = path.read_bytes()
        name = str(path.relative_to(source))
        rows.append({'path':name,'sha256':hashlib.sha256(data).hexdigest(),'bytes':len(data)})
        info = tarfile.TarInfo(name)
        info.size = len(data)
        info.mode = 0o644
        archive.addfile(info, io.BytesIO(data))
    data = (json.dumps(rows,ensure_ascii=False,indent=2)+'\n').encode()
    info = tarfile.TarInfo('evidence_index.json')
    info.size = len(data)
    info.mode = 0o644
    archive.addfile(info,io.BytesIO(data))
with tarfile.open(archive_path,'r:gz') as archive:
    assert set(archive.getnames())=={r['path'] for r in rows}|{'evidence_index.json'}
    for row in rows:
        data=archive.extractfile(row['path']).read()
        assert len(data)==row['bytes'] and hashlib.sha256(data).hexdigest()==row['sha256'],row['path']
for name in ['default','camera','points','events']:
    shutil.copyfile(source/f'viewer_r2/{name}.png',output/f'{name}.png')
shutil.copyfile(source/'live_gui_sigint_r2/live.png',output/'live.png')
shutil.copyfile(source/'artifacts_r2/viz_all_89493_826861668751458_1/observation.rrd',output/'example.rrd')
shutil.copyfile(source/'final_result.json',output/'summary.json')
receipt={'archive':archive_path.name,'sha256':hashlib.sha256(archive_path.read_bytes()).hexdigest(),'bytes':archive_path.stat().st_size,'indexed_files':len(rows),'root_verified_every_member':True,'scope':'软件证据，失败原件保留；无Orin安装/真实硬件验收'}
(output/'archive.json').write_text(json.dumps(receipt,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(receipt,ensure_ascii=False))
