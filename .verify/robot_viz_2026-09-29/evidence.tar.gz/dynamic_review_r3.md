# Rerun 动态证据与交付口径独审（2026-09-29）

结论：final-r3 的 **Mac 转换/录制、真实 Viewer 展示、实时连接、断连失败收尾及收到数据后的 SIGINT** 已有可接受的软件证据。未发现这些已完成范围的新阻断。整轮完成仍需 root 收到 Linux 最终回归结果并更新活跃文档；当前 Linux final-r3 生命周期 oracle 失败不能写成通过。未运行 Cargo、SSH、硬件或 MCP UI；仅读取原件、核哈希、查看已生成截图。

补充来源：已独立比较 r3/r4 两份 manifest，620 项无增删，唯一差异为 `crates/robot-rpc/src/events_subscribe.rs` 的 Linux 测试模块。`final-r4/source_manifest.json` SHA 为 `87884e0e69a6eb87ffc973f72ca585b2021df117ee7eb50c938c1fb12c311340`；`final-r4/source_delta.json` SHA 为 `a6b6af3470f102e94ec24c5d6152508ded67ee04b623f5cf24d2925533f72a3e`。该窄测试修订已静态认可，生产逻辑/依赖/配置与 r3 相同；应准确理解为“有一个源码文件的测试部分改变”，不是整个构建输入字节完全不变。复用 r3 已构建生产 peer 合理，viz 和 transport 专项没有源码变化，无需重复已完成的同源专项门。

## 来源与原件核验

代码来源沿用 `static_review_r3.md` 绑定的 final-r3 manifest：`9d06debc169d92e3b9ba99a84f0c7e6e82d0ce70bf289692c44d72f5ee5ae103`。本次三个 live 回执分别核 **25/25/34** 个列举原件，全部 bytes/SHA 匹配；两份最终 Mac 可执行文件仍与回执 SHA 相同。复核摘要 `dynamic_review_r3_receipt_check.json` SHA：`29db34a248bdc9d0e62a02a62661e0fa94b6cebf1bb5da13cb4260165a6e15bf`。

| 原件 | SHA-256 |
| --- | --- |
| `live_normal_r2/receipt.json` | `f25a93a1d799116cfd9921eb2da9b14628380e0b1a7e820b7fc1e2ec1f8f08af` |
| `live_disconnect_r2/receipt.json` | `897fbff800b942ae7455c8bd096f043cc6ada7e3ddddf7f207561076138b32b5` |
| `live_gui_sigint_r2/receipt.json` | `8faa66059262625aeae5c104c5111c62a402948e20e896fab7eff6b74a131f84` |
| `viewer_r2/cleanup.json` | `e56eb1f041c91f48967100b7842ee0e6dcdd07b58d3f02bb7a3ddbb606775485` |

## 已成立的动态结论

- Mac 定向 Clippy r12、17 个纯测试、6 个显式跨进程集成测试已通过；详此前静态报告引用的完成日志。阳性 RRD 为 `artifacts_r2/viz_all_89493_826861668751458_1/observation.rrd`，1000 帧、10 schema、11 实例、0 rejected；实际值与 Recording store 归属由官方解码器断言。四阶段 A/B 新序号握手保留严格 11 实例要求。
- Linux final-r3 的 `linux_outer.log` 已读到 fmt、根 Clippy、6 项 viz 集成、17 项 viz 单测、transport/default 与 mock 两门的 exit 0/reaped=true 回执。这些已过且源码未变的结果可引用到 r4；后续全仓失败不能倒改其已完成分项，分项通过也不能代替全仓/关闭链/rt_guard/release 的 r4 最终结果。
- 该桥自身正常关闭的 RRD 经官方 0.38.1 `rrd verify` 实际 exit 0、reaped=true，日志 `1 file verified without error.`，回执在 `viewer_r2/rrd_verify.json`。这只针对该文件，不外推其他临时捕获。
- 已亲看 `viewer_r2/default.png`：按量纲分组的关节曲线及四色 2×2 Tensor；`camera.png`：红/绿两像素图；`points.png`：两个点及 x[-1,1]/y[-2,2]/z[-3,3] 包围范围；`events.png`：来源文本、事件与元信息。`after_seek_state.json` 的活动 Recording 与本次录制一致，robot_time 已移动到 **826863500000000 ns**，不是只发出 seek 命令而未核落点。中文原始文本仍可能因默认字体缺字显示方框，固定标题/状态码已可读；原始文本在录制中保留。
- `live_normal_r2`：真实同版 gRPC 接收器，799 logged、10 schema、0 rejected、9 sequence gaps；桥 exit 0、producer exit 0、SDK worker_reaped=true，末次自有 session 为空。接收器在收尾阶段按计划 SIGINT，exit 130；这是受控停止，不是异常杀进程后冒称正常退出。
- `live_disconnect_r2`：已建立连接并实际接收数据后中断接收器，桥以 gRPC severed 报错、exit 1；78 logged、10 schema、0 rejected、34 sequence gaps。SDK worker_reaped=true，producer exit 0，末次自有 session 为空。符合连接中断负例，不应将该桥非零退出统计为产品阳性失败。
- `live_gui_sigint_r2`：官方 MCP 原件在信号前确认新活动 Recording、与隔离 robot_id 一致的 view origin、非零 robot_time/received_time 范围；已亲看 `live.png` 有 Live 来源、曲线与四色 Tensor。仅向自有桥父 PID **90441** 发 SIGINT，之后 bridge/producer **90439** 均 exit 0；80 logged、10 schema 各 8 帧、0 rejected、**67 sequence gaps**、worker_reaped=true，末次自有 session 为空。收到了数据之后的停止验收补齐了旧集成 SIGINT 场景本次 0 帧的证据边界。

GUI 门未信号已有 Viewer **89722**，前后仍为同一监听者。之后 root 单独停止其自有 PTY，会话实际 exit 130、89717/89718/89722 查询均不存在；不虚构每个后代独立 wait。该收尾记录同时保留一次启动早期 WARN：`Timeline "robot_time" not found`。文件阶段 `logs.json` 无消息不能外推为 Viewer 全程无警告。

## 必须保留的失败与限制

1. `live_normal_r2/live.rrd` 和 `live_disconnect_r2/live.rrd` 是官方 Viewer `--save` 接收器被 SIGINT 后的临时捕获，后续官方 verify **均 exit 1/reaped=true，Missing RRD footer / no RRD manifests**。已逐一核新 verify 日志 SHA/bytes。原 live receipt 的 `CHECKS_PASS_RRD_VERIFY_PENDING` 保持原样，须结合追加 verify FAIL 使用；不能把两件文件称为完整录制或整门全绿。此限制不推翻独立通过的桥自身 `--save` 文件和真实 GUI 实连证据。
2. Linux final-r2 双发布者阳性失败保留；final-r3 全仓 `events_subscribe` 旧 oracle 期待 2 Node、实见镜像引入的 3 Node，原 304 passed / 1 failed 保留。`events_subscribe.rs` 的后续窄补丁 SHA `b5731dcf572db395dc41f7360d419e157dc7b54405163f11eafd32dffb7a9bf0` 已静态认可：1→2→3→2→1→0 实体目录生命周期、真实镜像 join/预算归零，256 轮、nofile128、30 秒及最终 FD 门不放宽。但本报告不预写 final-r4 原生回归结果。
3. `live_gui_sigint_r1` 的输出日志重名导致 FileExists 前置失败保留；其零 fixture/桥启动不能写成一次成功。r2 是修正后独立新目录的真实结果。
4. 镜像有损；底层接收先连接持续饱和时可能饿死后连接。gap/drop 只覆盖已观察实例与缓存窗口，未见实例的缺失无法推算；不承诺全量无损或完整事件审计。本次 GUI 实测 67 gaps 必须保留，不可用另一阳性的零 gap 代替。
5. Tensor/intensity 显式范围是**逐样本**范围，不保证跨帧色阶可直接比较；原值保留。`GPU_PREVIEW_LIMIT` 说明 F32 GPU 表示边界，不能称任意有限 F64 保真呈色。媒体软件夹具通过不代表真实相机/雷达已接入。
6. 非实时发布者新增有界镜像 worker，原控制 QoS/返回/recipients/wire 保留，不能概括为整个运行时未变。未部署 Orin 正式件、未做本轮 RT 硬件再测，不关闭通信硬化硬件门或 D15。

## 收口文档检查

`docs/02_start_here.md` 当前使用步骤已覆盖 profile、配置、离线/实时命令、共享内存发布者前提、逐样本范围、字体、饥饿与 footer 限制，未见需扩大开发范围的问题。仓库没有根 README，现有入口是 `docs/README.md`，不需要新建另一个入口。

root 已承接最终活跃文档全量更新，本审查不以过渡期“实施中”字样新增开发要求。收口时 V5 的“事件 FIFO”应明确只指同一发布者中保留样本的顺序，不暗示跨发布者全序、公平或无损；V8 按 Linux 新门的实际回执填写。旧 macOS 根 Clippy 平台阻断、独立 CI job 范围及原失败也应如实保留，不能宣称全仓所有平台/远端 CI 全绿。

允许的当前表述：**“Rerun 录制与真实 Viewer 软件数据链已验证；最终 Linux 回归及交付文档收口进行中。”** Linux 最终门与文档闭合后可将本轮纯软件接入标为完成，不应把硬件部署作为本轮新增完成条件。
