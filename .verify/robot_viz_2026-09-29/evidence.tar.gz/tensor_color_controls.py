# /// script
# requires-python = ">=3.10"
# dependencies = ["rerun-sdk==0.38.1", "numpy"]
# ///
"""仅生成同版官方 Tensor 颜色映射对照；不连接 Viewer、不改原数据。"""

import hashlib
import importlib.metadata
import json
from pathlib import Path
import sys

import numpy as np
import rerun as rr
import rerun.blueprint as rrb


def main() -> None:
    output = Path(sys.argv[1]).resolve()
    output.mkdir(parents=True, exist_ok=False)
    assert importlib.metadata.version("rerun-sdk") == "0.38.1"
    rr.set_strict_mode(True)
    app_id = "robot-viz-tensor-color-controls"
    values = [[0.5, 1.5], [2.5, 3.5]]
    ranges = [("automatic", None), ("explicit_data_range", [0.5, 3.5]),
              ("explicit_image_range", [0.0, 255.0])]
    cases = []
    views = []
    for range_name, value_range in ranges:
        for dtype in (np.float32, np.float64):
            dtype_name = np.dtype(dtype).name
            entity = f"controls/{range_name}/{dtype_name}"
            cases.append({"entity": entity, "dtype": dtype_name,
                          "values": values, "value_range": value_range})
            label = f"{dtype_name}: {range_name}"
            views.append(rrb.TensorView(
                name=label, origin=entity, contents="$origin",
                scalar_mapping=rrb.TensorScalarMapping(
                    colormap="viridis", gamma=1.0, mag_filter="nearest"),
                view_fit="FillKeepAspectRatio"))
    blueprint = rrb.Blueprint(
        rrb.Grid(*views, grid_columns=2), auto_layout=False,
        auto_views=False, collapse_panels=True)
    rrd = output / "tensor_color_controls.rrd"
    layout = output / "tensor_color_controls.rbl"
    recording = rr.RecordingStream(app_id)
    recording.save(rrd)
    recording.send_blueprint(blueprint)
    for case in cases:
        data = np.array(values, dtype=case["dtype"])
        assert data.tolist() == values
        recording.log(case["entity"],
                      rr.Tensor(data, value_range=case["value_range"]), static=True)
    recording.flush(timeout_sec=5.0)
    recording.disconnect()
    blueprint.save(app_id, layout)
    manifest = {
        "application_id": app_id,
        "rerun_sdk_version": importlib.metadata.version("rerun-sdk"),
        "numpy_version": np.__version__,
        "scope": "仅颜色映射对照；原始浮点值和 2×2 形状相同",
        "cases": cases,
        "artifacts": [{"path": str(path), "bytes": path.stat().st_size,
                       "sha256": hashlib.sha256(path.read_bytes()).hexdigest()}
                      for path in (rrd, layout, Path(__file__).resolve())],
    }
    manifest_path = output / "manifest.json"
    manifest_path.write_text(json.dumps(manifest, indent=2, ensure_ascii=False) + "\n")
    print(json.dumps({"rrd": str(rrd), "blueprint": str(layout),
                      "manifest": str(manifest_path)}, ensure_ascii=False))


if __name__ == "__main__":
    main()
