#!/usr/bin/env bash
# 仅用于本轮新建的隔离 Linux ARM 虚拟机，不在 Orin 或宿主机执行。
set -euo pipefail
test "$(uname -m)" = aarch64
sudo apt-get update
sudo env DEBIAN_FRONTEND=noninteractive apt-get install -y \
  build-essential pkg-config libudev-dev libssl-dev clang cmake git curl \
  ca-certificates rsync python3
curl --proto '=https' --tlsv1.2 -fsSL https://sh.rustup.rs -o /tmp/robot-viz-rustup-init.sh
sh /tmp/robot-viz-rustup-init.sh -y --profile minimal \
  --default-toolchain nightly-2026-09-29 --component clippy --component rustfmt
"$HOME/.cargo/bin/rustc" +nightly-2026-09-29 --version
"$HOME/.cargo/bin/cargo" +nightly-2026-09-29 --version
