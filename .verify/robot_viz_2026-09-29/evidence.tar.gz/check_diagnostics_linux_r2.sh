#!/usr/bin/env bash
# 复用冻结诊断修复，仅增加已核对的 CLI nightly lint 等价修正。
set -euo pipefail
export PATH="$HOME/.cargo/bin:$HOME/.local/bin:$PATH"
dest_dir="$HOME/robot-checks/diagnostics-20260929-r2"
test ! -e "$dest_dir"
mkdir -p "$dest_dir"
tar xzf /Users/loosqk/repo/rust/robot-system/target/hardware_smoke_20260929/diagnosis/source_r2.tar.gz -C "$dest_dir"
cd "$dest_dir"
export CARGO_TARGET_DIR="$HOME/robot-checks/build"
export CARGO_BUILD_JOBS=4
export RUSTC_WRAPPER=""
export CARGO_BUILD_RUSTC_WRAPPER=""
uv run --no-project python verify_source.py > linux_source_before.json
uv run --no-project python gate.py linux_fmt -- cargo +nightly-2026-09-29 fmt --all --check
uv run --no-project python gate.py linux_clippy_workspace -- cargo +nightly-2026-09-29 clippy --locked --all --all-targets -- -D warnings
uv run --no-project python gate.py linux_test_feetech -- cargo +nightly-2026-09-29 test --locked -p robot-adapter-feetech --tests --features real-hw
uv run --no-project python gate.py linux_serial_convergence -- cargo +nightly-2026-09-29 test --locked -p robot-s0 --lib --features rt_guard post_e_convergence_acceptance
uv run --no-project python verify_source.py > linux_source_after.json
