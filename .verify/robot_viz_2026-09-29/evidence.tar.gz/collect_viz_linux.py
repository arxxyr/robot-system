"""收集已结束的 Linux 软件门；保留失败，不归入编译缓存或真实硬件状态。"""
import hashlib
import io
import json
import platform
import re
import subprocess
import sys
import tarfile
from pathlib import Path

base = Path.home() / 'robot-checks'
payloads = {}
for label in sys.argv[1:]:
    if label not in ['viz-final-r1', 'viz-final-r2', 'viz-final-r3', 'viz-final-r4', 'viz-final-r5', 'viz-final-r6']:
        raise ValueError(label)
    run = base / label
    for source in sorted(run.glob('linux_*')):
        if source.is_file():
            payloads[f'{label}/{source.name}'] = source.read_bytes()
    for name in ['source_manifest.json', 'gate.py', 'verify_source.py']:
        payloads[f'{label}/{name}'] = (run / name).read_bytes()
    for source in sorted((run / 'artifacts').rglob('*')):
        if source.is_file():
            payloads[f'{label}/{source.relative_to(run)}'] = source.read_bytes()
    failure_log = run / 'linux_s0_shutdown.log'
    if failure_log.exists():
        for temp in sorted(set(re.findall(r'失败证据保留：(/tmp/\.tmp[0-9A-Za-z]+)', failure_log.read_text()))):
            temp_dir = Path(temp)
            for source in sorted(temp_dir.rglob('*')):
                if source.is_file() and not source.is_symlink():
                    payloads[f'{label}/failed_temporary/{temp_dir.name}/{source.relative_to(temp_dir)}'] = source.read_bytes()
    # 只记录显式生成的工具及绑定测试 peer 身份；大体积调试件仍在 VM 隔离目录。
    peers = run / 'native_peers'
    if peers.exists():
        rows = []
        for source in sorted(peers.iterdir()):
            if source.is_file():
                rows.append({'path':str(source), 'sha256':hashlib.sha256(source.read_bytes()).hexdigest(), 'bytes':source.stat().st_size})
        payloads[f'{label}/peer_readback.json'] = json.dumps(rows,indent=2).encode()
payloads['environment.json'] = json.dumps({
    'scope':'本地 Lima Ubuntu ARM 软件验证；不是 Orin，不访问机器人或真实串口',
    'platform':platform.platform(), 'machine':platform.machine(),
    'rustc':subprocess.check_output([str(Path.home()/'.cargo/bin/rustc'),'+nightly-2026-09-29','-Vv'],text=True),
},ensure_ascii=False,indent=2).encode()
release = base / 'build/release-tools/robot-viz'
if release.is_file():
    payloads['release_tool_identity.json'] = json.dumps({
        'path':str(release), 'sha256':hashlib.sha256(release.read_bytes()).hexdigest(),
        'bytes':release.stat().st_size,
        'scope':'最终流水线结束后的实际 Linux ARM 优化产物，保留在隔离 VM，未安装 Orin',
    },ensure_ascii=False,indent=2).encode()
processes = subprocess.check_output(['ps','-eo','pid=,ppid=,args='],text=True)
owned_binary_rows = [line for line in processes.splitlines()
                     if str(base/'build') in line or str(base/'viz-final-r3/native_peers') in line
                     or str(base/'viz-final-r4/native_peers') in line or str(base/'viz-final-r5/native_peers') in line or str(base/'viz-final-r6/native_peers') in line]
payloads['processes_after.json'] = json.dumps({
    'scope':'门结束后的 build / native_peers 可执行路径进程扫描；不等价于所有子进程独立 wait',
    'matching_rows':owned_binary_rows, 'empty':not owned_binary_rows,
},ensure_ascii=False,indent=2).encode()
rows = [{'path':path, 'sha256':hashlib.sha256(data).hexdigest(), 'bytes':len(data)} for path,data in sorted(payloads.items())]
payloads['index.json'] = json.dumps(rows,indent=2).encode()
with tarfile.open(fileobj=sys.stdout.buffer,mode='w|gz') as archive:
    for name,data in sorted(payloads.items()):
        member=tarfile.TarInfo(name)
        member.size=len(data)
        member.mode=0o644
        archive.addfile(member,io.BytesIO(data))
