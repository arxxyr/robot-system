#!/usr/bin/env bash
# 仅预热依赖产物，不替代最终合并源码验收。
set -euo pipefail
export PATH="$HOME/.cargo/bin:$HOME/.local/bin:$PATH"
cd "$HOME/robot-checks/viz-warmup-r1"
export CARGO_TARGET_DIR="$HOME/robot-checks/build"
export CARGO_BUILD_JOBS=4
export RUSTC_WRAPPER=""
export CARGO_BUILD_RUSTC_WRAPPER=""
uv run --no-project python gate.py linux_build_warmup -- cargo +nightly-2026-09-29 test --locked -p robot-viz --test observer_roundtrip --no-run
