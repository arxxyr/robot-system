# /// script
# requires-python = ">=3.10"
# dependencies = ["rerun-sdk==0.38.1"]
# ///
"""生成验收专用视图布局；不修改原 RRD 数据或生产默认布局。"""
from pathlib import Path
import sys
import rerun.blueprint as blueprint

output = Path(sys.argv[1])
output.mkdir(exist_ok=False)
views = {
    'points': blueprint.Spatial3DView(name='点云数据验收', origin='topics'),
    'tensor': blueprint.TensorView(name='张量数据验收', origin='topics'),
    'images': blueprint.Spatial2DView(name='图像数据验收', origin='topics'),
}
for name, view in views.items():
    layout = blueprint.Blueprint(view, blueprint.TimePanel(timeline='robot_time'),
                                 auto_layout=False, auto_views=False, collapse_panels=True)
    layout.save('robot-viz', output / f'{name}.rbl')
print(output)
