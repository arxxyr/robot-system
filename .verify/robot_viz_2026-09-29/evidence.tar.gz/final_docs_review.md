# Rerun 最终文档与证据口径独审

结论：**通过，未发现阻断本轮 Rerun 纯软件接入收口的实质性口径错误。** 已只读核对 `CLAUDE.md`、`docs/02_start_here.md`、`docs/10_verification.md`、`docs/CHANGELOG.md`、实际文档入口 `docs/README.md` 和 HANDOFF 顶部；未修改这些文档或生产/测试源码，未运行 Cargo、VM 命令、SSH 或硬件。

审查时 `final_result.json` SHA-256 为 `0814b688d280ee7fdfda10bcecc3d92bf1c84bb3530cde544844f6f75b47a6d6`，状态 `SOFTWARE_ACCEPTED`。其 final-r6 manifest SHA 为 `abb7029420438ed69d12b0aab541cea9558f027485af68c196d4342359f430d2`；Linux source_before/source_after 均报告 620 项一致，文档没有把后续 CLAUDE 状态更新说成同字节构建输入。

## 最终门与文档声明相符

独立核验了文档引用的 **12 份 Linux gate receipt 及各自日志**：receipt 的 SHA/bytes 与汇总一致，日志 SHA/bytes 与 receipt 一致，均为真实 `wait_returncode=0`、`reaped=true`。复核清单 `final_docs_receipt_check.json` SHA 为 `1bdce861471cb5747333a67e7170d95424db3a9d1ab7bdbe1cf71fdc080ed862`。这是本次独审的定向核验范围，不冒称重新执行门或独立重核 root 的全部 167 件原件。

| 证据来源 | 核对结果 |
|---|---|
| r3 viz 单测及显式 SHM 集成 | 17 / 6 PASS；transport 默认及 mock 两门通过，ignored 独立保留 |
| r4 RT、优化构建、实际 help | 609 项 S0+rt_guard PASS；`release-tools` build 与真实二进制 `--help` 均退出 0 |
| r6 根 fmt/Clippy | 退出 0；Clippy 日志未见 warning |
| r6 S1 生命周期 | 定向真实工厂测试通过；未把 test-only oracle 修订写成生产 API 改动 |
| r6 完整 workspace | 明确 `--features robot-s1/test-fault-backend -- --test-threads=1`；整体退出 0，忽略项没有并入通过数 |
| r6 S0 关闭 | 日志明确 13 PASS，包含 Executor/IPC 快照耗尽及 IPC 提前退出；原严格退出后时间断言保留 |

r3 后三处文件变化均为 Linux 测试相关修订，r6 又仅调整测试中零尺寸 `SystemClock` 参数传递；复用未改生产逻辑的 r3 peer、r4 优化构建及 RT 结果的范围在 HANDOFF 和验证文档中说明清楚。原 r4 的 11 PASS / 2 FAIL 与 r5 Clippy 失败保留，没有被新结果覆盖。

已读取 VM stop receipt 的真实退出 0/reaped=true、独立 list 的 `Stopped`、最终限定路径进程扫描 `empty=true`。扫描的说明明确不等于所有后代逐一 wait；磁盘及隔离产物保留，不冒称删除 VM。

## 完成声明与保留边界

- 六份活跃文档一致把完成范围限定为 **独立 Rerun 观测桥、十类 pub/sub、有界隔离镜像、Mac/Linux 软件及真实同版 Viewer**。原设计冻结未改，SDK 不进入 S0/S1；非实时发布者新增镜像 worker 的事实没有隐藏。
- Mac 17+6、正常录制 1000 帧/10 类/11 实例及真实 GUI SIGINT 80 帧/10 类/67 gaps，与此前静态和动态独审、现有汇总一致。只读媒体夹具没有被写成真实相机、点云或现场机器人已接入。
- 有损观测、首连接饥饿、未见实例无法计算 gap、512 MiB 仅估算活跃预约、逐帧颜色范围、GPU F32 预览与中文字体限制均保留。V5 仅保证同一发布者保留样本的顺序，没有暗示跨发布者全序或完整事件审计。
- 桥正常关闭的 `--save` 文件 verify PASS，与两个接收器被中断后缺 footer 的 verify FAIL 分别记账；Viewer 实时初始化的 Timeline 警告和首轮截图/日志路径错误也未隐藏。
- Linux 完整回归明确为串行且绑定 peer，不关闭已有 S1 默认并行超时根因。CI 仅配置/actionlint 静态验收，未 push、未运行托管 workflow，没有“所有平台全仓全绿”的宣称。
- 本轮未部署 Orin、未执行新的 Rerun 硬件动作；SSH 信任待核、右 H2 整体 FAIL、D15 OPEN、`deployable=false` 仍在。历史同日双臂腕部探针被明确分段，不与本轮可视化软件混淆。

上手命令明确需要同共享内存环境及带新镜像的发布者，旧正式二进制不会凭空产生数据；后续 Orin 观测验证是下一阶段，不作为本轮已部署声明。历史“实施中/暂停/硬序”记录有日期或历史段落限定，当前入口已明确由用户后续目标先行完成软件。即将落地的 `.verify/robot_viz_2026-09-29` 链接按 root 归档计划接受，本审查不把短暂缺失当成代码或验收失败。

## 文档身份

| 文件 | 审查时 SHA-256 |
|---|---|
| CLAUDE.md | `2ed1f614cd7923b8ea3745dfde00fba8fae801cae53d45faa202d9c75ffd768d` |
| docs/02_start_here.md | `5d5ea2b6cc163af8877824f0e97dbd7fe55ed8146bf5e680bd06cf09489164ec` |
| docs/10_verification.md | `9332fb5c562880d08a5bd6739bcf2919cb747834d78a81fed84bcdb8b0658e24` |
| docs/CHANGELOG.md | `6ba202e6791874c1265ecd642dd04e37f5e67a2de5f900d0dc34f2d0f90386dc` |
| docs/README.md | `cf948f7b958ae6c4e9280955dd9478e153933b0bc9933fb64b72ad49d4f07e47` |
| team-swe/specs/post_e_comm_fault_hardening.HANDOFF.md | `79254d864bed200f1adc4d700ca57bd72479159c7aa82274e5f31e8b2c8948d8` |
