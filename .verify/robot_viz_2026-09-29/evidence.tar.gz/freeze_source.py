"""保存隔离软件检查源码；打包后逐项核对，保留每轮输入。"""
import hashlib
import json
import subprocess
import sys
import tarfile
import time
from pathlib import Path

root = Path.cwd()
out = root / 'target/robot_viz_20260929' / sys.argv[1]
out.mkdir(exist_ok=False)
prefixes = ['.cargo', '3rd-party', 'Cargo.toml', 'Cargo.lock', 'deny.toml', 'rust-toolchain.toml', 'CLAUDE.md', 'AGENTS.md', 'crates', 'configs', 'scripts', 'tools']
paths = subprocess.check_output(['git', 'ls-files', '-z', *prefixes]).decode().split('\0')
paths += subprocess.check_output(['git', 'ls-files', '--others', '--exclude-standard', '-z', 'crates']).decode().split('\0')
rows = []
with tarfile.open(out / 'source.tar.gz', 'w:gz', dereference=False) as archive:
    for name in sorted(set(filter(None, paths))):
        source = root / name
        info = archive.gettarinfo(str(source), name)
        info.mtime = int(time.time())
        if source.is_symlink():
            rows.append({'path': name, 'link': str(source.readlink())})
            archive.addfile(info)
        else:
            data = source.read_bytes()
            rows.append({'path': name, 'sha256': hashlib.sha256(data).hexdigest(), 'bytes': len(data)})
            import io
            info.size = len(data)
            archive.addfile(info, io.BytesIO(data))
    manifest = {'base_commit': subprocess.check_output(['git', 'rev-parse', 'HEAD']).decode().strip(),
                'scope': 'Rerun 软件检查，隔离源码，不访问真实串口/摄像头，不正式安装',
                'revision': sys.argv[1], 'files': rows}
    (out / 'source_manifest.json').write_text(json.dumps(manifest, ensure_ascii=False, indent=2) + '\n')
    archive.add(out / 'source_manifest.json', arcname='source_manifest.json')
    for name in ['gate.py', 'verify_source.py']:
        archive.add(root / 'target/hardware_smoke_20260929/diagnosis' / name, arcname=name)
for row in rows:
    source = root / row['path']
    if 'link' in row:
        assert str(source.readlink()) == row['link'], row['path']
    else:
        assert hashlib.sha256(source.read_bytes()).hexdigest() == row['sha256'], row['path']
print(json.dumps({'files': len(rows), 'manifest_sha256': hashlib.sha256((out/'source_manifest.json').read_bytes()).hexdigest(), 'archive_bytes': (out/'source.tar.gz').stat().st_size}))
