"""仅检查当前 CI/依赖策略结构，不运行 Cargo，不改输入文件。"""

from __future__ import annotations

import copy
import hashlib
import json
from pathlib import Path
import subprocess
import tomllib


ROOT = Path(__file__).resolve().parents[2]
BASE_COMMIT = "46981c27364a176f913876c28808e873560c36a5"
ORIGINAL_DENY_FAIL_SHA = "0f35ca80f89585144e9052778587f81100414b83e28990ccd4625622336596e5"


def baseline(path: str) -> str:
    return subprocess.check_output(
        ["git", "show", f"{BASE_COMMIT}:{path}"], cwd=ROOT, text=True
    )


def sha256(path: str) -> str:
    return hashlib.sha256((ROOT / path).read_bytes()).hexdigest()


def main() -> None:
    current = tomllib.loads((ROOT / "deny.toml").read_text())
    original = tomllib.loads(baseline("deny.toml"))
    expected_licenses = [
        {"name": "indent", "version": "=0.1.1", "allow": ["MPL-2.0"]},
        {"name": "option-ext", "version": "=0.2.0", "allow": ["MPL-2.0"]},
        {"name": "webpki-roots", "version": "=1.0.9", "allow": ["CDLA-Permissive-2.0"]},
        {"name": "xxhash-rust", "version": "=0.8.19", "allow": ["BSL-1.0"]},
    ]
    assert current["licenses"]["exceptions"] == (
        original["licenses"]["exceptions"] + expected_licenses
    ), "许可证例外超出四项精确新增范围"
    ignored = current["advisories"]["ignore"]
    assert len(ignored) == 2, "公告/撤回版本例外数量不符"
    assert set(ignored[0]) == {"id", "reason"}
    assert ignored[0]["id"] == "RUSTSEC-2024-0436"
    assert set(ignored[1]) == {"crate", "reason"}
    assert ignored[1]["crate"] == "serialport@4.10.0"
    assert all(isinstance(item["reason"], str) and item["reason"].strip() for item in ignored)
    normalized = copy.deepcopy(current)
    normalized["licenses"]["exceptions"] = original["licenses"]["exceptions"]
    normalized["advisories"]["ignore"] = original["advisories"]["ignore"]
    assert normalized == original, "其他依赖策略发生语义变化"
    assert current["advisories"]["yanked"] == "deny"

    workflow_path = ".github/workflows/ci.yml"
    old_workflow = baseline(workflow_path)
    workflow = (ROOT / workflow_path).read_text()
    old_test = old_workflow.split("  test:\n", 1)[1].split("  matrix-build:\n", 1)[0]
    new_test = workflow.split("  test:\n", 1)[1].split("  robot-viz:\n", 1)[0]
    assert old_test == new_test, "原 test job 未逐字保留"
    assert old_workflow.split("  matrix-build:\n", 1)[1] == workflow.split(
        "  matrix-build:\n", 1
    )[1], "其他原 jobs 未逐字保留"
    job = workflow.split("  robot-viz:\n", 1)[1].split("  matrix-build:\n", 1)[0]
    assert not any(line.lstrip().startswith("needs:") for line in job.splitlines())
    assert "os: [ubuntu-latest, macos-latest]" in job
    assert "timeout-minutes: 60" in job
    assert "shell: bash" in job
    assert "-p robot-viz -p robot-transport --all-targets" in job
    assert "-- -D warnings" in job
    assert "-- --ignored --test-threads=1 --nocapture" in job
    assert "actions-rust-lang/setup-rust-toolchain@v1" in job
    assert "mozilla-actions/sccache-action@v0.0.9" in job
    for step in [
        "- name: robot-viz observer roundtrip",
        "- name: Upload robot-viz software evidence",
        "- name: cargo build robot-viz release-tools",
    ]:
        assert workflow.count(step) == 1, f"新增步骤重复：{step}"
    assert "- name: Upload robot-viz software evidence\n        if: ${{ always() }}" in job
    ordered_commands = [
        "cargo fmt --all --check",
        "cargo clippy --locked",
        "cargo test --locked -p robot-viz --lib",
        "cargo test --locked -p robot-viz --test observer_roundtrip",
        "cargo build --locked --profile release-tools",
    ]
    offsets = [job.index(command) for command in ordered_commands]
    assert offsets == sorted(offsets), "检查步骤顺序不符"

    old_lock = tomllib.loads(baseline("Cargo.lock"))
    lock = tomllib.loads((ROOT / "Cargo.lock").read_text())
    old_serial = [p for p in old_lock["package"] if p["name"] == "serialport"]
    serial = [p for p in lock["package"] if p["name"] == "serialport"]
    assert len(old_serial) == len(serial) == 1
    assert serial[0]["version"] == old_serial[0]["version"] == "4.10.0"
    assert serial[0]["checksum"] == old_serial[0]["checksum"]
    original_fail_path = "target/robot_viz_20260929/logs/deny_r1.log"
    assert sha256(original_fail_path) == ORIGINAL_DENY_FAIL_SHA, "原 deny FAIL 被改写"

    inputs = [
        workflow_path,
        "deny.toml",
        "docs/CHANGELOG.md",
        "Cargo.lock",
        "target/robot_viz_20260929/dependency_review.md",
        "target/robot_viz_20260929/check_ci_dependency_config.py",
        "target/hardware_smoke_20260929/diagnosis/gate.py",
    ]
    print(json.dumps({
        "status": "PASS",
        "baseline_commit": BASE_COMMIT,
        "checks": [
            "TOML 精确例外及其余策略保持不变",
            "旧 test 与其他原 jobs 逐字保持不变",
            "独立双平台 viz job 无根 job 依赖且步骤唯一/串行",
            "旧 serialport 版本/checksum 不变",
            "原 deny FAIL SHA 不变",
        ],
        "source_sha256": {path: sha256(path) for path in inputs},
        "original_deny_fail": {"path": original_fail_path, "sha256": ORIGINAL_DENY_FAIL_SHA},
        "cargo_executed": False,
        "ci_executed": False,
    }, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
