# Rerun 双发布者夹具修正 r2：原 Linux 失败保留

本记录补充 `static_review_r1.md`，不覆盖旧审查或将旧 FAIL 回填为 PASS。本次仅修改两个测试文件，未改生产、vendor、控制接收语义；仅运行定向 rustfmt，未运行 Cargo、SSH 或硬件。

## 原失败与机制

Linux `final-r2/linux_outer.log`（SHA256 `73ae5ab00fadbed56f38406a30f99b89def512a31fc747ece9f1e4f3025ef126`）保留：六项集成中阳性失败、其余五项通过；十种 schema 均 logged，740 帧、0 rejected、461 个观测序号缺口，但实例数为 10，严格预期为 11。

原夹具同时以约 50 Hz 向同一 EStop topic 的两个 publisher 发送。`3rd-party/iceoryx2/src/port/details/receiver.rs` 的 `receive` 从连接列表前部扫描，一旦取得样本就返回；桥每轮每 topic 取一个样本，并同步输出 RRD。首连接持续积压时，后部连接可能始终没有接收机会。日志中每种 schema 恰好 74 帧符合这一机制；不能仅归因为 safe-overflow 的随机覆盖。

**生产观测限制仍在：有损观测不保证过载下各 publisher 的公平可见性。一个从未被接收到的实例，其序号缺口也无法由桥推断。不得宣称完整的多实例事件审计、无损接收或过载公平。** root 已裁决本轮 V3 验收十种逻辑 schema 和已观测实例的独立计数语义，不扩展为 vendor/控制接收公平性修改。

## 夹具修正

- 两个合法 EStop publisher 保持存活，改为 A→B→A→B 四阶段；每阶段只有当前来源发送。
- 下一阶段必须先由官方 RRD 解码器，在该实例的状态实体中找到新的 `source_seq`。后两阶段阈值高于该来源此前所有已发送序号，不能重复利用旧记录完成握手。
- 四阶段后停止两个事件源，其他 schema 继续；保持原 3 秒录制时间、严格 11 实例、两个独立事件实体、每个实体只含自身 reason 的断言。
- 运行中 RRD 快照只用于握手，允许尚未写完的文件尾；退出后仍严格解码整个 RRD，并验证实际标量、像素、点云、张量、事件及进程/线程回收。
- 新增 Store 身份断言：所有 `topics/` 数据块必须属于 `StoreKind::Recording`，且对应已出现的 `SetStoreInfo`；不能把 Blueprint store 的数据误当录制内容。

## 本次测试源码

| 文件 | SHA256 |
|---|---|
| `crates/robot-viz/tests/observer_roundtrip.rs` | `81f76c6a2e780f8c1de8fe454d9c84f0ab2f722fe400d56e06ea51ce6a8d72f1` |
| `crates/robot-viz/tests/support/fixtures.rs` | `82d1683a017f1fa4b033d27e44e8c03e039a3aa1ea140554688275538d7b59bb` |

新夹具的 Clippy、Mac/Linux 运行结果仍待 main/root 统一执行与绑定。未据静态修正计 PASS；Viewer 渲染和真实连接/断开仍由 root 单独验收。
