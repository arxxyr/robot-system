"""收集各轮原生软件门的已有原件，不重跑或改写历史。"""
import hashlib
import io
import json
import platform
import subprocess
import sys
import tarfile
from pathlib import Path

base = Path.home() / 'robot-checks'
payloads = {}
for label in ['diagnostics-20260929', 'diagnostics-20260929-r2', 'diagnostics-20260929-r3', 'diagnostics-20260929-r4']:
    run = base / label
    for source in sorted(run.glob('linux_*')):
        if source.is_file():
            payloads[f'{label}/{source.name}'] = source.read_bytes()
    for name in ['source_manifest.json', 'gate.py', 'verify_source.py']:
        payloads[f'{label}/{name}'] = (run / name).read_bytes()
payloads['environment.json'] = json.dumps({
    'scope': '本地 Lima Ubuntu ARM 软件门，不是 Orin，不访问串口',
    'platform': platform.platform(),
    'machine': platform.machine(),
    'rustc': subprocess.check_output([str(Path.home() / '.cargo/bin/rustc'), '+nightly-2026-09-29', '-Vv'], text=True),
}, ensure_ascii=False, indent=2).encode()
rows = [{'path': path, 'sha256': hashlib.sha256(data).hexdigest(), 'bytes': len(data)} for path, data in payloads.items()]
payloads['index.json'] = json.dumps(rows, indent=2).encode()
with tarfile.open(fileobj=sys.stdout.buffer, mode='w|gz') as archive:
    for name, data in payloads.items():
        member = tarfile.TarInfo(name)
        member.size = len(data)
        member.mode = 0o644
        archive.addfile(member, io.BytesIO(data))
