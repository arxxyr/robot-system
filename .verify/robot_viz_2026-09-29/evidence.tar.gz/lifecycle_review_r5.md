# r5 S1 lifecycle 测试差异独立审查

日期：2026-09-29。审查者：baseline_gate_diagnosis。结论：稳定稿静态审查未发现实质阻断。保留真实 factory 入口和原压力门，通过严格镜像订阅及 Linux 实际线程/Node 集合补齐镜像生命周期判据；不增加生产 API。本结论不预填 r5 原生测试结果，不代表整个软件阶段已经全绿。

## 来源与历史失败

- 文件：`crates/robot-s1/src/rr_server/handler.rs`。
- HEAD/r3/r4 原文件 SHA-256：`b455a4efb4f59df8f19f9820985c5890841156fe42f31086b04b12922b3640ae`。
- 本次独审稳定稿 SHA-256：`854ed62e638822c10f871aac2de0612f4b189f5ed33ff6efbfa44d0ef4bc5396`。
- `events_drain/runtime.rs` 当前 SHA-256：`42cd161f6e750c231d9b10731673159b4c1ec8f78fc13178dbd9955a40cd3898`，与 r3 manifest 完全一致。
- `final-r4/linux_outer.log` SHA-256：`ac29c6a35ca1eee4badbb3141a13bb4b37352d4279af5ca7268da7c64f375402`；206–209 行记录旧断言实际 3 Node、预期 2 Node，220 行为 S1 292 passed / 1 failed。原件保留，不改写为通过。

已独立解析 r3/r4 manifest，确认上述 S1 原文件身份一致；对 HEAD 与稳定稿作字节比较，Linux `node_lifetime_tests` 前的生产部分和其后的其他测试模块完全未变。审查时 r5 manifest 尚未生成，因此本文件绑定稳定稿 SHA，最终包应再核该 SHA 与 r5 来源清单一致。

## 判据核对

行号均对应上述稳定稿。

| 判据 | 源码证据 | 结论 |
|---|---|---|
| 原 factory / owner / drain 不改 | 493–506、795；runtime.rs 文件 SHA | 仍实际调用 `make_events_publisher_factory`，返回真实 `EventsPublisherGuard`；未换成测试另建 publisher，未增加 monitor accessor。guard、端口与 Node 的析构顺序及 drain 实现不变。 |
| 原子进程与时间门 | 539–595 | 原哨兵 FD 隔离、双管道 reader、30 秒父监督、超时 kill 后真实 wait、成功状态与完成标记仍保留。没有放宽或删除失败判据。 |
| 原压力及 FD 回收 | 725–783 | 仅隔离子进程的 NOFILE 软/硬上限 128、256 轮、最终 FD 数不得高于初始 baseline 均保留。 |
| 严格镜像准备 | 710–723、790–798 | 正式 subscriber 与镜像 observer 复用同一个对照 Node；镜像打开在 2 秒内等待，失败不转为正式通道 fallback。此时只证明端口可打开，后续双路事件才证明工作。 |
| 实际双路消息 | 799–842 | 原真实 publish、action_id/at_ns/seq 校验保留；新增镜像相同三字段及 observer_seq>0 校验，两路均收到才退出，仍有 2 秒截止。不拿线程存在或镜像 service 目录存在替代收到消息。 |
| 实际 Node 归属 | 668–697、791–792、844–849 | 从本进程 FD 的真实 Node details 提取目录，精确锁定 1→3，且三 Node 集合包含最初对照 Node；差集恰为工厂主 Node 和镜像 Node。目录当时必须存在，退出后连空目录残留也失败。 |
| 实际 worker 退出 | 703–708、793、850–860 | 记录本隔离进程真实 TID 集合；活动集合必须包含原集合且恰好多一条线程。先释放两路 subscriber，再 Drop 原 guard，随后真实 TID 集合必须精确回到原集合，未只检查枚举计数或停止请求位。 |
| 完整 Node 退场 | 853–865 | Drop guard 后只允许留下原对照 Node，工厂差集两目录必须消失；再 Drop 对照 Node 后实际 Node 数为零，先前全部三目录逐项不存在。未主动删除全局资源来制造通过。 |

交叉只读核对 `crates/robot-transport/src/iceoryx2/observer.rs:298–307`，`observer_subscriber` 使用镜像名称和属性验证并调用 `open_with_attributes`，不会首次创建服务，也没有正式通道 fallback。其 498–515 行的 dispatcher Drop 实际调用线程 join，worker RAII 退出；配合本测试的 TID 集合归还判据，不把请求停止当成已退出。

## 边界与后续证据

- 此门是实际生产 factory/owner 的端口生命周期回归；未新增完整 drain 线程、RR/RPC 或硬件链路端到端覆盖，原 drain 实现与其余测试保持不变。
- 本 S1 门直接断言的是实际线程集合、Node 目录和累计 FD 回到基线；没有通过 guard 内部 monitor 直接断言 pending_frames/pending_bytes/estimated_shm_bytes。不得将它写成这些私有计数的直接测量；这些计数已有 transport/RPC 独立门。
- 三 Node 是本进程对照 Node、实际 factory 主 Node、专用镜像 Node。observer 复用对照 Node，新增消费者不会被误算为第四 Node。
- 新增等待仍受原父进程 30 秒硬门约束，256 轮完成与整个 workspace 是否通过，由 root 后续真实 r5 回执判定；r4 FAIL 与其他阶段失败继续保留。
- 本次未运行 Cargo、未进入 VM、未修改源码；只新建此独审文件。
