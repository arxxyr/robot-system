"""仅新建软件夹具/桥，向既有授权 Viewer 实连后检查带数据的 SIGINT 收尾。"""

from __future__ import annotations

import json
import os
from pathlib import Path
import signal
import sys
import time

from live_viewer_check import CASE, CheckFailed, Harness, sha, utc, wait_config


HERE = Path(__file__).resolve().parent
VIEWER_PID = 89722
CONNECT = "rerun+http://127.0.0.1:9876/proxy"


def rpc(h: Harness, label: str, name: str, arguments: dict) -> dict:
    path = h.root / f"{label}.json"
    # 外层进程日志与 viewer_rpc 自己的 stderr/wait 原件使用不同前缀。
    process = h.start(f"mcp_call_{label}", [
        sys.executable, str(HERE / "viewer_rpc.py"), str(path), "tools/call",
        json.dumps({"name": name, "arguments": arguments}),
    ])
    if h.wait(process, 5.0) != 0:
        raise CheckFailed(f"官方 MCP 调用失败：{label}")
    result = json.loads(path.read_text())
    if result.get("result", {}).get("error"):
        raise CheckFailed(f"官方 MCP RPC 错误：{label}")
    content = result["result"]["result"]
    if content.get("isError"):
        raise CheckFailed(f"官方 MCP 工具错误：{label}")
    # 同时检查 wrapper 对自有 MCP 子进程的实际 wait 回执。
    waited = json.loads(path.with_suffix(".wait.json").read_text())
    if waited.get("reaped") is not True or waited.get("wait_returncode") != 0:
        raise CheckFailed(f"官方 MCP 子进程未正常回收：{label}")
    return content


def state(h: Harness, label: str) -> dict:
    content = rpc(h, label, "rerun_get_viewer_state", {})
    for item in content.get("content", []):
        if item.get("type") == "text":
            try:
                value = json.loads(item["text"])
            except json.JSONDecodeError:
                continue
            if isinstance(value, dict) and "recordings" in value:
                return value
    raise CheckFailed("官方 Viewer state 没有 recordings 字段")


def viewer_identity(h: Harness, label: str) -> dict:
    process = h.start(label, [
        "/usr/sbin/lsof", "-nP", "-iTCP:9876", "-sTCP:LISTEN", "-Fp",
    ])
    if h.wait(process, 2.0) != 0:
        raise CheckFailed("既有 Viewer 监听检查失败")
    pids = {int(line[1:]) for line in process.stdout_path.read_text().splitlines()
            if line.startswith("p")}
    if pids != {VIEWER_PID}:
        raise CheckFailed(f"9876 的监听 PID 与授权身份不同：{pids}")
    return {"port": 9876, "listener_pid": VIEWER_PID, "session_id": os.getsid(VIEWER_PID),
            "at_monotonic_ns": time.monotonic_ns(), "owned_by_this_harness": False}


def exercise(h: Harness, receipt: dict) -> None:
    source = json.loads((HERE / "live_normal_r2/receipt.json").read_text())
    for key in ("test_binary", "robot_viz"):
        value = source[key]
        path = Path(value["path"])
        if sha(path) != value["sha256"]:
            raise CheckFailed(f"最终 Mac 产物 SHA 不符：{key}")
        receipt[key] = value
    receipt["viewer_before"] = viewer_identity(h, "viewer_listener_before")
    initial = state(h, "viewer_state_before")
    before_ids = {item["store_id"] for item in initial["recordings"]}
    receipt["recordings_before"] = sorted(before_ids)

    producer_dir = h.root / "producer"
    producer_dir.mkdir()
    producer = h.start("producer", [receipt["test_binary"]["path"], CASE,
        "--ignored", "--exact", "--nocapture"],
        {"ROBOT_VIZ_TEST_ARTIFACTS": str(producer_dir)})
    config, robot_id = wait_config(h, producer, producer_dir)
    receipt["fixture"] = {"config": str(config), "config_sha256": sha(config), "robot_id": robot_id}
    live = h.start("live_bridge", [receipt["robot_viz"]["path"], "--connect", CONNECT,
        "--config", str(config), "--duration-ms", "20000", "--report", str(h.root / "live_report.json")])
    receipt["bridge_started_monotonic_ns"] = live.row["started_monotonic_ns"]

    observed = None
    until = min(time.monotonic() + 10.0, h.work_deadline - 12.0)
    attempts = 0
    while time.monotonic() < until:
        if live.status() is not None:
            raise CheckFailed("确认 Viewer 数据前本次桥已退出")
        current = state(h, f"viewer_state_live_{attempts:02d}")
        attempts += 1
        new = [recording for recording in current["recordings"]
               if recording["store_id"] not in before_ids]
        if len(new) > 1:
            raise CheckFailed("出现多个新 Recording，拒绝猜测归属")
        if len(new) == 1:
            recording = new[0]
            ranges = {timeline["timeline"]["name"]: timeline["time_range"]
                      for timeline in recording.get("timelines", []) if "time_range" in timeline}
            temporal = any(
                name in ranges and ranges[name].get("end", 0) > ranges[name].get("start", 0)
                for name in ("received_time", "robot_time")
            )
            own_view = any(f"/topics/{robot_id}/" in view.get("origin", "")
                           for view in current.get("views", []))
            if temporal and current.get("active_store_id") == recording["store_id"] and own_view:
                observed = {"state_file": f"viewer_state_live_{attempts - 1:02d}.json",
                    "store_id": recording["store_id"], "ranges": ranges,
                    "active_recording_matches": True, "view_origin_matches_robot_id": True,
                    "bridge_alive": live.status() is None, "at_monotonic_ns": time.monotonic_ns()}
                break
        time.sleep(0.05)
    if observed is None:
        raise CheckFailed("未证实新增活动 Recording 收到本夹具的非零时间范围数据")
    receipt["viewer_received_before_sigint"] = observed
    rpc(h, "live_screenshot", "rerun_save_screenshot", {"file_path": str(h.root / "live.png")})
    screenshot = h.root / "live.png"
    if not screenshot.is_file() or screenshot.read_bytes()[:8] != b"\x89PNG\r\n\x1a\n":
        raise CheckFailed("Viewer 没有保存实际 PNG 截图")
    if live.status() is not None:
        raise CheckFailed("SIGINT 前本次桥已经退出，不作为停止验收")
    # 只向本次直接子进程父 PID 发送 SIGINT；不信号整个组或 SDK worker。
    live.child.send_signal(signal.SIGINT)
    event = {"signal": "SIGINT", "target": "own_bridge_parent_pid", "pid": live.child.pid,
             "expected_injection": True, "at": utc(), "at_monotonic_ns": time.monotonic_ns()}
    live.row["signals"].append(event)
    receipt["sigint"] = event
    if h.wait(live, 12.0) != 0:
        raise CheckFailed("本次桥 SIGINT 后非零退出")
    report = json.loads((h.root / "live_report.json").read_text())
    receipt["live_report"] = report
    if not (report.get("frames_logged", 0) > 0 and report.get("output_status") == "success"
            and report.get("worker_reaped") is True and report.get("frames_rejected") == 0):
        raise CheckFailed("桥报告缺少正 logged 帧、success 或 worker_reaped，或有效夹具被拒")
    if any(not topic.startswith(f"/{robot_id}/") for topic in report.get("topics_seen", [])):
        raise CheckFailed("桥报告混入其他 robot topic")
    if h.wait(producer, 8.0) != 0:
        raise CheckFailed("完整 schema 原夹具非零退出")
    receipt["viewer_after"] = viewer_identity(h, "viewer_listener_after")
    receipt["checks_status"] = "PASS"


def main() -> int:
    output = HERE / "live_gui_sigint_r2"
    output.mkdir(exist_ok=False)
    h = Harness(output)
    receipt = {"schema": 1, "started_utc": utc(), "mode": "live_gui_sigint",
        "checks_status": "FAIL", "budget_seconds": 50.0, "connect_url": CONNECT,
        "harness_sha256": sha(Path(__file__)),
        "shared_harness_sha256": sha(HERE / "live_viewer_check.py"),
        "viewer_rpc_sha256": sha(HERE / "viewer_rpc.py"),
        "binary_identity_source": "live_normal_r2/receipt.json; final-r3 来源由 root 绑定",
        "scope": "自有软件夹具/桥；外部既有 Viewer 不归本 harness 清场"}

    def interrupted(signum: int, _frame: object) -> None:
        raise CheckFailed(f"harness 收到 {signal.Signals(signum).name}")

    signal.signal(signal.SIGINT, interrupted)
    signal.signal(signal.SIGTERM, interrupted)
    try:
        exercise(h, receipt)
    except BaseException as error:
        h.errors.append(f"{type(error).__name__}: {error}")
    finally:
        def cleanup_interrupted(signum: int, _frame: object) -> None:
            h.errors.append(f"清场期间收到 {signal.Signals(signum).name}")

        signal.signal(signal.SIGINT, cleanup_interrupted)
        signal.signal(signal.SIGTERM, cleanup_interrupted)
        receipt["owned_sessions_empty_and_direct_children_reaped"] = h.cleanup()
        receipt["processes"] = [process.row for process in h.processes]
        receipt["session_audits"] = h.audit
        receipt["artifacts"] = [
            {"path": str(path.relative_to(output)), "bytes": path.stat().st_size, "sha256": sha(path)}
            for path in sorted(output.rglob("*")) if path.is_file()
        ]
        receipt["finished_utc"] = utc()
        receipt["elapsed_seconds"] = time.monotonic() - h.started
        if receipt["elapsed_seconds"] >= 50:
            h.errors.append("超过 50 秒总预算")
        receipt["errors"] = h.errors
        good = (receipt["checks_status"] == "PASS" and not h.errors
                and receipt["owned_sessions_empty_and_direct_children_reaped"])
        receipt["status"] = "PASS" if good else "FAIL"
        path = output / "receipt.json"
        with path.open("x") as stream:
            json.dump(receipt, stream, ensure_ascii=False, indent=2)
            stream.write("\n")
        print(json.dumps({"status": receipt["status"], "receipt": str(path),
            "receipt_sha256": sha(path), "errors": h.errors}, ensure_ascii=False), flush=True)
    return 0 if good else 1


if __name__ == "__main__":
    raise SystemExit(main())
