# final-r3 增量独立审查（2026-09-29）

结论：本次冻结源码的增量静态审查通过，未发现需阻断交付的新增代码问题。认可范围为实例显示缓存、实际颜色范围、确定性双发布者夹具、独立 CI 门和精确依赖例外；不是 Linux、最终 Viewer、硬件或全局 CI 的完成声明。旧审查 `static_review_r1.md`、`fixture_review_r2.md` 与旧失败原件保持不变。

## 来源绑定

`final-r3/source_manifest.json` SHA-256：`9d06debc169d92e3b9ba99a84f0c7e6e82d0ce70bf289692c44d72f5ee5ae103`。独立读取全部 620 项，在审查时 **620/620 匹配**，包括 `AGENTS.md -> CLAUDE.md` 软链；没有运行 Cargo、SSH 或硬件。

`static_review_r3_source_check.json` SHA：`83a59ea52164b3b2380dd3c602feef2f342bfa8d7217301f21a85919dd625a1d`。CI 文件不在 620 个构建输入中，另行绑定其实际文件，不能误写成由该 manifest 覆盖。

| 关键文件 | SHA-256 |
| --- | --- |
| `crates/robot-viz/src/output.rs` | `9bc1f652cf9028ff81c7edbe12a04035ef91b2d74b8410991136beb1968b6e0f` |
| `crates/robot-viz/src/runtime.rs` | `a72861ad03cf06e1d7da854fadb868aaca1d12c5a16d609bb6233443d94e1a83` |
| `crates/robot-viz/tests/observer_roundtrip.rs` | `ede06db45c74a69750eb444054970a8c568906a15c01a3d75c7946e5531ad23f` |
| `crates/robot-viz/tests/support/fixtures.rs` | `82d1683a017f1fa4b033d27e44e8c03e039a3aa1ea140554688275538d7b59bb` |
| `deny.toml` | `fa433f2ab59c3cfe1278126f52b70ba32e6194338e0854f117881126f5ab22eb` |
| `.github/workflows/ci.yml`（另行绑定，10499 bytes） | `f9b24038470116eae7b499709739d2cd565af54da2c8660acf8163d24f693b7f` |

## 已复核的实现边界

1. **实例缓存与蓝图**：`Output` 的 topic 上限 64、每 topic 实例上限 8，与运行时窗口一致。稳定 A/B 交替不会重发 Blueprint，也不会隐藏另一合法实例；官方 memory sink 单测明确数激活命令并核两实例查询。运行时在新有效帧登记前同步 retain；坏 body 导致窗口淘汰后也同步 retain。拒绝同实例原 seq 倒退的早退不发生窗口淘汰，未形成漏清理分支。topic 退休删除视图并标记 dirty，下一次 health/log 刷新蓝图，历史录制不删除。退订/淘汰仍不表示任务或硬件执行结束。
2. **曲线与媒体**：按量纲拆分查询，用官方解析器测试只保留指定来源及末尾 `/**`；最多 512 个实例来源，不累计无界历史过滤器。图像/点云/Tensor 独立视图，没有叠加来源暗示共享外参。新布局只调整展示、元信息和范围，不改 wire、原数组值、时钟或控制行为。
3. **Tensor 范围**：普通有限非退化样本使用实际 `[min,max]`，常量用 `max(abs(c)*1e-6,1)` 扩展显示范围；F64 极端值保留有限原始范围。端点转 F32 非有限、跨度溢出或归零会标记 `GPU_PREVIEW_LIMIT`，原 Tensor F64 和 intensity F32 buffer 保留。本实现有意不尝试把无法表示的值伪造为可渲染数据；该标记是预览限制声明，不是修复 GPU 退化，也不是全精度保证。非有限 Tensor 输入仍由既有解码器拒绝。实图与官方源码解释见 `tensor_color_review.md`。
4. **双发布者夹具**：A→B→A→B 四窗，当前 RRD 内匹配 Recording store 的实际事件 source_seq 达到本窗新阈值才切换；第三/四窗不能复用先前记录。仍用原 3 秒运行预算、外层 35 秒监督及严格 11 实例断言，不以延时或减少断言掩盖失败。最终严格解码所有 RRD 消息，并检查 topic 数据属于正确 Recording store，握手的截断文件快照不能替代完整性门。
5. **CI 与依赖**：独立 Ubuntu/macOS job 不依赖既有根 test，串行 fmt→定向 Clippy→viz lib→六项 ignored→release-tools；bash pipefail 保留 Cargo 退出码，always 上传证据。原 job 及依赖未改。该独立 job 不运行 transport 专项动态测试，不能代称镜像全套动态回归或全局 CI 已绿。许可证仅新增四个精确包版本；paste 仅豁免指定维护公告，serialport 仅豁免既有 `4.10.0` 的撤回记录，未升级串口依赖且全局 yanked deny 保留。

## 已读到的动态证据与仍待补项

以下是审查时已完成的 **Mac** 日志内容复核，不是 reviewer 重新执行；主开发已报告真实完成：

| 原件 | 内容 | SHA-256 |
| --- | --- | --- |
| `logs/clippy_r12.log` | 定向 Clippy 完成 | `3fb7552c7b6e1b1404a2041ea1b9ec3da5ef562fd2c52b0b9f46e2b924fb77b9` |
| `logs/viz_units_r3.log` | 17 passed / 0 failed | `720e0b68c6b30c3fa80acea7d3c68cca13feea2505303e548a6d6d00c8c77ccf` |
| `logs/observer_roundtrip_r2.log` | 6 passed / 0 failed，31.84 秒 | `5ec4127d697fb4ab5ea0dcb128bba1ed73482596370c39cfb0d76f8c9c518d35` |

阳性 `artifacts_r2/viz_all_89493_826861668751458_1/report.json`：1000 logged、0 rejected、10 schema、11 实例、0 gap/drop、`worker_reaped=true`。日志四窗实际序号依次为 A16 / B2 / A19 / B3，后二窗阈值为 19/3，满足新记录握手。另 72 个累计短命 topic 场景发现 72、退休 8、无拒绝；六份报告均 `worker_reaped=true`。目录错误与黑洞 Viewer 报 error，符合负例；SIGINT 场景本次发生在 SDK worker 已建文件但尚无输入帧时，证明该时点收尾，不冒称已消费数据流后的中断验收。

Linux final-r3 完整门、最新真实 Viewer 重渲染与成功连接后断开 Viewer 的最终结果，审查时仍由 root 执行/汇总，**本报告不预写通过**。CI 远端托管运行未执行不称通过；原 Linux final-r2 的阳性 FAIL 与所有更早失败必须保留。

## 保留限制

iceoryx2 `receiver.rs:619–654` 每次从连接存储首部扫描并返回第一个可用样本。先连接发布者持续饱和时可能让后连接无样本可见；确定性交替夹具验证实例正确性，没有实现或承诺过载公平、全量无损、多实例完整事件审计。一个从未被观察到的实例，其丢失数量不能由本桥推算；gap/drop 仅在可见实例及其缓存计数窗口解释。

观测镜像 worker 已改变非实时发布者资源与退出路径，不能写“运行时完全未变”；保留原控制 QoS、recipients、发布返回和原 wire 的边界。未重部署 Orin 正式件、未完成本轮 RT 硬件再测，通信硬化硬件门和 D15 仍开放。
