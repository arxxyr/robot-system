# S0 关闭回归 r5 独立静态审查

本审查只读核对 Lima `robot-viz-check` 的原失败日志、4096 字节观测页及本地源码；未运行 Cargo、未重跑子进程、未涉及 Orin 或硬件。结论：两项测试窄修可接受，新的动态结果尚待 root 验证。原 r4 `comm_fault_startup` 的 **11 PASS / 2 FAIL** 保留，不能回填为通过。

## 原证据与解析

客体日志：`/home/loosqk.guest/robot-checks/viz-final-r4/linux_s0_shutdown.log`。失败目录 `/tmp/.tmplWJpgA` 为 Executor，`/tmp/.tmprrh0yD` 为 IPC。按 `comm_fault_observation.rs::ObservationField` 顺序读取 ABI v4 的前 75 个 little-endian u64，偏移为索引乘 8；未将未导出的零值解释为“未发生”。完整字段、偏移、原件长度与 SHA 保存在同目录 `shutdown_r4_observation_decode.json`，SHA-256 `4f8fad27c36ebe10667d0e30bdace44f97f83bcd67cf1f073451c9d5dc22f6e1`。

| 原件 | 字节数 | SHA-256 |
|---|---:|---|
| Executor observation | 4096 | `6ce80bdff975e8804ebf3c352438c7043c79bc5eb3a6866d4ba698ffe65a4072` |
| Executor s0.log | 9184 | `cf85ef80b4e6c462adfce8685cfa5a7b619bb01a1706411631d7afbef1045e71` |
| IPC observation | 4096 | `e7022482fea5b324f6d7390a635d611703c851db98a78e2ffd0e779f702fcd2f` |
| IPC s0.log | 7910 | `94b48e54a74662838badb61b47efb5ccaf67e69e3fb548e5c4f895bafbac99fe` |

Executor 原失败已真实非零退出、没有残余句柄：`R4C_EXIT_V1` 的 ACK/Clear/flush 成功，10 个 join 均成功，`failures=[]`；观测页 StopBitmap=255、ResidualBitmap=0、ExecutorPublishFailureAttempt=5820154757191、BeforeProcessExit=5820290462025。失败点是日志断言 `worker=Executor`：ANSI 控制字符实际夹在字段名、等号和值之间，因而原字面量不连续。不是退出链失败。

IPC 页关键字段如下：

| 字段 | 字节偏移 | 原始值 |
|---|---:|---:|
| Ready | 32 | 5837524145450 |
| RuntimeArmed | 224 | 5837527781616 |
| ShutdownDeadline | 264 | 5853703233619 |
| IpcPublishFailureAttempt | 216 | 0 |
| Fired / BeforeProcessExit | 48 / 280 | 0 / 0 |

`RuntimeArmed` 是监督器第一次看到 READY runtime 的时间，不能当作关闭开始时间。真实关闭 ticket 的 D 为 `5853703233619`，D 减生产 10 秒为 `5843703233619`，距 READY 为 **6.179088169 秒**。日志在进程启动后 6.206339712 秒记录 READY 后 worker 退出，随后只出现 ClearRR stopped。

旧测试把耗尽等待和关闭等待合并为 READY 后约 15 秒，隐含 8000 次 IPC 发布约 4 秒的速度假设。精确可复算的是 `D - (Ready + 15 秒) = 1.179088169 秒`；旧父进程没有单独记录 `wait_exit` 实际起点及 kill 时间，因此该数不是纳秒级实测提前 kill 量。原父预算未给这次较慢耗尽留下完整 10 秒关闭窗口，父超时 kill 后真实 wait；这足以解释为何没有最终退出报告，**不能证明给足原预算必然通过**。失败尝试值在 teardown 后才导出，当前零值也不能证明 IPC 没有耗尽。

## 窄修审查

冻结文件 `crates/robot-s0/tests/comm_fault_startup.rs` SHA-256：`61fe856df3aad1f6163e267a81bcd2f7369fe32ea6fff6baf9f4e3130cd01380`。

- 子进程启动前设置 `NO_COLOR=1` 并清除继承的 `ROBOT_LOG_FORMAT`。`robot-logging::init` 不强制覆盖 ANSI，锁定的 tracing-subscriber 0.3.23 默认确实读取非空 `NO_COLOR`；已有精确 worker/错误/日志先后断言全部保留。
- 仅两个快照耗尽测试改为原 15 秒阶段门等待非零 `shutdown_deadline_ns`，然后按**原 ticket D 加既有 1 秒回收余量**等真实退出。不从观测时间重新计算 10 秒；无 ticket 的已退出子进程明确失败。旧 `wait_exit` 仅等价委托绝对期限 helper。
- 原 IPC 退出后 `failure_attempt → reap` **9.75–10.1 秒**严格门、READY 4 秒、1000/8000 次注入、ACK/残件/真实回收判据都保留；生产关闭预算、调度、镜像实现与安全语义未改。

本次证据尚未表明镜像 join 阻塞：IPC 无 ACK 原本会先等关闭 L 才收集 join；Executor 已给出包含 Publisher 的成功 join。镜像仍有新增非 RT worker 资源和 Drop join，不能宣称运行时完全未变或所有关闭路径已经动态通过。快照耗尽在写奇数版本前返回，上一偶版本与载荷不变，未发现本次耗尽导致 snapshot reader 永久奇版本自旋的依据。

待验：root 在冻结 r5 来源上运行原严格门，核真实退出、原时间包络和所有 join/残件事实；若仍失败，应保留新原件定位，不能增加生产预算或用重复运行覆盖失败。
