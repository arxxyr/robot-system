"""追加隔离 Linux 软件证据，不改写先前本机及硬件归档。"""
import hashlib
import io
import json
import tarfile
from pathlib import Path

root = Path.cwd()
source = root / 'target/hardware_smoke_20260929/diagnosis'
destination = root / '.verify/hardware_smoke_2026-09-29'
archive_path = destination / 'diagnosis_linux_evidence.tar.gz'
assert not archive_path.exists()
for name, digest in {
    'evidence.tar.gz': 'ce5fdf02cc44f4bb47ca187972f8f1bc6b3e03433d653747ca20be068a880900',
    'run_01_evidence.tar.gz': '51fd09e979bc3b4e5002a7d6ef9f17b7784a9e57bc06b57465e62ff5f3dab83b',
    'diagnosis_local_evidence.tar.gz': 'bfd8eaca2a420cce8965278d59429166fa8cf17408fdd202327abc2eb62213ae',
}.items():
    assert hashlib.sha256((destination/name).read_bytes()).hexdigest() == digest
files = {str(p.relative_to(source)): p.read_bytes() for p in sorted((source/'linux_native_raw').rglob('*')) if p.is_file()}
for suffix in ['', '_r2', '_r3', '_r4']:
    for extension in ['json','log']:
        name = f'linux_vm_checks{suffix}.{extension}'
        files[name] = (source/name).read_bytes()
files['final_native_review.md'] = (source/'final_native_review.md').read_bytes()
for name in ['prepare_diagnostic_r4.py','collect_diagnostic_linux.py','check_diagnostics_linux_r4.sh','bootstrap_linux.log','bootstrap_linux_r2.log']:
    files['tooling/'+name] = (root/'target/robot_viz_20260929'/name).read_bytes()
manifest = json.loads((source/'source_manifest_r4.json').read_text())
changed = ['crates/robot-adapters/feetech/src/adapter.rs','crates/robot-adapters/feetech/src/diagnostic.rs',
           'crates/robot-adapters/feetech/tests/abort_diagnostics.rs','crates/robot-cli/src/bin/robotctl.rs',
           'crates/robot-s0/src/bin/s0_daemon.rs']
for name in changed:
    data = (root/name).read_bytes()
    row = next(row for row in manifest['files'] if row['path'] == name)
    assert hashlib.sha256(data).hexdigest() == row['sha256'], name
    files['sources/'+name] = data
index = [{'path':name,'sha256':hashlib.sha256(data).hexdigest(),'bytes':len(data)} for name,data in files.items()]
files['index.json'] = json.dumps(index,indent=2).encode()
with tarfile.open(archive_path,'w:gz') as archive:
    for name,data in files.items():
        member=tarfile.TarInfo(name);member.size=len(data);member.mode=0o644
        archive.addfile(member,io.BytesIO(data))
with tarfile.open(archive_path) as archive:
    for row in index:
        data=archive.extractfile(row['path']).read()
        assert len(data)==row['bytes'] and hashlib.sha256(data).hexdigest()==row['sha256']
summary_path=destination/'diagnosis_summary.json'
summary=json.loads(summary_path.read_text())
summary['status']='LOCAL_AND_LINUX_ARM_PASS_ORIN_NOT_RUN'
summary.pop('committed',None);summary.pop('commit_blocker',None)
summary['software_stage_ready_for_commit']=True
summary['linux_arm_validation']={
    'platform':'隔离 Lima Ubuntu 24.04.4 ARM，非 Orin',
    'toolchain':'nightly-2026-09-29 / rustc 1.101.0-nightly c1070d693',
    'source_manifest_sha256':hashlib.sha256((source/'source_manifest_r4.json').read_bytes()).hexdigest(),
    'source_files':605,'source_before_and_after_match':True,
    'cargo_fmt_all':'PASS','clippy_all_all_targets_deny_warnings':'PASS',
    'feetech_test_binaries_pass_counts':[147,5,12,3],
    'serial_convergence_rt_guard_pass_count':42,
    'all_commands_waited_and_reaped':True,
    'prior_failures_preserved':['r1 CLI nightly lint','r2 fmt indentation','r3 S0 nightly lint'],
    'independent_review':'PASS',
    'rerun_and_observer_mirror_included':False,
    'extra_source_changes':changed[-2:],
    'archive':str(archive_path.relative_to(root)),
    'archive_sha256':hashlib.sha256(archive_path.read_bytes()).hexdigest(),
    'archive_bytes':archive_path.stat().st_size,'indexed_files':len(index),
}
summary_path.write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(summary['linux_arm_validation'],ensure_ascii=False))
