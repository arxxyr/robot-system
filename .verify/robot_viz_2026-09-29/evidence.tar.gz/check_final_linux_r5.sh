#!/usr/bin/env bash
# r5 仅修订 S1 Linux 生命周期测试；生产门由生产输入相同的 r3/r4 承接。
set -euo pipefail
export PATH="$HOME/.cargo/bin:$HOME/.local/bin:$PATH"
host_inputs="/Users/loosqk/repo/rust/robot-system/target/robot_viz_20260929/final-r5"
dest_dir="$HOME/robot-checks/viz-final-r5"
test ! -e "$dest_dir"
mkdir -p "$dest_dir"
tar xzf "$host_inputs/source.tar.gz" -C "$dest_dir"
cd "$dest_dir"
export CARGO_TARGET_DIR="$HOME/robot-checks/build"
export CARGO_BUILD_JOBS=4
export RUSTC_WRAPPER=""
export CARGO_BUILD_RUSTC_WRAPPER=""
uv run --no-project python verify_source.py > linux_source_before.json
uv run --no-project python gate.py linux_fmt -- cargo +nightly-2026-09-29 fmt --all
uv run --no-project python gate.py linux_clippy -- cargo +nightly-2026-09-29 clippy --locked --all --all-targets -- -D warnings
uv run --no-project python gate.py linux_s1_node_lifecycle -- cargo +nightly-2026-09-29 test --locked -p robot-s1 --features test-fault-backend --lib rr_server::handler::node_lifetime_tests::action_publisher_releases_node_under_fd_limit -- --exact --nocapture
uv run --no-project python gate.py linux_s0_shutdown -- cargo +nightly-2026-09-29 test --locked -p robot-s0 --features test-comm-fault-hook --test comm_fault_startup -- --test-threads=1 --nocapture
mkdir native_peers
cp "$HOME/robot-checks/viz-final-r3/native_peers/"* native_peers/
cp "$HOME/robot-checks/viz-final-r3/linux_peers.json" linux_peers_source_r3.json
export B4_E2E_BIN_S0_DAEMON="$PWD/native_peers/s0_daemon"
export B4_E2E_BIN_S1_DAEMON="$PWD/native_peers/s1_daemon"
export B4_E2E_BIN_ROBOT_RPC_GATEWAY="$PWD/native_peers/robot_rpc_gateway"
export B4_E2E_BIN_ROBOTCTL="$PWD/native_peers/robotctl"
uv run --no-project python gate.py linux_workspace -- cargo +nightly-2026-09-29 test --locked --workspace --features robot-s1/test-fault-backend -- --test-threads=1
uv run --no-project python verify_source.py > linux_source_after.json
