# Tensor 着色独立诊断（2026-09-29）

结论：本轮 2×2 数据 `[[0.5,1.5],[2.5,3.5]]` 的深紫显示来自官方默认颜色范围启发式。数据数值没有损坏；F32/F64 两种输入均复现相同显示。显式范围 `[0.5,3.5]` 后四格颜色明显不同。此结论来自官方同版 SDK 对照及 root 独占 Viewer 的真实截图，不以仅生成文件代替渲染验证。

## 可复核产物

生成命令：`uv run --script target/robot_viz_20260929/tensor_color_controls.py target/robot_viz_20260929/tensor_color_controls_r3`。PEP 723 隔离依赖 `rerun-sdk==0.38.1`，实际 NumPy 2.5.3；strict mode 开启，进程真实退出 0，无警告。脚本不连接 Viewer、不启动生产进程、不改原录制。

| 产物 | SHA-256 |
| --- | --- |
| `tensor_color_controls.py` | `77d40aa81c805a90fe89bcf30d2b2a07c69fb8b7a7708136d34d39111c407710` |
| `tensor_color_controls_r3/tensor_color_controls.rrd`（119884 bytes） | `976389c29cd419e0fbdda8a28aeb0a500b2f873f613907c03729a7af04f0582a` |
| `tensor_color_controls_r3/tensor_color_controls.rbl` | `c6632773880d3e227ad97720f134cc483544f5f893a71e484f6502eea977e23e` |
| `tensor_color_controls_r3/manifest.json` | `7e33290e8ecc028004e2f93b7657b4187bbb73a3e0610f7ce4e9f5e47316f3e2` |
| `viewer_r1/tensor_control.png` | `abbc3378ff19ce62736e2a85b48ff953a5a39637dc4df288384309d06d24db8e` |

以上路径均相对本报告目录。六个视图左列 F32、右列 F64，三行依次自动范围、显式 `[0.5,3.5]`、显式 `[0,255]`；全部相同数值、形状、Viridis、gamma=1、nearest。截图已独立查看：第一及第三行深紫，第二行紫/蓝/绿/黄，左右列一致。root 的 MCP `wait_for` 曾用错误 F32 标签超时，原 `viewer_r1/tensor_control_wait.*` 保留；后续 state 确认录制加载及截图成功，该超时不能改写为产物加载失败。

首次 r1 生成有 `view_fit` 字符串拼写警告，r2 错误枚举入口导致退出 1，均保留；r3 使用实际支持的 `FillKeepAspectRatio` 及 strict mode。r1/r2 不是最终对照产物。

## 同版官方源码解释

- `upstream/re_view_tensor-0.38.1/src/visualizer_system.rs:83–103`：未提供 Tensor ValueRange 时走 `typed_fallback_for`。
- `upstream/re_view_tensor-0.38.1/src/view_class.rs:114–120`：属性面板数据范围来自 `TensorStatsCache`；`:356–374` 着色使用另行解析的 `data_range`，两者不是同一显示设置。
- `upstream/re_viewer_context-0.38.1/src/gpu_bridge/mod.rs:27–44`：浮点 `[0,1]` 保留该范围；其他全部落在 `[0,255]` 的数据使用 `[0,255]`；常量的后备路径扩展为 `[min-1,max+1]`。
- `upstream/re_view_tensor-0.38.1/src/tensor_slice_to_gpu.rs:126–146`：F32 原样传 R32Float，F64 只在 GPU 上传阶段缩为 F32。四个本次值均能精确表示，不能将本次问题归因于 F64 精度损失。
- `upstream/re_renderer-0.38.1/shader/rectangle_fs.wgsl:18–20`：直接除以 `range.y-range.x`，显式 `[c,c]` 不安全。显式 ValueRange 绕过启发式，必须保证 GPU 转换后端点有限、严格递增且跨度有限、非零；仅检查 F64 的 min!=max 不够。
- 官方 API 文档也明确解释默认范围可能扩为图像范围：[Tensor 文档](https://docs.rs/rerun/0.38.1/rerun/struct.Tensor.html)。

补充官方 crates.io 原件：`upstream/re_viewer_context-0.38.1.crate` SHA `c6713a7c122d0e0e5389ec3962a9feed587643c3026fc4d45e341fc735bdbab0`；`upstream/re_renderer-0.38.1.crate` SHA `4c5f7c30d52d635fc2a9b7d4ede7b677365ef5ce27195c77f7dec28269d291ba`。仅解包源码，没有 Cargo 或安装改动。

## 修复验收边界

同意普通非退化 Tensor/intensity 显式使用当前样本实际范围，只影响着色，不改 dtype、形状、数值。常量或 F32 转换后收缩为零跨度的情况须安全扩展显示范围并纯测；非有限输入沿既有拒绝路径。不能宣称任意有限 F64 均能被 GPU 保真显示：超出 F32 可表示范围或可分辨精度是官方显示路径限制，应明确说明，不能为颜色好看改写原数据。

本报告不宣称生产范围修复、最新 UI、Linux/Mac 新夹具或正式硬件已验收；其代码与动态证据由 main/root 后续冻结归档。D15、硬件再测及正式部署状态均不因本诊断改变。
