---
title: Reference
order: 5
cards: true
---

The reference docs detail how to use the logging APIs and the viewer.

-   [Types](./reference/types.md) - Archetypes, components, and encodings
-   [Viewer](./reference/viewer/overview.md) - The Rerun Viewer UI
-   [CLI manual](./reference/cli.md) - Command-line interface reference
-   [Python APIs](https://ref.rerun.io/docs/python) - Python SDK reference
-   [Rust APIs](https://docs.rs/rerun/) - Rust SDK reference
-   [C++ APIs](https://ref.rerun.io/docs/cpp) - C++ SDK reference
-   [Web Viewer API](https://ref.rerun.io/docs/js/) - JavaScript/TypeScript web viewer API
-   [Changelog](./changelog.md) - release notes and breaking changes for each version
-   [Migration guides](./reference/migration.md) - upgrading from versions before 0.34
