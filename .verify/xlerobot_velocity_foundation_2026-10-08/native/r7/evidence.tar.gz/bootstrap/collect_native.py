#!/usr/bin/env python3
"""本轮纯软件原件收集；默认仅计划，归档一致性不替代测试或硬件验收。"""

import argparse
from contextlib import contextmanager
import datetime
import hashlib
import io
import json
import os
from pathlib import Path, PurePosixPath
import stat
import sys
import tarfile


TREES = ("qa-r7", "source")
BOOTSTRAP_FILES = ("natural_runner.py", "artifacts.py", "run_checks.py", "expected_source.json", "expected_tests.json", "source_export.json", "receive_source.py", "receive_result.json", "collect_native.py")
FROZEN = {}
INDEX_NAME = "archive-index.json"
CHUNK = 1024 * 1024


def require(condition, message):
    if not condition:
        raise ValueError(message)


def encoded(value):
    return (json.dumps(value, ensure_ascii=False, sort_keys=True, indent=2,
                       allow_nan=False) + "\n").encode()


def sha_file(path):
    with path.open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


def canonical(path):
    require(path.is_absolute() and ".." not in path.parts and path == path.resolve(),
            "必须为无符号链接的规范绝对路径：" + str(path))


def file_state(info):
    return (info.st_dev, info.st_ino, info.st_mode, info.st_size,
            info.st_mtime_ns, info.st_ctime_ns)


def directory_state(info):
    return (info.st_dev, info.st_ino, info.st_mode, info.st_mtime_ns, info.st_ctime_ns)


def no_link_path(base, path):
    """每次打开前重查所有父目录；不用解引用链接后的路径冒充原件。"""
    require(path.is_relative_to(base), "原件越出本轮根")
    cursor = base
    require(stat.S_ISDIR(cursor.lstat().st_mode), "本轮根不再是普通目录")
    for part in path.relative_to(base).parts[:-1]:
        cursor = cursor / part
        require(stat.S_ISDIR(cursor.lstat().st_mode), "拒绝链接或非目录父路径：" + str(cursor))


@contextmanager
def open_original(base, path, expected):
    no_link_path(base, path)
    require(file_state(path.lstat()) == expected, "原件打开前身份改变：" + str(path))
    fd = os.open(path, os.O_RDONLY | os.O_NOFOLLOW)
    try:
        require(file_state(os.fstat(fd)) == expected, "原件打开时身份改变：" + str(path))
        stream = os.fdopen(fd, "rb")
        fd = None
        with stream:
            yield stream
            require(file_state(os.fstat(stream.fileno())) == expected, "原件读取期间改变：" + str(path))
        require(file_state(path.lstat()) == expected, "原件读取后身份改变：" + str(path))
    finally:
        if fd is not None:
            os.close(fd)


def inventory(base):
    files, directories = {}, {}

    def visit(path):
        no_link_path(base, path)
        info = path.lstat()
        name = path.relative_to(base).as_posix()
        if stat.S_ISDIR(info.st_mode):
            directories[name] = {"mode": stat.S_IMODE(info.st_mode),
                                 "state": directory_state(info)}
            for child in sorted(path.iterdir()):
                visit(child)
        else:
            require(stat.S_ISREG(info.st_mode), "拒绝符号链接或特殊文件：" + str(path))
            files[name] = {"mode": stat.S_IMODE(info.st_mode), "bytes": info.st_size,
                           "uid": info.st_uid, "gid": info.st_gid,
                           "mtime_ns": info.st_mtime_ns, "state": file_state(info)}

    for name in TREES:
        path = base / name
        require(path.exists() and stat.S_ISDIR(path.lstat().st_mode), "缺少普通证据目录：" + name)
        visit(path)
        require(any(key.startswith(name + "/") for key in files), "证据目录为空：" + name)
    bootstrap = base / "bootstrap"
    no_link_path(base, bootstrap)
    info = bootstrap.lstat()
    require(stat.S_ISDIR(info.st_mode), "bootstrap 必须为普通目录")
    directories["bootstrap"] = {"mode": stat.S_IMODE(info.st_mode), "state": directory_state(info)}
    for name in BOOTSTRAP_FILES:
        path = bootstrap / name
        require(stat.S_ISREG(path.lstat().st_mode), "缺少 bootstrap 普通文件：" + name)
        visit(path)
    for kind, names in FROZEN.items():
        for name in names:
            for suffix in ("", ".build.json"):
                require(f"release-r1/{kind}/{name}{suffix}" in files,
                        "缺少冻结原件或 sidecar：" + kind + "/" + name + suffix)
    return files, directories


def make_index(base, files, directories):
    rows = []
    for name, data in sorted(files.items()):
        with open_original(base, base / name, data["state"]) as stream:
            digest = hashlib.file_digest(stream, "sha256").hexdigest()
        rows.append({"path": name, "sha256": digest,
                     **{key: data[key] for key in ("bytes", "mode", "uid", "gid", "mtime_ns")}})
    return {"schema": "P7_NATIVE_EVIDENCE_INDEX_V1",
            "scope": "原件逐字归档；不解释或改写其中 PASS/FAIL，不代表功能验收。",
            "files": rows,
            "directories": [{"path": name, "mode": data["mode"]}
                            for name, data in sorted(directories.items())]}


def write_archive(base, raw, files, directories, index_bytes):
    with tarfile.open(fileobj=raw, mode="w:gz", format=tarfile.PAX_FORMAT) as archive:
        for name, data in sorted(directories.items()):
            entry = tarfile.TarInfo(name)
            entry.type, entry.mode = tarfile.DIRTYPE, data["mode"]
            archive.addfile(entry)
        for name, data in sorted(files.items()):
            entry = tarfile.TarInfo(name)
            entry.size, entry.mode = data["bytes"], data["mode"]
            entry.uid, entry.gid = data["uid"], data["gid"]
            entry.mtime = data["mtime_ns"] // 1_000_000_000
            with open_original(base, base / name, data["state"]) as stream:
                archive.addfile(entry, stream)
        entry = tarfile.TarInfo(INDEX_NAME)
        entry.size, entry.mode = len(index_bytes), 0o644
        archive.addfile(entry, io.BytesIO(index_bytes))


def verify_archive(out, index, index_bytes):
    expected = {row["path"]: row for row in index["files"]}
    dirs = {row["path"]: row for row in index["directories"]}
    seen = set()
    with tarfile.open(out, "r:gz") as archive:
        for member in archive:
            name = member.name
            path = PurePosixPath(name)
            require(not path.is_absolute() and ".." not in path.parts and path.as_posix() == name,
                    "归档成员路径不安全")
            require(name not in seen, "归档存在重复成员：" + name)
            seen.add(name)
            if name in dirs:
                require(member.isdir() and member.mode == dirs[name]["mode"], "目录类型或原 mode 不符")
            else:
                require(member.isfile() and not member.issym() and not member.islnk(), "拒绝非普通归档成员")
                stream = archive.extractfile(member)
                require(stream is not None, "归档成员无法读取")
                with stream:
                    if name == INDEX_NAME:
                        require(member.size == len(index_bytes) and stream.read() == index_bytes,
                                "包内外索引不同")
                    else:
                        require(name in expected, "归档存在未索引成员：" + name)
                        row = expected[name]
                        require(member.size == row["bytes"] and member.mode == row["mode"],
                                "归档成员大小或原 mode 不符：" + name)
                        require(member.uid == row["uid"] and member.gid == row["gid"],
                                "归档成员原属主数字不符：" + name)
                        require(hashlib.file_digest(stream, "sha256").hexdigest() == row["sha256"],
                                "归档成员 SHA 不符：" + name)
    require(seen == set(expected) | set(dirs) | {INDEX_NAME}, "归档有漏项")
    # 读至 gzip EOF，验证 trailer；不提取、不执行任何归档成员。
    import gzip
    with gzip.open(out, "rb") as stream:
        while stream.read(CHUNK):
            pass
    return {"files": len(expected), "directories": len(dirs), "members": len(seen)}


def collect(base, out, index_path, metadata_path):
    metadata = {"schema": "P7_NATIVE_EVIDENCE_COLLECTION_V1", "status": "FAIL",
                "scope": "仅归档一致性；原始失败保留，不代表 release/H2/D15 验收。",
                "base": str(base), "archive": str(out), "index": str(index_path),
                "started_at": datetime.datetime.now(datetime.timezone.utc).isoformat(),
                "collector_sha256": sha_file(Path(__file__).resolve())}
    archive_created = False
    try:
        files, directories = inventory(base)
        index = make_index(base, files, directories)
        index_bytes = encoded(index)
        with index_path.open("xb") as stream:
            stream.write(index_bytes)
        # 仅标记成功独占创建的自有输出；失败时保留部分包，绝不覆盖旧包。
        with out.open("xb") as raw:
            archive_created = True
            write_archive(base, raw, files, directories, index_bytes)
        metadata["readback"] = verify_archive(out, index, index_bytes)
        after_files, after_dirs = inventory(base)
        require((after_files, after_dirs) == (files, directories), "原件集合或身份在封包期间改变")
        require(make_index(base, after_files, after_dirs) == index, "封包前后原件哈希不一致")
        metadata.update(status="PASS", indexed_files=len(files),
                        original_bytes=sum(row["bytes"] for row in files.values()),
                        index_sha256=sha_file(index_path), archive_sha256=sha_file(out),
                        archive_bytes=out.stat().st_size, source_before_after="PASS")
    except BaseException as error:
        metadata["error"] = repr(error)
        if archive_created and out.is_file() and not out.is_symlink():
            metadata["partial_archive_preserved"] = str(out)
    finally:
        metadata["finished_at"] = datetime.datetime.now(datetime.timezone.utc).isoformat()
        with metadata_path.open("xb") as stream:
            stream.write(encoded(metadata))
    print(json.dumps(metadata, ensure_ascii=False), flush=True)
    return 0 if metadata["status"] == "PASS" else 1


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--base", type=Path, required=True)
    parser.add_argument("--out", type=Path, required=True, help="本轮根之外的全新 .tar.gz 文件")
    mode = parser.add_mutually_exclusive_group()
    mode.add_argument("--plan", action="store_true", help="默认：只显示预计范围及存在性")
    mode.add_argument("--collect", action="store_true", help="明确执行封包和逐项读回")
    options = parser.parse_args(argv)
    base, out = options.base, options.out
    canonical(base)
    canonical(out)
    require(base.is_dir() and stat.S_ISDIR(base.lstat().st_mode), "base 必须为已存在普通目录")
    require(out.name.endswith(".tar.gz") and out.parent.is_dir(), "out 必须为已有父目录下的 .tar.gz")
    require(not out.is_relative_to(base) and not base.is_relative_to(out), "输出不能位于本轮输入根内或包含输入根")
    index_path = Path(str(out) + ".index.json")
    metadata_path = Path(str(out) + ".metadata.json")
    if not options.collect:
        names = list(TREES) + ["bootstrap/" + name for name in BOOTSTRAP_FILES]
        print(json.dumps({"mode": "PLAN_ONLY", "actions_started": 0,
                          "base": str(base), "archive": str(out),
                          "inputs": [{"path": name, "exists": (base / name).exists(),
                                      "symlink": (base / name).is_symlink()} for name in names],
                          "excluded": ["build", "nightly-before", "bootstrap/source.bundle",
                                       ".git", "Cargo 缓存", "bootstrap 中未列入白名单的文件"],
                          "outputs": [str(out), str(index_path), str(metadata_path)],
                          "scope": "仅计划；允许待生成输入缺失，不表示归档或测试通过。"}, ensure_ascii=False))
        return 0
    for path in (out, index_path, metadata_path):
        canonical(path)
        require(not path.exists() and not path.is_symlink(), "拒绝覆盖已有输出：" + str(path))
    return collect(base, out, index_path, metadata_path)


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except (OSError, ValueError) as error:
        print(json.dumps({"status": "FAIL", "error": repr(error)}, ensure_ascii=False), file=sys.stderr)
        raise SystemExit(1)
