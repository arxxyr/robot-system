"""速度入站与SerialTick必要基础的纯软件QA；只使用本轮导出源，不访问硬件或正式安装。"""
import hashlib,importlib.util,json,os,re,signal,stat,sys
from pathlib import Path
from types import SimpleNamespace
sys.dont_write_bytecode=True
BASE=Path('/home/loosqk/robot-checks/xlerobot-velocity-foundation-20261001-r1')
SOURCE=BASE/'source';OUT=BASE/'qa-r1';BOOT=BASE/'bootstrap'
BOOT_ID='6cf7ee3e-a3c5-4c91-80bc-4ca924818b53'
def module(name,path):
 spec=importlib.util.spec_from_file_location(name,path);value=importlib.util.module_from_spec(spec);spec.loader.exec_module(value);return value
h=module('natural_runner',BOOT/'natural_runner.py');a=module('source_artifacts',BOOT/'artifacts.py');require=a.require
require(a.sha256(BOOT/'natural_runner.py')=='dad9bbc9405b8fac4d60d6efe794b36750e6a6f9ce9fdeba3debf7d3e1b9a471','Runner不是原冻结件')
expected=a.strict_json((BOOT/'expected_source.json').read_text());export=a.strict_json((BOOT/'source_export.json').read_text());names=a.strict_json((BOOT/'expected_tests.json').read_text())
OUT.mkdir();runner=h.Runner(SimpleNamespace(source=SOURCE,out=OUT,target=BASE/'build'),a)
result={'schema':'XLEROBOT_VELOCITY_FOUNDATION_SOFTWARE_QA_V1','status':'FAIL','deployable':False,'native_git_head':None,'source_kind':'exported compilation-input snapshot','origin':export['origin'],'self_sha256':a.sha256(Path(__file__)),'runner_sha256':a.sha256(BOOT/'natural_runner.py'),'artifacts_sha256':a.sha256(BOOT/'artifacts.py'),'not_hardware_or_full_B1':True,'gates':{},'receipts':[]}
old={};compiler=None;cargo=None;before=None
def interrupted(signum,frame):h.INTERRUPTED=signum
def source(label):
 require(not os.path.lexists(SOURCE/'.git'),'导出源不能伪称Git checkout')
 inventory=[]
 for root,dirs,files in os.walk(SOURCE,followlinks=False):
  for name in dirs:require(stat.S_ISDIR((Path(root)/name).lstat().st_mode),'导出源含链接目录')
  for name in files:inventory.append((Path(root)/name).relative_to(SOURCE).as_posix())
 require(set(inventory)==set(expected['files']) and len(inventory)==len(expected['files']),'导出源集合变化')
 require(set(export['files'])==set(expected['files']),'导出清单集合不同')
 for name,item in expected['files'].items():
  path=SOURCE/name;info=path.lstat();require(stat.S_ISREG(info.st_mode) and path.resolve()==path,'非普通源文件')
  with os.fdopen(os.open(path,os.O_RDONLY|os.O_NOFOLLOW),'rb') as stream:
   first=os.fstat(stream.fileno());data=stream.read(item['bytes']+1);last=os.fstat(stream.fileno())
  identity=lambda s:(s.st_dev,s.st_ino,s.st_mode,s.st_size,s.st_mtime_ns,s.st_ctime_ns)
  require(identity(info)==identity(first)==identity(last)==identity(path.lstat()),'读取源身份漂移')
  require(len(data)==item['bytes'] and hashlib.sha256(data).hexdigest()==item['sha256'],'源bytes/SHA变化')
  require(stat.S_IMODE(info.st_mode)==export['files'][name]['mode'] and bool(info.st_mode&stat.S_IXUSR)==item['executable'],'源mode/exec变化')
 value=a.snapshot_source(SOURCE,inventory);require(value==expected,'完整编译域不符');h.save(OUT/(label+'.json'),value);return value

def step(label,argv,timeout=7200):
 result['gates'][label]={'status':'RUNNING','argv':argv};source(label+'_source_before')
 try:
  reference,row=runner.command(label,argv,timeout)
  result['gates'][label].update(status='PASS',completion=reference)
  return row
 except BaseException as error:
  result['gates'][label].update(status='FAIL',error=repr(error));raise
 finally:source(label+'_source_after')

def tests(label,argv,required):
 row=step(label,argv);text=Path(row['stdout']).read_text();counts=re.findall(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored;',text);actual=re.findall(r'^test ([^ ]+) \.\.\. ok$',text,re.M)
 require(len(counts)==1 and counts[0][1:]==('0','0') and len(actual)==len(set(actual))==int(counts[0][0]),'完整测试计数/失败/ignored不符')
 require(set(required)<=set(actual),'本轮新测试子集缺失')
 if label=='serial_rt_e2e':require(set(actual)==set(required) and len(actual)==5,'原serial_rt_e2e不是完整5项')
 return {'passed':len(actual),'failed':0,'ignored':0,'names':actual,'required_subset':required}

COMMANDS=[('latest_nightly_update',['rustup','update','nightly','--no-self-update']),('fmt',['cargo','fmt','--all']),('clippy_default',['cargo','clippy','--locked','--all','--all-targets','--','-D','warnings']),('clippy_control_features',['cargo','clippy','--locked','--all','--all-targets','--features','robot-s0/rt_guard,robot-s0/test-comm-fault-hook,robot-s0/xlerobot-real','--','-D','warnings']),('s0_default_lib',['cargo','test','--locked','-p','robot-s0','--lib','--','--test-threads=1']),('s0_guard_hook_lib',['cargo','test','--locked','-p','robot-s0','--lib','--features','rt_guard,test-comm-fault-hook','--','--test-threads=1']),('serial_rt_e2e',['cargo','test','--locked','-p','robot-s0','--test','serial_rt_e2e','--features','rt_guard,test-comm-fault-hook','--','--test-threads=1'])]
result['gates']={name:{'status':'NOT_RUN','argv':argv} for name,argv in COMMANDS}
try:
 for sig in (signal.SIGINT,signal.SIGTERM,signal.SIGHUP):old[sig]=signal.signal(sig,interrupted)
 require(os.getuid()==1000 and os.getgid()==1000 and Path('/proc/sys/kernel/random/boot_id').read_text().strip()==BOOT_ID,'主机身份变化')
 require(BASE.resolve()==BASE and SOURCE.resolve()==SOURCE and not SOURCE.is_relative_to(BASE/'build'),'独立source/build路径不符')
 require(export['source_manifest']==expected and export['origin']['main_head']=='8fb17b153f4eb85cb1b88ca935cc115087784256' and export['origin']['native_git_head'] is None,'来源清单不符')
 before=source('source_before');h.save(OUT/'retained_cache_environment.json',{key:runner.env.get(key) for key in ('CARGO_HOME','CARGO_NET_OFFLINE','RUSTUP_AUTO_INSTALL','PYTHONDONTWRITEBYTECODE')})
 _,row=runner.command('rustc_before_update',['rustc','-vV']);result['compiler_before_update']=a.parse_rustc_identity(Path(row['stdout']).read_text());runner.command('cargo_before_update',['cargo','-V'])
 step(*COMMANDS[0],timeout=300)
 _,row=runner.command('rustc_after_update',['rustc','-vV']);compiler=a.parse_rustc_identity(Path(row['stdout']).read_text());_,row=runner.command('cargo_after_update',['cargo','-V']);cargo=Path(row['stdout']).read_bytes();result['compiler']=compiler
 step(*COMMANDS[1],timeout=300);step(*COMMANDS[2]);step(*COMMANDS[3])
 default=tests(*COMMANDS[4],names['library_new_subset']);featured=tests(*COMMANDS[5],names['library_new_subset']);serial=tests(*COMMANDS[6],names['serial_rt_e2e_all'])
 union=sorted(set(default['names'])|set(featured['names']));result.update(status='PASS',source_files=len(expected['files']),aggregate=expected['source_manifest_sha256'],tests={'default_lib':default,'guard_hook_lib':featured,'distinct_library_names':union,'distinct_library_count':len(union),'serial_rt_e2e':serial,'distinct_all_with_serial':len(union)+5,'new_library_subset':len(names['library_new_subset']),'no_subset_double_count':True},fmt_source_unchanged=True)
except BaseException as error:result['error']=repr(error)
finally:
 try:
  _,row=runner.command('rustc_after',['rustc','-vV']);value=a.parse_rustc_identity(Path(row['stdout']).read_text());require(compiler is not None and value==compiler,'工具链窗口不符');_,row=runner.command('cargo_after',['cargo','-V']);require(Path(row['stdout']).read_bytes()==cargo,'cargo窗口不符');result['compiler_window']='PASS'
 except BaseException as error:result.update(status='FAIL',compiler_window_error=repr(error))
 try:require(before is not None and source('source_after')==before,'源首末漂移');result['source_before_after']='PASS'
 except BaseException as error:result.update(status='FAIL',source_after_error=repr(error))
 result['receipts']=runner.receipts;h.save(OUT/'result.json',result)
 for sig,handler in old.items():signal.signal(sig,handler)
print(json.dumps(result,ensure_ascii=False),flush=True);raise SystemExit(0 if result['status']=='PASS' else 1)
