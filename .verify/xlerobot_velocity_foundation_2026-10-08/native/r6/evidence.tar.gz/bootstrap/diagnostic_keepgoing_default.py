"""一次默认根Clippy诊断；不修改原QA结果，不执行测试或硬件。"""
import hashlib,importlib.util,json,os,signal,stat,sys
from pathlib import Path
from types import SimpleNamespace
sys.dont_write_bytecode=True
BASE=Path('/home/loosqk/robot-checks/xlerobot-velocity-foundation-20261007-r6');SOURCE=BASE/'source';BOOT=BASE/'bootstrap';OUT=BASE/'diagnostic-default-keep-going-r1'
def module(name,path):
 spec=importlib.util.spec_from_file_location(name,path);value=importlib.util.module_from_spec(spec);spec.loader.exec_module(value);return value
h=module('natural_runner',BOOT/'natural_runner.py');a=module('source_artifacts',BOOT/'artifacts.py');require=a.require
require(a.sha256(BOOT/'natural_runner.py')=='dad9bbc9405b8fac4d60d6efe794b36750e6a6f9ce9fdeba3debf7d3e1b9a471','Runner漂移')
require(a.sha256(BOOT/'artifacts.py')=='bd2b3f7bb8527cd9ecec73894171638e9cf378656b89e284a585c3baa37b8731','原artifact门漂移')
expected=a.strict_json((BOOT/'expected_source.json').read_text());export=a.strict_json((BOOT/'source_export.json').read_text());OUT.mkdir();runner=h.Runner(SimpleNamespace(source=SOURCE,out=OUT,target=BASE/'build'),a)
result={'status':'DIAGNOSTIC_NOT_COMPLETED','not_QA_gate':True,'source_files':590,'aggregate':expected['source_manifest_sha256'],'argv':['cargo','clippy','--locked','--all','--all-targets','--keep-going','--','-D','warnings'],'self_sha256':a.sha256(Path(__file__))};old={};compiler=None;cargo=None
def source(label):
 require(not os.path.lexists(SOURCE/'.git'),'导出源不能伪称Git checkout')
 inventory=[]
 for root,dirs,files in os.walk(SOURCE,followlinks=False):
  for name in dirs:require(stat.S_ISDIR((Path(root)/name).lstat().st_mode),'导出源含链接目录')
  for name in files:inventory.append((Path(root)/name).relative_to(SOURCE).as_posix())
 require(set(inventory)==set(expected['files']) and len(inventory)==len(expected['files']),'导出源集合变化')
 require(set(export['files'])==set(expected['files']),'导出清单集合不同')
 for name,item in expected['files'].items():
  path=SOURCE/name;info=path.lstat();require(stat.S_ISREG(info.st_mode) and path.resolve()==path,'非普通源文件')
  with os.fdopen(os.open(path,os.O_RDONLY|os.O_NOFOLLOW),'rb') as stream:
   first=os.fstat(stream.fileno());data=stream.read(item['bytes']+1);last=os.fstat(stream.fileno())
  identity=lambda s:(s.st_dev,s.st_ino,s.st_mode,s.st_size,s.st_mtime_ns,s.st_ctime_ns)
  require(identity(info)==identity(first)==identity(last)==identity(path.lstat()),'读取源身份漂移')
  require(len(data)==item['bytes'] and hashlib.sha256(data).hexdigest()==item['sha256'],'源bytes/SHA变化')
  require(stat.S_IMODE(info.st_mode)==export['files'][name]['mode'] and bool(info.st_mode&stat.S_IXUSR)==item['executable'],'源mode/exec变化')
 value=a.snapshot_source(SOURCE,inventory);require(value==expected,'完整编译域不符');h.save(OUT/(label+'.json'),value);return value

def interrupted(signum,frame):h.INTERRUPTED=signum
try:
 for sig in (signal.SIGINT,signal.SIGTERM,signal.SIGHUP):old[sig]=signal.signal(sig,interrupted)
 require(os.getuid()==1000 and os.getgid()==1000 and Path('/proc/sys/kernel/random/boot_id').read_text().strip()=='6cf7ee3e-a3c5-4c91-80bc-4ca924818b53','主机身份变化')
 result['original_QA_sha256']=a.sha256(BASE/'qa-r6/result.json');source('source_before')
 _,row=runner.command('rustc_before',['rustc','-vV']);compiler=a.parse_rustc_identity(Path(row['stdout']).read_text());result['compiler']=compiler;_,row=runner.command('cargo_before',['cargo','-V']);cargo=Path(row['stdout']).read_bytes()
 source('clippy_source_before')
 try:
  reference,row=runner.command('clippy_default_keep_going',result['argv'],7200);result['cargo_exit']=row['exit_code'];result['cargo_completion']=reference
 except BaseException as error:result['cargo_error']=repr(error)
 finally:source('clippy_source_after')
 result['status']='DIAGNOSTIC_CAPTURE_COMPLETE_NOT_QA_PASS'
except BaseException as error:result['error']=repr(error)
finally:
 try:
  _,row=runner.command('rustc_after',['rustc','-vV']);require(a.parse_rustc_identity(Path(row['stdout']).read_text())==compiler,'compiler窗口漂移');_,row=runner.command('cargo_after',['cargo','-V']);require(Path(row['stdout']).read_bytes()==cargo,'cargo窗口漂移');result['compiler_window']='PASS'
 except BaseException as error:result['compiler_error']=repr(error)
 try:
  require(source('source_after')==expected,'源码漂移');require(a.sha256(BASE/'qa-r6/result.json')==result['original_QA_sha256'],'原QA结果变化');result['source_and_original_QA_unchanged']='PASS'
 except BaseException as error:result['source_error']=repr(error)
 result['receipts']=runner.receipts;h.save(OUT/'result.json',result)
 for sig,handler in old.items():signal.signal(sig,handler)
print(json.dumps(result,ensure_ascii=False),flush=True);raise SystemExit(1 if 'cargo_error' in result or 'error' in result or 'source_error' in result or 'compiler_error' in result else 0)
