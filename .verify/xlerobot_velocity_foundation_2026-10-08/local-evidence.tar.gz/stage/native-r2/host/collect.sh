set -eu
export PATH=/home/loosqk/.cargo/bin:/home/loosqk/.local/bin:$PATH
export PYTHONDONTWRITEBYTECODE=1
cd /home/loosqk/robot-checks/xlerobot-velocity-foundation-20261001-r2/bootstrap
printf '%s\n' 'ea9369ca47ad85aef08e765d0e8e4beb8f28ce6a035e3b987376fddcdb58be3e  collect_native.py' | sha256sum -c -
exec uv run --no-project python collect_native.py --collect --base /home/loosqk/robot-checks/xlerobot-velocity-foundation-20261001-r2 --out /home/loosqk/robot-checks/xlerobot-velocity-foundation-20261001-r2-native-evidence.tar.gz
