set -eu
export PATH=/home/loosqk/.cargo/bin:/home/loosqk/.local/bin:$PATH
TASK_BASE=/home/loosqk/robot-checks/xlerobot-velocity-foundation-20261001-r2
CACHE_SEED=/home/loosqk/robot-checks/xlerobot-velocity-foundation-20261001-r1/build/debug
test "$(cat /proc/sys/kernel/random/boot_id)" = 6cf7ee3e-a3c5-4c91-80bc-4ca924818b53
test ! -e "$TASK_BASE/build"
mkdir "$TASK_BASE/build"
du -sb "$CACHE_SEED"
df -B1 "$TASK_BASE"
cp -R --preserve=mode,timestamps --reflink=auto "$CACHE_SEED" "$TASK_BASE/build/debug"
uv run --no-project python - "$CACHE_SEED" "$TASK_BASE/build/debug" <<'CHECK'
import json,os,stat,sys
from pathlib import Path
source,dest=map(Path,sys.argv[1:]);count=0
for root,dirs,files in os.walk(source,followlinks=False):
 for name in files:
  p=Path(root)/name;q=dest/p.relative_to(source);a=p.lstat();b=q.lstat()
  if stat.S_ISREG(a.st_mode):
   assert stat.S_ISREG(b.st_mode) and (a.st_dev,a.st_ino)!=(b.st_dev,b.st_ino)
   assert a.st_size==b.st_size and stat.S_IMODE(a.st_mode)==stat.S_IMODE(b.st_mode)
   count+=1
print(json.dumps({'status':'PASS_CACHE_SEED_ONLY','source':str(source),'dest':str(dest),'regular_files':count,'no_source_dest_hardlink':True,'copy_argv':'cp -R --preserve=mode,timestamps --reflink=auto','not_test_or_source_identity_proof':True}))
CHECK
