set -eu
hostname
id
cat /proc/sys/kernel/random/boot_id
