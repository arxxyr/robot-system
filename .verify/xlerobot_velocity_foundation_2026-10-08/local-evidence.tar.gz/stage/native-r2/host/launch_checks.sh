set -eu
export PATH=/home/loosqk/.cargo/bin:/home/loosqk/.local/bin:$PATH
export CARGO_HOME=/home/loosqk/robot-checks/viz-orin-a6957cc-20260930-r1/cargo-home
export CARGO_NET_OFFLINE=true
export RUSTUP_AUTO_INSTALL=0
export PYTHONDONTWRITEBYTECODE=1
cd /home/loosqk/robot-checks/xlerobot-velocity-foundation-20261001-r2/bootstrap
printf '%s\n' 'cd4b81e08bbe07aa01706642f0fef8b0435468ff3738499741a03209efea6623  source-inputs.tar.gz' '8942ca51c407807aaceb34b8814388808df2b6a4bc691b3e15028d3534da4a2b  source_export.json' '805c02aad55cdcc835f850e1c582289c3e32d51a6164d9f10fb8891f74a82901  expected_source.json' '51ac45460000d80b1906e4947a93aaa69677417900d8b010f703267044fa44ad  expected_tests.json' '47147efb7bce1d285d72f5500138050ba401a400b8bae30ed422fc46f68c9daf  run_checks.py' 'dad9bbc9405b8fac4d60d6efe794b36750e6a6f9ce9fdeba3debf7d3e1b9a471  natural_runner.py' 'bd2b3f7bb8527cd9ecec73894171638e9cf378656b89e284a585c3baa37b8731  artifacts.py' 'fef1431b4068cf14ff5a59c633042475926cadbcd6a2fbd3c71a4a6d72708d61  receive_source.py' | sha256sum -c -
uv run --no-project python receive_source.py
exec taskset -c 0-3 uv run --no-project python run_checks.py
