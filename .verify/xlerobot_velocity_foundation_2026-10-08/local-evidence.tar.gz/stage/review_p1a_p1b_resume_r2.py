import hashlib
import importlib.util
import json
from pathlib import Path
import re
import subprocess
import sys
import time

sys.dont_write_bytecode = True
OUT = Path(__file__).with_name('independent_p1a_p1b_dynamic_review_resume_r2.json')
REPORT = {'schema': 'INDEPENDENT_P1A_P1B_READONLY_RESUME_REVIEW_R2', 'scope': '只读复核现有源码与原始回执；不执行 Cargo、rustup、SSH、UART；不修改源码、原证据或计划', 'checks': [], 'read_only_owned_children': []}

def identity(path):
    path = Path(path)
    raw = path.read_bytes()
    return {'path': str(path), 'sha256': hashlib.sha256(raw).hexdigest(), 'bytes': len(raw)}

def load(path):
    return json.loads(Path(path).read_text())

def check(label, ok, details=None):
    REPORT['checks'].append({'name': label, 'status': 'PASS' if ok else 'FAIL', 'details': details})

def git(root, *args, expected=0):
    argv = ['git', *args]
    started = time.monotonic_ns()
    child = subprocess.Popen(argv, cwd=root, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    stdout, stderr = child.communicate()
    REPORT['read_only_owned_children'].append({'argv': argv, 'cwd': str(root), 'pid': child.pid, 'exit_code': child.returncode, 'wait_reaped': child.returncode is not None, 'started_monotonic_ns': started, 'ended_monotonic_ns': time.monotonic_ns(), 'stdout_sha256': hashlib.sha256(stdout).hexdigest(), 'stdout_bytes': len(stdout), 'stderr_sha256': hashlib.sha256(stderr).hexdigest(), 'stderr_bytes': len(stderr)})
    check(str(root.name) + ':' + ' '.join(args), child.returncode == expected and not stderr)
    return stdout

def references(value, label):
    if isinstance(value, dict):
        if {'path', 'sha256', 'bytes'} <= value.keys():
            p = Path(value['path'])
            actual = identity(p) if p.is_file() else None
            check(label + ':文件引用', actual is not None and all(actual[k] == value[k] for k in ('sha256', 'bytes')), {'reference': value, 'actual': actual})
        for k, v in value.items():
            references(v, label + '/' + k)
    elif isinstance(value, list):
        for i, v in enumerate(value):
            references(v, label + '/' + str(i))

def raw_groups(text):
    pattern = re.compile(r'^running (\d+) tests?\s*\n(.*?)^test result: (ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored; (\d+) measured; (\d+) filtered out;', re.M | re.S)
    groups = []
    for m in pattern.finditer(text):
        rows = []
        for name, status in re.findall(r'^test (.+?) \.\.\. (ok|FAILED|ignored(?:,.*)?)$', m[2], re.M):
            name = name.removesuffix(' - should panic')
            rows.append({'name': name, 'raw_status': status, 'status': 'PASS' if status == 'ok' else 'FAIL' if status == 'FAILED' else 'IGNORED'})
        counts = dict(zip(['passed', 'failed', 'ignored', 'measured', 'filtered_out'], map(int, m.group(4, 5, 6, 7, 8))))
        groups.append({'announced': int(m[1]), 'tests': rows, 'counts': counts})
    return groups

def qa_receipts(root, run, supplemental, expected_count):
    summary = load(run / 'results.json')
    rows = summary['commands']
    check(str(run) + ':完成门', summary['status'] == 'PASS' and len(rows) == expected_count and summary['signals'] == [] and summary['hardware_actions'] == 0 and summary['not_workspace_quality_gate'] is True, {'commands': len(rows), 'summary': identity(run / 'results.json')})
    owner = set()
    end = None
    for row in rows:
        name = row['name']
        result = load(run / name / 'result.json')
        launch = load(run / name / 'launch.json')
        owner.add(row['owner_pid'])
        conditions = row == result and row['status'] == 'PASS' and row['exit_code'] == 0 and row['wait_reaped'] is True and not row['runner_error'] and not row['wait_errors'] and not row['signals']
        conditions &= all(launch[k] == row[k] for k in ['pid', 'owner_pid', 'argv', 'started_monotonic_ns']) and launch['cwd'] == str(root) and launch['cargo_target_dir'] == summary['target']
        conditions &= row['ended_monotonic_ns'] >= row['started_monotonic_ns'] and (end is None or end <= row['started_monotonic_ns'])
        end = row['ended_monotonic_ns']
        for channel in ('stdout', 'stderr'):
            actual = identity(run / name / (channel + '.log'))
            conditions &= all(actual[k] == row[channel][k] for k in ['sha256', 'bytes'])
        check(str(run) + ':真实完成/' + name, bool(conditions), {'pid': row['pid'], 'owner_pid': row['owner_pid'], 'argv': row['argv'], 'exit_code': row['exit_code'], 'wait_reaped': row['wait_reaped']})
    check(str(run) + ':顺序唯一owner', len(owner) == 1, list(owner))
    before = load(supplemental / 'after_fmt/binding.json')
    after = load(supplemental / 'after_all_cargo/binding.json')
    snapshot_before = load(supplemental / 'after_fmt/source_snapshot.json')
    snapshot_after = load(supplemental / 'after_all_cargo/source_snapshot.json')
    check(str(run) + ':完整源前后相同', snapshot_before == snapshot_after)
    check(str(run) + ':完整身份前后相同', all(before[k] == after[k] for k in ['root', 'head', 'branch', 'status_entries', 'input_count', 'source_manifest_sha256', 'snapshot_helper', 'compiler', 'cargo', 'inherited_build_environment', 'additional_environment']))
    check(str(run) + ':最新nightly实际身份', 'commit-hash: 1d81eb4ad9cd207e3e638bd32b17ec4fce8412a6' in before['compiler'] and 'host: aarch64-apple-darwin' in before['compiler'] and summary['update_executed'] is False and summary['toolchain_provenance'] == 'LATEST_INSTALLED_VERIFIED_BY_USER_AND_RUNTIME', {'compiler': before['compiler'], 'cargo': before['cargo'], 'update_executed': False})
    for side in ('after_fmt', 'after_all_cargo'):
        records = []
        for name in ('git_inventory', 'git_head', 'git_status', 'git_branch', 'rustc_identity', 'cargo_identity'):
            path = supplemental / side / (name + '.json')
            row = load(path)
            good = row['exit_code'] == 0 and row['wait_reaped'] is True and not row['wait_errors'] and not row['signal_requests']
            for channel in ('stdout', 'stderr'):
                actual = identity(supplemental / side / (name + '.' + channel))
                good &= all(actual[k] == row[channel][k] for k in ('sha256', 'bytes'))
            check(str(run) + ':窗口child/' + side + '/' + name, good, {'pid': row['pid'], 'owner_pid': row['owner_pid'], 'exit_code': row['exit_code'], 'wait_reaped': row['wait_reaped']})
            records.append(row)
        check(str(run) + ':窗口child顺序/' + side, all(a['ended_monotonic_ns'] <= b['started_monotonic_ns'] for a, b in zip(records, records[1:])))
        binding = load(supplemental / side / 'binding.json')
        inventory = (supplemental / side / 'git_inventory.stdout').read_bytes().split(b'\0')
        inventory = [p.decode() for p in inventory if p]
        check(str(run) + ':窗口freshGit输入/' + side, binding['inventory_count'] == len(inventory) and len(inventory) == len(set(inventory)))
    spec = importlib.util.spec_from_file_location('artifact_helper_' + root.parent.name, root / 'scripts/post_e_h2_artifacts.py')
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    current_inventory = [p.decode() for p in git(root, 'ls-files', '--cached', '--others', '--exclude-standard', '-z').split(b'\0') if p]
    current = module.snapshot_source(root, current_inventory)
    check(str(run) + ':当前完整源逐项相同', current == snapshot_before, {'source_manifest_sha256': current['source_manifest_sha256'], 'count': len(current['files'])})
    check(str(run) + ':当前Git身份', git(root, 'rev-parse', 'HEAD').decode().strip() == before['head'] and git(root, 'symbolic-ref', '--short', 'HEAD').decode().strip() == before['branch'] and [p.decode() for p in git(root, 'status', '--porcelain=v1', '-z').split(b'\0') if p] == before['status_entries'])
    after_subset = load(run / 'source_after_fmt.json')
    check(str(run) + ':小清单前后相同', after_subset == load(run / 'source_after_all_checks.json') and all(current['files'][k] == v for k, v in after_subset.items()))
    for tool in ('rustfmt', 'clippy', 'components'):
        check(str(run) + ':工具组件前后/' + tool, (run / (tool + '_before/stdout.log')).read_bytes() == (run / (tool + '_after/stdout.log')).read_bytes())
    return {'summary': identity(run / 'results.json'), 'manifest': current, 'binding': before, 'commands': [{'name': r['name'], 'pid': r['pid'], 'owner_pid': r['owner_pid'], 'argv': r['argv'], 'exit_code': r['exit_code'], 'wait_reaped': r['wait_reaped']} for r in rows]}

A = Path('/Users/loosqk/.codex/worktrees/xlerobot-base-profile/robot-system')
AA = A / 'target/b1-p1a-origin'
B = Path('/Users/loosqk/.codex/worktrees/xlerobot-wheel-profile/robot-system')
BB = B / 'target/wheel_velocity_profile'
manifest = load(AA / 'final_r5/candidate_manifest.json')
roster = load(AA / 'final_r5/test_roster_and_overlap.json')
references(manifest, 'P1A候选')
references(roster, 'P1A名册')
ar = qa_receipts(A, AA / 'r5', AA / 'supplementary/r5', 21)
check('P1A:六源当前SHA字节模式', all(ar['manifest']['files'][name] == value for name, value in manifest['six_source'].items()))
check('P1A:最终候选完整输入摘要', ar['manifest']['source_manifest_sha256'] == manifest['source_manifest_sha256'] and len(ar['manifest']['files']) == manifest['complete_input_count'] == 592)
sets = {}
for label, stage in [('full_default', 'tests_default_full_crate'), ('full_mock_only', 'tests_mock_only_full_crate')]:
    raw = raw_groups((AA / 'r5' / stage / 'stdout.log').read_text())
    claimed = roster[label]['groups']
    equal = len(raw) == len(claimed) and all(g['tests'] == c['tests'] and g['counts'] == c['counts'] and len(g['tests']) == g['announced'] for g, c in zip(raw, claimed))
    check('P1A:原始逐组方法名册/' + label, equal, [{'suite': c['suite'], 'counts': c['counts']} for c in claimed])
    sets[label] = {c['suite'] + '::' + t['name'] for c in claimed if not c['suite'].startswith('doctest:') for t in c['tests'] if t['status'] == 'PASS'}
check('P1A:129与61及61重叠', len(sets['full_default']) == 129 and len(sets['full_mock_only']) == 61 and sets['full_mock_only'] <= sets['full_default'] and set(roster['overlap_passed_rust_methods']) == sets['full_default'] & sets['full_mock_only'])
check('P1A:新增10方法为默认129子集', len(roster['new_methods_inside_default']) == 10 and set(roster['new_methods_inside_default']) <= sets['full_default'] and len(roster['new_methods_inside_mock_only']) == 8 and set(roster['new_methods_inside_mock_only']) <= sets['full_mock_only'])
for name, claimed in roster['special_runs'].items():
    raw = raw_groups((AA / 'r5' / name / 'stdout.log').read_text())
    check('P1A:专项实际名册/' + name, len(raw) == len(claimed['groups']) and all(r['tests'] == c['tests'] and r['counts'] == c['counts'] for r, c in zip(raw, claimed['groups'])))
fresh_diff = git(A, 'diff', '--no-ext-diff') + git(A, 'diff', '--no-index', '--', '/dev/null', 'crates/robot-transport/src/origin.rs', expected=1) + git(A, 'diff', '--no-index', '--', '/dev/null', 'crates/robot-transport/tests/publisher_origin.rs', expected=1)
check('P1A:六源当前diff与候选完全相同', fresh_diff == (AA / 'final_r5/six_source.diff').read_bytes())
for r in ('r1', 'r2'):
    d = load(AA / r / 'latest_nightly_update/result.json')
    check('P1A:历史TLS失败保留/' + r, d['status'] == 'FAIL' and d['exit_code'] == 1 and d['wait_reaped'] is True and not d['signals'] and 'tls handshake eof' in (AA / r / 'latest_nightly_update/stderr.log').read_text())
r3 = load(AA / 'r3/results.json')['commands']
signal = load(AA / 'r3/root_authorized_interruption/signal_sent.json')
check('P1A:历史一次SIGINT失败保留', r3['latest_nightly_update_direct']['exit_code'] == -2 and r3['latest_nightly_update_direct']['status'] == 'FAIL' and r3['latest_nightly_update_direct']['wait_reaped'] is True and len([r for r in r3.values() if r['status'] == 'NOT_RUN']) == 9 and signal['signal'] == 2 and signal['signal_sent'] is True and signal['child_pid'] == 19324)
r4 = load(AA / 'r4/results.json')
check('P1A:历史Clippy失败与后三门未跑保留', r4['status'] == 'FAIL' and any(r['name'] == 'clippy_default_all_targets' and r['exit_code'] == 101 and r['wait_reaped'] is True for r in r4['commands']) and len([r for r in r4['commands'] if r['status'] == 'NOT_RUN']) == 3 and 'similar_names' in (AA / 'r4/clippy_default_all_targets/stderr.log').read_text())
history = AA / 'history/r4_clippy_failure/crates/robot-transport/tests/publisher_origin.rs'
if history.exists():
    old = history.read_text()
    new = (A / 'crates/robot-transport/tests/publisher_origin.rs').read_text()
    pairs = {'command_pub': 'command_sender', 'heartbeat_pub': 'heartbeat_sender', 'command_sub': 'command_receiver', 'heartbeat_sub': 'heartbeat_receiver'}
    for k, v in pairs.items():
        old = re.sub(r'\b' + k + r'\b', v, old)
    check('P1A:r5四个测试局部变量名加rustfmt换行', re.findall(r'"(?:\\.|[^"\\])*"|\S+', old) == re.findall(r'"(?:\\.|[^"\\])*"|\S+', new) or re.sub(r'\s+', '', old) == re.sub(r'\s+', '', new))
else:
    check('P1A:r4测试源历史路径', False, str(history))

plan = load(BB / 'native_qa_r1/plan.json')
references({k: v for k, v in plan.items() if k != 'files'}, 'P1B历史计划')
for name, value in plan['files'].items():
    historical = BB / 'history/native_qa_pre_r1' / name
    actual = identity(historical)
    check('P1B:历史计划身份与归档匹配/' + name, all(actual[k] == value[k] for k in ('sha256', 'bytes')), {'plan': value, 'history': actual})
br = qa_receipts(B, BB / 'native_qa_r1/run', BB / 'native_qa_r1/supplementary', 15)
profile = (B / 'crates/robot-core/src/wheel_velocity_profile.rs').read_text()
new_names = re.findall(r'#\[test\]\s+fn (\w+)\(', profile)
special = raw_groups((BB / 'native_qa_r1/run/profile_four_methods/stdout.log').read_text())
lib = raw_groups((BB / 'native_qa_r1/run/core_full_lib/stdout.log').read_text())
doc = raw_groups((BB / 'native_qa_r1/run/core_full_doc/stdout.log').read_text())
expected = {'wheel_velocity_profile::tests::' + n for n in new_names}
check('P1B:四新增方法实际PASS且为143子集', len(new_names) == 4 and len(special) == len(lib) == 1 and special[0]['counts']['passed'] == 4 and lib[0]['counts']['passed'] == 143 and all(g['counts']['failed'] == g['counts']['ignored'] == 0 for g in special + lib) and expected == {t['name'] for t in special[0]['tests'] if t['status'] == 'PASS'} and expected <= {t['name'] for t in lib[0]['tests'] if t['status'] == 'PASS'}, {'new_methods': sorted(expected), 'lib_count': lib[0]['counts']})
check('P1B:19doc实际PASS', sum(g['counts']['passed'] for g in doc) == 19 and sum(g['counts']['failed'] for g in doc) == 0 and sum(g['counts']['ignored'] for g in doc) == 3, {'groups': [g['counts'] for g in doc]})
base = git(B, 'show', 'HEAD:crates/robot-core/src/serial_services.rs')
current = (B / 'crates/robot-core/src/serial_services.rs').read_bytes()
start = base.index(b'#[cfg(test)]\nmod tests {')
stop = base.index(b'\n\nuse crate::control_authority', start) + 1
block = base[start:stop]
rebuilt = base[:start] + base[stop + 1:]
rebuilt += b'\n' + block
check('P1B:1164字节原test块纯移EOF', len(block) == 1164 and rebuilt == current and current == (BB / 'native_qa_r1/serial_services_move_candidate.rs').read_bytes(), {'block_bytes': len(block), 'actual': identity(B / 'crates/robot-core/src/serial_services.rs')})
lib_base = git(B, 'show', 'HEAD:crates/robot-core/src/lib.rs')
check('P1B:corelib仅新增模块导出', lib_base.replace(b'pub mod time;\n', b'pub mod time;\npub mod wheel_velocity_profile;\n') == (B / 'crates/robot-core/src/lib.rs').read_bytes())
check('P1B:计划阶段元数据不可用作最终候选', plan['status'] == 'PREPARED_QA_NOT_RUN' and plan['files']['crates/robot-core/src/serial_services.rs']['sha256'] != br['manifest']['files']['crates/robot-core/src/serial_services.rs']['sha256'], {'interpretation': '原计划保留；另须最终manifest绑定fmt后591输入ebf4d9b及三源实际SHA，不回填旧plan', 'stale_plan_serial_sha': plan['files']['crates/robot-core/src/serial_services.rs']['sha256'], 'actual_serial_sha': br['manifest']['files']['crates/robot-core/src/serial_services.rs']['sha256']})
boundary = load(BB / 'native_qa_r1/prepare_boundary_failure.json')
check('P1B:准备期边界错误原件保留', boundary['status'] == 'FAIL_BEFORE_SOURCE_EDIT_OR_QA' and boundary['original_sources_unchanged'] is True and boundary['Cargo_runs'] == 0)
REPORT['p1a'] = {'manifest': identity(AA / 'final_r5/candidate_manifest.json'), 'source_manifest_sha256': ar['manifest']['source_manifest_sha256'], 'input_count': len(ar['manifest']['files']), 'six_source': manifest['six_source'], 'direct_completed_commands': len(ar['commands']), 'scoped_static_conclusion': '无静态阻断：实际系统header完整u128来源、未知None、mock样本与身份共同不可变；getter无分配/Arc增减、非认证权限机制', 'scope_limit': '仅本机六源transport独立tree；非Linux、非主树整合、非完整workspace门、非S0/S1活性守门或硬件证明'}
REPORT['p1b'] = {'source_manifest_sha256': br['manifest']['source_manifest_sha256'], 'input_count': len(br['manifest']['files']), 'three_source': {n: br['manifest']['files'][n] for n in ('crates/robot-core/src/lib.rs', 'crates/robot-core/src/wheel_velocity_profile.rs', 'crates/robot-core/src/serial_services.rs')}, 'direct_completed_commands': len(br['commands']), 'new_methods': sorted(expected), 'scoped_static_conclusion': '无静态阻断：三私有f64，finite且严格正校验，首非法字段具名错误；按位保存极端正值，不提前算比例/倒数，无默认/unchecked/serde/依赖/运行时接入', 'scope_limit': '仅本机core纯值合同与原test块移EOF；专项4为lib143子集，doc19单列；非Linux、非整合或全仓、非TOML/现场参数/固件单位/三轮实际运动'}
REPORT['open_deliverables'] = ['P1B须新增最终候选manifest，保留原PREPARED计划与准备期FAIL', '两候选尚未主树整合与整合后Linux/root fmt→Clippy质量门', '本评审只核任务指定的软件候选，硬件与全B1运行时尚不在本证据覆盖范围']
REPORT['previous_review'] = {'path': str(OUT.with_name('independent_p1a_p1b_dynamic_review_resume_r1.json')), 'reason': '保留r1完整读取问题：历史TLS实际文本为tls handshake eof；r4四旧局部名称为pub/sub加rustfmt换行；历史plan SHA对应历史归档；doc完整输出原有3ignored；不改源码、QA门或原回执'}
REPORT['status'] = 'SCOPED_SOFTWARE_SOURCE_AND_RECEIPTS_ACCEPTED_WITH_DELIVERY_LIMITS' if all(c['status'] == 'PASS' for c in REPORT['checks']) else 'REVIEW_FINDINGS_REQUIRE_RESOLUTION'
with OUT.open('x') as stream:
    json.dump(REPORT, stream, ensure_ascii=False, indent=2)
    stream.write('\n')
print(json.dumps({'report': identity(OUT), 'status': REPORT['status'], 'checks': len(REPORT['checks']), 'failed': [c for c in REPORT['checks'] if c['status'] != 'PASS'], 'p1a': {k: REPORT['p1a'][k] for k in ('input_count', 'source_manifest_sha256', 'direct_completed_commands')}, 'p1b': {k: REPORT['p1b'][k] for k in ('input_count', 'source_manifest_sha256', 'direct_completed_commands')}}, ensure_ascii=False))
