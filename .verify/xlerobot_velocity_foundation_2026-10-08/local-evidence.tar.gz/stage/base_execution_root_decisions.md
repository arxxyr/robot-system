# 完整底盘执行链的函数级计划约束

状态：root 设计选择，尚未实现或完成整链软件验收。S0 速度入口基础另行收口；本计划不能替代真机证据。

- XLeRobot 三轮顺序固定前8、左7、右9。保留既有 `base_back_wheel` 对前8的别名；S1 显式 `wheel_velocity` 配置轮半径、中心距和轮速上限，不填未经测量的默认值。复用已实现的具名 SI 正逆运动学与同比限速。
- 先核未占用再追加 `TaskKind=5` 和 `PayloadSchema=0x040F`，不重编号。载荷为 `vx_m_s/vy_m_s/wz_rad_s/duration_ms`，持续时间为正且区别于 RPC deadline；沿用真实授权、幂等账本和 RR 路径。
- 右 USB 总线只有一个物理 SerialIo/authority/writer。先实现三轮专用配置，右侧六臂的断扭需单独证明；不能开两个共享串口 writer。后续混合角色保留为明确工作项。
- S1 所有 Idle、Degraded、取消、完成和失败出口统一先发布零速，再发送终态。终态需真实 publisher 成功反馈；发布失败不得假成功，S0 期限/安全链仍生效。速度命令窗口最大100ms，逐 tick 更新；心跳保持50Hz。
- 不新增会话 wire 字段。当前 vendor 的 `Sample.header()` 可取真实共同 `UniqueNodeId` 和各自 `UniquePublisherId`，S1 两发布者确实来自同一个 Node。SampleLease 暴露强类型身份；不将不同 port ID 比为相等，不用哈希或默认0伪造身份。
- 底盘绑定配置来源与实际节点、各发布端代次，检查 header.seq 严格递增和 producer stamp 新鲜度。receiver accepted counter checked递增作为底盘 POD seq；`source_task_id` 保留任务关联，不当通用 sequence。
- Lost 记录 accepted seq 的恢复下限：好心跳仍需更新有效命令才恢复。节点或端口变更不自动恢复运动；切安全，经 Disabled/显式重建和 Enable 重绑后，要求新心跳、新命令及生产者时间下限，丢弃旧队列。不引入无限 retired 会话注册表。
- 补实际 IO 前与在途 deadline 拒绝。现 SerialTick 仅检查分派入口；PeriodicWrite probe 截止时间只约束 checkpoint/liveness，不能宣称 wire 时限已通过。
- 最终提供真实 Goal_Velocity、固件适配、初始化读回、enable 与 stop 正路径。Model/Mode/Phase、单位、零速与速度范围需具体合同和正负软件测试；永久 Unverified 拒绝不等于功能完成。未知固件保持 live 关闭，直到现场事实核实。
- 不改冻结设计。真实硬件访问当前禁止：上轮左腕回程 FAIL，人工断电待答；旧右H2 FAIL、D15 OPEN/DEFERRED、deployable=false 保持。代码、软件测试、安装与真机结果分别记录。

函数计划必须查真实符号和文件；不存在的 `BaseKinematics` trait、生产 cmd_vel 订阅或类型不可假造。按 profile/origin/freshness、S1任务与发布终态、固件和单总线正路径分包，列出能证明功能和拒绝边界的测试。
