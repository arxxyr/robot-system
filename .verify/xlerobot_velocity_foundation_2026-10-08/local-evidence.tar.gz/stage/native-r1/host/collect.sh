set -eu
export PATH=/home/loosqk/.cargo/bin:/home/loosqk/.local/bin:$PATH
export PYTHONDONTWRITEBYTECODE=1
cd /home/loosqk/robot-checks/xlerobot-velocity-foundation-20261001-r1/bootstrap
printf '%s\n' 'e0805cb4dd3a63abe0fcf09a901a0d63a9466482bf789c6bf4c973388a9784f8  collect_native.py' | sha256sum -c -
exec uv run --no-project python collect_native.py --collect --base /home/loosqk/robot-checks/xlerobot-velocity-foundation-20261001-r1 --out /home/loosqk/robot-checks/xlerobot-velocity-foundation-20261001-r1-native-evidence.tar.gz
