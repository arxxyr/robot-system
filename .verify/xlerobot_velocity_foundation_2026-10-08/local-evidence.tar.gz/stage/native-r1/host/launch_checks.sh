set -eu
export PATH=/home/loosqk/.cargo/bin:/home/loosqk/.local/bin:$PATH
export CARGO_HOME=/home/loosqk/robot-checks/viz-orin-a6957cc-20260930-r1/cargo-home
export CARGO_NET_OFFLINE=true
export RUSTUP_AUTO_INSTALL=0
export PYTHONDONTWRITEBYTECODE=1
cd /home/loosqk/robot-checks/xlerobot-velocity-foundation-20261001-r1/bootstrap
printf '%s\n' '6eb259e2c2ff16576c39de91f9ca5b1b401f4052c9763dcd86aced62fc608ea8  source-inputs.tar.gz' 'f64dec6ab221f63b0b36e3ad1fcf8133826e54734e07d6281c5574ea3872bee7  source_export.json' 'e1a6761b2fcc5d585c99323d3d81eae35c7f7ed3350cd906a90e7251db698653  expected_source.json' '51ac45460000d80b1906e4947a93aaa69677417900d8b010f703267044fa44ad  expected_tests.json' 'f995a34f020d364ce3458fa4f8fa350d10d7a239f2c8b32f035dd6d6bf350b0c  run_checks.py' 'dad9bbc9405b8fac4d60d6efe794b36750e6a6f9ce9fdeba3debf7d3e1b9a471  natural_runner.py' 'bd2b3f7bb8527cd9ecec73894171638e9cf378656b89e284a585c3baa37b8731  artifacts.py' 'ca793903d329c2c17eea816799cad25e9b1c4c2dc45cb93489cf19e38e567d4b  receive_source.py' | sha256sum -c -
uv run --no-project python receive_source.py
exec taskset -c 0-3 uv run --no-project python run_checks.py
