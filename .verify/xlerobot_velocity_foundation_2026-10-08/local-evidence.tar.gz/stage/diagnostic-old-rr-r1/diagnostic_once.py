"""一次旧RR测试ELF诊断；原QA失败不改，不编译、不触硬件。"""
import hashlib,importlib.util,json,os,re,signal,stat,sys
from pathlib import Path
from types import SimpleNamespace
sys.dont_write_bytecode=True
BASE=Path('/home/loosqk/robot-checks/xlerobot-velocity-foundation-20261001-r2');BOOT=BASE/'bootstrap';SOURCE=BASE/'source';OUT=BASE/'diagnostic-old-rr-r1'
ELF=BASE/'build/debug/build/robot-s0/79cfab88a8d40b86/out/robot_s0-79cfab88a8d40b86'
TEST='ipc_thread::tests::pending_adapter_fault_resolves_internal_adapter_error'
def module(name,path):
 spec=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);return m
h=module('natural_runner',BOOT/'natural_runner.py');a=module('source_artifacts',BOOT/'artifacts.py');require=a.require
require(a.sha256(BOOT/'natural_runner.py')=='dad9bbc9405b8fac4d60d6efe794b36750e6a6f9ce9fdeba3debf7d3e1b9a471','冻结Runner不符')
expected=a.strict_json((BOOT/'expected_source.json').read_text());export=a.strict_json((BOOT/'source_export.json').read_text())
OUT.mkdir();runner=h.Runner(SimpleNamespace(source=SOURCE,out=OUT,target=BASE/'build'),a)
result={'status':'FAIL','scope':'旧r2测试ELF一次exact软件诊断，单项结果不改原整体FAIL、不证明根因','original_qa':str(BASE/'qa-r2/result.json'),'test':TEST,'receipts':[],'compiler_kind':'ELF历史编译身份，不是10月7日新工具链更新'};previous={};before=None;binary=None
def source(label):
 require(not os.path.lexists(SOURCE/'.git'),'导出源不能伪称Git checkout')
 inventory=[]
 for root,dirs,files in os.walk(SOURCE,followlinks=False):
  for name in dirs:require(stat.S_ISDIR((Path(root)/name).lstat().st_mode),'导出源含链接目录')
  for name in files:inventory.append((Path(root)/name).relative_to(SOURCE).as_posix())
 require(set(inventory)==set(expected['files']) and len(inventory)==len(expected['files']),'导出源集合变化')
 require(set(export['files'])==set(expected['files']),'导出清单集合不同')
 for name,item in expected['files'].items():
  path=SOURCE/name;info=path.lstat();require(stat.S_ISREG(info.st_mode) and path.resolve()==path,'非普通源文件')
  with os.fdopen(os.open(path,os.O_RDONLY|os.O_NOFOLLOW),'rb') as stream:
   first=os.fstat(stream.fileno());data=stream.read(item['bytes']+1);last=os.fstat(stream.fileno())
  identity=lambda s:(s.st_dev,s.st_ino,s.st_mode,s.st_size,s.st_mtime_ns,s.st_ctime_ns)
  require(identity(info)==identity(first)==identity(last)==identity(path.lstat()),'读取源身份漂移')
  require(len(data)==item['bytes'] and hashlib.sha256(data).hexdigest()==item['sha256'],'源bytes/SHA变化')
  require(stat.S_IMODE(info.st_mode)==export['files'][name]['mode'] and bool(info.st_mode&stat.S_IXUSR)==item['executable'],'源mode/exec变化')
 value=a.snapshot_source(SOURCE,inventory);require(value==expected,'完整编译域不符');h.save(OUT/(label+'.json'),value);return value

def elf():
 info=ELF.lstat();require(stat.S_ISREG(info.st_mode) and ELF.resolve()==ELF and info.st_mode&0o111,'ELF不是独立普通可执行文件')
 with os.fdopen(os.open(ELF,os.O_RDONLY|os.O_NOFOLLOW),'rb') as stream:
  opened=os.fstat(stream.fileno());data=stream.read(info.st_size+1);after=os.fstat(stream.fileno())
 state=lambda p:(p.st_dev,p.st_ino,p.st_mode,p.st_size,p.st_mtime_ns,p.st_ctime_ns)
 require(state(info)==state(opened)==state(after)==state(ELF.lstat()) and len(data)==info.st_size,'ELF读取身份漂移')
 require(data[:6]==b'\x7fELF\x02\x01' and int.from_bytes(data[18:20],'little')==183,'必须是原生ELF183')
 return {'path':str(ELF),'sha256':hashlib.sha256(data).hexdigest(),'bytes':len(data),'mode':stat.S_IMODE(info.st_mode),'machine':183}
def interrupted(sig,frame):h.INTERRUPTED=sig
try:
 for sig in (signal.SIGINT,signal.SIGTERM,signal.SIGHUP):previous[sig]=signal.signal(sig,interrupted)
 require(os.getuid()==1000 and os.getgid()==1000 and Path('/proc/sys/kernel/random/boot_id').read_text().strip()=='6cf7ee3e-a3c5-4c91-80bc-4ca924818b53','主机身份不符')
 original=a.strict_json((BASE/'qa-r2/result.json').read_text());require(original['status']=='FAIL' and original['source_before_after']=='PASS','原失败身份不符');result['historical_compiler']=original['compiler'];result['original_qa_sha256']=a.sha256(BASE/'qa-r2/result.json')
 before=source('source_before');binary=elf();result['elf_before']=binary
 try:
  runner.command('exact_old_rr_once',[str(ELF),TEST,'--exact','--test-threads=1'],300)
 except BaseException as error:result['command_error']=repr(error)
 completion=a.strict_json((OUT/'exact_old_rr_once/completion.json').read_text());text=(OUT/'exact_old_rr_once/stdout.log').read_text();counts=re.findall(r'test result: (ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored;',text);names=re.findall(r'^test ([^ ]+) \.\.\. (ok|FAILED)$',text,re.M)
 require(len(counts)==1 and int(counts[0][1])+int(counts[0][2])==1 and counts[0][3]=='0' and names==[(TEST,'ok' if completion['exit_code']==0 else 'FAILED')],'实际精确方法数量必须为1且未ignored')
 result.update(status='PASS_SINGLE_OBSERVATION_NOT_FULL_QA' if completion['exit_code']==0 else 'FAIL_SINGLE_OBSERVATION',actual_test_count=1,test_counts=counts[0],exit_code=completion['exit_code'],original_cause='UNCONFIRMED')
except BaseException as error:result.update(status='FAIL',error=repr(error))
finally:
 try:
  require(before is not None and source('source_after')==before,'590源漂移');require(binary is not None and elf()==binary,'ELF前后身份漂移');result['source_and_elf_before_after']='PASS';require(a.sha256(BASE/'qa-r2/result.json')==result['original_qa_sha256'],'原QA变更')
 except BaseException as error:result.update(status='FAIL',after_error=repr(error))
 result['receipts']=runner.receipts;h.save(OUT/'result.json',result)
 for sig,handler in previous.items():signal.signal(sig,handler)
print(json.dumps(result,ensure_ascii=False),flush=True);raise SystemExit(0 if result['status']=='PASS_SINGLE_OBSERVATION_NOT_FULL_QA' else 1)
