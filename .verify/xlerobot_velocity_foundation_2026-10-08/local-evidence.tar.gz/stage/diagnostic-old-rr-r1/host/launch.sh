set -eu
export PATH=/home/loosqk/.cargo/bin:/home/loosqk/.local/bin:$PATH
export CARGO_HOME=/home/loosqk/robot-checks/viz-orin-a6957cc-20260930-r1/cargo-home
export CARGO_NET_OFFLINE=true
export RUSTUP_AUTO_INSTALL=0
export PYTHONDONTWRITEBYTECODE=1
cd /home/loosqk/robot-checks/xlerobot-velocity-foundation-20261001-r2/bootstrap
printf '%s\n' '75abe8ef7e786a9100d997fb5d0f6758e755feb0c6728aee651483ff7a6cff78  diagnostic_20261007_once.py' | sha256sum -c -
exec taskset -c 0-3 uv run --no-project python diagnostic_20261007_once.py
