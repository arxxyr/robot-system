set -eu
export PATH=/home/loosqk/.cargo/bin:/home/loosqk/.local/bin:$PATH
export PYTHONDONTWRITEBYTECODE=1
cd /home/loosqk/robot-checks/xlerobot-velocity-foundation-20261007-r5/bootstrap
printf '%s\n' '9060e0c19034c67c76d24fd47e357f2889a4e29536c12d2feeeb7667f3f3ec51  collect_native.py' | sha256sum -c -
exec uv run --no-project python collect_native.py --collect --base /home/loosqk/robot-checks/xlerobot-velocity-foundation-20261007-r5 --out /home/loosqk/robot-checks/xlerobot-velocity-foundation-20261007-r5-native-evidence.tar.gz
