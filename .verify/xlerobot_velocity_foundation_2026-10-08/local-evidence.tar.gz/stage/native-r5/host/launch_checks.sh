set -eu
export PATH=/home/loosqk/.cargo/bin:/home/loosqk/.local/bin:$PATH
export CARGO_HOME=/home/loosqk/robot-checks/viz-orin-a6957cc-20260930-r1/cargo-home
export CARGO_NET_OFFLINE=true
export RUSTUP_AUTO_INSTALL=0
export PYTHONDONTWRITEBYTECODE=1
cd /home/loosqk/robot-checks/xlerobot-velocity-foundation-20261007-r5/bootstrap
printf '%s\n' '30b55b008c1597356d34abb2556b81ecf7227d58c6d6db9ef90e157c90c7c853  source-inputs.tar.gz' 'a15262c72705d44474ad446a1248e2297c24a597e2785dbd3036e060feb1cce2  source_export.json' '89861e67e393d04d64489d365efe9511c9255ac142c64dd7e5e1c8a192938c23  expected_source.json' '51ac45460000d80b1906e4947a93aaa69677417900d8b010f703267044fa44ad  expected_tests.json' '9f361db38794aa37f038943ff8897e642c4749b3908fd564049504ca443bf8ab  run_checks.py' 'dad9bbc9405b8fac4d60d6efe794b36750e6a6f9ce9fdeba3debf7d3e1b9a471  natural_runner.py' 'bd2b3f7bb8527cd9ecec73894171638e9cf378656b89e284a585c3baa37b8731  artifacts.py' '30c9e26f4c5af90861db7004b346cbc204a27ef73180ccc3cb6224e8cf65e1d5  receive_source.py' | sha256sum -c -
uv run --no-project python receive_source.py
exec taskset -c 0-3 uv run --no-project python run_checks.py
