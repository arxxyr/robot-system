set -eu
export PATH=/home/loosqk/.cargo/bin:/home/loosqk/.local/bin:$PATH
test "$(hostname)" = ubuntu
test "$(id -u)" = 1000
test "$(id -g)" = 1000
test "$(cat /proc/sys/kernel/random/boot_id)" = 6cf7ee3e-a3c5-4c91-80bc-4ca924818b53
uv run --no-project python - <<'CHECK'
import datetime,json,os,stat
from pathlib import Path
pid=479977;expected_start=318194437
result={'scope':'本次一次只读下载状态；不读环境/配置、不控制进程','pid':pid,'expected_start_ticks':expected_start,'observed_utc':datetime.datetime.now(datetime.timezone.utc).isoformat()}
def limited(path,size):
 with path.open('rb') as f:data=f.read(size+1)
 if len(data)>size:raise ValueError('诊断读取超过上限')
 return data.decode(errors='replace')
p=Path('/proc')/str(pid)
if p.exists():
 raw=limited(p/'stat',16384);fields=raw.rsplit(')',1)[1].split();start=int(fields[19]);assert start==expected_start
 result['process']={'identity_status':'SAME_PID_AND_START','start_ticks':start,'state':fields[0],'utime_ticks':int(fields[11]),'stime_ticks':int(fields[12]),'processor':int(fields[36]),'wchan':limited(p/'wchan',4096),'exe':os.readlink(p/'exe')}
else:result['process']={'identity_status':'PID_NOT_PRESENT'}
log=Path('/home/loosqk/robot-checks/xlerobot-velocity-foundation-20261007-r5/qa-r5/latest_nightly_update/stderr.log');info=log.lstat();assert stat.S_ISREG(info.st_mode)
with os.fdopen(os.open(log,os.O_RDONLY|os.O_NOFOLLOW),'rb') as f:
 f.seek(max(0,info.st_size-65536));data=f.read(min(info.st_size,65536))
result['stderr']={'bytes_at_stat':info.st_size,'mtime_ns':info.st_mtime_ns,'tail_bytes':len(data),'tail':data.decode(errors='replace')}
directory=Path('/home/loosqk/.rustup/downloads');assert stat.S_ISDIR(directory.lstat().st_mode);rows=[]
for path in directory.iterdir():
 if path.name.endswith('.partial'):
  if len(rows)>=4096:raise ValueError('partial条目超过诊断上限')
  info=path.lstat();assert stat.S_ISREG(info.st_mode)
  rows.append({'name':path.name,'bytes':info.st_size,'mtime_ns':info.st_mtime_ns})
result['partial_files']={'count':len(rows),'total_bytes':sum(row['bytes'] for row in rows),'files':sorted(rows,key=lambda row:row['name'])}
result['status']='PASS_READONLY_SNAPSHOT_ONLY'
print(json.dumps(result,ensure_ascii=False,indent=2))
CHECK
