set -eu
test "$(hostname)" = ubuntu
test "$(id -u)" = 1000
test "$(id -g)" = 1000
test "$(cat /proc/sys/kernel/random/boot_id)" = 6cf7ee3e-a3c5-4c91-80bc-4ca924818b53
TASK_UPDATE=/home/loosqk/robot-checks/xlerobot-velocity-foundation-20261007-r5/qa-r5/latest_nightly_update
for filename in launch.json stdout.log stderr.log completion.json; do
 if test -f "$TASK_UPDATE/$filename"; then
  printf '%s\n' "$filename"
  tail -c 65536 "$TASK_UPDATE/$filename"
 fi
done
