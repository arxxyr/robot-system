import json, os, platform
from pathlib import Path
value={"hostname":platform.node(),"arch":platform.machine(),"uid":os.getuid(),"gid":os.getgid(),"boot_id":Path("/proc/sys/kernel/random/boot_id").read_text().strip()}
assert value=={"hostname":"ubuntu","arch":"aarch64","uid":1000,"gid":1000,"boot_id":"6cf7ee3e-a3c5-4c91-80bc-4ca924818b53"},value
print(json.dumps(value))
