set -eu
export PATH=/home/loosqk/.cargo/bin:/home/loosqk/.local/bin:$PATH
test "$(hostname)" = ubuntu
test "$(id -u)" = 1000
test "$(id -g)" = 1000
test "$(uname -m)" = aarch64
test "$(cat /proc/sys/kernel/random/boot_id)" = 6cf7ee3e-a3c5-4c91-80bc-4ca924818b53
ps -eo pid,ppid,args | awk '$0 ~ /[c]argo (build|test|clippy)/ {print; found=1} END {exit found ? 1 : 0}'
TASK_BASE=/home/loosqk/robot-checks/xlerobot-velocity-foundation-20261007-r3
test ! -e "$TASK_BASE"
mkdir "$TASK_BASE"
mkdir "$TASK_BASE/bootstrap"
