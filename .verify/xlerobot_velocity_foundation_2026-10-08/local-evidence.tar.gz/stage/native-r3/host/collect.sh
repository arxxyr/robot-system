set -eu
export PATH=/home/loosqk/.cargo/bin:/home/loosqk/.local/bin:$PATH
export PYTHONDONTWRITEBYTECODE=1
cd /home/loosqk/robot-checks/xlerobot-velocity-foundation-20261007-r3/bootstrap
printf '%s\n' '8c8c44e7d3a1152fa937a529599c5387c7711ebc0feb3f41815f7f9e75c7e63b  collect_native.py' | sha256sum -c -
exec uv run --no-project python collect_native.py --collect --base /home/loosqk/robot-checks/xlerobot-velocity-foundation-20261007-r3 --out /home/loosqk/robot-checks/xlerobot-velocity-foundation-20261007-r3-native-evidence.tar.gz
