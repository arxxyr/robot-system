set -eu
export PATH=/home/loosqk/.cargo/bin:/home/loosqk/.local/bin:$PATH
export CARGO_HOME=/home/loosqk/robot-checks/viz-orin-a6957cc-20260930-r1/cargo-home
export CARGO_NET_OFFLINE=true
export RUSTUP_AUTO_INSTALL=0
export PYTHONDONTWRITEBYTECODE=1
cd /home/loosqk/robot-checks/xlerobot-velocity-foundation-20261007-r3/bootstrap
printf '%s\n' 'c1418635c4c9e3a16ecfcf98ac312147bd4284dc813dfaf64903a42e6262544f  source-inputs.tar.gz' 'a604583661814254c15e738e1e146b3062c465744bbe03a70236d651c6883e75  source_export.json' '56f3e06dae7a974bd4e2b470d7c00cf486881d6d36fc071349dd3a9837af2e4f  expected_source.json' '51ac45460000d80b1906e4947a93aaa69677417900d8b010f703267044fa44ad  expected_tests.json' '55a45ae6e893e0efdf5049daa498b534adfd6a8f08e496e95c4164dec4dd2bcc  run_checks.py' 'dad9bbc9405b8fac4d60d6efe794b36750e6a6f9ce9fdeba3debf7d3e1b9a471  natural_runner.py' 'bd2b3f7bb8527cd9ecec73894171638e9cf378656b89e284a585c3baa37b8731  artifacts.py' 'c55b836bac678395725804c82c3a17d6f5e34e2de794d579e8a3ebdf57f48420  receive_source.py' | sha256sum -c -
uv run --no-project python receive_source.py
exec taskset -c 0-3 uv run --no-project python run_checks.py
