set -eu
export PATH=/home/loosqk/.cargo/bin:/home/loosqk/.local/bin:$PATH
export CARGO_HOME=/home/loosqk/robot-checks/viz-orin-a6957cc-20260930-r1/cargo-home
export CARGO_NET_OFFLINE=true
export RUSTUP_AUTO_INSTALL=0
export PYTHONDONTWRITEBYTECODE=1
cd /home/loosqk/robot-checks/xlerobot-velocity-foundation-20261007-r4/bootstrap
printf '%s\n' 'd2737776c394469bfc0e3921103851b135ab6268f932be3db2b8cbe137ef3f4a  source-inputs.tar.gz' '2c0be04f7220b027edcf19e85225e65a997f93f0dfe0d252ad1c4fd6dfa25561  source_export.json' 'b9879f37b4c20bdbb5939d5193d74b682c4dbf0d0ae087c17d3ef188a08f42c8  expected_source.json' '51ac45460000d80b1906e4947a93aaa69677417900d8b010f703267044fa44ad  expected_tests.json' '6fc7225ac09540c169bc0fd65592b8972413d74d5f7b409215f838221596d408  run_checks.py' 'dad9bbc9405b8fac4d60d6efe794b36750e6a6f9ce9fdeba3debf7d3e1b9a471  natural_runner.py' 'bd2b3f7bb8527cd9ecec73894171638e9cf378656b89e284a585c3baa37b8731  artifacts.py' '3a46db8aced49b48e2020193dac2d2192eeedf725ec9c4106bbd52e42653c967  receive_source.py' | sha256sum -c -
uv run --no-project python receive_source.py
exec taskset -c 0-3 uv run --no-project python run_checks.py
