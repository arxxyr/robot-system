set -eu
export PATH=/home/loosqk/.cargo/bin:/home/loosqk/.local/bin:$PATH
export PYTHONDONTWRITEBYTECODE=1
cd /home/loosqk/robot-checks/xlerobot-velocity-foundation-20261007-r4/bootstrap
printf '%s\n' '2789406bf0dddbe80f91f0b28dfa735a96ad66227f4cf07cf50aa2ec084bb8c5  collect_native.py' | sha256sum -c -
exec uv run --no-project python collect_native.py --collect --base /home/loosqk/robot-checks/xlerobot-velocity-foundation-20261007-r4 --out /home/loosqk/robot-checks/xlerobot-velocity-foundation-20261007-r4-native-evidence.tar.gz
