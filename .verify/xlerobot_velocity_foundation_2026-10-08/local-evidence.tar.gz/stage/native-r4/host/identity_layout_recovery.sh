set -eu
hostname
id
cat /proc/sys/kernel/random/boot_id
TASK_BASE=/home/loosqk/robot-checks/xlerobot-velocity-foundation-20261007-r4
if test -e "$TASK_BASE"; then
  ls -ld "$TASK_BASE"
  for part in bootstrap source build qa-r4; do
    if test -e "$TASK_BASE/$part"; then
      ls -ld "$TASK_BASE/$part"
    else
      printf 'ABSENT %s\n' "$TASK_BASE/$part"
    fi
  done
else
  printf 'ABSENT %s\n' "$TASK_BASE"
fi
