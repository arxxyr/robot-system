"""只读汇总四轮原件；失败仍为失败，重复测试按名称去重。"""
import hashlib
import json
import re
from pathlib import Path

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent


def require(ok, message):
    if not ok:
        raise ValueError(message)


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def load(path):
    return json.loads(path.read_text())


def reference(path):
    return {"path": str(path), "sha256": sha(path), "bytes": path.stat().st_size}


iterations = []
direct = []
owners = []
git_children = []
for number, expected_status, aggregate in (
    (1, "FAIL", "872bc3494c7e0834c9bf1a8bf03312b1ba1c3098557562d3d47ae46f6718b4ae"),
    (2, "FAIL", "309999d9d79852cd24ba5fa8ee54226d854ee722c6a8949fe0ee87ef401dfd65"),
    (3, "FAIL", "ddbeee4a1d231f752d3dfc1ab07692cbc1ca5d000c2e4fcf65692362e6c70420"),
    (4, "PASS", "d8699eb6e0e3d8a0031a535b9664255a3c63630215ac9440a308fd3a0198cfc0"),
):
    stage = ROOT / f"native-r{number}"
    extracted = stage / "native-extracted"
    remote = Path(f"/home/loosqk/robot-checks/xlerobot-velocity-foundation-{'20261007' if number >= 3 else '20261001'}-r{number}")
    qa = extracted / f"qa-r{number}"
    result = load(qa / "result.json")
    before, after = load(qa / "source_before.json"), load(qa / "source_after.json")
    require(result["status"] == expected_status, "原始结果状态不符")
    require(before == after == load(stage / "expected_source.json"), "源码首末不符")
    require(len(before["files"]) == 590 and before["source_manifest_sha256"] == aggregate,
            "完整输入域不符")
    require(result["compiler_window"] == result["source_before_after"] == "PASS", "后验不符")
    require(result["native_git_head"] is None and result["origin"]["main_head"] ==
            "8fb17b153f4eb85cb1b88ca935cc115087784256", "不得伪称原生Git身份")
    for manifest in qa.glob("*_source_*.json"):
        require(load(manifest) == before, "阶段前后源码不符：" + str(manifest))
    for receipt in result["receipts"]:
        path = extracted / Path(receipt["path"]).relative_to(remote)
        require(sha(path) == receipt["sha256"], "completion引用SHA不符")
        row = load(path)
        launch = load(path.parent / "launch.json")
        require(row["reaped"] is True and row["exec_gate_released"] is True,
                "真实执行或回收缺失")
        require(not row["signals"] and not row["budget_exceeded"] and
                not row["session_residual_before_cleanup"] and not row["session_residual_after_cleanup"],
                "信号、预算或残留不符")
        for field in ("name", "argv", "cwd", "env", "started_at", "started_monotonic_ns",
                      "timeout_seconds", "deadline_monotonic_ns", "pid", "identity",
                      "stdout", "stderr", "launch_receipt", "completion_receipt",
                      "bootstrap_argv", "bootstrap_sha256", "identity_phase"):
            require(row[field] == launch[field], "启动与完成绑定不符：" + field)
        require(row["identity"]["pid"] == row["pid"] and row["identity"]["start_ticks"] > 0 and
                row["identity"]["boot_id"] == "6cf7ee3e-a3c5-4c91-80bc-4ca924818b53", "PID身份不符")
        for kind in ("stdout", "stderr"):
            log = extracted / Path(row[kind]).relative_to(remote)
            require(sha(log) == row[kind + "_sha256"] and log.stat().st_size == row[kind + "_bytes"],
                    "原始日志身份不符")
        failed = (number == 1 and row["name"] == "clippy_default") or (number == 2 and row["name"] == "s0_default_lib") or (number == 3 and row["name"] == "clippy_default")
        require(row["exit_code"] == (101 if failed else 0), "实际退出码不符")
        require(row["runner_error"] == ("ValueError('命令原始退出码非零')" if failed else None),
                "原错误口径不符")
        direct.append({"iteration": number, **row, "local_completion": reference(path)})
    export = load(stage / "source_export.json")
    require(export["source_manifest"] == before, "导出源域不符")
    for row in export["git_children"]:
        require(row["exit_code"] == 0 and row["reaped"] is True, "导出Git child未回收")
        git_children.append({"iteration": number, **row})
    for directory in sorted((stage / "host").glob("*.owner")):
        path = directory / "result.json"
        require(path.is_file(), "owner尚未结束：" + str(directory))
        row = load(path)
        require(row["reaped"] is True and not row["owner_sent_signals"] and
                not row["received_signals"] and not row["errors"], "owner回收或信号不符")
        failed = number in (1, 2, 3) and directory.name == "checks.owner"
        transport_failed = (number == 2 and directory.name in ("upload_collector.owner", "collect.owner")) or (number == 4 and directory.name == "prepare.owner")
        code = 255 if transport_failed else 1 if failed else 0
        require(row["wait_returncode"] == code, "owner实际wait不符")
        require(row["status"] == ("FAIL" if code else "PASS"), "owner状态不符")
        log = directory / "child.log"
        require(sha(log) == row["log"]["sha256"] and log.stat().st_size == row["log"]["bytes"],
                "owner日志不符")
        owners.append({"iteration": number, **row, "local_result": reference(path)})
    verify = load(stage / "native_archive_verification.json")
    require(verify["status"] == "PASS" and verify["aggregate"] == aggregate, "原件包完整性不符")
    iterations.append({"number": number, "qa_status": expected_status, "aggregate": aggregate,
                       "source_files": 590, "result": reference(qa / "result.json"),
                       "source_before": reference(qa / "source_before.json"),
                       "source_after": reference(qa / "source_after.json"),
                       "archive": reference(stage / "native-evidence.tar.gz"),
                       "index": reference(stage / "native-evidence.index.json"),
                       "metadata": reference(stage / "native-evidence.metadata.json"),
                       "verification": reference(stage / "native_archive_verification.json"),
                       "gates": result["gates"], "compiler": result["compiler"]})

final = load(HERE / "native-extracted/qa-r4/result.json")
tests = final["tests"]
required = set(load(HERE / "expected_tests.json")["library_new_subset"])
require(len(required) == 24, "新增方法集合不是24")
for label, key in (("s0_default_lib", "default_lib"), ("s0_guard_hook_lib", "guard_hook_lib"),
                   ("serial_rt_e2e", "serial_rt_e2e")):
    stdout = (HERE / "native-extracted/qa-r4" / label / "stdout.log").read_text()
    counts = re.findall(r"test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored;", stdout)
    names = re.findall(r"^test ([^ ]+)(?: - should panic)? \.\.\. ok$", stdout, re.M)
    require(len(counts) == 1 and counts[0][1:] == ("0", "0") and
            len(names) == len(set(names)) == int(counts[0][0]) == tests[key]["passed"] and
            names == tests[key]["names"], "实际测试输出与报告不符")
    require(required <= set(names) if key != "serial_rt_e2e" else
            set(names) == set(load(HERE / "expected_tests.json")["serial_rt_e2e_all"]), "测试集合缺失")
union = set(tests["default_lib"]["names"]) | set(tests["guard_hook_lib"]["names"])
require(len(union) == tests["distinct_library_count"] and
        len(union) + 5 == tests["distinct_all_with_serial"], "去重计数不符")
diagnostic_stage = ROOT / "diagnostic-old-rr-r1"
diagnostic_root = diagnostic_stage / "remote-originals/diagnostic-old-rr-r1"
diagnostic = load(diagnostic_root / "result.json")
require(diagnostic["status"] == "PASS_SINGLE_OBSERVATION_NOT_FULL_QA" and diagnostic["actual_test_count"] == 1 and diagnostic["source_and_elf_before_after"] == "PASS", "单项诊断原件不符")
for directory in sorted((diagnostic_stage / "host").glob("*.owner")):
    path = directory / "result.json"
    row = load(path)
    require(row["reaped"] is True and row["wait_returncode"] == 0 and not row["errors"] and not row["owner_sent_signals"] and not row["received_signals"], "诊断owner未回收")
    require(sha(directory / "child.log") == row["log"]["sha256"], "诊断owner日志不符")
    owners.append({"iteration": "separate_old_ELF_diagnostic", **row, "local_result": reference(path)})
summary = {
    "schema": "XLEROBOT_VELOCITY_FOUNDATION_ORIN_EVIDENCE_SUMMARY_V1",
    "status": "PASS_SOFTWARE_CANDIDATE_WITH_PRIOR_FAIL_PRESERVED",
    "deployable": False, "not_full_B1": True, "native_git_head": None,
    "scope": "速度入站及SerialTick基础软件；不代表硬件、全workspace、release或完整B1验收。",
    "iterations": iterations, "tests": tests, "separate_diagnostic": diagnostic,
    "separate_diagnostic_result": reference(diagnostic_root / "result.json"),
    "separate_diagnostic_not_added_to_test_count": True,
    "direct_child_count": len(direct), "direct_children": direct,
    "host_owner_count": len(owners), "host_owners": owners,
    "export_git_child_count": len(git_children), "export_git_children": git_children,
    "prior_failure": "r1默认Clippy实际101；r2默认lib640PASS/1旧RR timeoutFAIL；三轮未执行项及三连接255保留；r3默认Clippy实际101为8d新nightly既有logging doc lint，r4只修两个变量名backticks。r2旧ELF精确单项PASS仅一次观察，原超时根因仍UNCONFIRMED。r3仅原旧method同步前提及QA shouldpanic解析窄修，不改生产或3秒预算。",
    "never_executed": ["UART", "硬件GO", "daemon/service启动", "正式安装", "release", "完整workspace", "push"],
}
with (HERE / "summary.json").open("x") as stream:
    json.dump(summary, stream, ensure_ascii=False, indent=2)
    stream.write("\n")
print(json.dumps({"status": summary["status"], "summary": reference(HERE / "summary.json"),
                  "direct_children": len(direct), "host_owners": len(owners),
                  "export_git_children": len(git_children),
                  "distinct_tests": tests["distinct_all_with_serial"]}, ensure_ascii=False))
