"""按root冻结输入独占导出源码；原仓只读，保留实际Git前后与逐文件身份。"""
import hashlib,importlib.util,io,json,os,stat,subprocess,tarfile,time
from pathlib import Path
HERE=Path(__file__).resolve().parent;ROOT=HERE.parents[2]
def module(path):
 spec=importlib.util.spec_from_file_location('artifacts',path);value=importlib.util.module_from_spec(spec);spec.loader.exec_module(value);return value
a=module(HERE/'artifacts.py');expected=a.strict_json((HERE/'expected_source.json').read_text());records=[]
def git(args):
 argv=['git',*args];started=time.monotonic_ns();p=subprocess.Popen(argv,cwd=ROOT,stdout=subprocess.PIPE,stderr=subprocess.PIPE);output,error=p.communicate();records.append({'argv':argv,'pid':p.pid,'exit_code':p.returncode,'reaped':p.returncode is not None,'started_monotonic_ns':started,'ended_monotonic_ns':time.monotonic_ns(),'stdout':output.decode(),'stderr':error.decode()});a.require(p.returncode==0,'Git只读命令失败');return output
head=git(['rev-parse','HEAD']).decode().strip();a.require(head=='8fb17b153f4eb85cb1b88ca935cc115087784256','主HEAD变化')
status=git(['status','--porcelain=v1','--untracked-files=all']).decode();inventory=git(['ls-files','-z','--cached','--others','--exclude-standard']).decode().rstrip('\0').split('\0');a.require(a.snapshot_source(ROOT,inventory)==expected,'不是root最终编译域')
allowed={'crates/robot-s0/src/ipc_thread.rs','crates/robot-s0/src/serial_tick.rs','crates/robot-core/src/executor_ctrl.rs','crates/robot-logging/src/lib.rs'}
a.require({row[3:] for row in status.splitlines() if any(row[3:]==d or row[3:].startswith(d+'/') for d in a.INPUT_DOMAINS)}==allowed,'编译域dirty范围变化')
files={};archive=HERE/'source-inputs.tar.gz'
def identity(s):return(s.st_dev,s.st_ino,s.st_mode,s.st_size,s.st_mtime_ns,s.st_ctime_ns)
with tarfile.open(archive,'x:gz') as tar:
 for name,item in expected['files'].items():
  path=ROOT/name;info=path.lstat();a.require(stat.S_ISREG(info.st_mode) and path.resolve()==path,'非普通原文件')
  with os.fdopen(os.open(path,os.O_RDONLY|os.O_NOFOLLOW),'rb') as stream:
   first=os.fstat(stream.fileno());data=stream.read(item['bytes']+1);last=os.fstat(stream.fileno())
  a.require(identity(info)==identity(first)==identity(last)==identity(path.lstat()),'原文件读取身份漂移')
  a.require(len(data)==item['bytes'] and hashlib.sha256(data).hexdigest()==item['sha256'] and bool(info.st_mode&stat.S_IXUSR)==item['executable'],'原文不匹配冻结输入')
  row={**item,'mode':stat.S_IMODE(info.st_mode)};files[name]=row;member=tarfile.TarInfo(name);member.size=len(data);member.mode=row['mode'];tar.addfile(member,io.BytesIO(data))
a.require(git(['rev-parse','HEAD']).decode().strip()==head and git(['status','--porcelain=v1','--untracked-files=all']).decode()==status,'Git前后变化');a.require(a.snapshot_source(ROOT,inventory)==expected,'导出后源码漂移')
value={'schema':'FROZEN_COMPILATION_INPUT_EXPORT_V1','status':'PASS_EXPORT_ONLY','origin':{'main_root':str(ROOT),'main_head':head,'main_porcelain':status,'dirty_compilation_paths':sorted(allowed),'native_git_head':None,'source_kind':'exported compilation-input snapshot'},'source_manifest':expected,'files':files,'archive':{'sha256':a.sha256(archive),'bytes':archive.stat().st_size},'git_children':records,'artifacts_sha256':a.sha256(HERE/'artifacts.py')}
with (HERE/'source_export.json').open('x') as f:json.dump(value,f,ensure_ascii=False,indent=2);f.write('\n')
print(json.dumps({'status':value['status'],'files':len(files),'aggregate':expected['source_manifest_sha256'],'archive':value['archive']},ensure_ascii=False))
