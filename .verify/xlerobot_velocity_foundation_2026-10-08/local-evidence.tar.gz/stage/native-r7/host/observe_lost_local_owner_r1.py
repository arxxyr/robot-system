"""仅记录旧本机持有者缺失；不伪造旧 wait/reap，也不修改旧回执。"""
import datetime
import hashlib
import json
from pathlib import Path
import subprocess

base = Path(__file__).resolve().parent
old = base / "checks.owner"

def reference(path):
    raw = path.read_bytes()
    return {"path": str(path), "sha256": hashlib.sha256(raw).hexdigest(), "bytes": len(raw)}

before = {name: reference(old / name) for name in ("launch.json", "status.json", "child.log")}
row = json.loads((old / "launch.json").read_text())
assert (row["owner_pid"], row["pid"]) == (36112, 36113)
argv = ["/bin/ps", "-p", "36112,36113", "-o", "pid=,ppid=,lstart=,stat=,command="]
child = subprocess.Popen(argv, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
stdout, stderr = child.communicate()
code = child.wait()
assert code == 1 and not stdout.strip() and not stderr.strip(), (code, stdout, stderr)
after = {name: reference(old / name) for name in before}
assert before == after
assert not (old / "result.json").exists()
value = {"schema": "XLEROBOT_R7_LOCAL_OWNER_LOST_OBSERVATION_V1", "observed_at": datetime.datetime.now(datetime.timezone.utc).isoformat(),
         "status": "LOCAL_OWNER_REAP_UNKNOWN", "original_owner_pid": 36112, "original_ssh_pid": 36113,
         "original_wait_returncode": None, "original_reaped": None, "original_result_exists": False,
         "current_processes": "BOTH_ABSENT", "observation_child": {"argv": argv, "pid": child.pid, "wait_returncode": code, "reaped": True, "stdout": stdout.decode(), "stderr": stderr.decode()},
         "original_files_before": before, "original_files_after": after, "original_files_unchanged": True,
         "limitation": "远端 QA 回执只能证明远端各子命令回收；不能证明丢失的本机 SSH 持有者真实 wait/reap。"}
out = base / "lost_local_owner_observation_r1.json"
with out.open("x") as stream:
    json.dump(value, stream, ensure_ascii=False, indent=2)
    stream.write("\n")
print(json.dumps({"status": value["status"], "current_processes": value["current_processes"], "evidence": reference(out)}, ensure_ascii=False))
