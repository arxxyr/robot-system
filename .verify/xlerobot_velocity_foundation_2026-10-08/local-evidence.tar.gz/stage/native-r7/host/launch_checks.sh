set -eu
export PATH=/home/loosqk/.cargo/bin:/home/loosqk/.local/bin:$PATH
export CARGO_HOME=/home/loosqk/robot-checks/viz-orin-a6957cc-20260930-r1/cargo-home
export CARGO_NET_OFFLINE=true
export RUSTUP_AUTO_INSTALL=0
export PYTHONDONTWRITEBYTECODE=1
cd /home/loosqk/robot-checks/xlerobot-velocity-foundation-20261008-r7/bootstrap
printf '%s\n' 'e77d23b630229beb95a2a0c8e43c4cae9e980a13faada8290f7e9ad401586f29  source-inputs.tar.gz' '6294126f21aca09ccbccdb41042f01a6c439219045a8368e8f3b5181e4116c93  source_export.json' '9761ec5dce8436a98198d399313e3dc576080fc751372a8f611fab9a52f189f8  expected_source.json' '51ac45460000d80b1906e4947a93aaa69677417900d8b010f703267044fa44ad  expected_tests.json' '7e22de24271c20b00ac3be19a7b33b74e3e8002e16e0b9179921afe8ab509c18  run_checks.py' 'dad9bbc9405b8fac4d60d6efe794b36750e6a6f9ce9fdeba3debf7d3e1b9a471  natural_runner.py' 'bd2b3f7bb8527cd9ecec73894171638e9cf378656b89e284a585c3baa37b8731  artifacts.py' '1491c5704f2fe31a25ed21e4de695532b86b5d22b3da37075e7da4e1a475b33a  receive_source.py' | sha256sum -c -
uv run --no-project python receive_source.py
exec taskset -c 0-3 uv run --no-project python run_checks.py
