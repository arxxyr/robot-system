set -eu
export PATH=/home/loosqk/.cargo/bin:/home/loosqk/.local/bin:$PATH
export PYTHONDONTWRITEBYTECODE=1
cd /home/loosqk/robot-checks/xlerobot-velocity-foundation-20261008-r7/bootstrap
printf '%s\n' '3e23b941c16c21ad36d4baea3d967f5f230c10b295fe8cc1c45bbe4d7238a486  collect_native.py' | sha256sum -c -
uv run --no-project python collect_native.py --base /home/loosqk/robot-checks/xlerobot-velocity-foundation-20261008-r7 --out /home/loosqk/robot-checks/xlerobot-velocity-foundation-20261008-r7-native-evidence-resume-r1.tar.gz --collect
