set -eu
export PATH=/home/loosqk/.cargo/bin:/home/loosqk/.local/bin:$PATH
export PYTHONDONTWRITEBYTECODE=1
uv run --no-project python - <<'PY'
import json, os, platform, socket, time
from pathlib import Path
base = Path('/home/loosqk/robot-checks/xlerobot-velocity-foundation-20261008-r7')
identity = {'hostname': socket.gethostname(), 'uid': os.getuid(), 'gid': os.getgid(), 'machine': platform.machine(), 'boot_id': Path('/proc/sys/kernel/random/boot_id').read_text().strip()}
assert identity == {'hostname':'ubuntu','uid':1000,'gid':1000,'machine':'aarch64','boot_id':'6cf7ee3e-a3c5-4c91-80bc-4ca924818b53'}, identity
rows=[]
for entry in sorted(Path('/proc').iterdir(), key=lambda p: int(p.name) if p.name.isdecimal() else 0):
    if not entry.name.isdecimal(): continue
    try:
        argv=(entry/'cmdline').read_bytes().replace(b'\0',b' ').decode(errors='replace')
        cwd=os.readlink(entry/'cwd')
        if str(base) in argv or cwd.startswith(str(base)):
            raw=(entry/'stat').read_text(); tail=raw[raw.rfind(')')+2:].split()
            rows.append({'pid':int(entry.name),'ppid':int(tail[1]),'state':tail[0],'start_ticks':int(tail[19]),'argv':argv,'cwd':cwd})
    except (FileNotFoundError, PermissionError, ProcessLookupError): pass
print(json.dumps({'observed_epoch_ns':time.time_ns(),'identity':identity,'processes':rows},ensure_ascii=False),flush=True)
qa=base/'qa-r7'
for name in ('result.json','progress.json'):
    p=qa/name
    print(json.dumps({'path':str(p),'exists':p.exists(),'value':json.loads(p.read_text()) if p.exists() else None},ensure_ascii=False),flush=True)
for path in sorted(qa.rglob('completion.json')):
    print(json.dumps({'path':str(path),'value':json.loads(path.read_text())},ensure_ascii=False),flush=True)
for path in sorted(qa.rglob('launch.json')):
    if not (path.parent/'completion.json').exists():
        print(json.dumps({'uncompleted_launch':str(path),'value':json.loads(path.read_text())},ensure_ascii=False),flush=True)
PY
