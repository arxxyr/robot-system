"""只读汇总七轮原件；旧本机owner丢失另记UNKNOWN，不伪造wait/reap。"""
import hashlib
import json
import re
from pathlib import Path

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent


def require(ok, message):
    if not ok:
        raise ValueError(message)


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def load(path):
    return json.loads(path.read_text())


def reference(path):
    return {"path": str(path), "sha256": sha(path), "bytes": path.stat().st_size}


iterations = []
direct = []
owners = []
local_owner_unknown = []
git_children = []
for number, expected_status, aggregate in (
    (1, "FAIL", "872bc3494c7e0834c9bf1a8bf03312b1ba1c3098557562d3d47ae46f6718b4ae"),
    (2, "FAIL", "309999d9d79852cd24ba5fa8ee54226d854ee722c6a8949fe0ee87ef401dfd65"),
    (3, "FAIL", "ddbeee4a1d231f752d3dfc1ab07692cbc1ca5d000c2e4fcf65692362e6c70420"),
    (4, "FAIL", "d8699eb6e0e3d8a0031a535b9664255a3c63630215ac9440a308fd3a0198cfc0"),
    (5, "FAIL", "c8e95fbce71b10d141e0f02fd0f99d7d12c844f79649727cd3dbbf0c89135c9b"),
    (6, "FAIL", "c8e95fbce71b10d141e0f02fd0f99d7d12c844f79649727cd3dbbf0c89135c9b"),
    (7, "PASS", load(HERE / "expected_source.json")["source_manifest_sha256"]),
):
    stage = ROOT / f"native-r{number}"
    extracted = stage / "native-extracted"
    remote = Path(f"/home/loosqk/robot-checks/xlerobot-velocity-foundation-{'20261008' if number == 7 else '20261007' if number >= 3 else '20261001'}-r{number}")
    qa = extracted / f"qa-r{number}"
    result = load(qa / "result.json")
    before, after = load(qa / "source_before.json"), load(qa / "source_after.json")
    require(result["status"] == expected_status, "原始结果状态不符")
    require(before == after == load(stage / "expected_source.json"), "源码首末不符")
    require(len(before["files"]) == 590 and before["source_manifest_sha256"] == aggregate,
            "完整输入域不符")
    require(result["source_before_after"] == "PASS", "源后验不符")
    if number == 5:
        require(result.get("compiler_window_error") == "ValueError('工具链窗口不符')" and result.get("compiler_window") is None, "r5原工具链窗口错误必须保留")
        require(result["gates"]["latest_nightly_update"]["status"] == "FAIL" and all(row["status"] == "NOT_RUN" for label, row in result["gates"].items() if label != "latest_nightly_update"), "r5预算失败及后六未运行不符")
    else:
        require(result["compiler_window"] == "PASS", "工具链后验不符")
    require(result["native_git_head"] is None and result["origin"]["main_head"] ==
            "8fb17b153f4eb85cb1b88ca935cc115087784256", "不得伪称原生Git身份")
    for manifest in qa.glob("*_source_*.json"):
        require(load(manifest) == before, "阶段前后源码不符：" + str(manifest))
    for receipt in result["receipts"]:
        path = extracted / Path(receipt["path"]).relative_to(remote)
        require(sha(path) == receipt["sha256"], "completion引用SHA不符")
        row = load(path)
        launch = load(path.parent / "launch.json")
        require(row["reaped"] is True and row["exec_gate_released"] is True,
                "真实执行或回收缺失")
        budget_failed = number == 5 and row["name"] == "latest_nightly_update"
        require(not row["signals"] and row["budget_exceeded"] is budget_failed and
                not row["session_residual_before_cleanup"] and not row["session_residual_after_cleanup"],
                "信号、预算或残留不符")
        for field in ("name", "argv", "cwd", "env", "started_at", "started_monotonic_ns",
                      "timeout_seconds", "deadline_monotonic_ns", "pid", "identity",
                      "stdout", "stderr", "launch_receipt", "completion_receipt",
                      "bootstrap_argv", "bootstrap_sha256", "identity_phase"):
            require(row[field] == launch[field], "启动与完成绑定不符：" + field)
        require(row["identity"]["pid"] == row["pid"] and row["identity"]["start_ticks"] > 0 and
                row["identity"]["boot_id"] == "6cf7ee3e-a3c5-4c91-80bc-4ca924818b53", "PID身份不符")
        for kind in ("stdout", "stderr"):
            log = extracted / Path(row[kind]).relative_to(remote)
            require(sha(log) == row[kind + "_sha256"] and log.stat().st_size == row[kind + "_bytes"],
                    "原始日志身份不符")
        failed = (number == 1 and row["name"] == "clippy_default") or (number == 2 and row["name"] == "s0_default_lib") or (number in (3, 4, 6) and row["name"] == "clippy_default")
        require(row["exit_code"] == (101 if failed else 0), "实际退出码不符")
        if budget_failed:
            require(row["exit_code"] == 0 and row["timeout_seconds"] == 300 and row["elapsed_ns"] > 300 * 1_000_000_000, "r5真实exit0/原预算300与超限不符")
        require(row.get("runner_error") == ("ValueError('原监督预算超限；真实自然wait后FAIL，不重试')" if budget_failed else "ValueError('命令原始退出码非零')" if failed else None),
                "原错误口径不符")
        direct.append({"iteration": number, **row, "local_completion": reference(path)})
    export = load(stage / "source_export.json")
    require(export["source_manifest"] == before, "导出源域不符")
    for row in export["git_children"]:
        require(row["exit_code"] == 0 and row["reaped"] is True, "导出Git child未回收")
        git_children.append({"iteration": number, **row})
    for directory in sorted((stage / "host").glob("*.owner")):
        path = directory / "result.json"
        if number == 7 and directory.name == "checks.owner":
            require(not path.exists(), "不得把原丢失owner回填为已回收")
            observed_path = stage / "host/lost_local_owner_observation_r1.json"
            observed = load(observed_path)
            require(observed["status"] == "LOCAL_OWNER_REAP_UNKNOWN" and observed["current_processes"] == "BOTH_ABSENT", "丢失owner观察口径不符")
            require(observed["original_owner_pid"] == 36112 and observed["original_ssh_pid"] == 36113 and observed["original_wait_returncode"] is None and observed["original_reaped"] is None, "不能由远端回执伪造本机wait/reap")
            child = observed["observation_child"]
            require(child["wait_returncode"] == 1 and child["reaped"] is True and not child["stdout"].strip() and not child["stderr"].strip(), "实际ps旁证不符")
            require(observed["original_files_before"] == observed["original_files_after"] and observed["original_files_unchanged"] is True, "旧回执曾被改写")
            for name, ref in observed["original_files_after"].items():
                require(reference(directory / name) == ref, "旧owner原件与旁证不符:" + name)
            stale = load(directory / "status.json")
            launch = load(directory / "launch.json")
            require(stale["owner_pid"] == launch["owner_pid"] == 36112 and stale["pid"] == launch["pid"] == 36113 and stale["status"] == "RUNNING" and stale["wait_returncode"] is None and stale["reaped"] is False, "旧未完成原件事实不同")
            local_owner_unknown.append({"iteration": 7, "status": "LOCAL_OWNER_REAP_UNKNOWN", "observation": reference(observed_path), "original_launch": reference(directory / "launch.json"), "stale_status": reference(directory / "status.json"), "original_child_log": reference(directory / "child.log"), "original_wait_returncode": None, "original_reaped": None, "not_added_to_reaped_host_owner_count": True})
            continue
        require(path.is_file(), "owner尚未结束：" + str(directory))
        row = load(path)
        require(row["reaped"] is True and not row["owner_sent_signals"] and
                not row["received_signals"] and not row["errors"], "owner回收或信号不符")
        failed = (number in (1, 2, 3, 4, 5, 6) and directory.name == "checks.owner") or (number == 6 and directory.name == "diagnostic_default.owner")
        transport_failed = (number == 2 and directory.name in ("upload_collector.owner", "collect.owner")) or (number == 4 and directory.name == "prepare.owner")
        code = 255 if transport_failed else 1 if failed else 0
        require(row["wait_returncode"] == code, "owner实际wait不符")
        require(row["status"] == ("FAIL" if code else "PASS"), "owner状态不符")
        log = directory / "child.log"
        require(sha(log) == row["log"]["sha256"] and log.stat().st_size == row["log"]["bytes"],
                "owner日志不符")
        owners.append({"iteration": number, **row, "local_result": reference(path)})
    verify = load(stage / "native_archive_verification.json")
    require(verify["status"] == "PASS" and verify["aggregate"] == aggregate, "原件包完整性不符")
    iterations.append({"number": number, "qa_status": expected_status, "aggregate": aggregate,
                       "source_files": 590, "result": reference(qa / "result.json"),
                       "source_before": reference(qa / "source_before.json"),
                       "source_after": reference(qa / "source_after.json"),
                       "archive": reference(stage / "native-evidence.tar.gz"),
                       "index": reference(stage / "native-evidence.index.json"),
                       "metadata": reference(stage / "native-evidence.metadata.json"),
                       "verification": reference(stage / "native_archive_verification.json"),
                       "gates": result["gates"], "compiler": result.get("compiler"), "compiler_before_update": result.get("compiler_before_update"), "rustc_after_raw": reference(qa / "rustc_after/stdout.log"), "compiler_window": result.get("compiler_window"), "compiler_window_error": result.get("compiler_window_error")})

final = load(HERE / "native-extracted/qa-r7/result.json")
tests = final["tests"]
required = set(load(HERE / "expected_tests.json")["library_new_subset"])
require(len(required) == 24, "新增方法集合不是24")
for label, key in (("s0_default_lib", "default_lib"), ("s0_guard_hook_lib", "guard_hook_lib"),
                   ("serial_rt_e2e", "serial_rt_e2e")):
    stdout = (HERE / "native-extracted/qa-r7" / label / "stdout.log").read_text()
    counts = re.findall(r"test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored;", stdout)
    names = re.findall(r"^test ([^ ]+)(?: - should panic)? \.\.\. ok$", stdout, re.M)
    require(len(counts) == 1 and counts[0][1:] == ("0", "0") and
            len(names) == len(set(names)) == int(counts[0][0]) == tests[key]["passed"] and
            names == tests[key]["names"], "实际测试输出与报告不符")
    require(required <= set(names) if key != "serial_rt_e2e" else
            set(names) == set(load(HERE / "expected_tests.json")["serial_rt_e2e_all"]), "测试集合缺失")
union = set(tests["default_lib"]["names"]) | set(tests["guard_hook_lib"]["names"])
require(len(union) == tests["distinct_library_count"] and
        len(union) + 5 == tests["distinct_all_with_serial"], "去重计数不符")
diagnostic_stage = ROOT / "diagnostic-old-rr-r1"
diagnostic_root = diagnostic_stage / "remote-originals/diagnostic-old-rr-r1"
diagnostic = load(diagnostic_root / "result.json")
require(diagnostic["status"] == "PASS_SINGLE_OBSERVATION_NOT_FULL_QA" and diagnostic["actual_test_count"] == 1 and diagnostic["source_and_elf_before_after"] == "PASS", "单项诊断原件不符")
for directory in sorted((diagnostic_stage / "host").glob("*.owner")):
    path = directory / "result.json"
    row = load(path)
    require(row["reaped"] is True and row["wait_returncode"] == 0 and not row["errors"] and not row["owner_sent_signals"] and not row["received_signals"], "诊断owner未回收")
    require(sha(directory / "child.log") == row["log"]["sha256"], "诊断owner日志不符")
    owners.append({"iteration": "separate_old_ELF_diagnostic", **row, "local_result": reference(path)})
keep_stage = ROOT / "native-r6"
keep_extracted = keep_stage / "native-extracted"
keep_root = keep_extracted / "diagnostic-default-keep-going-r1"
keep = load(keep_root / "result.json")
require(keep["status"] == "DIAGNOSTIC_CAPTURE_COMPLETE_NOT_QA_PASS" and keep["not_QA_gate"] is True, "诊断不能成为QA通过")
require(keep["compiler_window"] == keep["source_and_original_QA_unchanged"] == "PASS", "诊断源/工具链窗口不符")
require(keep["original_QA_sha256"] == sha(keep_extracted / "qa-r6/result.json"), "诊断改写原QA")
keep_remote = Path("/home/loosqk/robot-checks/xlerobot-velocity-foundation-20261007-r6")
keep_children = []
require(len(keep["receipts"]) == 5, "诊断不是原五child")
for receipt in keep["receipts"]:
    path = keep_extracted / Path(receipt["path"]).relative_to(keep_remote)
    require(sha(path) == receipt["sha256"], "诊断completion SHA不符")
    row = load(path)
    launch = load(path.parent / "launch.json")
    for field in ("name", "argv", "cwd", "env", "started_at", "started_monotonic_ns", "timeout_seconds", "deadline_monotonic_ns", "pid", "identity", "stdout", "stderr", "launch_receipt", "completion_receipt", "bootstrap_argv", "bootstrap_sha256", "identity_phase"):
        require(row[field] == launch[field], "诊断启动/完成不符:" + field)
    failed = row["name"] == "clippy_default_keep_going"
    require(row["exit_code"] == (101 if failed else 0) and row.get("runner_error") == ("ValueError('命令原始退出码非零')" if failed else None), "诊断原退出/错误不符")
    require(row["reaped"] is True and row["exec_gate_released"] is True and not row["signals"] and not row["budget_exceeded"] and not row["session_residual_before_cleanup"] and not row["session_residual_after_cleanup"], "诊断真实wait/预算不符")
    require(row["identity"]["pid"] == row["pid"] and row["identity"]["start_ticks"] > 0 and row["identity"]["boot_id"] == "6cf7ee3e-a3c5-4c91-80bc-4ca924818b53", "诊断PID身份不符")
    for kind in ("stdout", "stderr"):
        log = keep_extracted / Path(row[kind]).relative_to(keep_remote)
        require(sha(log) == row[kind + "_sha256"] and log.stat().st_size == row[kind + "_bytes"], "诊断日志不符")
    keep_children.append({**row, "local_completion": reference(path)})
require(load(keep_root / "source_before.json") == load(keep_root / "source_after.json") == load(keep_stage / "expected_source.json"), "诊断590前后不符")
require(keep["argv"] == ["cargo", "clippy", "--locked", "--all", "--all-targets", "--keep-going", "--", "-D", "warnings"], "诊断指令改变")
main_owners = []
for label in ("main_rustc_r7", "main_cargo_r7", "main_fmt_r7"):
    directory = ROOT / (label + ".owner")
    row = load(directory / "result.json")
    require(row["wait_returncode"] == 0 and row["reaped"] is True and not row["errors"] and not row["owner_sent_signals"] and not row["received_signals"], "main真实child未回收")
    require(sha(directory / "child.log") == row["log"]["sha256"], "main身份日志不符")
    main_owners.append({**row, "local_result": reference(directory / "result.json")})
summary = {
    "schema": "XLEROBOT_VELOCITY_FOUNDATION_ORIN_EVIDENCE_SUMMARY_V1",
    "status": "PASS_SOFTWARE_CANDIDATE_WITH_PRIOR_FAIL_PRESERVED",
    "deployable": False, "not_full_B1": True, "native_git_head": None,
    "scope": "速度入站及SerialTick基础软件；不代表硬件、全workspace、release或完整B1验收。",
    "iterations": iterations, "tests": tests, "separate_diagnostic": diagnostic,
    "separate_diagnostic_result": reference(diagnostic_root / "result.json"),
    "separate_diagnostic_not_added_to_test_count": True,
    "separate_keepgoing_diagnostic": keep, "separate_keepgoing_result": reference(keep_root / "result.json"), "separate_keepgoing_children": keep_children, "separate_keepgoing_direct_child_count": len(keep_children), "main_preparation_owners": main_owners,
    "formal_QA_direct_count_excludes_separate_diagnostics": True,
    "direct_child_count": len(direct), "direct_children": direct,
    "host_owner_count": len(owners), "host_owners": owners, "lost_local_owner_count": len(local_owner_unknown), "lost_local_owners": local_owner_unknown, "local_original_qa_owner_reap_verified": False,
    "export_git_child_count": len(git_children), "export_git_children": git_children,
    "prior_failure": "r1默认Clippy101；r2默认lib640PASS/1旧RR timeoutFAIL；r3logging doc lint101；r4RPC test模块位置lint101；r5更新自然exit0但3393.452秒超原300秒预算FAIL及原compiler_window_error，后六门NOT_RUN；r6serial_services test模块位置lint101、后四门NOT_RUN、独立默认keep-going101。全部失败、未运行和网络255保留。r2旧ELF精确单项PASS仅一次观察，原超时根因仍UNCONFIRMED。r7仅原serial_services test模块逐字移EOF，不改生产、两个原测试或预算。",
    "obsolete_unexecuted_helpers": [reference(ROOT / ("native-r" + str(number)) / "summarize_evidence.py") for number in (2, 3, 4, 5)],
    "obsolete_helper_note": "早轮为后续预备的摘要脚本未运行；其未来PASS假设不代表任何旧原件结果。唯一阶段事实以逐轮qa/result和实际回执为准。",
    "never_executed": ["UART", "硬件GO", "daemon/service启动", "正式安装", "release", "完整workspace", "push"],
}
with (HERE / "summary_resume_r2.json").open("x") as stream:
    json.dump(summary, stream, ensure_ascii=False, indent=2)
    stream.write("\n")
print(json.dumps({"status": summary["status"], "summary": reference(HERE / "summary_resume_r2.json"),
                  "direct_children": len(direct), "host_owners": len(owners),
                  "export_git_children": len(git_children),
                  "distinct_tests": tests["distinct_all_with_serial"]}, ensure_ascii=False))
