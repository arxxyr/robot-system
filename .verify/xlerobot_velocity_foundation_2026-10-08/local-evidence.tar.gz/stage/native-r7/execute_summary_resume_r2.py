"""独立拥有摘要审计子进程，保存真实 wait 与原始输出；不是 QA 重跑。"""
import datetime
import hashlib
import json
from pathlib import Path
import subprocess
import time

base = Path(__file__).resolve().parent
out = base / "audit-resume-r2"
out.mkdir()
argv = ["uv", "run", "--no-project", "python", str(base / "summarize_evidence_resume_r2.py")]
start = time.monotonic_ns()
child = subprocess.Popen(argv, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
stdout, stderr = child.communicate()
code = child.wait()
for name, raw in (("stdout.log", stdout), ("stderr.log", stderr)):
    with (out / name).open("xb") as stream:
        stream.write(raw)
value = {"scope": "只读摘要审计，不是 QA 新一轮", "argv": argv, "pid": child.pid, "wait_returncode": code, "reaped": True, "elapsed_ns": time.monotonic_ns() - start, "finished_at": datetime.datetime.now(datetime.timezone.utc).isoformat(), "signals_sent": [],
         "stdout": {"sha256": hashlib.sha256(stdout).hexdigest(), "bytes": len(stdout)}, "stderr": {"sha256": hashlib.sha256(stderr).hexdigest(), "bytes": len(stderr)}}
with (out / "completion.json").open("x") as stream:
    json.dump(value, stream, ensure_ascii=False, indent=2)
    stream.write("\n")
print(stdout.decode(), end="")
print(stderr.decode(), end="")
print(json.dumps(value, ensure_ascii=False))
raise SystemExit(code)
