set -eu
export PATH=/home/loosqk/.cargo/bin:/home/loosqk/.local/bin:$PATH
export CARGO_HOME=/home/loosqk/robot-checks/viz-orin-a6957cc-20260930-r1/cargo-home
export CARGO_NET_OFFLINE=true
export RUSTUP_AUTO_INSTALL=0
export PYTHONDONTWRITEBYTECODE=1
cd /home/loosqk/robot-checks/xlerobot-velocity-foundation-20261007-r6/bootstrap
printf '%s\n' '930a854037da2a1de622cd7aaa1c1de06fcb45da8ca3fa96310a4c256515cc25  diagnostic_keepgoing_default.py' | sha256sum -c -
exec taskset -c 0-3 uv run --no-project python diagnostic_keepgoing_default.py
