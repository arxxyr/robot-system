set -eu
export PATH=/home/loosqk/.cargo/bin:/home/loosqk/.local/bin:$PATH
export PYTHONDONTWRITEBYTECODE=1
cd /home/loosqk/robot-checks/xlerobot-velocity-foundation-20261007-r6/bootstrap
printf '%s\n' '6851a49ac04bcaa0f37cf01dfca3fed99867a73dfb0494ac82bda659ca9d83c2  collect_native.py' | sha256sum -c -
exec uv run --no-project python collect_native.py --collect --base /home/loosqk/robot-checks/xlerobot-velocity-foundation-20261007-r6 --out /home/loosqk/robot-checks/xlerobot-velocity-foundation-20261007-r6-native-evidence.tar.gz
