set -eu
export PATH=/home/loosqk/.cargo/bin:/home/loosqk/.local/bin:$PATH
export CARGO_HOME=/home/loosqk/robot-checks/viz-orin-a6957cc-20260930-r1/cargo-home
export CARGO_NET_OFFLINE=true
export RUSTUP_AUTO_INSTALL=0
export PYTHONDONTWRITEBYTECODE=1
cd /home/loosqk/robot-checks/xlerobot-velocity-foundation-20261007-r6/bootstrap
printf '%s\n' 'e0fa599ab3c06a69ebeef14c1b129d04950684fc6038f97c5be2e990d588be15  source-inputs.tar.gz' '1a3a7533f636fbe030a854f763c9423bf5a3a80d0a5f76f795a4b0ab8a893839  source_export.json' '89861e67e393d04d64489d365efe9511c9255ac142c64dd7e5e1c8a192938c23  expected_source.json' '51ac45460000d80b1906e4947a93aaa69677417900d8b010f703267044fa44ad  expected_tests.json' '889b7922e3a553d27f1bdc9ac1b99ee33fc7d42ccab743855c3a2c0045700803  run_checks.py' 'dad9bbc9405b8fac4d60d6efe794b36750e6a6f9ce9fdeba3debf7d3e1b9a471  natural_runner.py' 'bd2b3f7bb8527cd9ecec73894171638e9cf378656b89e284a585c3baa37b8731  artifacts.py' 'e6067b2e510cca1b4aec3f59a58e77168714cf537295bb09ea0dad704dcfa1a2  receive_source.py' | sha256sum -c -
uv run --no-project python receive_source.py
exec taskset -c 0-3 uv run --no-project python run_checks.py
