set -eu
export PATH=/home/loosqk/.cargo/bin:/home/loosqk/.local/bin:$PATH
export CARGO_HOME=/home/loosqk/robot-checks/viz-orin-a6957cc-20260930-r1/cargo-home
export CARGO_NET_OFFLINE=true
export RUSTUP_AUTO_INSTALL=0
export PYTHONDONTWRITEBYTECODE=1
cd /home/loosqk/robot-checks/xlerobot-velocity-foundation-20261008-r7/bootstrap
printf '%s\n' 'ca7f4f03899ee608cdc96c6aa116fc0796081f8ba3ac41fc91b3297080296d34  precommit_run_r1.py' | sha256sum -c -
exec taskset -c 0-3 uv run --no-project python precommit_run_r1.py
