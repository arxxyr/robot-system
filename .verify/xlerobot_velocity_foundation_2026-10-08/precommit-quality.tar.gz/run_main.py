"""提交前本机顺序门；不更新工具链，不运行硬件或 Clippy。"""
import datetime
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import subprocess
import sys

ROOT = Path('/Users/loosqk/repo/rust/robot-system')
OUT = Path(__file__).resolve().parent
EXPECTED_HASH = '1d81eb4ad9cd207e3e638bd32b17ec4fce8412a6'


def save(path, value):
    with path.open('x') as stream:
        json.dump(value, stream, ensure_ascii=False, indent=2)
        stream.write('\n')


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def owned(label, argv):
    command = [sys.executable, str(OUT / 'host_owner.py'), '--label', label, '--', *argv]
    with (OUT / (label + '.wrapper.stdout.log')).open('xb') as stdout, (OUT / (label + '.wrapper.stderr.log')).open('xb') as stderr:
        child = subprocess.Popen(command, cwd=ROOT, env={**os.environ, 'RUSTUP_TOOLCHAIN': 'nightly'}, stdout=stdout, stderr=stderr)
        code = child.wait()
    wrapper = {'argv': command, 'pid': child.pid, 'wait_returncode': code, 'reaped': True, 'signals_sent': []}
    save(OUT / (label + '.wrapper.completion.json'), wrapper)
    row = json.loads((OUT / (label + '.owner/result.json')).read_text())
    assert code == row['wait_returncode'] == 0 and row['reaped'] is True and not row['errors'] and not row['owner_sent_signals'] and not row['received_signals'], label
    log = OUT / (label + '.owner/child.log')
    assert sha(log) == row['log']['sha256'] and log.stat().st_size == row['log']['bytes']
    return row, log.read_bytes()


spec = importlib.util.spec_from_file_location('artifacts', ROOT / 'target/xlerobot_velocity_foundation/native-r7/artifacts.py')
artifacts = importlib.util.module_from_spec(spec)
spec.loader.exec_module(artifacts)
assert sha(ROOT / 'target/xlerobot_velocity_foundation/native-r7/artifacts.py') == 'bd2b3f7bb8527cd9ecec73894171638e9cf378656b89e284a585c3baa37b8731'
assert sha(OUT / 'host_owner.py') == '96d1c8ed14fa94e62cbfcb0ea28ff60f628bdcf0d76cf3796d968602ce14938a'
expected = json.loads((ROOT / 'target/xlerobot_velocity_foundation/expected_source_r7.json').read_text())


def source(label):
    _, raw = owned(label + '_inventory', ['git', 'ls-files', '-z', '--cached', '--others', '--exclude-standard'])
    names = raw.decode().rstrip('\0').split('\0')
    value = artifacts.snapshot_source(ROOT, names)
    assert value == expected and len(value['files']) == 590
    save(OUT / (label + '.json'), value)
    return value


def rustc(label):
    _, raw = owned(label, ['/Users/loosqk/.cargo/bin/rustc', '-vV'])
    fields = {}
    for line in raw.decode().splitlines():
        if ': ' in line:
            key, value = line.split(': ', 1)
            assert key not in fields
            fields[key] = value
    assert fields['commit-hash'] == EXPECTED_HASH and fields['release'].endswith('-nightly') and fields['host'] == 'aarch64-apple-darwin'
    return fields


result = {'schema': 'XLEROBOT_MAIN_PRECOMMIT_FMT_V1', 'status': 'FAIL', 'commands': [],
          'scope': '仅本机原生fmt及源码/实际编译器前后绑定；不是根Clippy或硬件验证。',
          'toolchain_update': 'NOT_RUN;用户已更新最新，核实际已安装1d81身份。'}
try:
    before = source('main_source_before')
    compiler_before = rustc('main_rustc_before')
    _, cargo_before = owned('main_cargo_before', ['/Users/loosqk/.cargo/bin/cargo', '-V'])
    fmt, _ = owned('main_fmt', ['/Users/loosqk/.cargo/bin/cargo', 'fmt', '--all'])
    compiler_after = rustc('main_rustc_after')
    _, cargo_after = owned('main_cargo_after', ['/Users/loosqk/.cargo/bin/cargo', '-V'])
    after = source('main_source_after')
    assert before == after and compiler_before == compiler_after and cargo_before == cargo_after
    result.update(status='PASS', source_files=590, aggregate=before['source_manifest_sha256'],
                  source_before_after='PASS', compiler_before=compiler_before, compiler_after=compiler_after,
                  compiler_window='PASS', cargo_before=cargo_before.decode(), cargo_after=cargo_after.decode(),
                  fmt_owner=fmt, six_sources_unchanged=True)
except BaseException as error:
    result['error'] = repr(error)
finally:
    result['finished_at'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
    save(OUT / 'main_result.json', result)
print(json.dumps({'status': result['status'], 'source_files': result.get('source_files'), 'aggregate': result.get('aggregate'), 'error': result.get('error')}, ensure_ascii=False), flush=True)
raise SystemExit(0 if result['status'] == 'PASS' else 1)
