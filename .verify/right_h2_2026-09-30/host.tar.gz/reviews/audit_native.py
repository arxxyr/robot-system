"""独立核原件与新冻结件；仅本地读取，不执行成员或硬件。"""

import argparse
from collections import Counter
import datetime
import hashlib
import json
from pathlib import Path
import re
import stat
import tomllib


BASE = Path('/home/loosqk/robot-checks/h2-serial-recovery-20260930-r1')
HEAD = 'b01603b56117a35279407de0c201bcd91bb6e5b2'
SOURCE_SHA = 'c03888074cbd4005837bc0291aafdf72fff4a59f473d75f52298b1da42182a96'
COMPILER = '5c543b0b8c73c7b72bc8284ced4fb22ead15734d'
SPECS = {
    'production': {
        's0': ('robot-s0', ['s0_daemon', 'xlerobot_deploy'], ['--features', 'xlerobot-real'], ['default', 'feetech', 'mock', 'xlerobot', 'xlerobot-real']),
        's1': ('robot-s1', ['s1_daemon'], [], ['backend-hold-pose', 'backend-ik', 'backend-mock-dwell', 'backend-scripted', 'default']),
        'gateway': ('robot-rpc', ['robot_rpc_gateway'], ['--no-default-features'], []),
    },
    'measurement': {
        's0': ('robot-s0', ['s0_daemon'], ['--no-default-features', '--features', 'xlerobot-real,rt_guard,test-comm-fault-hook'], ['feetech', 'mock', 'rt_guard', 'test-comm-fault-hook', 'xlerobot', 'xlerobot-real']),
        'gateway': ('robot-rpc', ['robot_rpc_gateway'], ['--no-default-features', '--features', 'test-comm-fault-hook'], ['test-comm-fault-hook']),
        'tool': ('robot-tests', ['comm_fault_e2e'], ['--no-default-features', '--features', 'comm-fault-e2e,real-hw'], ['comm-fault-e2e', 'comm-fault-rpc', 'real-hw']),
    },
}


def strict(raw):
    def pairs(items):
        value = {}
        for key, item in items:
            assert key not in value
            value[key] = item
        return value
    return json.loads(raw, object_pairs_hook=pairs, parse_constant=lambda value: (_ for _ in ()).throw(ValueError(value)))


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


class Audit:
    def __init__(self, directory, fresh):
        self.directory, self.fresh = directory, strict(fresh.read_bytes())
        self.inputs, self.receipts = {}, {}

    def local(self, remote):
        path = Path(remote)
        assert path.is_absolute() and '..' not in path.parts and path.is_relative_to(BASE)
        return self.directory / path.relative_to(BASE)

    def read(self, remote):
        path = self.local(remote)
        assert stat.S_ISREG(path.lstat().st_mode)
        raw = path.read_bytes()
        self.inputs[str(path)] = {'path': str(path), 'sha256': sha(raw), 'bytes': len(raw)}
        return raw

    def value(self, remote):
        return strict(self.read(remote))

    def pinned(self, ref):
        raw = self.read(ref['path'])
        assert sha(raw) == ref['sha256']
        return strict(raw)

    def completion(self, ref):
        row = self.pinned(ref)
        assert row['completion_receipt'] == ref['path']
        assert 'runner_error' not in row and row['exit_code'] == 0 and row['reaped'] is True and row['signals'] == []
        assert row['session_residual_before_cleanup'] == row['session_residual_after_cleanup'] == []
        assert row.get('exec_gate_released') is True
        launch = self.value(row['launch_receipt'])
        for key in ('name', 'argv', 'cwd', 'env', 'removed_env_keys', 'started_at', 'started_monotonic_ns', 'timeout_seconds', 'stdout', 'stderr', 'launch_receipt', 'completion_receipt', 'pid', 'identity', 'bootstrap_argv', 'bootstrap_sha256', 'identity_phase', 'argv_semantics'):
            assert row[key] == launch[key], key
        assert launch['exit_code'] is None and launch['reaped'] is False and launch['signals'] == []
        identity = row['identity']
        assert row['pid'] == identity['pid'] == identity['sid'] and identity['start_ticks'] > 0
        assert identity['boot_id'] == self.fresh['boot_id']
        assert row['identity_phase'] == 'bootstrap' and Path(identity['exe']).is_absolute()
        assert row['ended_monotonic_ns'] >= row['started_monotonic_ns'] > 0
        for key in ('stdout', 'stderr'):
            raw = self.read(row[key])
            assert len(raw) == row[key + '_bytes'] and sha(raw) == row[key + '_sha256']
        self.receipts[ref['path']] = {'path': ref['path'], 'sha256': ref['sha256'], 'name': row['name'], 'pid': row['pid'], 'exit_code': 0, 'reaped': True}
        return row

    def compiler(self, row):
        assert row['argv'] == ['rustc', '-vV']
        text = self.read(row['stdout']).decode()
        assert 'commit-hash: ' + COMPILER + '\n' in text
        assert 'host: aarch64-unknown-linux-gnu\n' in text and 'release: 1.101.0-nightly\n' in text

    def elf(self, item, fresh=None):
        raw = self.read(item['path'])
        assert len(raw) == item['bytes'] and sha(raw) == item['sha256']
        assert raw[:6] == b'\x7fELF\x02\x01' and int.from_bytes(raw[18:20], 'little') == item['elf_machine'] == 183
        assert int.from_bytes(raw[16:18], 'little') in (2, 3)
        fresh = fresh or self.fresh['actual_frozen'][item['path']]
        for key in ('sha256', 'bytes', 'mode'):
            assert item[key] == fresh[key]
        assert fresh['nlink'] == 1 and fresh['mode'] & stat.S_IXUSR
        assert fresh['elf_header_hex'] == raw[:64].hex()
        return fresh

    def run(self):
        release = BASE / 'release-r1'
        result = self.value(release / 'result.json')
        assert result['status'] == result['source_after'] == result['isolation_after'] == 'PASS'
        assert result['interrupted_signal'] is None and result['deployable'] is False
        assert result['runner_sha256'] == sha(self.read(BASE / 'bootstrap/run_release_v2.py'))
        source = self.value(release / 'source_before.json')
        assert source == self.value(release / 'source_after.json')
        assert source['source_manifest_sha256'] == SOURCE_SHA and len(source['files']) == 589
        canonical = json.dumps(source['files'], sort_keys=True, separators=(',', ':'), ensure_ascii=False, allow_nan=False).encode()
        assert sha(canonical) == SOURCE_SHA and source['files'] == self.fresh['source_actual']
        assert self.fresh['git']['head']['stdout'].strip() == HEAD and self.fresh['git']['status']['stdout'] == ''
        assert all(row['wait_returncode'] == 0 and row['reaped'] for row in self.fresh['git'].values())
        names = self.fresh['git']['inventory']['stdout'].rstrip('\0').split('\0')
        assert len(names) == len(set(names))
        assert {n for n in names if any(n == d or n.startswith(d + '/') for d in source['domains'])} == set(source['files'])
        manifests, recipes, frozen = {}, [], []
        for kind in ('production', 'measurement'):
            manifest = self.pinned(result['artifacts'][kind])
            manifests[kind] = manifest
            assert manifest['schema'] == 'P7_RELEASE_ARTIFACTS_V2' and manifest['kind'] == kind
            assert manifest['build_head'] == HEAD and manifest['build_root'] == str(BASE / 'source')
            assert manifest['deployable'] is False and manifest['toolchain'] == 'nightly' and manifest['machine'] == 183
            assert manifest['rustc_identity'] == {'release': '1.101.0-nightly', 'commit_hash': COMPILER, 'host': 'aarch64-unknown-linux-gnu'}
            assert manifest['source_manifest_sha256'] == SOURCE_SHA and self.pinned(manifest['source_manifest']) == source
            assert manifest['artifact_directory'] == str(release / kind)
            assert set(manifest['builds']) == set(SPECS[kind])
            assert set(manifest['artifacts']) == {name for _, names, _, _ in SPECS[kind].values() for name in names}
            before, after = [self.completion(manifest[key]) for key in ('rustc_before', 'rustc_after')]
            self.compiler(before); self.compiler(after)
            assert before['env'] == after['env'] and before['ended_monotonic_ns'] <= after['started_monotonic_ns']
            env = before['env']
            assert set(env) == {'RUSTUP_TOOLCHAIN', 'RUSTC_WRAPPER', 'CARGO_BUILD_JOBS', 'CARGO_TERM_COLOR', 'CARGO_TARGET_DIR', 'PATH'}
            assert env['RUSTUP_TOOLCHAIN'] == 'nightly' and env['RUSTC_WRAPPER'] == '' and env['CARGO_BUILD_JOBS'] == '2'
            for build, (package, names, options, features) in SPECS[kind].items():
                row = self.completion(manifest['builds'][build])
                argv = ['cargo', 'build', '--locked', '--release', '--message-format=json', '-p', package]
                for name in names:
                    argv += ['--bin', name]
                assert row['argv'] == argv + options and row['env'] == env and row['cwd'] == str(BASE / 'source')
                assert before['ended_monotonic_ns'] <= row['started_monotonic_ns'] <= row['ended_monotonic_ns'] <= after['started_monotonic_ns']
                records = [strict(line) for line in self.read(row['stdout']).splitlines() if line.strip()]
                assert [r for r in records if r['reason'] == 'build-finished'] == [{'reason': 'build-finished', 'success': True}]
                artifacts = [r for r in records if r['reason'] == 'compiler-artifact']
                if kind == 'production':
                    assert not any(f.startswith('test-') for r in artifacts for f in r['features'])
                for name in names:
                    matches = [r for r in artifacts if r['target']['name'] == name and r['target']['kind'] == ['bin'] and r.get('executable')]
                    assert len(matches) == 1
                    actual, item = matches[0], manifest['artifacts'][name]
                    assert sorted(actual['features']) == sorted(features)
                    profile = actual['profile']
                    assert profile['opt_level'] == '3' and profile['test'] is False and profile['debug_assertions'] is False and profile['overflow_checks'] is False and profile['debuginfo'] in (None, 0)
                    assert item['compiler_artifact'] == actual and item['features'] == actual['features']
                    assert item['command'] == row['argv'] and item['cargo_path'] == actual['executable']
                    assert item['path'] == str(release / kind / name) and item['build_head'] == HEAD and item['source_manifest_sha256'] == SOURCE_SHA
                    assert item['profile'] == 'release' and item['exit_code'] == 0
                    assert self.pinned(item['sidecar']) == {k: v for k, v in item.items() if k != 'sidecar'}
                    frozen.append({'kind': kind, 'name': name, **self.elf(item)})
                recipes.append({'kind': kind, 'build': build, 'argv': row['argv'], 'features': features, 'cargo_records': len(records), 'exit_code': 0, 'reaped': True})
        assert len(frozen) == 7 and len({(r['device'], r['inode']) for r in frozen}) == 7
        for key in ('rustc_before', 'rustc_after', 'rustc_identity'):
            assert manifests['production'][key] == manifests['measurement'][key]
        for ref in result['receipts']:
            self.completion(ref)
        by_name = {self.completion(ref)['name']: self.completion(ref) for ref in result['receipts']}
        assert by_name['fmt']['argv'] == ['cargo', 'fmt', '--all']
        assert by_name['clippy']['argv'] == ['cargo', 'clippy', '--locked', '--all', '--all-targets', '--', '-D', 'warnings']
        assert re.search(rb'Ran 71 tests', self.read(by_name['python_tests']['stderr']))
        assert strict(self.read(by_name['default_plan']['stdout']))['mode'] == 'PLAN_ONLY'
        isolation = self.value(release / 'isolation_before.json')['installed']
        assert isolation == self.value(release / 'isolation_after.json')['installed']
        for row in isolation:
            name = Path(row['path']).name
            fresh = self.fresh['formal_actual'][name]
            assert all(row[key] == fresh[key] for key in ('sha256', 'bytes', 'mode', 'device', 'inode'))
        update = self.read(BASE / 'bootstrap/update-nightly.log').decode()
        assert 'unchanged - rustc 1.101.0-nightly (5c543b0b8 2026-09-29)' in update
        assert 'commit-hash: ' + COMPILER in self.read(BASE / 'bootstrap/nightly_after.txt').decode()
        assert re.search(r'^cargo [0-9.]+-nightly \([0-9a-f]+ [0-9-]+\)', self.read(BASE / 'bootstrap/cargo_after.txt').decode())
        post = self.post(manifests, source)
        read_tool = self.read_tool(manifests, source)
        return {'status': 'PASS', 'build_head': HEAD, 'source_files': 589, 'source_manifest_sha256': SOURCE_SHA, 'compiler_commit': COMPILER, 'recipes': recipes, 'frozen': frozen, 'postchecks': post, 'read_tool': read_tool, 'natural_completed_commands': list(self.receipts.values()), 'input_index': list(self.inputs.values()), 'scope': '本轮新V2release/postchecks/readback-tool原件、fresh只读源/冻结ELF/正式四件；正式服务后验另审。', 'blocking_findings': []}

    def post(self, manifests, source):
        folder = BASE / 'post-release-r1'
        result = self.value(folder / 'post_release_result.json')
        assert result['status'] == result['source_after'] == result['identities_after'] == 'PASS'
        assert result['deployable'] is False
        assert result['helper_sha256'] == sha(self.read(BASE / 'bootstrap/run_release_v2.py'))
        assert result['self_sha256'] == sha(self.read(BASE / 'bootstrap/post_release_checks.py'))
        assert result['release_result_sha256'] == sha(self.read(BASE / 'release-r1/result.json'))
        assert self.value(folder / 'source_before.json') == self.value(folder / 'source_after.json') == source
        assert self.value(folder / 'identities_before.json') == self.value(folder / 'identities_after.json')
        rows = {self.completion(ref)['name']: self.completion(ref) for ref in result['receipts']}
        self.compiler(rows['rustc_before']); self.compiler(rows['rustc_after'])
        helps = []
        for kind, manifest in manifests.items():
            for name, item in manifest['artifacts'].items():
                key = 'help_' + kind + '_' + name
                row = rows[key]
                assert row['argv'] == [item['path'], '--help']
                assert row['stdout_bytes'] + row['stderr_bytes'] > 0
                helps.append(key)
        assert len(helps) == 7
        mock_root = folder / 'mock_ac12'
        report = self.value(mock_root / 'report.json')
        assert sha(self.read(mock_root / 'report.json')) == result['mock_report_sha256']
        assert report['status'] == 'PASS' and report['invocation']['phase'] == 'Mock' and report['invocation']['case_filter'] == 'AC-12'
        assert report['invocation']['config'] is None and report['invocation']['hardware_id'] is None
        assert report['invocation']['current_exe_sha256'] == manifests['measurement']['artifacts']['comm_fault_e2e']['sha256']
        assert report['hardware'] == {'H1': 'NEEDS_HUMAN', 'H2': 'NEEDS_HUMAN', 'H3': 'NEEDS_HUMAN', 'D15': 'OPEN'}
        assert len(report['cases']) == 1 and report['cases'][0]['case'] == 'runtime_estop_sampling_and_recovery' and report['cases'][0]['status'] == 'PASS'
        data = report['cases'][0]['evidence']
        measurement, environment = data['measurement'], data['environment']
        assert environment['physical_uart'] is False and environment['runtime_only'] is True and environment['mock_lease'] is True
        assert measurement['trace_dropped'] == 0 and measurement['runtime_only'] is True and measurement['hardware_only'] is False
        groups = measurement['groups']
        assert len(groups) == 8 and Counter((r['external'], r['in_flight']) for r in groups) == Counter({(False, False): 2, (False, True): 2, (True, False): 2, (True, True): 2})
        assert all(r['matched'] and r['mock_lease'] and r['real_rpc_recovery_verified'] and r['requested_in_flight'] == r['in_flight'] for r in groups)
        assert data['final_state']['ok'] and data['final_trace']['valid'] and data['final_trace']['children_stopped']
        probe = mock_root / '000_runtime_sla_probe'
        assert self.value(probe / 'environment.json') == environment
        assert self.value(probe / 'final_stop.json') == data['final_state'] and self.value(probe / 'final_trace.json') == data['final_trace']
        config = tomllib.loads(self.read(probe / 'robot.toml').decode())
        assert len(config['hardware']) == 1 and config['hardware'][0]['adapter'] == 'mock_serial_rt' and config['hardware'][0]['auto_enable'] is False and 'address' not in config['hardware'][0]
        stdout = self.read(rows['final_stop_transport']['stdout']).decode()
        assert re.findall(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored;', stdout) == [('6', '0', '0')]
        scenes = []
        for line in stdout.splitlines():
            start = line.find('{')
            if start >= 0:
                try:
                    row = strict(line[start:])
                except ValueError:
                    continue
                if 'server_joined' in row:
                    scenes.append(row)
        assert scenes == self.value(folder / 'loopback_scenes.json') and len(scenes) == 9
        assert all(r['server_joined'] and r['active_requests'] == 0 for r in scenes)
        assert Counter(r['reply'] for r in scenes) == Counter({'Ack': 5, 'Error': 1, 'WrongIdentity': 1, 'DryRun': 1, 'ZeroTimestamp': 1})
        successes = [r for r in scenes if r['evidence']['ok']]
        assert len(successes) == 1 and successes[0]['delay_ms'] == 2100 and successes[0]['ordinary'] is False and successes[0]['server_reply_elapsed_ns'] >= 2_100_000_000
        timeouts = [r for r in scenes if r['evidence']['disable'].get('message') == 'Timeout expired']
        assert len(timeouts) == 2 and {(r['ordinary'], r['delay_ms']) for r in timeouts} == {(True, 2100), (False, 3300)}
        return {'help': 7, 'mock_groups': 4, 'mock_samples': 8, 'tonic_tests': 6, 'tonic_scenes': 9, 'physical_uart': False, 'all_scene_servers_joined': True}

    def read_tool(self, manifests, source):
        folder = BASE / 'readback-tool-r1'
        result = self.value(folder / 'result.json')
        assert result['status'] == 'PASS' and result['build_head'] == HEAD and result['source_manifest_sha256'] == SOURCE_SHA
        assert self.value(folder / 'source_before.json') == self.value(folder / 'source_after.json') == source
        assert result['rustc_identity'] == manifests['production']['rustc_identity']
        rows = {self.completion(ref)['name']: self.completion(ref) for ref in result['receipts']}
        self.compiler(rows['rustc_before']); self.compiler(rows['rustc_after'])
        build = self.completion(result['build_receipt'])
        assert build['argv'] == ['cargo', 'build', '--locked', '--release', '-p', 'robot-adapter-feetech', '--features', 'real-hw', '--example', 'feetech_poke', '--message-format=json']
        records = [strict(line) for line in self.read(build['stdout']).splitlines() if line.strip()]
        assert [r for r in records if r['reason'] == 'build-finished'] == [{'reason': 'build-finished', 'success': True}]
        matches = [r for r in records if r['reason'] == 'compiler-artifact' and r['target']['name'] == 'feetech_poke' and r.get('executable')]
        assert matches == [result['cargo_artifact']]
        artifact = matches[0]
        assert artifact['target']['kind'] == ['example'] and 'real-hw' in artifact['features'] and not any(f.startswith('test-') for f in artifact['features'])
        profile = artifact['profile']
        assert profile['opt_level'] == '3' and profile['test'] is False and profile['debug_assertions'] is False and profile['overflow_checks'] is False and profile['debuginfo'] in (None, 0)
        self.elf(result['artifact'], self.fresh['read_tool_actual'])
        return {'status': 'PASS', 'artifact': result['artifact'], 'features': artifact['features'], 'profile': profile, 'executed': False}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--directory', type=Path, required=True)
    parser.add_argument('--fresh', type=Path, required=True)
    parser.add_argument('--report', type=Path, required=True)
    args = parser.parse_args()
    try:
        result = Audit(args.directory, args.fresh).run()
    except Exception as error:
        result = {'status': 'FAIL', 'blocking_findings': [repr(error)]}
    result['reviewer_script_sha256'] = sha(Path(__file__).read_bytes())
    with args.report.open('x') as stream:
        json.dump(result, stream, ensure_ascii=False, indent=2)
        stream.write('\n')
    print(json.dumps({'status': result['status'], 'report': str(args.report), 'sha256': sha(args.report.read_bytes()), 'blocking_findings': result['blocking_findings']}, ensure_ascii=False))
    return 0 if result['status'] == 'PASS' else 1


if __name__ == '__main__':
    raise SystemExit(main())
