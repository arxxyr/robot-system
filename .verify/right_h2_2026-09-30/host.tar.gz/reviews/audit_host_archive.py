"""本机证据包独审：仅流式读包，不解压或执行成员。"""
import argparse
import gzip
import hashlib
import json
from pathlib import Path, PurePosixPath
import tarfile


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def state(path):
    row = path.stat()
    return (row.st_dev, row.st_ino, row.st_size, row.st_mtime_ns, row.st_ctime_ns)


def verify(archive, index_path, metadata_path):
    paths = (archive, index_path, metadata_path)
    before = {str(p): state(p) for p in paths}
    index_raw = index_path.read_bytes()
    index, metadata = json.loads(index_raw), json.loads(metadata_path.read_bytes())
    assert metadata['status'] == 'PASS' and metadata['archive_sha256'] == sha(archive)
    assert metadata['archive_bytes'] == archive.stat().st_size and metadata['index_sha256'] == sha(index_path)
    assert metadata['indexed_files'] == len(index)
    rows = {row['path']: row for row in index}
    assert len(rows) == len(index)
    for name, row in rows.items():
        path = PurePosixPath(name)
        assert not path.is_absolute() and '..' not in path.parts and '\\' not in name and str(path) == name
        assert set(row) == {'path', 'sha256', 'bytes'} and type(row['bytes']) is int and row['bytes'] >= 0
    expected, seen, payload_end, retained, owners = set(rows) | {'index.json'}, set(), 0, [], []
    with tarfile.open(archive, 'r|gz') as tar:
        for member in tar:
            assert member.name not in seen and member.name in expected
            assert member.isfile() and not member.issym() and not member.islnk() and member.sparse is None
            seen.add(member.name)
            raw = tar.extractfile(member).read()
            payload_end = max(payload_end, member.offset_data + (member.size + 511) // 512 * 512)
            if member.name == 'index.json':
                assert raw == index_raw
                continue
            row = rows[member.name]
            assert len(raw) == member.size == row['bytes'] and hashlib.sha256(raw).hexdigest() == row['sha256']
            assert member.mode == 0o644 and member.uid == member.gid == 0
            if member.name.endswith('.owner/result.json'):
                value = json.loads(raw)
                assert value['reaped'] is True and value['wait_returncode'] is not None
                owners.append({'path': member.name, 'pid': value['pid'], 'status': value['status'], 'wait_returncode': value['wait_returncode'], 'reaped': True})
                if value['status'] != 'PASS':
                    assert value['wait_returncode'] == 128 and member.name == 'host/bundle_b01603b.owner/result.json'
                    retained.append({'path': member.name, 'exit': 128, 'reason': value['errors']})
            if member.name in ('reviews/native_dynamic_review_r1.json', 'reviews/native_archive_review.json'):
                value = json.loads(raw)
                assert value['status'] == 'FAIL'
                retained.append({'path': member.name, 'reason': value['blocking_findings']})
    assert seen == expected and len(retained) == 3
    decoded = 0
    with gzip.open(archive, 'rb') as stream:
        while block := stream.read(1024 * 1024):
            assert not any(block[max(0, payload_end - decoded):])
            decoded += len(block)
    assert decoded >= payload_end + 1024 and before == {str(p): state(p) for p in paths}
    assert {'docs_draft/application.json', 'docs_draft/final_docs.diff', 'host/precommit_source_comparison.json', 'finalize_host_archive.py', 'reviews/native_dynamic_review_r2.json', 'reviews/native_archive_review_r2.json', 'reviews/final_evidence_binding_review.json'} <= set(rows)
    assert not any(PurePosixPath(n).name == 'source.bundle' or 'native-extracted' in PurePosixPath(n).parts or 'early_native' in PurePosixPath(n).parts for n in rows)
    return {'status': 'PASS', 'scope': '仅本机归档安全集合、逐hash/bytes和owner真实回收；文档语义另审，不替代硬件。', 'archive': {'path': str(archive), 'sha256': sha(archive), 'bytes': archive.stat().st_size}, 'index': {'path': str(index_path), 'sha256': sha(index_path), 'bytes': index_path.stat().st_size}, 'metadata': {'path': str(metadata_path), 'sha256': sha(metadata_path), 'bytes': metadata_path.stat().st_size}, 'checks': {'indexed_files': len(rows), 'members': len(seen), 'all_member_hash_bytes_and_safe_types': True, 'internal_external_index_exact': True, 'gzip_crc_and_zero_tar_tail': True, 'input_before_after_unchanged': True, 'owner_results_reaped': len(owners)}, 'owners': owners, 'preserved_nonpass': retained, 'blocking_findings': []}


def main():
    parser = argparse.ArgumentParser()
    for name in ('archive', 'index', 'metadata', 'report'):
        parser.add_argument('--' + name, type=Path, required=True)
    args = parser.parse_args()
    try:
        result = verify(args.archive, args.index, args.metadata)
    except Exception as error:
        result = {'status': 'FAIL', 'blocking_findings': [repr(error)]}
    result['reviewer_script_sha256'] = sha(Path(__file__))
    with args.report.open('x') as stream:
        json.dump(result, stream, ensure_ascii=False, indent=2)
        stream.write('\n')
    print(json.dumps({'status': result['status'], 'report': str(args.report), 'sha256': sha(args.report), 'blocking_findings': result['blocking_findings']}, ensure_ascii=False))
    return 0 if result['status'] == 'PASS' else 1


if __name__ == '__main__':
    raise SystemExit(main())
