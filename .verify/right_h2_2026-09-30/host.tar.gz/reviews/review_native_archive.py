#!/usr/bin/env python3
"""独立只读校验本轮归档；不解包、不执行成员，不代替软件或硬件验收。"""

import argparse
import gzip
import hashlib
import json
from pathlib import Path, PurePosixPath
import re
import stat
import tarfile


HERE = Path(__file__).resolve().parent
INDEX_NAME = "archive-index.json"
TREES = {"release-r1", "post-release-r1", "readback-tool-r1"}
BOOTSTRAP = {'nightly_before_files.sha256', 'cargo_before.txt', 'run_release_v2.py', 'collect_native.py', 'update-nightly.log', 'cargo_after.txt', 'post_release_checks.py', 'nightly_before.txt', 'nightly_after.txt'}
MAX_FILES = 50_000
MAX_ARCHIVE = 2 * 1024**3
MAX_LOGICAL = 8 * 1024**3
CHUNK = 1024**2


def require(condition, message):
    if not condition:
        raise ValueError(message)


def strict_json(raw):
    def pairs(items):
        out = {}
        for key, value in items:
            require(key not in out, "JSON 重复键：" + key)
            out[key] = value
        return out

    def invalid(value):
        raise ValueError("JSON 非有限数：" + value)

    return json.loads(raw, object_pairs_hook=pairs, parse_constant=invalid)


def file_state(path):
    value = path.lstat()
    require(stat.S_ISREG(value.st_mode), "本地输入不是普通文件：" + str(path))
    return (value.st_dev, value.st_ino, value.st_size, value.st_mtime_ns, value.st_ctime_ns)


def sha(path):
    with path.open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


def path_ok(name):
    require(isinstance(name, str) and name and "\\" not in name, "空或非 POSIX 成员名")
    path = PurePosixPath(name)
    require(not path.is_absolute() and ".." not in path.parts and path.as_posix() == name
            and name != ".", "归档路径越界或不规范：" + name)
    return path


def scope_ok(name, directory=False):
    path = path_ok(name)
    require(path.parts[0] in TREES or name == "bootstrap" and directory
            or len(path.parts) == 2 and path.parts[0] == "bootstrap" and path.name in BOOTSTRAP,
            "原件超出本轮三树与 bootstrap 白名单：" + name)


def verify(archive_path, index_path, metadata_path):
    before = {str(path): file_state(path) for path in (archive_path, index_path, metadata_path)}
    require(0 < before[str(archive_path)][2] <= MAX_ARCHIVE, "压缩归档超过本次有界校验范围")
    require(before[str(index_path)][2] <= 16 * CHUNK and before[str(metadata_path)][2] <= CHUNK,
            "索引或 metadata 异常过大")
    index_raw, metadata_raw = index_path.read_bytes(), metadata_path.read_bytes()
    index, metadata = strict_json(index_raw), strict_json(metadata_raw)
    require(index["schema"] == "P7_NATIVE_EVIDENCE_INDEX_V1"
            and metadata["schema"] == "P7_NATIVE_EVIDENCE_COLLECTION_V1", "归档协议不符")
    require(metadata["status"] == "PASS" and metadata["source_before_after"] == "PASS", "collector 原回执未通过")
    archive_sha = sha(archive_path)
    require(archive_sha == metadata["archive_sha256"]
            and before[str(archive_path)][2] == metadata["archive_bytes"], "归档本体 SHA/bytes 与 metadata 不符")
    require(hashlib.sha256(index_raw).hexdigest() == metadata["index_sha256"], "外层索引 SHA 与 metadata 不符")
    require(0 < len(index["files"]) <= MAX_FILES and len(index["directories"]) <= MAX_FILES,
            "索引成员数量超限")
    files, directories = {}, {}
    for row in index["files"]:
        require(set(row) == {"path", "sha256", "bytes", "mode", "uid", "gid", "mtime_ns"}, "文件索引字段不符")
        name = row["path"]
        scope_ok(name)
        require(name not in files and re.fullmatch(r"[0-9a-f]{64}", row["sha256"]), "索引重复或 SHA 格式不符")
        require(all(type(row[key]) is int and row[key] >= 0 for key in ("bytes", "mode", "uid", "gid", "mtime_ns"))
                and row["bytes"] <= MAX_ARCHIVE and row["mode"] <= 0o7777, "索引大小或属性非法")
        files[name] = row
    for row in index["directories"]:
        require(set(row) == {"path", "mode"}, "目录索引字段不符")
        name = row["path"]
        scope_ok(name, directory=True)
        require(name not in directories and name not in files and type(row["mode"]) is int
                and 0 <= row["mode"] <= 0o7777, "目录重复、类型冲突或 mode 非法")
        directories[name] = row
    total = sum(row["bytes"] for row in files.values())
    require(total <= MAX_LOGICAL and metadata["original_bytes"] == total, "原件逻辑总字节不符或超限")
    require(TREES | {"bootstrap"} <= set(directories), "三证据树或 bootstrap 缺失")
    require({"bootstrap/" + name for name in BOOTSTRAP} <= set(files), "bootstrap 白名单缺件")
    for kind, names in {"production": ["s0_daemon", "xlerobot_deploy", "s1_daemon", "robot_rpc_gateway"],
                        "measurement": ["s0_daemon", "robot_rpc_gateway", "comm_fault_e2e"]}.items():
        require("release-r1/" + kind + ".json" in files, "V2 清单缺失")
        for name in names:
            require(all("release-r1/" + kind + "/" + name + suffix in files for suffix in ("", ".build.json")),
                    "冻结 ELF 或 sidecar 缺失")
    require("release-r1/result.json" in files, "原构建总回执缺失")
    expected = set(files) | set(directories) | {INDEX_NAME}
    require(metadata["indexed_files"] == len(files) and metadata["readback"] == {
        "files": len(files), "directories": len(directories), "members": len(expected)}, "metadata 数量与索引不符")
    seen, nonpass, payload_end = set(), [], 0
    with tarfile.open(archive_path, mode="r|gz") as archive:
        for member in archive:
            name = member.name
            path_ok(name)
            require(name not in seen and name in expected, "多余或重复 tar 成员：" + name)
            seen.add(name)
            require(len(seen) <= len(expected) and member.sparse is None, "成员数量超限或 sparse 非普通成员")
            payload_end = max(payload_end, member.offset_data + (member.size + 511) // 512 * 512)
            if name in directories:
                require(member.isdir() and member.size == 0 and member.mode == directories[name]["mode"], "目录类型/属性不符")
                continue
            require(member.isfile() and not member.issym() and not member.islnk(), "拒绝链接或特殊 tar 成员")
            expected_size = len(index_raw) if name == INDEX_NAME else files[name]["bytes"]
            require(member.size == expected_size, "成员大小不符：" + name)
            digest, read, captured = hashlib.sha256(), 0, bytearray()
            with archive.extractfile(member) as stream:
                while block := stream.read(CHUNK):
                    read += len(block)
                    require(read <= expected_size, "成员读取超出索引大小")
                    digest.update(block)
                    if name == INDEX_NAME or name.endswith("completion.json") and expected_size <= 4 * CHUNK:
                        captured.extend(block)
            require(read == expected_size, "成员读取字节缺失")
            if name == INDEX_NAME:
                require(bytes(captured) == index_raw, "包内外索引不逐字相同")
            else:
                row = files[name]
                require(digest.hexdigest() == row["sha256"] and member.mode == row["mode"]
                        and member.uid == row["uid"] and member.gid == row["gid"]
                        and member.mtime == row["mtime_ns"] // 1_000_000_000, "成员内容或属性不符：" + name)
                if captured:
                    value = strict_json(captured)
                    if "runner_error" in value or value.get("exit_code") != 0 or value.get("reaped") is not True:
                        nonpass.append({"path": name, "sha256": row["sha256"], "exit_code": value.get("exit_code"),
                                        "reaped": value.get("reaped"), "runner_error": value.get("runner_error")})
    require(seen == expected, "tar 缺少索引成员")
    # 第二次流式读至 gzip EOF，验证 CRC/trailer，并拒绝首个 tar 结束标记后的隐藏载荷。
    decoded = 0
    with gzip.open(archive_path, "rb") as stream:
        while block := stream.read(CHUNK):
            require(decoded + len(block) <= total + len(index_raw) + 128 * CHUNK, "tar 结构开销异常或展开超限")
            tail_start = max(0, payload_end - decoded)
            require(not any(block[tail_start:]), "tar 最后索引成员后存在非零隐藏载荷")
            decoded += len(block)
    require(decoded >= payload_end + 1024, "缺少 tar 双零块结尾")
    after = {str(path): file_state(path) for path in (archive_path, index_path, metadata_path)}
    require(after == before and sha(archive_path) == archive_sha, "本地归档输入在独审期间改变")
    return {"status": "PASS", "scope": "仅归档完整性独审；不解包、不执行成员，不替代软件/H2/D15 验收。",
            "archive": {"path": str(archive_path), "sha256": archive_sha, "bytes": before[str(archive_path)][2]},
            "index": {"path": str(index_path), "sha256": hashlib.sha256(index_raw).hexdigest(), "bytes": len(index_raw)},
            "metadata": {"path": str(metadata_path), "sha256": hashlib.sha256(metadata_raw).hexdigest(), "bytes": len(metadata_raw)},
            "verified": {"files": len(files), "directories": len(directories), "members": len(seen),
                         "original_bytes": total, "gzip_eof": True, "tar_tail_zero": True,
                         "all_member_bytes_sha_and_attributes": True, "internal_external_index_identical": True,
                         "no_missing_extra_duplicate_traversal_or_link": True, "input_before_after_unchanged": True},
            "preserved_nonpass_completions": nonpass,
            "nonpass_scope": "这些原始 completion 逐字保留；其中预期负例与实际失败的业务判定由软件证据审查负责。",
            "blocking_findings": []}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    for name in ("archive", "index", "metadata"):
        parser.add_argument("--" + name, type=Path, required=True)
    options = parser.parse_args()
    report = HERE / "native_archive_review_r2.json"
    require(not report.exists(), "不覆盖已有独审回执")
    try:
        result = verify(*(getattr(options, name).resolve(strict=True) for name in ("archive", "index", "metadata")))
    except Exception as error:
        result = {"status": "FAIL", "scope": "归档完整性独审", "blocking_findings": [repr(error)]}
    result["reviewer_script_sha256"] = sha(Path(__file__))
    with report.open("x", encoding="utf-8") as stream:
        json.dump(result, stream, ensure_ascii=False, indent=2)
        stream.write("\n")
    print(json.dumps(result, ensure_ascii=False), flush=True)
    return 0 if result["status"] == "PASS" else 1


if __name__ == "__main__":
    raise SystemExit(main())
