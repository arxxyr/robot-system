# s52 右 H2：root 最终执行清单

本文件是未执行的组装清单。只核本地已有原件与当前契约；不生成现场事实、inputs、GO 或运行目录。真实动作须由 root 收到本轮现场答复后执行一次。若 HEAD、文件 SHA、主机 boot 或现场条件变化，重新核实绑定；不沿用旧 s51 输入。

## 1. 固定身份与路径

| 项目 | 本次值 |
|---|---|
| Orin 基目录 `BASE` | `/home/loosqk/robot-checks/h2-serial-recovery-20260930-r1` |
| 运行 `expected_head` | `4a8e171f27bf18625973aa4f3a6097e9b9fbed18` |
| 冻结 `build_head` | `b01603b56117a35279407de0c201bcd91bb6e5b2`；保留原值，不回填运行 HEAD |
| 编译输入 | 589 项，`c03888074cbd4005837bc0291aafdf72fff4a59f473d75f52298b1da42182a96` |
| tracked driver | `BASE/source/scripts/run_post_e_h2.py` |
| GO / cleanup helper | `BASE/bootstrap/s52-control-helper-r1/{prelaunch_go.py,post_h2_cleanup.py}` |
| 已通过只读准备 | `BASE/right-readonly-r1/run.json`，SHA `417109c792e786ba1214a301fc1de1dcb2b375c35644a4d312ddf0d391f8fbfe`；16 门 PASS、授权/启动均 0 |
| 准备草案 | `BASE/right-readonly-r1/preparation_inputs_draft.json`，仅 `P7_H2_PREPARATION_DRAFT_V1`，不可直接作为 `--inputs` |
| 新两端 alignment | `BASE/bootstrap/s52-alignment-r1.json`，SHA `4c8eef3908ebe65a681710e41ed10c3ad482f94c0a96b39612ace6c5dec321ec` |
| alignment 时刻 | `recorded_at_ns = 1790788549102315000`；本次现场确认时间须不早于此值 |
| 本次真实运行输出 | `BASE/right-h2-run-01`；禁止预创建，driver 独占创建即消费本次运行 |
| 建议后续独立清场输出 | `BASE/right-h2-cleanup-r1`；清场时须是新的同级目录 |

最新只读准备和 alignment 不是现场证明。启动前重新确认实际运行端 HEAD/clean、两端身份、七冻结件/正式四件、六服务、USB 与 fuser；确认上述原件及 helper SHA 未变。Orin boot 当前绑定 `6cf7ee3e-a3c5-4c91-80bc-4ca924818b53`。

## 2. 收到真实现场答复后才能组装三份回执

- **physical**：`schema=P7_H2_PHYSICAL_CONFIRMATION_V1`、`side=right`、`issued_by=root`、本次 `expected_head/output`；绑定 `measurement_manifest_sha256=bae41b6feaceb0f7fa5c0a1c5c1565bb5867a619b32346739853a6f3a461c7e2` 和上述 `alignment_sha256`；`source` 留真实用户答复/来源，`alignment.recorded_at_ns <= confirmed_at_ns <= 当前 time_ns`。七字段 `supported/unloaded/area_clear/motor_power_cycle/usb_replug/continuous_presence_until_cleanup/immediate_power_cut` 必须来自真实答复且为 JSON 布尔 `true`。不从旧“已经搞好”或重插记录推定，不将 D15 暂缓等同手动断电事实。
- **inputs**：`schema=P7_H2_INPUTS_V1`、`side=right`、本次 `expected_head/output`；复制本次准备草案的 `candidate_inputs`（`repository/source/production/measurement/source_manifest_sha256/installed/config_sha256/calibration`），再加入已写出且实测 SHA 的 `alignment/physical` 两个 `{path,sha256}` 引用。全部引用是规范绝对路径、独立普通文件，无链接；配置/标定/安装快照须原件复核后采用。
- **GO**：由 root 独立评审后签发 `schema=P7_H2_RIGHT_ROOT_GO_V1`、`approved=true`、`side=right`、本次 `expected_head/output`，绑定实际 `inputs_sha256/physical_sha256/alignment_sha256`，真实 `signed_at_ns/expires_at_ns` 满足 `0 < signed_at_ns <= now < expires_at_ns`；最后交接前再次检查期限与原件。`CHECK_ONLY` 也要求有效 GO，不能用于跳过事实。

建议未来文件名为 `BASE/bootstrap/s52-right-physical-r1.json`、`s52-right-inputs-r1.json`、`s52-right-go-r1.json`；这里只列名称，没有创建这些文件。签发后立即 SHA 读回，替换下面两个占位摘要；不把候选清单直接改名冒充已授权输入。

## 3. 一次启动与真实等待

由 root 将下列远端模板保存为本地全新输入脚本后，用已审非 kill `s52/host/ssh_owner.py` 持有严格 SSH。不要套 `timeout`、旧 `host_gate.py`、整组 kill 或带 `output` 参数的 `uv run` 父进程。解释器先用 uv 选取，再 shell `exec`；GO helper 在同 PID `exec` tracked driver。

```sh
set -eu
export PATH=/home/loosqk/.local/bin:$PATH
BASE=/home/loosqk/robot-checks/h2-serial-recovery-20260930-r1
H2_PYTHON="$(uv python find 3.12)"
exec taskset -c 0-3 "$H2_PYTHON" "$BASE/bootstrap/s52-control-helper-r1/prelaunch_go.py" \
  --execute --driver "$BASE/source/scripts/run_post_e_h2.py" \
  --expected-head 4a8e171f27bf18625973aa4f3a6097e9b9fbed18 \
  --inputs "$BASE/bootstrap/s52-right-inputs-r1.json" --inputs-sha256 '__实际_INPUTS_SHA256__' \
  --go "$BASE/bootstrap/s52-right-go-r1.json" --go-sha256 '__实际_GO_SHA256__' \
  --output "$BASE/right-h2-run-01"
```

本地 owner 参数：全新 `--label s52-right-h2-run-01`、`--observe-seconds 5`、`--input <root 新写且核 SHA 的规范绝对脚本>`，命令为 `/usr/bin/ssh -o BatchMode=yes -o StrictHostKeyChecking=yes -o ConnectTimeout=15 robot /bin/bash -s`。owner 无总运行超时、不转发信号；记录实际 SSH PID/wait/reaped。SSH exit 不替代远端工具/driver 回收证据。

driver 固定顺序是 `status → revoke → status → 一次 authorize → status → 一次工具启动`；右侧必须显式传递，helper 已组装 `--side right --physical-reset-confirmed`。整个运行不自动重授权、重启工具、重跑失败组或拼接旧四组；任何失败保留原回执。

H2 为 topic/external × idle/inflight 四组，每组 **100 预热 + 1000 正式样本**；SLA-A **P99 ≤ 2 ms**，SLA-B **idle P99 ≤ 20 ms / inflight P99 ≤ 75 ms**。保留 max 和原样本，不能放宽预算。最终 Disable 业务预算 **2 s**、最终传输等待 **3 s**、gateway grace **500 ms**；普通 RPC 传输仍 **2 s**。必须有本次合法、非 dry-run 的最终 Disable Ack、合法 Disarm trace，不能只凭四组测量 PASS。

## 4. 收尾 → 独立清场 → 34 条读回

1. 持续现场看护直到全部收尾。先取得工具实际退出码/`tool_naturally_reaped`、driver 最终 `run.json` 和本地 SSH 实际 wait/reaped；未真实回收时不读回串口。owner/driver 收到信号后继续持有监督，不用信号制造“已结束”。
2. 在新的独立清场目录调用同源 `post_h2_cleanup.py`；输入绑定原 inputs SHA，`--preparation BASE/right-readonly-r1/run.json --preparation-sha256 417109c792e786ba1214a301fc1de1dcb2b375c35644a4d312ddf0d391f8fbfe`，`--driver BASE/source/scripts/run_post_e_h2.py --output BASE/right-h2-run-01 --out BASE/right-h2-cleanup-r1`。仍采用 `uv python find 3.12` 后 `exec`，由另一个全新 SSH owner 持有并真实 wait；不要复用清场目录。
3. 分别核 `driver_status`、`readonly_cleanup_status`、工具真实回收、六服务/相关进程/串口和锁 fuser、正式四件/配置/冻结件/保护文件。清场 helper 不读电机寄存器，`physical_torque_state=UNKNOWN`。若原 driver FAIL，即使只读清场 PASS，整体仍 FAIL；不得覆盖原 H2 结果。
4. 仅在工具与 driver 已回收、独立清场无控制进程及串口/锁持有者、当前现场仍就绪时，按 **`s52/readback_plan.json` 的原 34 个 `steps` 顺序**逐条读回：左 ID 1–8（机械臂含夹爪 1–6，头部 7–8），右 ID 1–9（机械臂含夹爪 1–6，底盘 7–9）；每 ID 先 `Torque_Enable`、再 `Present_Velocity`。现场答复与持续值守应覆盖读回和最终清场全过程。
5. 每总线开始前再次核精确 by-id、fuser/控制进程和现场值守；先核读回 ELF SHA `f2014ee4008311e7a8725235a39f0d1b3913391f17cbd977b7441f120539114b`。工具为 `BASE/readback-tool-r1/feetech_poke`，每条 argv、预期 stdout 和 exit 按 plan；每条实际 wait/reaped并保存原 stdout/stderr。每条会打开 1 Mbps 串口，PING、读取型号 777、读取目标寄存器；不写寄存器。
6. 任何非零、异常输出、未回收或条件变化，停止后续读回；不自动重试、Enable 或补写寄存器。保留原失败与尚未执行条目。最后独立复核无进程/持有者并保留现场收尾事实，再解除值守。

34 条全零仅支持各采样时刻的扭矩使能/速度读回，不证明连续静止、头部/底盘主动运动通过或硬件 fail-safe。D15 保持 **OPEN/DEFERRED**、`deployable=false`；历史右 H2 FAIL 保留。

契约定位：`scripts/run_post_e_h2.py::validate_facts`、`prelaunch_go.py::validate_authorization`、`post_h2_cleanup.py::driver_outcome/combine_status`、`scripts/post_e_h2_report.py`、`crates/robot-tests/src/comm_fault/sla.rs`、`crates/robot-tests/src/comm_fault_rpc.rs`。
