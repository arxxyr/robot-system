# s52 右 H2 前置步骤

当前只上传了三个 helper；没有生成现场事实、GO 或真实运行目录。
固定 build HEAD 为 `b01603b56117a35279407de0c201bcd91bb6e5b2`。
后续仅文档提交后的运行 HEAD 必须由 root 显式提供，不能改写新 V2 清单的 build HEAD。

1. 等待 `release-r1/result.json` 及 post 软件验收通过，独审核六配方、七个冻结件、编译器前后身份、589 项输入与正式安装隔离状态。固定源聚合为 `c03888074cbd4005837bc0291aafdf72fff4a59f473d75f52298b1da42182a96`。
2. 记录同源 `feetech_poke` 新冻结文件的真实 SHA、bytes 与 ELF 183；据此生成 `readback_plan.json`。这里只生成命令计划，不执行工具。
3. 本地 evidence/docs 阶段提交后，将远端隔离 `source` ff 到该完整提交；确认两端 clean、589 项输入仍与新冻结源逐项相同。
4. root 将 `export H2_EXPECTED_HEAD=<完整最终运行提交>` 前置写入新的独占脚本，再拼接 `host/prepare_readonly.sh`；通过 `host/ssh_owner.py` 执行 SSH 并保留真实 wait/reap 原件。不依赖本地环境变量经 SSH 转发。输出固定 `right-readonly-r1`，计划输出 `right-h2-run-01` 始终不能由准备步骤创建。
5. 下载原 `right-readonly-r1` 三个 JSON；核 16 项检查 PASS、`NOT_AUTHORIZED`、authorize/launch 均为 0、计划输出未创建。若原失败则保留，不能覆盖后补。
6. root 以同样的显式远端变量方式执行 `host/alignment_probe.sh`，下载原 `bootstrap/s52-alignment-identity-r1.json` 和 `bootstrap/s52-alignment-source-r1.json`，核下载 SHA 与远端打印值一致。该脚本只查询 Git、源码文件和主机 boot，独占写入证据。
7. root 用 `uv run --no-project python host/make_alignment.py`，显式传 `--expected-head`、下载原身份文件和 SHA、原 `source_before.json` 和 SHA，以及全新的 `--out` / `--local-evidence`。本机 fresh Git/589 逐项一致后才写 `P7_H2_ALIGNMENT_V1`；上传该实际回执并校验 SHA，不复用 s51 alignment。
8. 最终 alignment 的 `recorded_at_ns` 之后，root 才接受本次现场事实：电机电源重置、USB 重插、双臂空载并有支撑、接触范围清空、持续看护到读回/清场并能立即手动断电。事实来源和时刻必须实际可核，不由脚本推断。
9. root 创建与最终运行 HEAD、alignment SHA、测量清单 SHA、唯一输出绑定的 physical/input/独立 GO。`prelaunch_go.py` 校验通过后同 PID exec 已跟踪 driver；H2 故障或失败不自动重跑。
10. 真实工具和 driver 完成 wait/reap 后，继续独立只读清场；清场不替代读寄存器。确认控制进程、串口与锁持有者为空，现场继续值守，再按新 34 条计划分别读 Torque_Enable 与 Present_Velocity。首个失败或非零立即停止，保存原件，不自动写入或重试。

最后三步包含硬件动作，当前不执行。D15 保持 OPEN/DEFERRED；寄存器零值只支持采样时刻的读回结果，不证明连续静止或独立硬件 fail-safe。
