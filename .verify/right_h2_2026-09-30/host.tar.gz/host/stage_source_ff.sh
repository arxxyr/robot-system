set -eu
base=/home/loosqk/robot-checks/h2-serial-recovery-20260930-r1
source="$base/source"
bundle="$base/bootstrap/post-stage-source.bundle"
formal=/home/loosqk/repo/robot/robot-system
test -f "$bundle"
test ! -L "$bundle"
test "$(stat -c %h "$bundle")" = 1
test "$(sha256sum "$bundle" | cut -d ' ' -f 1)" = c9dea5aeffeaeec9cdd212ffadc095c6a2f9b11f23389e889b57e43bcdfbe1e6
test "$(git -C "$source" rev-parse HEAD)" = b01603b56117a35279407de0c201bcd91bb6e5b2
test -z "$(git -C "$source" status --porcelain=v1 --untracked-files=all)"
test ! -e "$base/right-h2-run-01"
test ! -L "$base/right-h2-run-01"
git -C "$source" bundle verify "$bundle"
git -C "$source" fetch "$bundle" HEAD
test "$(git -C "$source" rev-parse FETCH_HEAD)" = 4a8e171f27bf18625973aa4f3a6097e9b9fbed18
git -C "$source" merge-base --is-ancestor HEAD FETCH_HEAD
git -C "$source" checkout --detach FETCH_HEAD
test "$(git -C "$source" rev-parse HEAD)" = 4a8e171f27bf18625973aa4f3a6097e9b9fbed18
test -z "$(git -C "$source" status --porcelain=v1 --untracked-files=all)"
test "$(git -C "$formal" rev-parse HEAD)" = ca14f0e6cf6df8ecc6baaaa8dff2dddb64abbd0a
test -z "$(git -C "$formal" status --porcelain=v1 --untracked-files=all)"
sha256sum "$bundle"
git -C "$source" rev-parse HEAD
git -C "$source" status --porcelain=v1 --untracked-files=all
