set -eu
export PATH=/home/loosqk/.cargo/bin:/home/loosqk/.local/bin:$PATH
TASK_ROOT=/home/loosqk/robot-checks/h2-serial-recovery-20260930-r1
test "$(hostname)" = ubuntu
test "$(id -un)" = loosqk
test "$(cat /proc/sys/kernel/random/boot_id)" = 6cf7ee3e-a3c5-4c91-80bc-4ca924818b53
test "$(git -C /home/loosqk/repo/robot/robot-system rev-parse HEAD)" = ca14f0e6cf6df8ecc6baaaa8dff2dddb64abbd0a
test -z "$(git -C /home/loosqk/repo/robot/robot-system status --porcelain)"
# 仅列出相关软件构建进程；已有目录拒绝重入，避免中断后误重跑。
ps -eo pid,ppid,args | awk '$0 ~ /[c]argo (build|test|clippy)|[r]un_release_v2.py --run-builds|[p]ost_release_checks.py --run-checks/ {print; found=1} END {exit found ? 1 : 0}'
test ! -e "$TASK_ROOT"
mkdir -p "$TASK_ROOT/bootstrap"
rustc +nightly -Vv > "$TASK_ROOT/bootstrap/nightly_before.txt"
cargo +nightly -V > "$TASK_ROOT/bootstrap/cargo_before.txt"
cp -a --reflink=auto /home/loosqk/.rustup/toolchains/nightly-aarch64-unknown-linux-gnu "$TASK_ROOT/nightly-before"
sha256sum "$TASK_ROOT/nightly-before/bin/rustc" "$TASK_ROOT/nightly-before/bin/cargo" > "$TASK_ROOT/bootstrap/nightly_before_files.sha256"
rustup update nightly --no-self-update > "$TASK_ROOT/bootstrap/update-nightly.log" 2>&1
cat "$TASK_ROOT/bootstrap/update-nightly.log"
rustc +nightly -Vv > "$TASK_ROOT/bootstrap/nightly_after.txt"
cargo +nightly -V > "$TASK_ROOT/bootstrap/cargo_after.txt"
cat "$TASK_ROOT/bootstrap/nightly_after.txt" "$TASK_ROOT/bootstrap/cargo_after.txt"
