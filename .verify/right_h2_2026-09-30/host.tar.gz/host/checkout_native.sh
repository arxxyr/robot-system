set -eu
BASE=/home/loosqk/robot-checks/h2-serial-recovery-20260930-r1
FORMAL=/home/loosqk/repo/robot/robot-system
cd "$BASE/bootstrap"
printf '%s\n' 'f17f7a92528c9addcaa3df483311d8fda50d4f55d489226536953e4968559d65  source.bundle' 'e11d5b7eac3f03f2e60267f8bd1944c2920b81dcd347d5beeee4650275098b93  run_release_v2.py' '4f567265b93687411324811363ab4d79a1730ff5a0d41bb745a37942c385449e  post_release_checks.py' | sha256sum -c -
test "$(git -C "$FORMAL" rev-parse HEAD)" = ca14f0e6cf6df8ecc6baaaa8dff2dddb64abbd0a
test -z "$(git -C "$FORMAL" status --porcelain)"
test ! -e "$BASE/source"
git clone --shared --no-checkout "$FORMAL" "$BASE/source"
git -C "$BASE/source" bundle verify "$BASE/bootstrap/source.bundle"
git -C "$BASE/source" fetch "$BASE/bootstrap/source.bundle" HEAD
git -C "$BASE/source" checkout --detach b01603b56117a35279407de0c201bcd91bb6e5b2
git -C "$BASE/source" rev-parse HEAD
git -C "$BASE/source" status --porcelain
test -z "$(git -C "$BASE/source" status --porcelain)"
test "$(git -C "$FORMAL" rev-parse HEAD)" = ca14f0e6cf6df8ecc6baaaa8dff2dddb64abbd0a
test -z "$(git -C "$FORMAL" status --porcelain)"
