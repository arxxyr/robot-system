set -eu
export PATH=/home/loosqk/.cargo/bin:/home/loosqk/.local/bin:$PATH
export CARGO_HOME=/home/loosqk/robot-checks/viz-orin-a6957cc-20260930-r1/cargo-home
export CARGO_NET_OFFLINE=true
export RUSTUP_AUTO_INSTALL=0
BASE=/home/loosqk/robot-checks/h2-serial-recovery-20260930-r1
cd "$BASE/bootstrap"
printf '%s\n' 'e11d5b7eac3f03f2e60267f8bd1944c2920b81dcd347d5beeee4650275098b93  run_release_v2.py' '4f567265b93687411324811363ab4d79a1730ff5a0d41bb745a37942c385449e  post_release_checks.py' | sha256sum -c -
exec taskset -c 0-3 uv run --no-project python post_release_checks.py --run-checks --source "$BASE/source" --target /home/loosqk/robot-checks/h2-nightly-v2-20260930-r1/build --release "$BASE/release-r1" --out "$BASE/post-release-r1" --build-head b01603b56117a35279407de0c201bcd91bb6e5b2 --formal-root /home/loosqk/repo/robot/robot-system --helper "$BASE/bootstrap/run_release_v2.py"
