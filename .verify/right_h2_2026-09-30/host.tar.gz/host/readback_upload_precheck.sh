set -eu
base=/home/loosqk/robot-checks/h2-serial-recovery-20260930-r1
for p in "$base/bootstrap/s52-control-helper-r1/readback_serial_once.py" "$base/bootstrap/s52-readback-plan-r1.json" "$base/register-readback-r1"; do
 test ! -e "$p"
 test ! -L "$p"
done
