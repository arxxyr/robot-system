set -eu
export PATH=/home/loosqk/.cargo/bin:/home/loosqk/.local/bin:$PATH
export CARGO_HOME=/home/loosqk/robot-checks/viz-orin-a6957cc-20260930-r1/cargo-home
export CARGO_NET_OFFLINE=true
export RUSTUP_AUTO_INSTALL=0
cd /home/loosqk/robot-checks/h2-serial-recovery-20260930-r1
exec taskset -c 0-3 uv run --no-project python - <<'PY'
import importlib.util,json,shutil,sys
from pathlib import Path
from types import SimpleNamespace
base=Path.cwd();source=base/'source';target=Path('/home/loosqk/robot-checks/h2-nightly-v2-20260930-r1/build')
sys.dont_write_bytecode=True
sys.path.insert(0,str(source/'scripts'))
import post_e_h2_artifacts as a
helper_path=base/'bootstrap/run_release_v2.py'
assert a.sha256(helper_path)=='e11d5b7eac3f03f2e60267f8bd1944c2920b81dcd347d5beeee4650275098b93'
spec=importlib.util.spec_from_file_location('helper',helper_path);helper=importlib.util.module_from_spec(spec);spec.loader.exec_module(helper)
out=base/'readback-tool-r1';out.mkdir()
runner=helper.Runner(SimpleNamespace(source=source,target=target,out=out,build_head='b01603b56117a35279407de0c201bcd91bb6e5b2'),a)
before=runner.source('source_before')
assert before==json.loads((base/'release-r1/source_before.json').read_text())
assert before['source_manifest_sha256']=='c03888074cbd4005837bc0291aafdf72fff4a59f473d75f52298b1da42182a96' and len(before['files'])==589
_,rustc_before=runner.command('rustc_before',['rustc','-vV'])
compiler=a.parse_rustc_identity(Path(rustc_before['stdout']).read_text())
production=json.loads((base/'release-r1/production.json').read_text())
assert compiler==production['rustc_identity']
build_ref,_=runner.command('build',['cargo','build','--locked','--release','-p','robot-adapter-feetech','--features','real-hw','--example','feetech_poke','--message-format=json'],1200)
messages=[json.loads(line) for line in (out/'build/stdout.log').read_text().splitlines() if line.startswith('{')]
assert [r for r in messages if r.get('reason')=='build-finished']==[{'reason':'build-finished','success':True}]
artifacts=[r for r in messages if r.get('reason')=='compiler-artifact' and r['target']['name']=='feetech_poke' and r.get('executable')]
assert len(artifacts)==1 and artifacts[0]['target']['kind']==['example'] and 'real-hw' in artifacts[0]['features']
origin=Path(artifacts[0]['executable']);assert origin==target/'release/examples/feetech_poke'
original=a.elf_identity(origin)
frozen=out/'feetech_poke';shutil.copyfile(origin,frozen);frozen.chmod(origin.stat().st_mode & 0o777)
identity=a.elf_identity(frozen)
assert identity==original==a.elf_identity(origin)
_,rustc_after=runner.command('rustc_after',['rustc','-vV'])
assert a.parse_rustc_identity(Path(rustc_after['stdout']).read_text())==compiler
assert runner.source('source_after')==before
helper.save(out/'result.json',{'status':'PASS','scope':'仅编译并冻结独立寄存器读回工具，未运行ELF/串口','build_head':runner.options.build_head,'source_manifest_sha256':before['source_manifest_sha256'],'artifact':{**identity,'path':str(frozen)},'cargo_artifact':artifacts[0],'rustc_identity':compiler,'build_receipt':build_ref,'receipts':runner.receipts})
print(json.dumps({'status':'PASS','result':str(out/'result.json'),'artifact':identity},ensure_ascii=False))
PY
