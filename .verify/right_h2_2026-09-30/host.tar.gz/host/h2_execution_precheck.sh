set -eu
base=/home/loosqk/robot-checks/h2-serial-recovery-20260930-r1
source="$base/source"
test "$(cat /proc/sys/kernel/random/boot_id)" = 6cf7ee3e-a3c5-4c91-80bc-4ca924818b53
test "$(git -C "$source" rev-parse HEAD)" = 4a8e171f27bf18625973aa4f3a6097e9b9fbed18
test -z "$(git -C "$source" status --porcelain=v1 --untracked-files=all)"
for path in "$base/right-h2-run-01" "$base/right-h2-cleanup-r1" "$base/bootstrap/s52-right-physical-r1.json" "$base/bootstrap/s52-right-inputs-r1.json" "$base/bootstrap/s52-right-go-r1.json"; do
 test ! -e "$path"
 test ! -L "$path"
done
sha256sum "$base/bootstrap/s52-control-helper-r1/prelaunch_go.py" "$base/bootstrap/s52-control-helper-r1/post_h2_cleanup.py" "$base/bootstrap/s52-alignment-r1.json"
