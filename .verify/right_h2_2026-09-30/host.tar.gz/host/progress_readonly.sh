set -eu
export PATH=/home/loosqk/.cargo/bin:/home/loosqk/.local/bin:$PATH
exec uv run --no-project python - <<'PY'
import json
from pathlib import Path
base=Path('/home/loosqk/robot-checks/h2-serial-recovery-20260930-r1')
for name in ('release-r1','post-release-r1','readback-tool-r1'):
 directory=base/name
 if not directory.exists(): continue
 for command in sorted(directory.iterdir()):
  if not command.is_dir() or not (command/'launch.json').is_file(): continue
  launch=json.loads((command/'launch.json').read_text())
  completion=command/'completion.json'
  row={'tree':name,'command':command.name,'pid':launch['pid'],'start_ticks':launch['identity']['start_ticks']}
  if completion.is_file():
   done=json.loads(completion.read_text());row.update(exit_code=done['exit_code'],reaped=done['reaped'],runner_error=done.get('runner_error'))
  else:
   row['state']='COMPLETION_ABSENT'
   stderr=command/'stderr.log'
   if stderr.exists(): row['stderr_last_lines']=stderr.read_text(errors='replace').splitlines()[-3:]
  print(json.dumps(row,ensure_ascii=False))
PY
