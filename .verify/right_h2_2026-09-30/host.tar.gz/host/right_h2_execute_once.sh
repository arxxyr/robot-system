set -eu
export PATH=/home/loosqk/.cargo/bin:/home/loosqk/.local/bin:$PATH
BASE=/home/loosqk/robot-checks/h2-serial-recovery-20260930-r1
test -f "$BASE/bootstrap/s52-right-go-r1.json"
test ! -L "$BASE/bootstrap/s52-right-go-r1.json"
test "$(stat -c %h "$BASE/bootstrap/s52-right-go-r1.json")" = 1
test "$(sha256sum "$BASE/bootstrap/s52-right-go-r1.json" | cut -d ' ' -f 1)" = e4d0ff958faea72dfda31471ce9f57b35e5a86248ac6572e95658af6d76b3389
sha256sum "$BASE/bootstrap/s52-right-go-r1.json"
H2_PYTHON="$(uv python find 3.12)"
exec taskset -c 0-3 "$H2_PYTHON" "$BASE/bootstrap/s52-control-helper-r1/prelaunch_go.py" \
 --execute --driver "$BASE/source/scripts/run_post_e_h2.py" \
 --expected-head 4a8e171f27bf18625973aa4f3a6097e9b9fbed18 \
 --inputs "$BASE/bootstrap/s52-right-inputs-r1.json" --inputs-sha256 541d7f463948cfb5393dbf1a8fe20be648c6e550f014caa4245d4b446dbcbff7 \
 --go "$BASE/bootstrap/s52-right-go-r1.json" --go-sha256 e4d0ff958faea72dfda31471ce9f57b35e5a86248ac6572e95658af6d76b3389 \
 --output "$BASE/right-h2-run-01"
