set -eu
test -f /home/loosqk/robot-checks/h2-serial-recovery-20260930-r1/bootstrap/s52-alignment-r1.json
test ! -L /home/loosqk/robot-checks/h2-serial-recovery-20260930-r1/bootstrap/s52-alignment-r1.json
test "$(stat -c %h /home/loosqk/robot-checks/h2-serial-recovery-20260930-r1/bootstrap/s52-alignment-r1.json)" = 1
test "$(sha256sum /home/loosqk/robot-checks/h2-serial-recovery-20260930-r1/bootstrap/s52-alignment-r1.json | cut -d ' ' -f 1)" = 4c8eef3908ebe65a681710e41ed10c3ad482f94c0a96b39612ace6c5dec321ec
sha256sum /home/loosqk/robot-checks/h2-serial-recovery-20260930-r1/bootstrap/s52-alignment-r1.json
cat /home/loosqk/robot-checks/h2-serial-recovery-20260930-r1/bootstrap/s52-alignment-r1.json
