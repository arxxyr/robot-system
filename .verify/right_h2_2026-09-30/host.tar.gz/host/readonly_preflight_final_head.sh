set -eu
export PATH=/home/loosqk/.local/bin:$PATH
H2_PYTHON="$(uv python find 3.12)"
exec "$H2_PYTHON" - <<'PYREMOTE'
import hashlib,json,os,stat,subprocess,time
from pathlib import Path
base=Path('/home/loosqk/robot-checks/h2-serial-recovery-20260930-r1')
source=base/'source';out=base/'right-readonly-r1';planned=base/'right-h2-run-01'
result={'mode':'READ_ONLY_PREFLIGHT','recorded_at_ns':time.time_ns(),'out_exists':out.exists() or out.is_symlink(),'planned_exists':planned.exists() or planned.is_symlink(),'out':str(out),'planned_output':str(planned)}
for key,args in [('source_head',['rev-parse','HEAD']),('source_status',['status','--porcelain=v1','--untracked-files=all'])]:
 row=subprocess.run(['git','-C',str(source),*args],capture_output=True,text=True,check=False,timeout=30,env={**os.environ,'GIT_OPTIONAL_LOCKS':'0'})
 result[key]={'exit_code':row.returncode,'stdout':row.stdout,'stderr':row.stderr}
helper=base/'bootstrap/s52-control-helper-r1/prepare_right_readonly.py'
info=helper.lstat();result['helper']={'path':str(helper),'sha256':hashlib.sha256(helper.read_bytes()).hexdigest(),'bytes':info.st_size,'nlink':info.st_nlink,'regular':stat.S_ISREG(info.st_mode)}
result['existing_readonly_files']={}
if result['out_exists'] and out.is_dir() and not out.is_symlink():
 for name in ['run.json','preparation_inputs_draft.json','installed_before.json']:
  path=out/name
  if path.exists():
   info=path.lstat();result['existing_readonly_files'][name]={'bytes':info.st_size,'sha256':hashlib.sha256(path.read_bytes()).hexdigest()} if stat.S_ISREG(info.st_mode) else {'regular':False}
result['status']='PASS' if not result['out_exists'] and not result['planned_exists'] and result['source_head']=={'exit_code':0,'stdout':'4a8e171f27bf18625973aa4f3a6097e9b9fbed18\n','stderr':''} and result['source_status']=={'exit_code':0,'stdout':'','stderr':''} and result['helper']['sha256']=='ce097c64ca229601502072c9911ed57ef7de7c01a866fac75d630d1b3884e747' and result['helper']['regular'] and result['helper']['nlink']==1 else 'FAIL'
print(json.dumps(result,ensure_ascii=False))
raise SystemExit(0 if result['status']=='PASS' else 2)
PYREMOTE
