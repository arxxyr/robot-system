set -eu
export PATH=/home/loosqk/.local/bin:$PATH
H2_PYTHON="$(uv python find 3.12)"
exec "$H2_PYTHON" - <<'PYREMOTE'
import hashlib,json,os,stat,time
from pathlib import Path
base=Path('/home/loosqk/robot-checks/h2-serial-recovery-20260930-r1')
result_path=base/'readback-tool-r1/result.json'
info=result_path.lstat();assert stat.S_ISREG(info.st_mode) and info.st_nlink==1
raw=result_path.read_bytes();assert hashlib.sha256(raw).hexdigest()=="f17b198cf6a64f6f6df3e8dc00f36c6f28957d1f55bc15143df181794a1b65a5"
result=json.loads(raw);assert result['status']=='PASS'
assert result['build_head']=='b01603b56117a35279407de0c201bcd91bb6e5b2'
assert result['source_manifest_sha256']=='c03888074cbd4005837bc0291aafdf72fff4a59f473d75f52298b1da42182a96'
path=Path(result['artifact']['path']);assert path==base/'readback-tool-r1/feetech_poke' and path==path.resolve(strict=True)
info=path.lstat();assert stat.S_ISREG(info.st_mode) and info.st_nlink==1
with path.open('rb') as stream: actual_sha=hashlib.file_digest(stream,'sha256').hexdigest()
header=path.open('rb').read(64)
assert header[:4]==b'\x7fELF' and header[4:6]==bytes([2,1]) and int.from_bytes(header[18:20],'little')==183
assert actual_sha==result['artifact']['sha256'] and info.st_size==result['artifact']['bytes']
planned=base/'right-h2-run-01';assert not planned.exists() and not planned.is_symlink()
print(json.dumps({'status':'PASS','scope':'只读新读回工具冻结文件与result身份；未执行ELF/UART','recorded_at_ns':time.time_ns(),'result_sha256':hashlib.sha256(raw).hexdigest(),'artifact':{'path':str(path),'sha256':actual_sha,'bytes':info.st_size,'nlink':info.st_nlink,'regular':True,'elf_machine':183},'planned_output_created':False},ensure_ascii=False))
PYREMOTE
