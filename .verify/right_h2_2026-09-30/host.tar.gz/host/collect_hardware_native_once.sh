set -eu
export PATH=/home/loosqk/.local/bin:$PATH
H2_PYTHON="$(uv python find 3.12)"
exec "$H2_PYTHON" - <<'END_PY'
from pathlib import Path
import hashlib,json,os,stat,tarfile,time
base=Path('/home/loosqk/robot-checks/h2-serial-recovery-20260930-r1')
out=base/'hardware-evidence-r1'
assert not out.exists() and not out.is_symlink()
roots=['right-readonly-r1','right-h2-run-01','right-h2-cleanup-r1','register-readback-r1','right-h2-postread-r1','bootstrap/s52-right-inputs-r1.json','bootstrap/s52-right-physical-r1.json','bootstrap/s52-right-go-r1.json','bootstrap/s52-alignment-r1.json','bootstrap/s52-readback-plan-r1.json','bootstrap/s52-right-h2-ssh-wait-r1.json','bootstrap/s52-control-helper-r1']
files=[]
for name in roots:
 p=base/name
 assert p.exists() and not p.is_symlink()
 if p.is_dir():
  for q in sorted(p.rglob('*')):
   m=q.lstat()
   assert not stat.S_ISLNK(m.st_mode)
   if stat.S_ISREG(m.st_mode): files.append(q)
   else: assert stat.S_ISDIR(m.st_mode)
 else:files.append(p)
assert len(set(files))==len(files)
def identity(p):
 m=p.lstat();assert stat.S_ISREG(m.st_mode) and m.st_nlink==1
 h=hashlib.sha256()
 with p.open('rb') as f:
  while block:=f.read(1024*1024):h.update(block)
 assert p.lstat().st_size==m.st_size
 return {'path':str(p.relative_to(base)),'sha256':h.hexdigest(),'bytes':m.st_size}
before=[identity(p) for p in files]
out.mkdir()
archive=out/'native.tar.gz'
with archive.open('xb') as stream:
 with tarfile.open(fileobj=stream,mode='w:gz') as tar:
  for p in files:tar.add(p,arcname=str(p.relative_to(base)),recursive=False)
 stream.flush();os.fsync(stream.fileno())
after=[identity(p) for p in files]
assert before==after
manifest={'schema':'P7_H2_HARDWARE_NATIVE_ARCHIVE_V1','status':'PASS','started_scope':'实际硬件/清场/寄存器原件与当次绑定，只打包，不控制硬件','files':before,'file_count':len(files),'input_bytes':sum(x['bytes'] for x in before),'source_before_after_equal':True,'archive':identity(archive),'finished_ns':time.time_ns()}
with (out/'manifest.json').open('x') as f:json.dump(manifest,f,ensure_ascii=False,indent=2);f.write('\n')
print(json.dumps({k:manifest[k] for k in ('schema','status','file_count','input_bytes','source_before_after_equal','archive','finished_ns')},ensure_ascii=False))
END_PY
