set -eu
base=/home/loosqk/robot-checks/h2-serial-recovery-20260930-r1
for name in s52-right-physical-r1.json s52-right-inputs-r1.json; do
 p="$base/bootstrap/$name"
 test -f "$p"
 test ! -L "$p"
 test "$(stat -c %h "$p")" = 1
done
test "$(sha256sum "$base/bootstrap/s52-right-physical-r1.json" | cut -d ' ' -f 1)" = 048580198f81c37a27507ee0b76397692d0e6da5b7e9b1ad23c195fc2c26bdde
test "$(sha256sum "$base/bootstrap/s52-right-inputs-r1.json" | cut -d ' ' -f 1)" = 541d7f463948cfb5393dbf1a8fe20be648c6e550f014caa4245d4b446dbcbff7
sha256sum "$base/bootstrap/s52-right-physical-r1.json" "$base/bootstrap/s52-right-inputs-r1.json"
