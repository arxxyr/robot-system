set -eu
base=/home/loosqk/robot-checks/h2-serial-recovery-20260930-r1
source="$base/source"
formal=/home/loosqk/repo/robot/robot-system
test ! -e "$base/bootstrap/post-stage-source.bundle"
test ! -L "$base/bootstrap/post-stage-source.bundle"
test ! -e "$base/right-readonly-r1"
test ! -L "$base/right-readonly-r1"
test ! -e "$base/right-h2-run-01"
test ! -L "$base/right-h2-run-01"
test "$(git -C "$source" rev-parse HEAD)" = b01603b56117a35279407de0c201bcd91bb6e5b2
test -z "$(git -C "$source" status --porcelain)"
test "$(git -C "$formal" rev-parse HEAD)" = ca14f0e6cf6df8ecc6baaaa8dff2dddb64abbd0a
test -z "$(git -C "$formal" status --porcelain)"
hostname
id -un
uname -m
cat /proc/sys/kernel/random/boot_id
git -C "$source" rev-parse HEAD
git -C "$formal" rev-parse HEAD
