set -eu
export PATH=/home/loosqk/.cargo/bin:/home/loosqk/.local/bin:$PATH
BASE=/home/loosqk/robot-checks/h2-serial-recovery-20260930-r1
cd "$BASE/bootstrap"
printf '%s\n' '0453236e02c3580bd4703e8a80976ae9204e2c341eaf8f9beecc25678a13866a  collect_native.py' | sha256sum -c -
exec uv run --no-project python collect_native.py --collect --base "$BASE" --out /home/loosqk/robot-checks/h2-serial-recovery-20260930-r1-evidence.tar.gz
