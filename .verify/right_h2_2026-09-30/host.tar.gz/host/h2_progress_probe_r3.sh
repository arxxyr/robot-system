set -eu
export PATH=/home/loosqk/.local/bin:$PATH
H2_PYTHON="$(uv python find 3.12)"
exec "$H2_PYTHON" - <<'END_PY'
import json
from pathlib import Path
b=Path('/home/loosqk/robot-checks/h2-serial-recovery-20260930-r1/right-h2-run-01')
r=json.loads((b/'run.json').read_text())
print(json.dumps({k:r.get(k) for k in ('status','supervisor_pid','authorization_attempts','launch_attempts','tool_pid','tool_exit','tool_naturally_reaped','failures','finished_ns')},ensure_ascii=False))
c=b/'orin_sla_right'
p=c/'attempts.jsonl'
if p.is_file():
 lines=p.read_text().splitlines();print(json.dumps({'attempt_lines':len(lines),'last_attempts':lines[-2:]},ensure_ascii=False))
for p in sorted(c.glob('*.json')):
 if p.name not in ('environment.json','rt_preflight.json'):
  print(json.dumps({'file':p.name,'bytes':p.stat().st_size,'value':json.loads(p.read_text()) if p.stat().st_size<60000 else 'LARGE'},ensure_ascii=False))
p=b/'tool.log'
if p.is_file(): print(p.read_text(errors='replace')[-2500:])
END_PY
