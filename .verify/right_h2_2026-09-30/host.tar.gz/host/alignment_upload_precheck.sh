set -eu
test ! -e /home/loosqk/robot-checks/h2-serial-recovery-20260930-r1/bootstrap/s52-alignment-r1.json
test ! -L /home/loosqk/robot-checks/h2-serial-recovery-20260930-r1/bootstrap/s52-alignment-r1.json
