set -eu
export PATH=/home/loosqk/.cargo/bin:/home/loosqk/.local/bin:$PATH
BASE=/home/loosqk/robot-checks/h2-serial-recovery-20260930-r1
SCRIPT="$BASE/bootstrap/s52-control-helper-r1/readback_serial_once.py"
test "$(sha256sum "$SCRIPT")" = "2daec821f6384bf64297d91297577fd2253db656d69d11819b3bc24a9805de91  $SCRIPT"
H2_PYTHON="$(uv python find 3.12)"
exec taskset -c 0-3 "$H2_PYTHON" "$SCRIPT" --run-sha256 c70d164b025bf8346b31c44d92098265a1f3e331a3774d47c80a714e112fb099 --cleanup-sha256 d367c28c142d93a326526634c63e53af9dec2f584bb71e713a30c968ae3a37c8 --ssh-wait-sha256 98f0f40f27e03cf57013ebdd0da8573f9b89f7899a5f5da64ca7a45c0f861f83
