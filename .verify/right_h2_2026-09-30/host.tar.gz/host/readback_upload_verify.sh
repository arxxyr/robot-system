set -eu
base=/home/loosqk/robot-checks/h2-serial-recovery-20260930-r1
for p in "$base/bootstrap/s52-control-helper-r1/readback_serial_once.py" "$base/bootstrap/s52-readback-plan-r1.json"; do
 test -f "$p"
 test ! -L "$p"
 test "$(stat -c %h "$p")" = 1
done
test "$(sha256sum "$base/bootstrap/s52-control-helper-r1/readback_serial_once.py" | cut -d ' ' -f 1)" = 2daec821f6384bf64297d91297577fd2253db656d69d11819b3bc24a9805de91
test "$(sha256sum "$base/bootstrap/s52-readback-plan-r1.json" | cut -d ' ' -f 1)" = 1966dc076d3b8f32d63ddbd173e4865c640f43e82779d8cadfbe0b89dad11f87
sha256sum "$base/bootstrap/s52-control-helper-r1/readback_serial_once.py" "$base/bootstrap/s52-readback-plan-r1.json"
