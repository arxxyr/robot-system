set -eu
export PATH=/home/loosqk/.cargo/bin:/home/loosqk/.local/bin:$PATH
export CARGO_HOME=/home/loosqk/robot-checks/viz-orin-a6957cc-20260930-r1/cargo-home
export CARGO_TARGET_DIR=/home/loosqk/robot-checks/h2-nightly-v2-20260930-r1/build
export CARGO_NET_OFFLINE=true
export RUSTUP_AUTO_INSTALL=0
export RUSTC_WRAPPER=
export CARGO_BUILD_JOBS=2
cd /home/loosqk/robot-checks/h2-serial-recovery-20260930-r1/source
rustc +nightly -Vv
cargo +nightly -V
cargo +nightly fmt --all
cargo +nightly clippy --all --all-targets -- -D warnings
git status --porcelain=v1 --untracked-files=all
rustc +nightly -Vv
