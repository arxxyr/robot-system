set -eu
export PATH=/home/loosqk/.cargo/bin:/home/loosqk/.local/bin:$PATH
H2_PYTHON="$(uv python find 3.12)"
exec taskset -c 0-3 "$H2_PYTHON" - __READBACK_SHA__ <<'END_PY'
import hashlib
import json
import os
from pathlib import Path
import stat
import subprocess
import sys
import time
sys.dont_write_bytecode = True
BASE=Path('/home/loosqk/robot-checks/h2-serial-recovery-20260930-r1')
sys.path.insert(0,str(BASE/'bootstrap/s52-control-helper-r1'))
from prelaunch_go import pinned, reference, require, tracked_driver, read_regular
ROOT=BASE/'source'
result={'schema':'P7_H2_FINAL_BOTH_BUS_GUARD_V1','read_only':True,'status':'FAIL','started_ns':time.time_ns(),'checks':[]}
def check(name,action):
 row={'name':name,'status':'FAIL','started_ns':time.time_ns()}
 result['checks'].append(row)
 try:
  row['value']=action(); row['status']='PASS'
 except Exception as error: row['error']=repr(error)
 row['finished_ns']=time.time_ns()
 return row.get('value')
def verify_readback():
 r=pinned(BASE/'register-readback-r1/result.json',sys.argv[1])
 require(r['schema']=='P7_H2_SERIAL_REGISTER_READBACK_V1' and r['read_only'] is True and r['status']=='PASS' and r['completed']==34 and len(r['steps'])==34 and not r['errors'] and not r['received_signals'] and r['original_h2_unchanged'] is True,'本次34读回不完整')
 require(all(s['status']=='PASS' and s['reaped'] is True and s['exit_code']==0 for s in r['steps']),'读回子进程未回收')
 require(all(c['reaped'] is True and c['child_end_class']=='EXIT_STATUS' and c['signals_sent']==[] for c in r['commands']),'读回命令生命周期缺项')
 return {'sha256':sys.argv[1],'completed':r['completed'],'finished_ns':r['finished_ns']}
def cmd(argv,code):
 # 只读短命令，无总超时、无信号；真实等待后保留完整输出。
 c=subprocess.run(argv,stdin=subprocess.DEVNULL,capture_output=True,check=False)
 row={'argv':argv,'exit_code':c.returncode,'stdout':c.stdout.decode(errors='replace'),'stderr':c.stderr.decode(errors='replace')}
 require(c.returncode==code and c.stderr==b'','只读命令退出或stderr错误：'+repr(row))
 return row
try:
 require(hashlib.sha256(read_regular(BASE/'bootstrap/s52-control-helper-r1/prelaunch_go.py')).hexdigest()=='8121c8e8454d5a06dfa1f828ca85417917a0cdcd756d222717af89adf1024b77','GO helper身份变化')
 driver,hashes=tracked_driver(ROOT/'scripts/run_post_e_h2.py',ROOT,'4a8e171f27bf18625973aa4f3a6097e9b9fbed18')
 result['driver_helpers']=hashes
 inputs=pinned(BASE/'bootstrap/s52-right-inputs-r1.json','541d7f463948cfb5393dbf1a8fe20be648c6e550f014caa4245d4b446dbcbff7')
 binaries=[Path(r['path']) for k in ('production','measurement') for r in reference(inputs[k])['artifacts'].values()]
 binaries += [Path(r['path']) for n,r in reference(inputs['installed'])['files'].items() if n.startswith('installed:')]
 binaries.append(BASE/'readback-tool-r1/feetech_poke')
 check('readback_result',verify_readback)
 def processes():
  value=driver.process_snapshot(-1,BASE/'right-h2-run-01',binaries)
  require(value['clean'] is True,'相关控制/读回进程残留或身份不可读')
  return value
 check('processes',processes)
 for side in ('left','right'):
  profile=driver.arm_profile(side)
  def device(profile=profile):
   row=cmd(['udevadm','info','--query=property','--name',profile.device],0)
   lines=row['stdout'].splitlines()
   for key,value in {'ID_VENDOR_ID':'1a86','ID_MODEL_ID':'55d3','ID_SERIAL_SHORT':profile.usb_serial,'ID_USB_DRIVER':'cdc_acm'}.items():
    require([l for l in lines if l.startswith(key+'=')]==[key+'='+value],'USB身份不符')
   metadata=Path(profile.device).stat()
   require(stat.S_ISCHR(metadata.st_mode) and os.access(profile.device,os.R_OK|os.W_OK),'USB类型/权限错误')
   return row
  check(side+'_device',device)
  for path in (Path(profile.device),profile.trust/'rx_trust.lock',profile.trust/'estop_latch.lock'):
   for elevated in (False,True):
    def holder(path=path,elevated=elevated):
     require(path.exists(),'持有者查询路径缺失：'+str(path))
     row=cmd((['sudo','-n'] if elevated else [])+['fuser',str(path)],1)
     require(row['stdout']=='','串口/锁仍被持有')
     return row
    check(side+'_holder_'+path.name+('_sudo' if elevated else ''),holder)
 result['status']='PASS' if len(result['checks'])==16 and all(r['status']=='PASS' for r in result['checks']) else 'FAIL'
except Exception as error: result['error']=repr(error)
result['finished_ns']=time.time_ns()
print(json.dumps(result,ensure_ascii=False,allow_nan=False),flush=True)
raise SystemExit(0 if result['status']=='PASS' else 1)
END_PY
