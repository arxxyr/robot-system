set -eu
export PATH=/home/loosqk/.cargo/bin:/home/loosqk/.local/bin:$PATH
BASE=/home/loosqk/robot-checks/h2-serial-recovery-20260930-r1
H2_PYTHON="$(uv python find 3.12)"
exec taskset -c 0-3 "$H2_PYTHON" "$BASE/bootstrap/s52-control-helper-r1/post_h2_cleanup.py"  --inputs "$BASE/bootstrap/s52-right-inputs-r1.json"  --inputs-sha256 541d7f463948cfb5393dbf1a8fe20be648c6e550f014caa4245d4b446dbcbff7  --preparation "$BASE/right-readonly-r1/run.json"  --preparation-sha256 417109c792e786ba1214a301fc1de1dcb2b375c35644a4d312ddf0d391f8fbfe  --driver "$BASE/source/scripts/run_post_e_h2.py"  --output "$BASE/right-h2-run-01"  --out "$BASE/right-h2-postread-r1"
