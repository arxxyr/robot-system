set -eu
export PATH=/home/loosqk/.local/bin:$PATH
H2_PYTHON="$(uv python find 3.12)"
exec "$H2_PYTHON" - <<'END_PY'
import json
from pathlib import Path
b=Path('/home/loosqk/robot-checks/h2-serial-recovery-20260930-r1/right-h2-run-01')
r=json.loads((b/'run.json').read_text()) if (b/'run.json').is_file() else {}
print(json.dumps({'run_exists':b.exists(),'status':r.get('status'),'supervisor_pid':r.get('supervisor_pid'),'authorization_attempts':r.get('authorization_attempts'),'launch_attempts':r.get('launch_attempts'),'tool_pid':r.get('tool_pid'),'tool_exit':r.get('tool_exit'),'tool_naturally_reaped':r.get('tool_naturally_reaped'),'failures':r.get('failures',[]),'report':r.get('report'),'finished_ns':r.get('finished_ns')},ensure_ascii=False))
for p in sorted(b.glob('*.json')):
 if p.name not in ('run.json',):
  try:
   d=json.loads(p.read_text());print(json.dumps({'file':p.name,'status':d.get('status'),'success':d.get('success'),'result':d.get('result')},ensure_ascii=False))
  except Exception as e: print(json.dumps({'file':p.name,'error':repr(e)}))

for p in sorted(b.glob('orin_sla*/*')):
 if p.is_file():
  print(json.dumps({'case_file':str(p.relative_to(b)),'bytes':p.stat().st_size}))
  if p.suffix=='.json' and p.stat().st_size<60000:
   print(p.read_text()[:4000])
p=b/'tool.log'
if p.is_file():
 print(p.read_text(errors='replace')[-5000:])
END_PY
