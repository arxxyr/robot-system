set -eu
export PATH=/home/loosqk/.cargo/bin:/home/loosqk/.local/bin:$PATH
hostname
id -un
uname -smr
cat /proc/sys/kernel/random/boot_id
git -C /home/loosqk/repo/robot/robot-system rev-parse HEAD
git -C /home/loosqk/repo/robot/robot-system status --porcelain=v1 --untracked-files=all
sha256sum /home/loosqk/repo/robot/robot-system/target/release/s0_daemon /home/loosqk/repo/robot/robot-system/target/release/xlerobot_deploy /home/loosqk/repo/robot/robot-system/target/release/s1_daemon /home/loosqk/repo/robot/robot-system/target/release/robot_rpc_gateway
systemctl show xlerobot-s0-left-arm.service xlerobot-s0-right-arm.service xlerobot-s1-left.service xlerobot-s1-right.service xlerobot-gateway-left.service xlerobot-gateway-right.service -p Id -p LoadState -p ActiveState -p SubState -p MainPID
pgrep -af '(^|/)(s0_daemon|s1_daemon|robot_rpc_gateway|comm_fault_e2e)( |$)' || test "$?" -eq 1
rustc +nightly -Vv
df -B1 /home/loosqk
