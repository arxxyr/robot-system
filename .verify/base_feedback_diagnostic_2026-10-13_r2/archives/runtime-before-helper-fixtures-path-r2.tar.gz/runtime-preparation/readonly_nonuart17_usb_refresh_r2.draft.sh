#!/bin/bash
set -eu
export PYTHONDONTWRITEBYTECODE=1
exec /home/loosqk/.local/share/uv/python/cpython-3.12.13-linux-aarch64-gnu/bin/python3 - <<'PYREMOTE'
import base64,hashlib,json,os,subprocess,time
from pathlib import Path
FIELD_STAMP=None
FIELD_EXPECTED=None
assert type(FIELD_STAMP) is int and FIELD_STAMP>0 and isinstance(FIELD_EXPECTED,tuple) and len(FIELD_EXPECTED)==2, '爸爸，本轮恢复供电和新现场确认未绑定，零child/文件I/O。'
assert 0<=time.time_ns()-FIELD_STAMP<600_000_000_000, '爸爸，本轮新现场确认过期；不刷新或沿用旧确认。'
legacy=Path('/home/loosqk/robot-checks/position-return-20261010-r1');phase=Path('/home/loosqk/robot-checks/base-feedback-diagnostic-r2');probe=legacy/'normal-read-r4/nonuart_probe_r4.sh'
phase.mkdir(mode=0o700,exist_ok=False)
assert hashlib.sha256(probe.read_bytes()).hexdigest()=='e3962ec7841a9d5ed783ca8279ed718c8f29ed718701de528c226f0588b91527'
started=time.time_ns();c=subprocess.Popen(['bash',str(probe)],stdin=subprocess.DEVNULL,stdout=subprocess.PIPE,stderr=subprocess.PIPE);a,b=c.communicate();code=c.wait();finished=time.time_ns()
values={'usb-refresh-nonuart-r2.stdout':a,'usb-refresh-nonuart-r2.stderr':b}
r={'field_stamp':FIELD_STAMP,'field_expected':FIELD_EXPECTED,'field_scope':'CURRENT_POWER_ON_AND_SUSPENDED_WHEELS_READONLY_READY','pid':c.pid,'started_ns':started,'finished_ns':finished,'exit_code':code,'wait_returncode':code,'reaped':True,'signals_sent':[],'argv':['bash',str(probe)]}
for name,raw in values.items():
 with (phase/name).open('xb') as f:f.write(raw);f.flush();os.fsync(f.fileno())
 r[name]={'sha256':hashlib.sha256(raw).hexdigest(),'bytes':len(raw)}
rr=(json.dumps(r,ensure_ascii=False,indent=2)+'\n').encode()
with (phase/'usb-refresh-nonuart-r2.receipt.json').open('xb') as f:f.write(rr);f.flush();os.fsync(f.fileno())
assert code==0 and b==b'';assert 0<=time.time_ns()-FIELD_STAMP<600_000_000_000;v=json.loads(a);assert v['status']=='PASS_NON_UART_CURRENT_FACTS' and len(v['checks'])==17 and all(x['status']=='PASS' for x in v['checks']) and v['uart_open_or_read'] is False and v['hardware_writes']==0 and v['identity_before']==v['identity_after'] and v['files_before']==v['files_after']
print(json.dumps({'status':'PASS_NONUART17_USB_REFRESH_ORIGINALS','receipt':r,'stdout_base64':base64.b64encode(a).decode(),'receipt_base64':base64.b64encode(rr).decode(),'UART':0},ensure_ascii=False),flush=True)
PYREMOTE
