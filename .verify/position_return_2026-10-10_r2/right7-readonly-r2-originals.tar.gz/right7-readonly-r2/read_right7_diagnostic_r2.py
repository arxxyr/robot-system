# 下轮固定35次right7原帧诊断；复用既有RealExecutor，不写寄存器，不运动，不重试。
import fcntl, hashlib, importlib.util, json, os, signal, stat, sys, time
from pathlib import Path
sys.dont_write_bytecode=True
BASE=Path('/home/loosqk/robot-checks/position-return-20261010-r1/right7-readonly-r2')
C=json.loads((BASE/'config.json').read_bytes())
assert (C['files']['read_raw_13c97115']['path'],C['files']['read_raw_13c97115']['sha256'],C['files']['read_raw_13c97115']['bytes'])==('/home/loosqk/robot-checks/h2-right-ready-20261009-r1/readback-tool-r1/feetech_poke','13c97115b89d9f8780ea8b9cac80a091ddcc2b73549d34b2d5cbad83c718ffe1',1510912),'冻结raw工具身份不符'
OUT=BASE/'evidence'
# 默认仅输出固定清单，不创建执行目录或触UART。
DIAGNOSTICS=('Model_Number','Firmware_Major_Version','Firmware_Minor_Version','Operating_Mode','Phase','Present_Position','Goal_Velocity','Present_Velocity')
PLANNED=[(side,motor,'Torque_Enable') for side,count in (('left',8),('right',9)) for motor in range(1,count+1)]
PLANNED += [('right',7,reg) for reg in DIAGNOSTICS]
PLANNED += [('right',7,reg) for group in range(5) for reg in ('Present_Position','Present_Velocity')]
if sys.argv[1:]!=['--execute']:
 require_plan_only=sys.argv[1:] in ([],['--plan-only'])
 if not require_plan_only:raise ValueError('仅--plan-only或root明确--execute')
 print(json.dumps({'status':'PLAN_ONLY','tool':C['files']['read_raw_13c97115'],'uart_commands':35,'fixed_reads':PLANNED,'five_group_interval_ms':50,'source_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'hardware_writes':0,'uart_open_or_read':False,'physical':None,'go_created':False,'capture_pass_is_stop_pass':False},ensure_ascii=False,indent=2))
 sys.exit(0)
OUT.mkdir()
SOURCE=Path('/home/loosqk/robot-checks/h2-exit-observation-20261009-r1/source/scripts/run_hardware_maintenance.py')
SOURCE_SHA='dc12de3b2f00f506213c47441f4cceec2f4d534e308e87a65e98167aaaabacfa'
meta={'Torque_Enable':(40,1),'Model_Number':(3,2),'Firmware_Major_Version':(0,1),'Firmware_Minor_Version':(1,1),'Operating_Mode':(33,1),'Phase':(18,1),'P_Coefficient':(21,1),'D_Coefficient':(22,1),'I_Coefficient':(23,1),'CW_Dead_Zone':(26,1),'CCW_Dead_Zone':(27,1),'Goal_Position':(42,2),'Present_Position':(56,2),'Goal_Velocity':(46,2),'Present_Velocity':(58,2),'Lock':(55,1),'Min_Position_Limit':(9,2),'Max_Position_Limit':(11,2),'Homing_Offset':(31,2)}
result={'status':'RUNNING','pid':os.getpid(),'started_ns':time.time_ns(),'nonuart_snapshot_reference':{k:v for k,v in C.items() if k.startswith('nonuart_snapshot_')},'field_confirmation':C.get('field_confirmation'),'readouts':[],'register_writes':0,'motion_commands':0,'errors':[],'source':{'path':str(SOURCE),'sha256':SOURCE_SHA},'tool':C['files']['read_raw_13c97115']}
locks=[]; io=None

def require(value,text):
 if not value:raise ValueError(text)

def identities():
 require(Path('/proc/sys/kernel/random/boot_id').read_text().strip()==C['boot_id'],'boot变化')
 files={}
 for name,ref in C['files'].items():
  p=Path(ref['path']);s=p.lstat();raw=p.read_bytes()
  row={'path':str(p),'sha256':hashlib.sha256(raw).hexdigest(),'bytes':len(raw),'uid':s.st_uid,'gid':s.st_gid,'mode':stat.S_IMODE(s.st_mode),'device':s.st_dev,'inode':s.st_ino,'mtime_ns':s.st_mtime_ns,'ctime_ns':s.st_ctime_ns,'elf_machine':int.from_bytes(raw[18:20],'little')}
  require(stat.S_ISREG(s.st_mode) and row==ref,'ELF身份变化:'+name); files[name]=row
 for side,ref in C['devices'].items():
  p=Path(ref['device']);s=p.stat();ls=p.lstat()
  require(stat.S_ISCHR(s.st_mode) and stat.S_ISLNK(ls.st_mode) and str(p.resolve())==ref['resolved'] and s.st_rdev==ref['rdev'] and s.st_ino==ref['device_inode'] and ls.st_ino==ref['link_inode'],'USB身份变化:'+side)
 require(hashlib.sha256(SOURCE.read_bytes()).hexdigest()==SOURCE_SHA,'既有Executor源码变化')
 return {'boot_id':C['boot_id'],'files':files,'devices':C['devices']}

def protection():
 rows={}
 for side in ('left','right'):
  for name in ('rx_trust.lock','estop_latch.lock','rx_trust_marker','rx_trust_marker.bak','estop_latch','estop_latch.bak'):
   p=Path('/var/lib/robot/xlerobot_'+side)/name
   if not p.exists():
    require(not p.is_symlink(),'保护符号链接');rows[str(p)]={'exists':False};continue
   fd=os.open(p,os.O_RDONLY|os.O_NOFOLLOW)
   with os.fdopen(fd,'rb') as f:s=os.fstat(f.fileno());raw=f.read()
   require(stat.S_ISREG(s.st_mode),'保护文件类型')
   rows[str(p)]={'exists':True,'sha256':hashlib.sha256(raw).hexdigest(),'bytes':len(raw),'uid':s.st_uid,'gid':s.st_gid,'mode':stat.S_IMODE(s.st_mode),'inode':s.st_ino,'raw_hex':raw.hex()}
 return rows

try:
 result['identity_before']=identities()
 spec=importlib.util.spec_from_file_location('maintenance_readonly_existing',SOURCE);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
 io=m.RealExecutor(C['files']['read_raw_13c97115'],OUT)
 for sig in (signal.SIGINT,signal.SIGTERM,signal.SIGHUP,signal.SIGQUIT):signal.signal(sig,io.mark_signal)
 result['protection_before']=protection()
 for side in ('left','right'):
  for name in ('rx_trust.lock','estop_latch.lock'):
   fd=os.open('/var/lib/robot/xlerobot_'+side+'/'+name,os.O_RDONLY|os.O_NOFOLLOW);locks.append(fd);fcntl.flock(fd,fcntl.LOCK_EX|fcntl.LOCK_NB)
 rows=PLANNED
 require(len(rows)==35,'固定35项集合错误')
 for seq,(side,motor,reg) in enumerate(rows,1):
  if seq in (28,30,32,34):io.sleep(0.05)
  m.verify_ref(C['files']['read_raw_13c97115'],executable=True)
  device=C['devices'][side]['device'];argv=[C['files']['read_raw_13c97115']['path'],device,str(motor),'read-raw',reg]
  text=io.command(argv);require(len(text.splitlines())==1,'结果行数错误');j=m.strict_json(text);addr,width=meta[reg]
  keys={'operation','serial_device','motor_id','register','requested_register_address','width','raw_unsigned','tx','rx'}
  require(set(j)==keys and (j['operation'],j['serial_device'],j['motor_id'],j['register'],j['requested_register_address'],j['width'])==('sync_read',device,motor,reg,addr,width),'JSON身份不一致')
  tx=[255,255,254,5,130,addr,width,motor];tx.append((~sum(tx[2:]))&255);rx=j['rx'];raw=j['raw_unsigned']
  require(type(raw) is int and j['tx']==tx and type(rx) is list and all(type(v) is int and 0<=v<=255 for v in rx) and len(rx)==6+width and rx[:5]==[255,255,motor,width+2,0] and (sum(rx[2:])&255)==255 and int.from_bytes(bytes(rx[5:5+width]),'little')==raw,'原帧校验错误')
  result['readouts'].append({'seq':seq,'side':side,'motor_id':motor,'register':reg,'raw':j,'command_sequence':io.sequence,'started_monotonic_ns':io.commands[-1]['started_ns'],'finished_monotonic_ns':io.commands[-1]['finished_ns'],'observation_group':(seq-26)//2+1 if seq>=26 else None})
  print(json.dumps({'seq':seq,'side':side,'motor_id':motor,'register':reg,'raw_unsigned':raw},ensure_ascii=False),flush=True)
  require(reg!='Torque_Enable' or raw==0,'TE非零，停止后续读取，请现场立即断电')
  require(reg!='Model_Number' or raw==777,'目标型号不是777')
  require(reg!='Operating_Mode' or raw==1,'right7不是预期模式1')
 require(len(result['readouts'])==35,'输出不足35项')
except BaseException as error:
 result['errors'].append(repr(error));print('爸爸，只读批次失败，停止后续UART，不自动重试：'+repr(error),flush=True)
finally:
 for name,fn in (('identity_after',identities),('protection_after',protection)):
  try:result[name]=fn()
  except BaseException as error:result['errors'].append(name+':'+repr(error))
 if result.get('protection_before')!=result.get('protection_after'):result['errors'].append('保护文件前后变化')
 for fd in reversed(locks):os.close(fd)
 if io is not None:
  result['commands']=io.commands;result['received_signal']=io.interrupted;result['evidence_errors']=io.evidence_errors;io.journal.close()
  if io.interrupted or io.evidence_errors:result['errors'].append('收到信号/证据错误')
 result['stop_verification']='NOT_FULL_17_MOTOR_STOP_VERIFICATION'
 result['right7_velocity_nonzero_observed']=[v['seq'] for v in result['readouts'] if v['side']=='right' and v['motor_id']==7 and v['register'] in ('Present_Velocity','Goal_Velocity') and v['raw']['raw_unsigned']!=0]
 result['finished_ns']=time.time_ns();result['status']='FAIL' if result['errors'] else 'PASS_DIAGNOSTIC_CAPTURE_35'
 with (BASE/'result.json.tmp').open('x') as f:json.dump(result,f,ensure_ascii=False,indent=2);f.write('\n');f.flush();os.fsync(f.fileno())
 (BASE/'result.json.tmp').rename(BASE/'result.json')
 print(json.dumps({'terminal':True,'status':result['status'],'readouts':len(result['readouts']),'child_count':len(result.get('commands',[])),'errors':result['errors']},ensure_ascii=False),flush=True)
sys.exit(1 if result['errors'] else 0)
