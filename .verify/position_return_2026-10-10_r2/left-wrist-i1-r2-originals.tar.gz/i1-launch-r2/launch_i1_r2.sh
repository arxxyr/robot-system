#!/bin/bash
set -eu
export PYTHONDONTWRITEBYTECODE=1
tmux set-option -w -t "$TMUX_PANE" remain-on-exit on
exec /home/loosqk/.local/share/uv/python/cpython-3.12.13-linux-aarch64-gnu/bin/python3 /home/loosqk/robot-checks/position-return-20261010-r1/next-preparation-r2/i1_trial_left5_candidate_r1.py --maintenance /home/loosqk/robot-checks/position-return-20261010-r1/software-facts-r1/scripts/run_hardware_maintenance.py --bindings /home/loosqk/robot-checks/position-return-20261010-r1/maintenance_bindings_i1_r3.json --output /home/loosqk/robot-checks/position-return-20261010-r1/left-wrist-i1-r2 --run-id left-wrist-i1-r2 --artifact-root /home/loosqk/robot-checks/position-return-20261010-r1 --execute --approval /home/loosqk/robot-checks/position-return-20261010-r1/left-wrist-i1-r2.go.json > /home/loosqk/robot-checks/position-return-20261010-r1/i1-launch-r2/driver.log 2>&1
