set -eu
export PATH=/home/loosqk/.cargo/bin:/home/loosqk/.local/bin:$PATH
export CARGO_HOME=/home/loosqk/robot-checks/viz-orin-a6957cc-20260930-r1/cargo-home
export CARGO_NET_OFFLINE=true
export RUSTUP_AUTO_INSTALL=0
export PYTHONDONTWRITEBYTECODE=1
test "$(hostname)" = ubuntu
test "$(id -u)" = 1000
test "$(id -g)" = 1000
test "$(cat /proc/sys/kernel/random/boot_id)" = 6cf7ee3e-a3c5-4c91-80bc-4ca924818b53
BASE=/home/loosqk/robot-checks/feetech-diagnostic-b0-20260930-r2
cd "$BASE/bootstrap"
printf '%s\n' '00f87e857e2ac6070de67ba615f194383b8e01b0ffc38c96ce930cebf9fe0513  feetech_poke.rs' '267aac059e9b258bf108f1e3d0004e0fa8668f7b86ec420fe3503f470b18440d  bus.rs' 'f4155b2a4f71aec7489ca724a90cc2865219a9920ba4a51494d2267298335e8c  diagnostic.rs' 'd3d4c8c005d712f124755ce8c3530ff93b1302855f07b9ec915e04c887a276c5  error.rs' 'b7d40b8ae3557632c6996fbbc52a76c4e5dc508d8cc217abc28a39a4c13bbb36  registers.rs' '8c49aded71bc718ee03487e5ae5fc1a59b6cf1358e099ed9d899f802234e4488  base.rs' 'a919d5f6dc30d51b9a674a28b541025d0503381cde746e6ff52feed58112ebd1  lib.rs' 'de8493354c87c994082308b6595fd6016d32f4e733d855575a7805e875ce9c68  run_checks.py' 'e96e7a235988fd63507cbe4cc20c2c7ec12ccbb6bd23b086bb687c82353c0f87  run_release_v2.py' 'dad9bbc9405b8fac4d60d6efe794b36750e6a6f9ce9fdeba3debf7d3e1b9a471  run_release_v2.original.py' 'ed5f1a7276ae84d90358956d76a93caf6a14367ecdcd59fa3d818ece338466e7  run_release_v2.diff' '645f09c416f5a0b2100788ea8fba8fece4e100407e94de1d9b9c0d3991825259  expected_source.json' '297200ba469f7c3cf9c0398d9d72af2ee34fbd5233da0f7b2e7a149fdd52ca2a  frozen_inputs.json' 'ebe7ffe178339b1b6031ed8f01287f204e48fc6c5954dd5cc7655ec27954e67d  expected_tests.json' '6182957d1931fe3154447492e92c615f83b75c1665ff427d8bd12d8393109d67  preservation_pins.json' | sha256sum -c -
test "$(git -C "$BASE/source" rev-parse HEAD)" = 1c5758f97b7c502a38c850e8352ce970216bea53
test -z "$(git -C "$BASE/source" status --porcelain=v1 --untracked-files=all)"
test ! -e "$BASE/source/crates/robot-kinematics-xlerobot/src/base.rs"
cp feetech_poke.rs "$BASE/source/crates/robot-adapters/feetech/examples/feetech_poke.rs"
cp bus.rs "$BASE/source/crates/robot-adapters/feetech/src/bus.rs"
cp diagnostic.rs "$BASE/source/crates/robot-adapters/feetech/src/diagnostic.rs"
cp error.rs "$BASE/source/crates/robot-adapters/feetech/src/error.rs"
cp registers.rs "$BASE/source/crates/robot-adapters/feetech/src/registers.rs"
cp base.rs "$BASE/source/crates/robot-kinematics-xlerobot/src/base.rs"
cp lib.rs "$BASE/source/crates/robot-kinematics-xlerobot/src/lib.rs"
exec taskset -c 0-3 uv run --no-project python run_checks.py
