set -eu
export PATH=/home/loosqk/.cargo/bin:/home/loosqk/.local/bin:$PATH
export CARGO_HOME=/home/loosqk/robot-checks/viz-orin-a6957cc-20260930-r1/cargo-home
export CARGO_NET_OFFLINE=true
export RUSTUP_AUTO_INSTALL=0
export PYTHONDONTWRITEBYTECODE=1
cd /home/loosqk/robot-checks/feetech-diagnostic-b0-20260930-r2/bootstrap
printf '%s\n' 'ca35ae7d7169ec81d0dc8745eab7bcee714eac0734ecdbd3f78cf6c9de5b1d83  collect_native.py' | sha256sum -c -
exec uv run --no-project python collect_native.py --base /home/loosqk/robot-checks/feetech-diagnostic-b0-20260930-r2 --out /home/loosqk/robot-checks/feetech-diagnostic-b0-20260930-native-r2.tar.gz --collect
