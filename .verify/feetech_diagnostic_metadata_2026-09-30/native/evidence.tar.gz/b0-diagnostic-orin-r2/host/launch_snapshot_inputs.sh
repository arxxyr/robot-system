set -eu
export PATH=/home/loosqk/.cargo/bin:/home/loosqk/.local/bin:$PATH
export CARGO_HOME=/home/loosqk/robot-checks/viz-orin-a6957cc-20260930-r1/cargo-home
export CARGO_NET_OFFLINE=true
export RUSTUP_AUTO_INSTALL=0
export PYTHONDONTWRITEBYTECODE=1
cd /home/loosqk/robot-checks/feetech-diagnostic-b0-20260930-r2/bootstrap
printf '%s\n' '01e52e59f3791b7f9a742766b46f8122f92253aff7a38b747d22097f9d5f802a  snapshot_inputs.py' | sha256sum -c -
exec uv run --no-project python snapshot_inputs.py
