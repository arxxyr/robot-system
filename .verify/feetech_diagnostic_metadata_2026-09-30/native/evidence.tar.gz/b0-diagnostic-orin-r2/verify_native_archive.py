"""逐项验证本轮原件包并安全解包；不执行包内代码或ELF。"""
import hashlib,json,stat,tarfile
from pathlib import Path,PurePosixPath
BASE=Path(__file__).resolve().parent;OUT=BASE/'native-extracted';ARCHIVE=BASE/'native-evidence.tar.gz';INDEX=BASE/'native-evidence.index.json';META=BASE/'native-evidence.metadata.json'
def require(ok,message):
    if not ok:raise ValueError(message)
def sha(path):
    with path.open('rb') as stream:return hashlib.file_digest(stream,'sha256').hexdigest()
meta=json.loads(META.read_text());require(meta['status']=='PASS','远端collector未通过')
require(sha(ARCHIVE)==meta['archive_sha256'] and ARCHIVE.stat().st_size==meta['archive_bytes'],'下载archive身份不符')
require(sha(INDEX)==meta['index_sha256'],'下载index身份不符');raw=INDEX.read_bytes();index=json.loads(raw)
require(index['schema']=='P7_NATIVE_EVIDENCE_INDEX_V1','index schema错');files={r['path']:r for r in index['files']};directories={r['path']:r for r in index['directories']};require(len(files)==len(index['files']) and len(directories)==len(index['directories']) and not (set(files)&set(directories)),'索引重复');seen=set();OUT.mkdir()
with tarfile.open(ARCHIVE,'r:gz') as archive:
    for member in archive:
        name=member.name;p=PurePosixPath(name);require(not p.is_absolute() and '..' not in p.parts and str(p)==name and name not in seen,'路径错误或重复');seen.add(name);dest=OUT/name
        if name in directories:
            require(member.isdir() and member.mode==directories[name]['mode'],'目录类型/mode不同');dest.mkdir(parents=True,exist_ok=True);dest.chmod(member.mode);continue
        require(member.isfile() and not member.issym() and not member.islnk(),'非普通成员');stream=archive.extractfile(member);require(stream is not None,'无法读取成员');content=stream.read(member.size+1)
        if name=='archive-index.json':require(content==raw,'内外index不同');expected={'bytes':len(raw),'mode':0o644}
        else:
            require(name in files,'未索引成员');expected=files[name];require(len(content)==expected['bytes'] and hashlib.sha256(content).hexdigest()==expected['sha256'],'bytes/SHA不同:'+name);require(member.uid==expected['uid'] and member.gid==expected['gid'],'原属主数字不同')
        require(member.size==expected['bytes'] and member.mode==expected['mode'],'size/mode不同:'+name);dest.parent.mkdir(parents=True,exist_ok=True)
        with dest.open('xb') as stream:stream.write(content)
        dest.chmod(member.mode);require(sha(dest)==hashlib.sha256(content).hexdigest() and stat.S_IMODE(dest.stat().st_mode)==member.mode,'解包读回不同')
require(seen==set(files)|set(directories)|{'archive-index.json'},'有漏项/额外成员')
source=json.loads((OUT/'qa-r1/source_before.json').read_text());require(len(source['files'])==590 and source['source_manifest_sha256']=='e81e417ea5adca3de92db7d1d72c363d180656af25e0e733b3fcc9e70a3e4fed','source身份错误')
for name,item in source['files'].items():
    path=OUT/'source-inputs-r1/files'/name;require(sha(path)==item['sha256'] and path.stat().st_size==item['bytes'] and bool(path.stat().st_mode&0o111)==item['executable'],'590副本不同:'+name)
require({p.relative_to(OUT/'source-inputs-r1/files').as_posix() for p in (OUT/'source-inputs-r1/files').rglob('*') if p.is_file()}==set(source['files']),'副本集合不同')
result={'status':'PASS','indexed_files':len(files),'directories':len(directories),'tar_members':len(seen),'archive_sha256':sha(ARCHIVE),'archive_bytes':ARCHIVE.stat().st_size,'index_sha256':sha(INDEX),'source_files':590,'aggregate':source['source_manifest_sha256'],'all_bytes_sha_mode_verified':True,'extracted':str(OUT),'scope':'原件完整性和安全解包，不代表硬件或测试新增通过。'}
with (BASE/'native_archive_verification.json').open('x') as stream:json.dump(result,stream,ensure_ascii=False,indent=2);stream.write('\n')
print(json.dumps(result,ensure_ascii=False))
