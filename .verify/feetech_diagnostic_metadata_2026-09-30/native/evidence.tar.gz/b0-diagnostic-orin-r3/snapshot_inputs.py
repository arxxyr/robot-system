"""仅复制本轮590编译输入并核对前后身份；不运行硬件或修改原源码。"""
import hashlib,importlib.util,json,os,signal,stat,sys
from pathlib import Path
from types import SimpleNamespace
sys.dont_write_bytecode=True
BASE=Path('/home/loosqk/robot-checks/feetech-diagnostic-b0-20260930-r3');SOURCE=BASE/'source';OUT=BASE/'source-inputs-r1';HEAD='1c5758f97b7c502a38c850e8352ce970216bea53'
def module(name,path):
    spec=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);return m
helper=module('input_runner',BASE/'bootstrap/run_release_v2.py');a=module('input_artifacts',SOURCE/'scripts/post_e_h2_artifacts.py');OUT.mkdir()
options=SimpleNamespace(source=SOURCE,out=OUT,target=BASE/'build',build_head=HEAD,formal_root=Path('/home/loosqk/repo/robot/robot-system'));runner=helper.Runner(options,a)
result={'status':'FAIL','scope':'590编译输入原文副本；不代表新测试或硬件通过。','self_sha256':a.sha256(Path(__file__)),'receipts':[]};before=None;old={}
def interrupted(signum,frame):helper.INTERRUPTED=signum
def identity(info):return (info.st_dev,info.st_ino,info.st_mode,info.st_size,info.st_mtime_ns,info.st_ctime_ns)
def source(label):
    _,p=runner.command(label+'_head',['git','rev-parse','HEAD']);a.require(Path(p['stdout']).read_text().strip()==HEAD,'HEAD不同')
    _,p=runner.command(label+'_status',['git','status','--porcelain=v1','--untracked-files=all']);a.require(Path(p['stdout']).read_text()==' M crates/robot-adapters/feetech/examples/feetech_poke.rs\n M crates/robot-adapters/feetech/src/bus.rs\n M crates/robot-adapters/feetech/src/diagnostic.rs\n M crates/robot-adapters/feetech/src/error.rs\n M crates/robot-adapters/feetech/src/registers.rs\n M crates/robot-kinematics-xlerobot/src/lib.rs\n?? crates/robot-kinematics-xlerobot/src/base.rs\n','范围不同')
    _,p=runner.command(label+'_files',['git','ls-files','-z','--cached','--others','--exclude-standard']);names=Path(p['stdout']).read_text().rstrip('\0').split('\0');value=a.snapshot_source(SOURCE,names);a.require(value==a.strict_json((BASE/'bootstrap/expected_source.json').read_text()),'不是冻结590');helper.save(OUT/(label+'.json'),value);return value
try:
    for sig in (signal.SIGTERM,signal.SIGINT,signal.SIGHUP):old[sig]=signal.signal(sig,interrupted)
    before=source('source_before');a.require(before==a.strict_json((BASE/'qa-r1/source_before.json').read_text()),'源与release不一致');a.require(len(before['files'])==590,'输入数错误')
    for name,item in before['files'].items():
        a.require(helper.INTERRUPTED is None,'收到信号，停止后续副本')
        src=SOURCE/name;dest=OUT/'files'/name;info=src.lstat();a.require(stat.S_ISREG(info.st_mode) and src.resolve()==src,'不是普通原文件')
        fd=os.open(src,os.O_RDONLY|os.O_NOFOLLOW)
        with os.fdopen(fd,'rb') as stream:
            first=os.fstat(stream.fileno());a.require((first.st_dev,first.st_ino,first.st_size,first.st_mtime_ns,first.st_ctime_ns,first.st_mode)==(info.st_dev,info.st_ino,info.st_size,info.st_mtime_ns,info.st_ctime_ns,info.st_mode),'打开身份改变')
            data=stream.read(item['bytes']+1);last=os.fstat(stream.fileno());a.require(identity(first)==identity(last),'读取身份改变')
        a.require(identity(src.lstat())==identity(info) and len(data)==item['bytes'] and hashlib.sha256(data).hexdigest()==item['sha256'],'原文变化')
        a.require(bool(stat.S_IMODE(info.st_mode)&0o111)==item['executable'],'可执行位不同');dest.parent.mkdir(parents=True,exist_ok=True)
        with dest.open('xb') as stream:stream.write(data)
        dest.chmod(stat.S_IMODE(info.st_mode));a.require(a.sha256(dest)==item['sha256'] and dest.stat().st_size==item['bytes'] and stat.S_IMODE(dest.stat().st_mode)==stat.S_IMODE(info.st_mode),'副本读回不同')
    result.update(status='PASS',files=590,aggregate=before['source_manifest_sha256'])
except BaseException as error:result['error']=repr(error)
finally:
    try:
        after=source('source_after');a.require(before is not None and after==before,'副本后源码变化');result['source_before_after_equal']=True
    except BaseException as error:result.update(status='FAIL',source_after_error=repr(error))
    result['receipts']=runner.receipts;helper.save(OUT/'result.json',result)
    for sig,handler in old.items():signal.signal(sig,handler)
print(json.dumps(result,ensure_ascii=False),flush=True);raise SystemExit(0 if result['status']=='PASS' else 1)
