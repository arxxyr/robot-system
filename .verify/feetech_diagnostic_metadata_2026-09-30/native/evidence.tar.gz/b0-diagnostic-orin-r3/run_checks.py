"""仅验证B0诊断元数据与拒写软件候选；历史源/冻结件/包只读核验。"""
import hashlib,importlib.util,json,os,re,signal,sys
from pathlib import Path
from types import SimpleNamespace
sys.dont_write_bytecode=True
BASE=Path('/home/loosqk/robot-checks/feetech-diagnostic-b0-20260930-r3');SOURCE=BASE/'source';OUT=BASE/'qa-r1';CACHE=BASE/'build';OLD=Path('/home/loosqk/robot-checks/h2-trace-owner-v2-20260930-r1');HEAD='1c5758f97b7c502a38c850e8352ce970216bea53'
STATUS=' M crates/robot-adapters/feetech/examples/feetech_poke.rs\n M crates/robot-adapters/feetech/src/bus.rs\n M crates/robot-adapters/feetech/src/diagnostic.rs\n M crates/robot-adapters/feetech/src/error.rs\n M crates/robot-adapters/feetech/src/registers.rs\n M crates/robot-kinematics-xlerobot/src/lib.rs\n?? crates/robot-kinematics-xlerobot/src/base.rs\n'
def module(name,path):
    spec=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);return m
helper=module('base_runner',BASE/'bootstrap/run_release_v2.py');a=module('base_artifacts',SOURCE/'scripts/post_e_h2_artifacts.py');require=a.require;require(a.sha256(BASE/'bootstrap/run_release_v2.py')=='e96e7a235988fd63507cbe4cc20c2c7ec12ccbb6bd23b086bb687c82353c0f87','helper身份不同');OUT.mkdir();r=None
expected=a.strict_json((BASE/'bootstrap/expected_source.json').read_text());inputs=a.strict_json((BASE/'bootstrap/frozen_inputs.json').read_text());original_source=a.strict_json((OLD/'release-r1/source_before.json').read_text());pins=a.strict_json((BASE/'bootstrap/preservation_pins.json').read_text());test_names=a.strict_json((BASE/'bootstrap/expected_tests.json').read_text());result={'status':'FAIL','scope':'B0诊断只读元数据与拒写纯软件QA；非新硬件/全workspace/H2六配方。','self_sha256':a.sha256(Path(__file__)),'native_git_head':HEAD,'main_integration_head':'d5ac7aa7acaa11bef1d318e762d17a4443718120','receipts':[]};old={};before=None;original=None;compiler=None

def interrupted(signum,frame):helper.INTERRUPTED=signum
def candidate_source(label):
    _,p=r.command(label+'_head',['git','rev-parse','HEAD']);require(Path(p['stdout']).read_text().strip()==HEAD,'HEAD非1c')
    _,p=r.command(label+'_status',['git','status','--porcelain=v1','--untracked-files=all']);require(Path(p['stdout']).read_text()==STATUS,'候选改动范围变化')
    _,p=r.command(label+'_files',['git','ls-files','-z','--cached','--others','--exclude-standard']);names=Path(p['stdout']).read_text().rstrip('\0').split('\0');value=a.snapshot_source(SOURCE,names);require(value==expected and len(value['files'])==590,'590输入不匹配')
    for name,pinned in inputs.items():require(value['files'][name]['sha256']==pinned['sha256'] and value['files'][name]['bytes']==pinned['bytes'],'冻结七文件变化')
    helper.save(OUT/(label+'.json'),value);return value

def originals(label):
    _,p=r.command(label+'_old_head',['git','-C',str(OLD/'source'),'rev-parse','HEAD']);require(Path(p['stdout']).read_text().strip()==HEAD,'原源HEAD变化')
    _,p=r.command(label+'_old_status',['git','-C',str(OLD/'source'),'status','--porcelain=v1','--untracked-files=all']);require(Path(p['stdout']).read_bytes()==b'','原源非clean')
    source=a.snapshot_source(OLD/'source',list(original_source['files']));require(source==original_source,'原589源变化');files={}
    for kind in ('production','measurement'):
        manifest=a.strict_json((OLD/'release-r1'/f'{kind}.json').read_text());a.validate_artifact_set(manifest,source_manifest=source,expected_kind=kind,expected_head=HEAD)
        for name,item in manifest['artifacts'].items():files[kind+'/'+name]=a.elf_identity(item['path'])
        for name in (f'{kind}.json',):files['release/'+name]={'sha256':a.sha256(OLD/'release-r1'/name),'bytes':(OLD/'release-r1'/name).stat().st_size}
    for name in ('result.json','source_before.json','source_after.json'):files['release/'+name]={'sha256':a.sha256(OLD/'release-r1'/name),'bytes':(OLD/'release-r1'/name).stat().st_size}
    for name in ('h2-trace-owner-v2-20260930-native-r1.tar.gz','h2-maintenance-precommit-20260930-native-r1.tar.gz'):
        for suffix in ('','.index.json','.metadata.json'):
            path=OLD.parent/(name+suffix);files[name+suffix]={'sha256':a.sha256(path),'bytes':path.stat().st_size}
    for root,value in pins['math_sources'].items():require(a.snapshot_source(Path(root),list(value['files']))==value,'旧数学源码变化')
    for name,pinned in pins['files'].items():
        path=Path(name);value={'sha256':a.sha256(path),'bytes':path.stat().st_size};require(value==pinned,'旧数学原件变化:'+name);files[name]=value
    value={'source':source,'files':files,'preserved_sources_unchanged':True};helper.save(OUT/(label+'_originals.json'),value);return value

TOOL=BASE/'read-tool-r1/feetech_poke';NX=OUT/'never-open-device'
SMOKES={f'deny_{name}_{case}':[str(TOOL),str(NX),'1','write',name]+([] if value is None else [value]) for name in ('Phase','CW_Dead_Zone','CCW_Dead_Zone') for case,value in (('missing',None),('bad','bad-value'),('legal','255'))}
helper.save(BASE/'bootstrap/smoke_allowlist.json',{'expected_exit':2,'commands':SMOKES,'device_must_not_exist':str(NX),'not_device_path':True})

def validate_for_runner(reference):
    row=a.read_pinned_json(reference)
    if row.get('expected_exit')==0:return a.validate_completion(reference)
    require(row.get('expected_exit')==2 and row.get('name') in SMOKES and row.get('argv')==SMOKES[row['name']],'非固定9拒写命令')
    require(row['completion_receipt']==reference['path']==str(OUT/row['name']/'completion.json'),'拒写completion路径不同')
    require('runner_error' not in row and row.get('exit_code')==2 and row.get('reaped') is True and row.get('signals')==[],'拒写未自然完成')
    launch_path,_=a.regular_file(row['launch_receipt']);launch=a.strict_json(launch_path.read_text())
    for key in ('name','argv','cwd','env','removed_env_keys','started_at','started_monotonic_ns','timeout_seconds','stdout','stderr','launch_receipt','completion_receipt','pid','identity','expected_exit','bootstrap_argv'):
        require(key in row and row[key]==launch.get(key),'拒写原launch/completion不同:'+key)
    require('runner_error' not in launch and launch.get('reaped') is False and launch.get('exit_code') is None and launch.get('signals')==[],'拒写原launch非启动状态')
    require(type(row['pid']) is int and row['pid']>0 and row['identity']['pid']==row['pid'],'拒写PID缺失')
    ident=row['identity'];require(type(ident.get('start_ticks')) is int and ident['start_ticks']>0 and ident.get('boot_id')=='6cf7ee3e-a3c5-4c91-80bc-4ca924818b53' and Path(ident.get('exe','')).is_absolute(),'拒写启动身份缺失')
    require(type(row['started_monotonic_ns']) is int and type(row['ended_monotonic_ns']) is int and row['ended_monotonic_ns']>=row['started_monotonic_ns'],'拒写时序错误')
    require(row['elapsed_ns']==row['ended_monotonic_ns']-row['started_monotonic_ns'] and row['elapsed_ns']<=row['timeout_seconds']*10**9 and not row['budget_exceeded'] and row['exec_gate_released'] is True,'拒写预算或启动门错误')
    require(row['session_residual_before_cleanup']==[] and row['session_residual_after_cleanup']==[] and not os.path.lexists(NX),'拒写残留或NX出现')
    require(row['cwd']==str(SOURCE),'拒写cwd不匹配');a.validate_build_environment(row['env'])
    for key in ('stdout','stderr'):
        path,info=a.regular_file(row[key]);require(info.st_size==row[key+'_bytes'] and a.sha256(path)==row[key+'_sha256'],'拒写日志变化')
    require(Path(row['stdout']).read_bytes()==b'' and Path(row['stderr']).read_text()=='error: 本项目诊断专用寄存器禁止写入：'+row['argv'][4]+'\n','不是精确typed拒写输出')
    return row
runner_a=SimpleNamespace(**vars(a));runner_a.validate_completion=validate_for_runner
r=helper.Runner(SimpleNamespace(source=SOURCE,out=OUT,target=CACHE,build_head=HEAD,formal_root=Path('/home/loosqk/repo/robot/robot-system')),runner_a)

def source_guard(label):
    value=a.snapshot_source(SOURCE,sorted(expected['files']));require(value==expected,'590逐门源漂移:'+label);helper.save(OUT/(label+'.json'),value)
def step(label,argv,timeout=7200):
    source_guard(label+'_source_before');value=r.command(label,argv,timeout);source_guard(label+'_source_after');return value

def tests(label,argv,expected_names,exact=False):
    _,row=step(label,argv);text=Path(row['stdout']).read_text();counts=re.findall(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored;',text)
    require(len(counts)==1 and counts[0][1:]==('0','0'),'测试失败或ignored:'+label)
    names=re.findall(r'^test ([^ ]+) \.\.\. ok$',text,re.M);require(len(names)==len(set(names))==int(counts[0][0]),'测试名字/计数不同')
    require(set(expected_names)<=set(names) and (not exact or set(expected_names)==set(names)),'新测试子集缺失')
    return {'passed':len(names),'failed':0,'ignored':0,'names':names,'new_subset':expected_names}

try:
    for sig in (signal.SIGTERM,signal.SIGINT,signal.SIGHUP):old[sig]=signal.signal(sig,interrupted)
    require(os.getuid()==1000 and os.getgid()==1000 and Path('/proc/sys/kernel/random/boot_id').read_text().strip()=='6cf7ee3e-a3c5-4c91-80bc-4ca924818b53','主机身份变化')
    require(BASE.resolve()==BASE and OUT.resolve()==OUT and NX.parent==OUT and not os.path.lexists(NX),'NX必须为新目录不存在路径')
    before=candidate_source('source_before');original=originals('before')
    _,row=r.command('rustc_before_update',['rustc','-vV']);compiler_before=a.parse_rustc_identity(Path(row['stdout']).read_text());r.command('cargo_before_update',['cargo','-V'])
    r.command('latest_nightly_update',['rustup','update','nightly','--no-self-update'],300)
    _,row=r.command('rustc_after_update',['rustc','-vV']);compiler=a.parse_rustc_identity(Path(row['stdout']).read_text());_,row=r.command('cargo_after_update',['cargo','-V']);cargo=Path(row['stdout']).read_bytes();result.update(compiler=compiler,compiler_before_update=compiler_before)
    step('fmt',['cargo','fmt','--all'],300);require(candidate_source('source_after_fmt')==before,'fmt改变冻结候选')
    step('clippy_default',['cargo','clippy','--locked','--all','--all-targets','--','-D','warnings'])
    step('clippy_real_hw',['cargo','clippy','--locked','--all','--all-targets','--features','robot-adapter-feetech/real-hw','--','-D','warnings'])
    lib=tests('adapter_lib',['cargo','test','--locked','-p','robot-adapter-feetech','--lib'],test_names['library_new_subset'])
    example=tests('example_tests',['cargo','test','--locked','-p','robot-adapter-feetech','--example','feetech_poke','--features','real-hw'],test_names['example_all'],True)
    _,row=step('release_example',['cargo','build','--locked','--release','--message-format=json','-p','robot-adapter-feetech','--example','feetech_poke','--features','real-hw'])
    messages=[a.strict_json(line) for line in Path(row['stdout']).read_text().splitlines() if line.strip()];finished=[v for v in messages if v.get('reason')=='build-finished'];require(len(finished)==1 and finished[0]['success'] is True,'build-finished不唯一成功')
    artifacts=[v for v in messages if v.get('reason')=='compiler-artifact' and v.get('executable') is not None];require(len(artifacts)==1,'example executable不唯一');artifact=artifacts[0]
    require(artifact['target']['name']=='feetech_poke' and artifact['target']['kind']==['example'] and artifact['target']['crate_types']==['bin'] and artifact['manifest_path']==str(SOURCE/'crates/robot-adapters/feetech/Cargo.toml') and artifact['executable']==str(CACHE/'release/examples/feetech_poke'),'构建配方/路径不同')
    require(artifact['features']==['default','real-hw'] and artifact['profile']['opt_level']=='3' and artifact['profile']['test'] is False and artifact['profile']['debug_assertions'] is False,'不是完整features/release profile')
    src=Path(artifact['executable']);identity=a.elf_identity(src);TOOL.parent.mkdir();import shutil;shutil.copy2(src,TOOL);require(a.elf_identity(TOOL)==identity and a.elf_identity(src)==identity,'冻结/readback ELF不一致')
    tool={'schema':'FEETECH_B0_READ_TOOL_SOFTWARE_V1','deployable':False,'native_git_head':HEAD,'main_integration_head':'d5ac7aa7acaa11bef1d318e762d17a4443718120','source_files':590,'source_manifest_sha256':before['source_manifest_sha256'],'rustc_identity':compiler,'path':str(TOOL),'elf':identity,'compiler_artifact':artifact,'build_completion':r.receipts[-1]};helper.save(TOOL.parent/'feetech_poke.build.json',tool)
    smoke=[]
    for label,argv in SMOKES.items():
        require(not os.path.lexists(NX) and a.elf_identity(TOOL)==identity,'smoke前NX或ELF改变');source_guard(label+'_source_before');_,receipt=r.command(label,argv,60,expected_exit=2);source_guard(label+'_source_after');require(not os.path.lexists(NX),'smoke后NX出现');smoke.append({'name':label,'exit_code':receipt['exit_code'],'completion':r.receipts[-1]})
    _,row=r.command('rustc_after',['rustc','-vV']);require(a.parse_rustc_identity(Path(row['stdout']).read_text())==compiler,'门后rustc漂移');_,row=r.command('cargo_after',['cargo','-V']);require(Path(row['stdout']).read_bytes()==cargo,'门后cargo漂移')
    require(a.elf_identity(TOOL)==identity,'门后ELF漂移')
    result.update(status='PASS',source_files=590,aggregate=before['source_manifest_sha256'],fmt_source_unchanged=True,tests={'adapter_lib':lib,'example_tests':example,'distinct_total':lib['passed']+example['passed'],'new_distinct_subset':18,'lib_real_hw_duplicate':'NOT_RERUN','full_workspace':'NOT_RUN'},compiled_smoke=smoke,smoke_cases=9,read_tool=tool,compiler_after_update_after_equal=True)
except BaseException as error:result['error']=repr(error)
finally:
    for name,check in [('source_after',lambda:candidate_source('source_after')),('after_originals',lambda:originals('after'))]:
        try:
            value=check();require(value==({'source_after':before,'after_originals':original}[name]),name+'变化或缺前值');result[name]='PASS'
        except BaseException as error:result.update(status='FAIL');result[name]=repr(error)
    result['receipts']=r.receipts;helper.save(OUT/'result.json',result)
    for sig,handler in old.items():signal.signal(sig,handler)
print(json.dumps(result,ensure_ascii=False),flush=True);raise SystemExit(0 if result['status']=='PASS' else 1)
