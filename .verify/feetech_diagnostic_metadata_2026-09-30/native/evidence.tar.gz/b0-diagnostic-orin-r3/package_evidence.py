"""归档三轮B0诊断软件候选原件；不重复解包树，独审报告另交root。"""
import hashlib,io,json,stat,tarfile
from pathlib import Path,PurePosixPath
ROOT=Path(__file__).resolve().parents[1]
STAGES=tuple(ROOT/f'b0-diagnostic-orin-r{i}' for i in (1,2,3))
ARCHIVE=ROOT/'b0-diagnostic-orin-evidence.tar.gz'
INDEX=ROOT/'b0-diagnostic-orin-evidence.index.json'
def require(ok,message):
    if not ok:raise ValueError(message)
def sha(data):return hashlib.sha256(data).hexdigest()
paths=[p for base in STAGES for p in base.rglob('*') if p.is_file() and 'native-extracted' not in p.parts and p.suffix!='.pyc' and not p.name.startswith('independent_') and p.name!='outer_archive_verification.json']
entries={}
for p in sorted(paths):
    require(p.resolve()==p and stat.S_ISREG(p.lstat().st_mode),'拒绝非普通文件:'+str(p))
    data=p.read_bytes();entries[p.relative_to(ROOT).as_posix()]={'sha256':sha(data),'bytes':len(data),'mode':stat.S_IMODE(p.stat().st_mode),'executable':bool(p.stat().st_mode&stat.S_IXUSR)}
index={'schema':'FEETECH_B0_DIAGNOSTIC_ORIN_OUTER_ARCHIVE_V1','source_head':'1c5758f97b7c502a38c850e8352ce970216bea53','frozen_base_sha256':'8c49aded71bc718ee03487e5ae5fc1a59b6cf1358e099ed9d899f802234e4488','aggregate':'3d8491ee8b82bdaed1182e572bfaac6cbb5a47e6088d4dc91ea40cc8949cbcde','files':entries}
raw=(json.dumps(index,sort_keys=True,ensure_ascii=False,indent=2)+'\n').encode()
with INDEX.open('xb') as stream:stream.write(raw)
with tarfile.open(ARCHIVE,'x:gz') as tar:
    for name,entry in entries.items():
        data=(ROOT/name).read_bytes();require(sha(data)==entry['sha256'] and len(data)==entry['bytes'],'封包期间身份变化')
        item=tarfile.TarInfo(name);item.size=len(data);item.mode=entry['mode'];tar.addfile(item,io.BytesIO(data))
    item=tarfile.TarInfo('outer-index.json');item.size=len(raw);item.mode=0o644;tar.addfile(item,io.BytesIO(raw))
seen=set()
with tarfile.open(ARCHIVE,'r:gz') as tar:
    for item in tar:
        name=item.name;p=PurePosixPath(name);require(not p.is_absolute() and '..' not in p.parts and str(p)==name and item.isfile() and name not in seen,'非法成员');seen.add(name)
        blob=tar.extractfile(item).read(item.size+1)
        if name=='outer-index.json':require(blob==raw,'内外索引不同')
        else:
            require(name in entries,'未索引成员');entry=entries[name];require(sha(blob)==entry['sha256'] and len(blob)==entry['bytes'] and item.mode==entry['mode'],'成员读回不同')
require(seen==set(entries)|{'outer-index.json'},'漏项/额外成员')
for name,entry in entries.items():
    p=ROOT/name;require(sha(p.read_bytes())==entry['sha256'] and p.stat().st_size==entry['bytes'] and stat.S_IMODE(p.stat().st_mode)==entry['mode'],'封包后本机原件变化')
result={'status':'PASS','archive':{'path':str(ARCHIVE),'sha256':sha(ARCHIVE.read_bytes()),'bytes':ARCHIVE.stat().st_size},'index':{'path':str(INDEX),'sha256':sha(raw),'bytes':len(raw)},'indexed_files':len(entries),'tar_members':len(seen),'sha_bytes_mode_verified':True,'independent_reviews':'另行归档，原包不回填'}
with (STAGES[2]/'outer_archive_verification.json').open('x') as stream:json.dump(result,stream,ensure_ascii=False,indent=2);stream.write('\n')
print(json.dumps(result,ensure_ascii=False))
