set -eu
export PATH=/home/loosqk/.cargo/bin:/home/loosqk/.local/bin:$PATH
export CARGO_HOME=/home/loosqk/robot-checks/viz-orin-a6957cc-20260930-r1/cargo-home
export CARGO_NET_OFFLINE=true
export RUSTUP_AUTO_INSTALL=0
export PYTHONDONTWRITEBYTECODE=1
test "$(hostname)" = ubuntu
test "$(id -u)" = 1000
test "$(id -g)" = 1000
test "$(cat /proc/sys/kernel/random/boot_id)" = 6cf7ee3e-a3c5-4c91-80bc-4ca924818b53
BASE=/home/loosqk/robot-checks/feetech-diagnostic-b0-20260930-r3
cd "$BASE/bootstrap"
printf '%s\n' '25fa97a762e3815febff53d97ff71ca2131a0b3fd83241be71ca5f8b3a8b2c5d  feetech_poke.rs' '211ce25a1a819e2c3ecec293a830c7c0561ffb35b6d564d64e548da02dd3f659  bus.rs' 'f4155b2a4f71aec7489ca724a90cc2865219a9920ba4a51494d2267298335e8c  diagnostic.rs' 'd3d4c8c005d712f124755ce8c3530ff93b1302855f07b9ec915e04c887a276c5  error.rs' 'b7d40b8ae3557632c6996fbbc52a76c4e5dc508d8cc217abc28a39a4c13bbb36  registers.rs' '8c49aded71bc718ee03487e5ae5fc1a59b6cf1358e099ed9d899f802234e4488  base.rs' 'a919d5f6dc30d51b9a674a28b541025d0503381cde746e6ff52feed58112ebd1  lib.rs' 'be262024472e8653a9f23ee1a9bb9b4d18128853918eb6f045151b79cb4a9dbd  run_checks.py' 'e96e7a235988fd63507cbe4cc20c2c7ec12ccbb6bd23b086bb687c82353c0f87  run_release_v2.py' 'dad9bbc9405b8fac4d60d6efe794b36750e6a6f9ce9fdeba3debf7d3e1b9a471  run_release_v2.original.py' 'ed5f1a7276ae84d90358956d76a93caf6a14367ecdcd59fa3d818ece338466e7  run_release_v2.diff' '03d56d03f871cfa92739803e89598da591dea07f9e5fa21c24a1d04fcfc69216  expected_source.json' '6f402c0d13e92af1b55dedc91b0c704e19c4c0f95cc530ed39c1675ca51a57c3  frozen_inputs.json' 'ebe7ffe178339b1b6031ed8f01287f204e48fc6c5954dd5cc7655ec27954e67d  expected_tests.json' '1ffbc5d2602abc93079ee3fc6bb19d144101589b1bea89c4f7973f9e3e60af7c  preservation_pins.json' | sha256sum -c -
test "$(git -C "$BASE/source" rev-parse HEAD)" = 1c5758f97b7c502a38c850e8352ce970216bea53
test -z "$(git -C "$BASE/source" status --porcelain=v1 --untracked-files=all)"
test ! -e "$BASE/source/crates/robot-kinematics-xlerobot/src/base.rs"
cp feetech_poke.rs "$BASE/source/crates/robot-adapters/feetech/examples/feetech_poke.rs"
cp bus.rs "$BASE/source/crates/robot-adapters/feetech/src/bus.rs"
cp diagnostic.rs "$BASE/source/crates/robot-adapters/feetech/src/diagnostic.rs"
cp error.rs "$BASE/source/crates/robot-adapters/feetech/src/error.rs"
cp registers.rs "$BASE/source/crates/robot-adapters/feetech/src/registers.rs"
cp base.rs "$BASE/source/crates/robot-kinematics-xlerobot/src/base.rs"
cp lib.rs "$BASE/source/crates/robot-kinematics-xlerobot/src/lib.rs"
exec taskset -c 0-3 uv run --no-project python run_checks.py
