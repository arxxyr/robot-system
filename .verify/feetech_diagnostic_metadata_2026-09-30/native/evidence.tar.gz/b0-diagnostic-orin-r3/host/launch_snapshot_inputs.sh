set -eu
export PATH=/home/loosqk/.cargo/bin:/home/loosqk/.local/bin:$PATH
export CARGO_HOME=/home/loosqk/robot-checks/viz-orin-a6957cc-20260930-r1/cargo-home
export CARGO_NET_OFFLINE=true
export RUSTUP_AUTO_INSTALL=0
export PYTHONDONTWRITEBYTECODE=1
cd /home/loosqk/robot-checks/feetech-diagnostic-b0-20260930-r3/bootstrap
printf '%s\n' 'a75a1c76f7b2b4035f417a5df3fc539a296ddcecca2bdb217080d6461b4180f6  snapshot_inputs.py' | sha256sum -c -
exec uv run --no-project python snapshot_inputs.py
