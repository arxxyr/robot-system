set -eu
export PATH=/home/loosqk/.cargo/bin:/home/loosqk/.local/bin:$PATH
export CARGO_HOME=/home/loosqk/robot-checks/viz-orin-a6957cc-20260930-r1/cargo-home
export CARGO_NET_OFFLINE=true
export RUSTUP_AUTO_INSTALL=0
export PYTHONDONTWRITEBYTECODE=1
cd /home/loosqk/robot-checks/feetech-diagnostic-b0-20260930-r3/bootstrap
printf '%s\n' '49f9be9376767730ec1b1ca28a1ebc5ac9739ce0adf461e46749c0a08474ec03  collect_native.py' | sha256sum -c -
exec uv run --no-project python collect_native.py --base /home/loosqk/robot-checks/feetech-diagnostic-b0-20260930-r3 --out /home/loosqk/robot-checks/feetech-diagnostic-b0-20260930-native-r3.tar.gz --collect
