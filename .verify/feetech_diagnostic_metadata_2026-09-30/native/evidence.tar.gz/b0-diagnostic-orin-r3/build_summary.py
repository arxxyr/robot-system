"""只读原件生成本轮软件汇总；不执行远端或硬件。"""
import hashlib,json,stat
from pathlib import Path
ROOT=Path(__file__).resolve().parent.parent
MAIN=Path('/Users/loosqk/repo/rust/robot-system')
EXPECTED=['4136d5ef284acc0cf44dc2a3aa4382caac0932b4bda719c8c83117c2a8732e95','e81e417ea5adca3de92db7d1d72c363d180656af25e0e733b3fcc9e70a3e4fed','3d8491ee8b82bdaed1182e572bfaac6cbb5a47e6088d4dc91ea40cc8949cbcde']
def load(p):return json.loads(p.read_text())
def sha(p):
 with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def ref(p):return {'path':str(p),'sha256':sha(p),'bytes':p.stat().st_size}
def require(ok,message):
 if not ok:raise ValueError(message)
rows=[];total_direct=total_owner=0
for index,aggregate in enumerate(EXPECTED,1):
 p=ROOT/f'b0-diagnostic-orin-r{index}';e=p/'native-extracted';q=load(e/'qa-r1/result.json');ver=load(p/'native_archive_verification.json');manifest=load(e/'qa-r1/source_before.json');require(manifest['source_manifest_sha256']==aggregate and len(manifest['files'])==590,'源错误')
 require(q['status']==('PASS' if index==3 else 'FAIL') and q['source_after']=='PASS' and q['after_originals']=='PASS','QA口径错误');require(load(e/'qa-r1/source_after.json')==manifest and load(e/'qa-r1/source_after_fmt.json')==manifest,'源漂移');require(load(e/'qa-r1/before_originals.json')==load(e/'qa-r1/after_originals.json'),'旧件漂移')
 commands=[]
 for subtree in ('qa-r1','source-inputs-r1')+(() if index==3 else ('diagnostic-r1',)):
  value=load(e/subtree/'result.json')
  for pinned in value['receipts']:
   prefix=f'/home/loosqk/robot-checks/feetech-diagnostic-b0-20260930-r{index}/';path=e/pinned['path'].removeprefix(prefix);require(sha(path)==pinned['sha256'],'回执改变');row=load(path);require(row['reaped'] is True and row['signals']==[] and row['exec_gate_released'] is True and not row['budget_exceeded'],'非真实自然回收');require(row['session_residual_before_cleanup']==row['session_residual_after_cleanup']==[],'残留')
   launch=load(e/row['launch_receipt'].removeprefix(prefix))
   for key in ('name','argv','cwd','env','removed_env_keys','started_at','started_monotonic_ns','timeout_seconds','stdout','stderr','launch_receipt','completion_receipt','pid','identity','expected_exit','bootstrap_argv'):require(row[key]==launch[key],'启动完成不绑定')
   require(launch['reaped'] is False and launch['exit_code'] is None and row['identity']['pid']==row['pid'] and row['identity']['start_ticks']>0,'PID缺失')
   for key in ('stdout','stderr'):
    log=e/row[key].removeprefix(prefix);require(sha(log)==row[key+'_sha256'] and log.stat().st_size==row[key+'_bytes'],'日志改变')
   allowed=(index<3 and row['name']=='clippy_default' and row['exit_code']==101 and row['expected_exit']==0) or (index==3 and row['name'].startswith('deny_') and row['exit_code']==row['expected_exit']==2) or row['exit_code']==row['expected_exit']==0
   require(allowed,'未授权异常退出');require(row.get('runner_error')== ("ValueError('命令原始退出码非预期')" if index<3 and row['name']=='clippy_default' else None),'原runner_error不匹配');commands.append({k:row[k] for k in ('name','argv','pid','identity','exit_code','expected_exit','reaped','elapsed_ns','timeout_seconds','stdout_sha256','stdout_bytes','stderr_sha256','stderr_bytes') } | {'runner_error':row.get('runner_error')})
 owners=[]
 for child in sorted((p/'host').glob('*.owner')):
  result=child/'result.json';require(result.exists(),'owner未完成:'+str(child));o=load(result);require(o['reaped'] is True and o['phase']=='REAPED' and o['owner_sent_signals']==[] and o['received_signals']=={} and o['errors']==[],'owner未自然回收');require(o['wait_returncode']==(1 if index<3 and child.name=='checks.owner' else 0),'owner异常');log=Path(o['log']['path']);require(sha(log)==o['log']['sha256'] and log.stat().st_size==o['log']['bytes'],'owner日志改变');owners.append({**ref(result),'owner_pid':o['owner_pid'],'pid':o['pid'],'wait_returncode':o['wait_returncode'],'reaped':True,'command':o['command']})
 total_direct+=len(commands);total_owner+=len(owners)
 value={'native_iteration':index,'logical_candidate_revision':index+1,'status':q['status'],'aggregate':aggregate,'source_files':590,'qa_result':ref(e/'qa-r1/result.json'),'compiler':q['compiler'],'compiler_before_update':q['compiler_before_update'],'input_before_after_fmt_equal':True,'prior_sources_elves_archives_unchanged':True,'native_archive':ref(p/'native-evidence.tar.gz'),'native_index':ref(p/'native-evidence.index.json'),'native_metadata':ref(p/'native-evidence.metadata.json'),'archive_verification':ref(p/'native_archive_verification.json'),'extracted':str(e),'direct_children':commands,'direct_count':len(commands),'host_owners':owners,'host_owner_count':len(owners)}
 if index<3:
  require(next(r for r in commands if r['name']=='clippy_default')['exit_code']==101,'原FAIL不在');value.update(error=q['error'],not_run=['clippy_real_hw','adapter_lib','example_tests','release_example','9_compiled_denial_smokes'],failure_stderr=ref(e/'qa-r1/clippy_default/stderr.log'),compiler_after_failure_equal=True)
 else:
  require(q['tests']['new_distinct_subset']==18 and q['smoke_cases']==9,'测试口径变');value.update(tests=q['tests'],compiled_smoke=q['compiled_smoke'],read_tool=q['read_tool'],compiler_after_update_after_equal=q['compiler_after_update_after_equal'])
  allow=load(e/'bootstrap/smoke_allowlist.json')['commands'];require(len(allow)==9,'allowlist错误');smokes=[r for r in commands if r['name'].startswith('deny_')];require(len(smokes)==9,'实际smoke不足')
  for r in smokes:
   require(r['argv']==allow[r['name']] and r['argv'][1].endswith('/qa-r1/never-open-device') and not r['argv'][1].startswith('/dev/'),'非NX命令');require((e/'qa-r1'/r['name']/'stdout.log').read_bytes()==b'' and (e/'qa-r1'/r['name']/'stderr.log').read_text()=='error: 本项目诊断专用寄存器禁止写入：'+r['argv'][4]+'\n','非精确拒写')
 rows.append(value)
manifest=load(ROOT/'b0-diagnostic-orin-r3/expected_source.json')
for name,item in manifest['files'].items():
 p=MAIN/name;require(p.is_file() and not p.is_symlink() and sha(p)==item['sha256'] and p.stat().st_size==item['bytes'] and bool(p.stat().st_mode&0o111)==item['executable'],'main冻结源改变:'+name)
prior=load(ROOT/'xlerobot-base-orin-r1/previous_stage_archive_handoff.json')['files']
for item in prior:require(ref(Path(item['path']))==item,'此前H2本机档案变化')
math=[]
for name in ('xlerobot-base-orin-r2/summary.json','xlerobot-base-orin-r1/native-evidence.tar.gz','xlerobot-base-orin-r1/native-evidence.index.json','xlerobot-base-orin-r2/native-evidence.tar.gz','xlerobot-base-orin-r2/native-evidence.index.json','xlerobot-base-si-orin-evidence.tar.gz','xlerobot-base-si-orin-evidence.index.json'):
 p=ROOT/name;math.append(ref(p))
require(math==load(ROOT/'b0-diagnostic-orin-r3/previous_math_local_archive_frozen_refs.json'),'数学冻结档案变化')
out={'schema':'FEETECH_B0_DIAGNOSTIC_NATIVE_SOFTWARE_V1','status':'PASS_AFTER_TWO_PRESERVED_FAILURES','scope':'B0诊断元数据/3寄存器拒写纯软件候选；非新硬件、非H2六配方、非全workspace。','native_git_head':'1c5758f97b7c502a38c850e8352ce970216bea53','native_dirty_inputs':7,'main_integration_head_before_B0_commit':'d5ac7aa7acaa11bef1d318e762d17a4443718120','main_dirty_B0_inputs':5,'final_source_files':590,'final_aggregate':EXPECTED[2],'main_final_590_each_path_bytes_sha_exec_equal':True,'final_inputs':load(ROOT/'b0-diagnostic-orin-r3/frozen_inputs.json'),'iterations':rows,'ownership':{'direct_child_count':total_direct,'host_owner_count':total_owner,'all_naturally_waited_reaped':True,'no_kill_no_observation_timeout_restart':True},'distinct_tests':rows[-1]['tests'],'compiled_refusal_cases':9,'new_methods_subset_included':18,'three_diagnostic_literal_cases':'existing method扩展，不计为新增方法','lib_real_hw_repeat':'NOT_RUN','full_workspace':'NOT_RUN','hardware':'NOT_RUN','deployment_install_push':'NOT_RUN','physical_power_off':'PENDING','old_H2_overall_FAIL':'PRESERVED','D15':'OPEN/DEFERRED','deployable':False,'previous_H2_local_archives_unchanged':prior,'previous_math_local_archives':math,'frozen_summary_immutable':True}
p=ROOT/'b0-diagnostic-orin-r3/summary.json'
with p.open('x') as f:json.dump(out,f,ensure_ascii=False,indent=2,allow_nan=False);f.write('\n')
print(json.dumps({'status':'PASS_SUMMARY_BINDING','summary':ref(p),'direct':total_direct,'owners':total_owner,'tests':out['distinct_tests']['distinct_total']},ensure_ascii=False))
