"""首QA编译拒绝后的编译器只读取证，非测试重跑。"""
import importlib.util,json,signal,sys
from pathlib import Path
from types import SimpleNamespace
sys.dont_write_bytecode=True
BASE=Path('/home/loosqk/robot-checks/feetech-diagnostic-b0-20260930-r1');OUT=BASE/'diagnostic-r1';SOURCE=BASE/'source'
def module(name,path):
 spec=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);return m
h=module('failed_runner',BASE/'bootstrap/run_release_v2.py');a=module('failed_artifacts',SOURCE/'scripts/post_e_h2_artifacts.py');OUT.mkdir();r=h.Runner(SimpleNamespace(source=SOURCE,out=OUT,target=BASE/'build',build_head='1c5758f97b7c502a38c850e8352ce970216bea53',formal_root=Path('/home/loosqk/repo/robot/robot-system')),a);old={};result={'status':'FAIL'}
def interrupted(signum,frame):h.INTERRUPTED=signum
try:
 for sig in (signal.SIGINT,signal.SIGTERM,signal.SIGHUP):old[sig]=signal.signal(sig,interrupted)
 prior=a.strict_json((BASE/'qa-r1/result.json').read_text());a.require(prior['status']=='FAIL','不是首拒绝')
 _,row=r.command('rustc_after_failure',['rustc','-vV']);a.require(a.parse_rustc_identity(Path(row['stdout']).read_text())==prior['compiler'],'失败后compiler漂移')
 _,row=r.command('cargo_after_failure',['cargo','-V']);a.require(Path(row['stdout']).read_bytes()==(BASE/'qa-r1/cargo_after_update/stdout.log').read_bytes(),'失败后cargo漂移')
 result.update(status='PASS',scope='首FAIL后compiler/cargo未变；不代表QA或新测试通过。')
except BaseException as error:result['error']=repr(error)
finally:
 result['receipts']=r.receipts;h.save(OUT/'result.json',result)
 for sig,handler in old.items():signal.signal(sig,handler)
print(json.dumps(result,ensure_ascii=False),flush=True);raise SystemExit(0 if result['status']=='PASS' else 1)
