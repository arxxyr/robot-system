set -eu
export PATH=/home/loosqk/.cargo/bin:/home/loosqk/.local/bin:$PATH
test "$(hostname)" = ubuntu
test "$(id -u)" = 1000
test "$(id -g)" = 1000
test "$(uname -m)" = aarch64
test "$(cat /proc/sys/kernel/random/boot_id)" = 6cf7ee3e-a3c5-4c91-80bc-4ca924818b53
ps -eo pid,ppid,args | awk '$0 ~ /[c]argo (build|test|clippy)|[r]un_release_v2.py --run-builds|[p]ost_release_checks.py --run-checks/ {print; found=1} END {exit found ? 1 : 0}'
TASK_BASE=/home/loosqk/robot-checks/feetech-diagnostic-b0-20260930-r1
OLD_SOURCE=/home/loosqk/robot-checks/h2-trace-owner-v2-20260930-r1/source
test "$(git -C "$OLD_SOURCE" rev-parse HEAD)" = 1c5758f97b7c502a38c850e8352ce970216bea53
test -z "$(git -C "$OLD_SOURCE" status --porcelain=v1 --untracked-files=all)"
test ! -e "$TASK_BASE"
mkdir "$TASK_BASE"
mkdir "$TASK_BASE/bootstrap"
git clone --no-hardlinks --no-checkout "$OLD_SOURCE" "$TASK_BASE/source"
git -C "$TASK_BASE/source" checkout --detach 1c5758f97b7c502a38c850e8352ce970216bea53
test ! -e "$TASK_BASE/source/.git/objects/info/alternates"
test -z "$(git -C "$TASK_BASE/source" status --porcelain=v1 --untracked-files=all)"
test -z "$(git -C "$OLD_SOURCE" status --porcelain=v1 --untracked-files=all)"
