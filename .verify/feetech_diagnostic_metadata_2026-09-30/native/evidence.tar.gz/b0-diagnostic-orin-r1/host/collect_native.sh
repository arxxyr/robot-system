set -eu
export PATH=/home/loosqk/.cargo/bin:/home/loosqk/.local/bin:$PATH
export PYTHONDONTWRITEBYTECODE=1
cd /home/loosqk/robot-checks/feetech-diagnostic-b0-20260930-r1/bootstrap
printf '%s\n' '904fd8ead314d16fb33eb7e7ade3c242fb7aab7f87fd35752d9906317a1d53a3  collect_native.py' | sha256sum -c -
exec uv run --no-project python collect_native.py --base /home/loosqk/robot-checks/feetech-diagnostic-b0-20260930-r1 --out /home/loosqk/robot-checks/feetech-diagnostic-b0-20260930-native-r1.tar.gz --collect
