set -eu
export PATH=/home/loosqk/.cargo/bin:/home/loosqk/.local/bin:$PATH
export CARGO_HOME=/home/loosqk/robot-checks/viz-orin-a6957cc-20260930-r1/cargo-home
export CARGO_NET_OFFLINE=true
export RUSTUP_AUTO_INSTALL=0
export PYTHONDONTWRITEBYTECODE=1
cd /home/loosqk/robot-checks/feetech-diagnostic-b0-20260930-r1/bootstrap
printf '%s\n' '1901f4766e2d0dd95b03e5dcc33ee0077e34df21d6cc78c3a76ad69702e520a0  snapshot_inputs.py' '4463de6355826d1f9abb2e6d727df2e490943e89a976a51d2b203cb57da57bf8  diagnostic.py' '904fd8ead314d16fb33eb7e7ade3c242fb7aab7f87fd35752d9906317a1d53a3  collect_native.py' | sha256sum -c -
uv run --no-project python diagnostic.py
exec uv run --no-project python snapshot_inputs.py
