#!/bin/bash
set -eu
export PYTHONDONTWRITEBYTECODE=1
tmux set-option -p remain-on-exit on
exec /home/loosqk/.local/share/uv/python/cpython-3.12.13-linux-aarch64-gnu/bin/python3 /home/loosqk/robot-checks/position-return-20261010-r1/head1-p32-reverse-r16/boot/prepare_head1_p32_reverse_r16.py > /home/loosqk/robot-checks/position-return-20261010-r1/head1-p32-reverse-r16/boot/driver.log 2>&1
