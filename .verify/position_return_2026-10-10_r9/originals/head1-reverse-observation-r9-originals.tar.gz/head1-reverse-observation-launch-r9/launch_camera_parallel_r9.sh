#!/bin/bash
set -euC
export PYTHONDONTWRITEBYTECODE=1
tmux set-option -w -t "$TMUX_PANE" remain-on-exit on
exec /home/loosqk/.local/share/uv/python/cpython-3.12.13-linux-aarch64-gnu/bin/python3 /home/loosqk/robot-checks/position-return-20261010-r1/head-reverse-r9/capture_parallel_20s_r9.py > /home/loosqk/robot-checks/position-return-20261010-r1/head-reverse-r9/camera-driver-r9.log 2>&1
