"""纯软件反例；不启动 systemd、网络或真实串口。"""
import contextlib
import importlib.util
import io
import os
from pathlib import Path
import stat
import subprocess
import types
import unittest
from unittest.mock import Mock, patch

spec = importlib.util.spec_from_file_location("arm_smoke", Path(__file__).with_name("run_arm_smoke.py"))
arm = importlib.util.module_from_spec(spec)
spec.loader.exec_module(arm)


def calibration(side):
    return {f"{side}_arm_{suffix}": {"id": i, "range_min": 100, "range_max": 3000}
            for i, suffix in enumerate(("shoulder_pan", "shoulder_lift", "elbow_flex",
                                       "wrist_flex", "wrist_roll", "gripper"), 1)}


def plan():
    return {"run_id": "test-20260929", "sides": ["left", "right"], "output": "/tmp/nonexistent-arm-test",
            "working_directory": "/verified/source", "binaries": {n: "/frozen/" + n for n in arm.BIN_NAMES},
            "tools": {n: {"path": "/frozen/" + n} for n in ("demo", "robotctl", "poke")}}


class FakeRunner(arm.Runner):
    def __init__(self, *, timeout=False, estop_fail=False, stop_fail=False, residual=False, busy=False, clear_fail=False):
        self.plan, self.go = plan(), {}
        self.state = {"sides": {}, "steps": []}
        self.output = Path("/tmp/nonexistent-arm-test")
        self.calibrations = {side: calibration(side) for side in ("left", "right")}
        self.events = []
        self.timeout, self.estop_fail, self.stop_fail, self.residual, self.busy = timeout, estop_fail, stop_fail, residual, busy
        self.clear_fail = clear_fail
        self.markers = {"left": b"1\n", "right": b"1\n"}
        self.idle_count = 0

    def save(self):
        pass

    def verify_files(self):
        pass

    def idle(self):
        self.events.append("idle")
        self.idle_count += 1
        if self.busy and self.idle_count > 1:
            raise ValueError("仍占用")

    def read_bus(self, side):
        self.events.append("read_bus")
        return {i: 1000 for i in range(1, 10)}

    def marker_check(self, side, expected):
        arm.require(self.markers[side] == expected, "marker状态不同")

    def marker(self, side, action):
        self.events.append(action)
        if action == "authorize":
            self.markers[side] = b"0\n"
        if action == "revoke":
            self.markers[side] = b"1\n"

    def start(self, side, role):
        self.events.append("start_" + role)
        if self.residual:
            raise ValueError("消费前启动失败")
        self.markers[side] = b"1\n"
        return {}

    def watch(self, side):
        self.events.append("watch")
        return []

    def command(self, argv, **kwargs):
        if argv[0].endswith("demo"):
            self.events.append("demo")
            if self.timeout:
                raise subprocess.TimeoutExpired(argv, 45)
            side = argv[argv.index("--side") + 1]
            return f"side={side} Completed(Success) + motion evidence + disable confirmed PASS"
        if "estop" in argv:
            self.events.append("estop")
            if self.estop_fail:
                raise ValueError("EStop 发布失败")
        elif "clear-estop" in argv:
            self.events.append("clear")
            if self.clear_fail:
                raise ValueError("ClearEStop 回执不确定")
        return ""

    def stop_side(self, side):
        self.events.append("stop")
        if self.stop_fail:
            raise ValueError("daemon退出非零")


class ArmSmokeTests(unittest.TestCase):
    def side(self, runner, expected_failure=False):
        with patch.object(arm, "validate_go"), patch.object(arm.shared, "inspect_runtime_preconditions", return_value={}), \
             patch.object(arm.shared, "validate_runtime_preconditions", return_value={}), \
             patch.object(Path, "read_bytes", return_value=b"1\n"), \
             patch.object(Path, "read_text", return_value="boot"), contextlib.redirect_stderr(io.StringIO()):
            if expected_failure:
                with self.assertRaises(ValueError):
                    runner.run_side("left", {"operator": "secret", "maintainer": "secret2"})
            else:
                runner.run_side("left", {"operator": "secret", "maintainer": "secret2"})

    def test_default_plan_never_starts_process(self):
        with patch.object(arm.subprocess, "Popen", side_effect=AssertionError("不得启动")), \
             contextlib.redirect_stdout(io.StringIO()) as output:
            self.assertEqual(arm.main([]), 0)
        self.assertIn("PLAN_ONLY", output.getvalue())
        with self.assertRaises(ValueError):
            arm.main(["--execute"])

    def test_go_rejects_missing_physical_and_wrong_plan(self):
        p = plan()
        physical = {side: dict.fromkeys(arm.FACTS, True) | {"confirmed_at_ns": 100, "usb_devnum": 4,
                    "usb_serial": arm.arm_profile(side).usb_serial} for side in ("left", "right")}
        go = {"schema": "ARM_SMOKE_GO_V1", "issued_by": "root", "plan_sha256": arm.digest(p),
              "host": "orin", "boot_id": "boot", "issued_at_ns": 100, "expires_at_ns": 1000,
              "source": "当次现场答复", "physical": physical}
        arm.validate_go(go, p, 101, "orin", "boot")
        go["physical"]["right"]["usb_replug"] = False
        with self.assertRaises(ValueError):
            arm.validate_go(go, p, 101, "orin", "boot")
        go["physical"]["right"]["usb_replug"] = True
        go["plan_sha256"] = "0" * 64
        with self.assertRaises(ValueError):
            arm.validate_go(go, p, 101, "orin", "boot")

    def test_transient_fixed_no_restart_and_required_ready(self):
        argv = arm.service_command(plan(), "right", "s0")
        self.assertIn("--wait", argv)
        self.assertIn("--property=Restart=no", argv)
        self.assertIn("--property=Type=notify", argv)
        self.assertIn("--property=WatchdogSec=2s", argv)
        self.assertEqual(argv[argv.index("--cpu") + 1], "5")
        self.assertEqual(argv.count("--config"), 1)
        self.assertIn("required", argv)
        self.assertNotIn("preflight-handoff", argv)

    def test_start_waits_not_found_then_activating_then_ready(self):
        runner = FakeRunner()
        runner.created, runner.waiters, runner.env = [], {}, {}
        runner.plan["services"] = {"left": {"s0": arm.service_command(runner.plan, "left", "s0")}}
        missing = {"LoadState": "not-found"}
        activating = {"LoadState": "loaded", "ActiveState": "activating", "Restart": "no"}
        active = activating | {"ActiveState": "active", "SubState": "running", "MainPID": "1234",
                               "Type": "notify", "User": "loosqk", "Group": "loosqk"}
        runner.show = Mock(side_effect=[missing, missing, activating, active])
        runner.check_serial_rt = Mock()
        child = Mock(pid=1200)
        child.poll.return_value = None
        with patch.object(arm.subprocess, "Popen", return_value=child), patch.object(arm.time, "sleep"):
            self.assertEqual(arm.Runner.start(runner, "left", "s0"), active)
        runner.check_serial_rt.assert_called_once_with(1234, 4)

    def test_cleanup_waits_for_pending_creation_before_stop(self):
        runner = FakeRunner()
        unit = arm.unit_name(runner.plan["run_id"], "left", "s0")
        runner.created = [unit]
        child = Mock(pid=1200, returncode=0)
        child.poll.return_value = None
        child.communicate.return_value = ("done", "")
        runner.waiters = {unit: (child, {})}
        runner.secrets = []
        missing = {"LoadState": "not-found"}
        creating = {"LoadState": "loaded", "ControlGroup": ""}
        stopped = {"LoadState": "not-found", "MainPID": "0", "ActiveState": "inactive"}
        runner.show = Mock(side_effect=[missing, creating, stopped])
        runner.command = Mock(return_value="")
        with patch.object(arm.time, "sleep"):
            arm.Runner.stop_side(runner, "left")
        self.assertIn(["sudo", "-n", "systemctl", "stop", unit], [c.args[0] for c in runner.command.call_args_list])
        child.terminate.assert_not_called()
        child.kill.assert_not_called()
        self.assertTrue(runner.waiters[unit][1]["reaped"])

    def test_cleanup_query_failure_does_not_cancel_pending_creator(self):
        runner = FakeRunner()
        unit = arm.unit_name(runner.plan["run_id"], "left", "s0")
        runner.created = [unit]
        child = Mock(pid=1200, returncode=0)
        child.poll.return_value = None
        child.communicate.return_value = ("done", "")
        runner.waiters, runner.secrets = {unit: (child, {})}, []
        runner.show = Mock(side_effect=[ValueError("查询暂时失败"), {"LoadState": "not-found"},
            {"LoadState": "loaded", "ControlGroup": ""},
            {"LoadState": "not-found", "MainPID": "0", "ActiveState": "inactive"}])
        runner.command = Mock(return_value="")
        with patch.object(arm.time, "sleep"), self.assertRaisesRegex(ValueError, "原错误保留"):
            arm.Runner.stop_side(runner, "left")
        self.assertIn(["sudo", "-n", "systemctl", "stop", unit], [c.args[0] for c in runner.command.call_args_list])
        child.terminate.assert_not_called()
        child.kill.assert_not_called()
        self.assertTrue(runner.waiters[unit][1]["reaped"])

    def test_only_exact_right_elbow_four_tick_exception(self):
        values = dict.fromkeys(range(1, 7), 1000)
        values[3] = 3004
        self.assertEqual(arm.validate_positions("right", calibration("right"), values)[0]["clamp_ticks"], 4)
        with self.assertRaises(ValueError):
            arm.validate_positions("left", calibration("left"), values)
        values[3] = 3005
        with self.assertRaises(ValueError):
            arm.validate_positions("right", calibration("right"), values)
        values[3], values[5] = 1000, 2937
        with self.assertRaises(ValueError):
            arm.validate_positions("right", calibration("right"), values)

    def test_read_bus_never_writes_and_rejects_operating_mode_drift(self):
        runner = FakeRunner()
        seen = []
        def response(argv, **kwargs):
            seen.append(argv)
            motor, operation, register = int(argv[2]), argv[3], argv[4]
            self.assertEqual(operation, "read")
            value = {"Operating_Mode": 1, "Torque_Enable": 0,
                     "Present_Velocity": 0, "Present_Position": 1000}[register]
            return f"read {register}@{motor} = {value}\n"
        runner.command = response
        with self.assertRaisesRegex(ValueError, "Operating_Mode"):
            arm.Runner.read_bus(runner, "left")
        self.assertTrue(seen)

    def test_success_estop_before_stop_and_single_authorize(self):
        runner = FakeRunner()
        self.side(runner)
        self.assertEqual(runner.events.count("authorize"), 1)
        self.assertLess(runner.events.index("demo"), runner.events.index("estop"))
        self.assertLess(runner.events.index("estop"), runner.events.index("stop"))
        self.assertEqual(runner.state["sides"]["left"]["result"], "PASS")
        self.assertTrue(runner.state["sides"]["left"]["latch_restored_by_estop"])

    def test_demo_timeout_still_estops_then_stops(self):
        runner = FakeRunner(timeout=True)
        self.side(runner, True)
        self.assertLess(runner.events.index("estop"), runner.events.index("stop"))
        self.assertEqual(runner.events.count("demo"), 1)
        self.assertTrue(runner.state["sides"]["left"]["final_torque_off_and_zero_velocity"])

    def test_clear_failure_still_estops_without_motion(self):
        runner = FakeRunner(clear_fail=True)
        self.side(runner, True)
        self.assertNotIn("demo", runner.events)
        self.assertLess(runner.events.index("estop"), runner.events.index("stop"))
        self.assertTrue(runner.state["sides"]["left"]["latch_restored_by_estop"])

    def test_estop_and_stop_errors_do_not_skip_final_readback(self):
        runner = FakeRunner(estop_fail=True, stop_fail=True)
        self.side(runner, True)
        self.assertEqual(runner.events.count("read_bus"), 2)
        self.assertFalse(runner.state["sides"]["left"]["latch_restored_by_estop"])
        self.assertTrue(runner.state["sides"]["left"]["final_torque_off_and_zero_velocity"])

    def test_unconsumed_authorization_revoked_only_after_idle(self):
        runner = FakeRunner(residual=True)
        self.side(runner, True)
        self.assertEqual(runner.events.count("authorize"), 1)
        self.assertEqual(runner.events.count("revoke"), 1)
        self.assertLess(runner.events.index("stop"), runner.events.index("revoke"))
        self.assertEqual(runner.markers["left"], b"1\n")

    def test_busy_cleanup_does_not_revoke_or_open_serial(self):
        runner = FakeRunner(residual=True, busy=True)
        self.side(runner, True)
        self.assertNotIn("revoke", runner.events)
        self.assertEqual(runner.events.count("read_bus"), 1)

    def test_left_failure_never_enters_right(self):
        runner = FakeRunner()
        runner.credentials = lambda: {}
        runner.redact = lambda text: text
        runner.run_side = Mock(side_effect=ValueError("左失败"))
        account = types.SimpleNamespace(pw_uid=os.getuid(), pw_gid=os.getgid())
        info = types.SimpleNamespace(st_mode=stat.S_IFDIR | 0o750, st_uid=os.getuid(), st_gid=os.getgid())
        with patch.object(arm.pwd, "getpwnam", return_value=account), \
             patch.object(arm.os, "uname", return_value=types.SimpleNamespace(machine="aarch64")), \
             patch.object(Path, "lstat", return_value=info):
            self.assertEqual(runner.run(), 1)
        runner.run_side.assert_called_once_with("left", {})

    def test_command_timeout_waits_reaps_and_redacts_token(self):
        runner = FakeRunner()
        runner.env, runner.secrets = {}, ["private-secret"]
        child = Mock(pid=1234, returncode=-9)
        child.communicate.side_effect = [subprocess.TimeoutExpired("demo", 1),
                                        subprocess.TimeoutExpired("demo", 5), ("private-secret", "private-secret")]
        with patch.object(arm.subprocess, "Popen", return_value=child) as popen, \
             contextlib.redirect_stderr(io.StringIO()), self.assertRaises(subprocess.TimeoutExpired):
            arm.Runner.command(runner, ["demo"], token="private-secret", timeout=1)
        child.terminate.assert_called_once()
        child.kill.assert_called_once()
        self.assertEqual(popen.call_args.kwargs["env"]["ROBOT_TOKEN"], "private-secret")
        self.assertTrue(runner.state["steps"][0]["reaped"])
        self.assertNotIn("private-secret", str(runner.state))

    def test_exit_zero_with_no_or_faulted_state_is_not_confirmation(self):
        with self.assertRaises(ValueError):
            arm.state_samples("state: (no sample yet)")
        line = "state: stamp={} layout=0x123 n=6 pos=[0,0,0,0,0,0]\ns0: mode=Safe link=Ok out=Stop safety=TorqueOffConfirmed fault=Unknown\n"
        self.assertEqual(len(arm.state_samples(line.format(1) + line.format(2))), 2)
        with self.assertRaises(ValueError):
            arm.state_samples((line.format(1) + line.format(2)).replace("fault=Unknown", "fault=CommFault"))


if __name__ == "__main__":
    unittest.main()
