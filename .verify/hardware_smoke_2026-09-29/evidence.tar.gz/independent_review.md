# 2026-09-29 双臂功能探针软件独立审查

结论：本次定点软件审查通过，未发现剩余本范围阻断。`hardware_ready=false`，状态为 `awaitphysical`；未收到本次现场 reset 答复，本记录不授予真实动作 GO。右 H2 整体 FAIL、D15 OPEN、deployable=false 均不改变。

本审查仅只读核对本地源码、测试与主 agent 归档日志；审查 agent 未 SSH，未运行 native 测试、systemd 或串口操作。以下本地及 Orin 测试由主 agent 执行，均为纯 mock 软件回归，不是机械臂动作验收。

## 最终身份

- `run_arm_smoke.py` SHA-256：`cf56987234d6e55a9e4abcd2054a01280ab487975f1b661f69b499dcd05ba5d5`。
- `test_arm_smoke.py` SHA-256：`cdf87dc7389816929aaa6d575c93b90ca7eb3b11809e4e4e61c6201db0f76889`。
- `plan_final_orin.json`：`PLAN_ONLY`，`actions_started=0`；计划 SHA-256 为 `279b720cca9a4ffa893553711892c362766930f1035e5b90ab057652be19cbcb`。

## 定点结论与证据

1. `run_arm_smoke.py:361–394` 不再将创建期间的 `not-found` 当作启动完成或失败。`403–472` 在创建未决、状态查询暂时失败时继续持有原 `systemd-run --wait` 客户端；待 unit 可见后才停止，随后真实 wait/reap 并核对 PID/cgroup/退出结果。查询错误保留为 FAIL，持续未决时明确要求现场介入，不宣称清场。对应反例见 `test_arm_smoke.py:149–203`，包括查询失败 → not-found → loaded；断言先 stop、真实 reap、未 terminate/kill 创建客户端且原错误保留。
2. `state_samples` 要求 Safe、TorqueOffConfirmed、fault=Unknown 是当前 wire 的正确组合。`crates/robot-msg/schemas/joint.fbs:78–80` 定义 Unknown=0 用于非 Fault 场景；`crates/robot-s0/src/pub_thread.rs:372–376` 明确将 Safe 映射到 S0FaultCode::Unknown。该修正没有把具体故障码放行。
3. 最终源码继续保留先前已复核的默认仅计划、现场/文件身份绑定、单次 authorize、clear 不确定响应及 demo 超时后的独立 topic EStop、双份 latch 恢复、失败后的独立清场及串口互斥门、残余 marker 撤销和前侧 FAIL 阻断后侧。EStop topic 发布回执不冒充 RPC Ack 或物理断扭证明。

## 软件回归记录

- `test_runner_final_local.log`：17 tests，OK；日志 SHA-256 `20ca7690bed736899a5b01d6fcf5429bcafdbae4399e5af8ae43fe61e7150e97`。
- `test_runner_final_orin.log`：17 tests，OK；日志 SHA-256 `1eed6459c11a9a86b8abf7cacd6614b50c1dcda9db1bcf758487aa82ca16bcd7`。主 agent 确认 native 进程 exit 0 并已 wait。
- 旧 15 项日志保留为历史，不作为最终文件的覆盖证明。上述结果只支持本次软件准备；真实 systemd 启停、机械臂动作、最终断扭和现场清场尚未执行。
