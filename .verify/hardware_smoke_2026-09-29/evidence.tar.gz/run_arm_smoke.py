#!/usr/bin/env -S uv run --no-project python
"""一次性双臂功能探针；默认仅输出计划，执行需要绑定计划 SHA 的本次 root GO。

只复用已有 guard / S0 / S1 / gateway / demo；不提供裸寄存器写接口。
正式 unit 不变；本轮 transient 不重启；任一异常禁止下一侧。
"""
from __future__ import annotations

import argparse
import hashlib
import json
import os
from pathlib import Path
import pwd
import re
import signal
import stat
import subprocess
import sys
import time
import tomllib

REPO = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(REPO / "scripts"))
import run_post_e_h2 as shared
from post_e_h2_report import arm_profile, require, strict_json

CA14 = "ca14f0e6cf6df8ecc6baaaa8dff2dddb64abbd0a"
ROLES = Path("/etc/robot/rpc_roles.toml")
BIN_NAMES = ("s0_daemon", "xlerobot_deploy", "s1_daemon", "robot_rpc_gateway")
FACTS = ("supported", "unloaded", "area_clear", "motor_power_cycle", "usb_replug",
         "continuous_presence_until_cleanup", "immediate_power_cut")
# 保守原始计数窗口大于默认 0.05 rad 的约 33 tick；不替代 adapter 的标定夹限。
PROBE_MARGIN_TICKS = 64
PROPERTIES = ("LoadState", "ActiveState", "SubState", "MainPID", "Result", "ExecMainCode",
              "ExecMainStatus", "ControlGroup", "Type", "User", "Group", "Restart")


def canonical(value):
    return json.dumps(value, sort_keys=True, separators=(",", ":"), ensure_ascii=False).encode()


def digest(value):
    return hashlib.sha256(canonical(value)).hexdigest()


def file_ref(path):
    path = Path(path)
    require(path.is_absolute() and path == path.resolve(), "文件必须是绝对路径且无符号链接")
    return {"path": str(path), "sha256": shared.file_hash(path)}


def pinned(reference):
    require(file_ref(reference["path"]) == reference, "绑定文件 SHA 已改变")
    return Path(reference["path"])


def artifact_paths(manifest):
    require(manifest["kind"] == "production" and manifest["build_head"] == CA14,
            "仅接受已验收 ca14 生产冻结包")
    require(set(manifest["artifacts"]) == set(BIN_NAMES), "生产四件必须完整")
    result = {}
    for name, row in manifest["artifacts"].items():
        require(row["build_head"] == CA14 and row["profile"] == "release"
                and row["elf_machine"] == 183 and row["exit_code"] == 0
                and not any(f.startswith("test-") for f in row["features"]), "产物不是批准的生产组合")
        require(Path(row["path"]).parent == Path(manifest["artifact_directory"]), "冻结包路径分叉")
        result[name] = row["path"]
    return result


def unit_name(run_id, side, role):
    require(re.fullmatch(r"[a-z0-9][a-z0-9-]{0,39}", run_id), "run-id 格式错误")
    require(side in ("left", "right") and role in ("s0", "s1", "gateway"), "未知 transient 身份")
    return f"robot-arm-smoke-{run_id}-{side}-{role}.service"


def service_command(plan, side, role):
    p = arm_profile(side)
    bins = plan["binaries"]
    name = unit_name(plan["run_id"], side, role)
    props = ["Type=notify", "NotifyAccess=main", "User=loosqk", "Group=loosqk",
             "SupplementaryGroups=dialout", "Restart=no", "CPUAffinity=0-3", "LimitRTPRIO=99",
             "LimitMEMLOCK=infinity", "KillMode=control-group", "TimeoutStopSec=30s",
             "TimeoutStartSec=infinity", f"WatchdogSec={'2s' if role == 's0' else '5s'}",
             f"WorkingDirectory={plan['working_directory']}", "StandardOutput=journal", "StandardError=journal"]
    if role == "s0":
        props += ["RuntimeDirectory=robot-system/preflight", "RuntimeDirectoryMode=0750",
                  "RuntimeDirectoryPreserve=yes"]
        argv = [bins["xlerobot_deploy"], "guard", "--arm", side, "--config", str(p.config),
                "--s0-bin", bins["s0_daemon"], "--", "--robot-id", p.robot_id,
                "--hardware-id", p.hardware_id, "--latch-path", str(p.trust / "estop_latch"),
                "--tick-hz", "50", "--serial-fifo", "70", "--cpu", str(p.serial_cpu),
                "--notify-mode", "required", "--strict-rt"]
    else:
        s0 = unit_name(plan["run_id"], side, "s0")
        props += [f"Requires={s0}", f"After={s0}"]
        if role == "s1":
            argv = [bins["s1_daemon"], "--robot-id", p.robot_id, "--hardware-id", p.hardware_id,
                    "--config", str(p.config)]
        else:
            s1 = unit_name(plan["run_id"], side, "s1")
            props += [f"Wants={s1}", f"After={s1}"]
            argv = [bins["robot_rpc_gateway"], "--robot-id", p.robot_id, "--config", str(p.config),
                    "--rpc-roles-toml", str(ROLES), "--listen-addr", gateway(side)]
    return ["sudo", "-n", "systemd-run", "--wait", "--unit", name,
            *[f"--property={v}" for v in props], "--setenv=ROBOT_LOG_FORMAT=json",
            "--setenv=RUST_LOG=info", "--", *argv]


def gateway(side):
    return "127.0.0.1:50051" if side == "left" else "127.0.0.1:50052"


def build_plan(options):
    manifest_ref, bindings_ref = file_ref(options.manifest), file_ref(options.bindings)
    manifest = strict_json(Path(options.manifest).read_text())
    bindings = strict_json(Path(options.bindings).read_text())
    require(bindings["schema"] == "ARM_SMOKE_BINDINGS_V1"
            and bindings["manifest_sha256"] == manifest_ref["sha256"], "bindings 未绑定 production manifest")
    tools = {name: {"path": str(getattr(options, name)), "sha256": bindings[name + "_sha256"]}
             for name in ("robotctl", "demo", "poke")}
    for reference in tools.values():
        require(Path(reference["path"]).is_absolute() and re.fullmatch(r"[0-9a-f]{64}", reference["sha256"]),
                "工具路径/SHA 错误")
    require(Path(options.output).is_absolute(), "证据目录必须绝对路径")
    plan = {"schema": "ARM_SMOKE_PLAN_V1", "run_id": options.run_id,
            "output": str(options.output), "working_directory": manifest["build_root"],
            "manifest": manifest_ref, "bindings": bindings_ref,
            "script": file_ref(__file__), "helpers": [file_ref(shared.__file__),
            file_ref(REPO / "scripts/post_e_h2_report.py")], "binaries": artifact_paths(manifest),
            "tools": tools, "sides": ["left", "right"], "phase": "single-arm", "offset_rad": 0.05,
            "approved_clamp_exception": {"right_arm_elbow_flex": {"maximum_excess_ticks": 4}},
            "scope": "逐侧小幅功能；不关闭右H2 FAIL/D15，不启动正式units，不执行头部/底盘动作"}
    plan["services"] = {side: {role: service_command(plan, side, role)
                              for role in ("s0", "s1", "gateway")} for side in plan["sides"]}
    return plan


def validate_go(go, plan, now, host, boot):
    require(go["schema"] == "ARM_SMOKE_GO_V1" and go["issued_by"] == "root"
            and go["plan_sha256"] == digest(plan), "GO 未绑定本次完整计划")
    require(go["host"] == host and go["boot_id"] == boot, "GO 主机/boot 不符")
    require(type(go["issued_at_ns"]) is int and type(go["expires_at_ns"]) is int
            and go["issued_at_ns"] <= now < go["expires_at_ns"]
            and 0 < go["expires_at_ns"] - go["issued_at_ns"] <= 3600 * 10**9, "GO 过期或时间错误")
    require(isinstance(go["source"], str) and go["source"].strip(), "缺现场事实来源")
    require(set(go["physical"]) == {"left", "right"}, "两侧现场事实不完整")
    for side in plan["sides"]:
        row = go["physical"][side]
        for fact in FACTS:
            require(row[fact] is True, f"缺少 {side} 本次事实：{fact}")
        require(row["confirmed_at_ns"] <= now and row["confirmed_at_ns"] >= go["issued_at_ns"] - 3600 * 10**9,
                "物理事实时间不属本次")
        require(row["usb_serial"] == arm_profile(side).usb_serial
                and type(row["usb_devnum"]) is int and row["usb_devnum"] > 0, "USB 枚举事实不完整")


def validate_positions(side, calibration, positions):
    exceptions = []
    for index, name in enumerate(arm_profile(side).hardware_id + suffix for suffix in (
            "_shoulder_pan", "_shoulder_lift", "_elbow_flex", "_wrist_flex", "_wrist_roll", "_gripper")):
        cal, raw = calibration[name], positions[index + 1]
        require(cal["id"] == index + 1 and 0 <= cal["range_min"] < cal["range_max"] <= 4095,
                "标定 ID/范围错误")
        lo, hi = cal["range_min"], cal["range_max"]
        if name == "right_arm_elbow_flex" and hi < raw <= hi + 4:
            exceptions.append({"joint": name, "raw": raw, "maximum": hi, "clamp_ticks": raw - hi})
        else:
            require(lo <= raw <= hi, f"{name} 当前位超标定，禁止启动")
        if name.endswith("_wrist_roll"):
            require(raw + PROBE_MARGIN_TICKS <= hi, f"{side} wrist 正向余量不足")
    return exceptions


def state_samples(text):
    pattern = (r"state: stamp=(\d+)\s+layout=(0x[0-9a-f]+)\s+n=6\s+pos=\[([^\]]+)\]\s*"
               r"s0:\s+mode=([A-Za-z]+)\s+link=([A-Za-z]+)\s+out=([A-Za-z]+)\s+safety=([A-Za-z]+)\s+fault=([^\s]+)")
    rows = []
    for match in re.finditer(pattern, text):
        stamp, layout, values, mode, link, output, safety, fault = match.groups()
        positions = [float(v.strip()) for v in values.split(",")]
        require(len(positions) == 6 and all(abs(v) < 100 for v in positions), "状态位置畸形")
        rows.append({"stamp": int(stamp), "layout": layout, "positions": positions, "mode": mode,
                     "link": link, "output": output, "safety": safety, "fault": fault})
    require(len({row["stamp"] for row in rows}) >= 2 and rows[-1]["stamp"] > rows[0]["stamp"], "缺新鲜递增状态")
    # wire 的无故障值是 Unknown=0（joint.fbs），不是 Rust Option::None。
    require(all(r["mode"] == "Safe" and r["safety"] == "TorqueOffConfirmed" and r["fault"] == "Unknown"
                for r in rows), "状态未确认 Safe/TorqueOffConfirmed/无故障")
    return rows


class Runner:
    def __init__(self, plan, go):
        self.plan, self.go = plan, go
        self.output = Path(plan["output"])
        self.output.mkdir(mode=0o700, parents=False, exist_ok=False)
        self.state = {"schema": "ARM_SMOKE_RUN_V1", "plan": plan, "go": go,
                      "result": "RUNNING", "steps": [], "sides": {}, "warnings": []}
        self.created = []
        self.waiters = {}
        self.secrets = []
        self.env = shared.clean_environment(os.environ)
        self.save()

    def save(self):
        temporary = self.output / "run.json.tmp"
        with temporary.open("w") as stream:
            json.dump(self.state, stream, indent=2, ensure_ascii=False)
            stream.flush()
            os.fsync(stream.fileno())
        temporary.replace(self.output / "run.json")

    def redact(self, text):
        for secret in self.secrets:
            text = text.replace(secret, "[凭据已隐去]")
        return text

    def command(self, argv, *, allowed=(0,), token=None, timeout=30):
        row = {"argv": [str(v) for v in argv], "started_ns": time.time_ns()}
        self.state["steps"].append(row)
        self.save()
        env = self.env.copy()
        if token is not None:
            env["ROBOT_TOKEN"] = token
        process = subprocess.Popen(row["argv"], stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                                   text=True, env=env, start_new_session=True)
        row["pid"] = process.pid
        try:
            stdout, stderr = process.communicate(timeout=timeout)
        except BaseException:
            row["interrupted"] = True
            print("爸爸，子命令异常：若已上扭，请立即人工切断总电源；本轮禁止继续。", file=sys.stderr, flush=True)
            process.terminate()
            try:
                stdout, stderr = process.communicate(timeout=5)
            except subprocess.TimeoutExpired:
                process.kill()
                stdout, stderr = process.communicate()
            row.update(exit_code=process.returncode, reaped=True, stdout=self.redact(stdout),
                       stderr=self.redact(stderr), finished_ns=time.time_ns())
            self.save()
            raise
        row.update(exit_code=process.returncode, reaped=True, stdout=self.redact(stdout),
                   stderr=self.redact(stderr), finished_ns=time.time_ns())
        self.save()
        require(process.returncode in allowed, f"命令失败：{Path(str(argv[0])).name}，见步骤 {len(self.state['steps'])}")
        return stdout

    def show(self, unit):
        text = self.command(["systemctl", "show", unit, "--property=" + ",".join(PROPERTIES)], allowed=(0, 1))
        row = dict(line.split("=", 1) for line in text.splitlines() if "=" in line)
        require(set(PROPERTIES) <= set(row), "systemctl 查询不完整")
        return row

    def idle(self):
        for unit in shared.UNITS:
            row = self.show(unit)
            require(row["LoadState"] == "loaded" and row["ActiveState"] == "inactive"
                    and row["SubState"] == "dead" and row["MainPID"] == "0", "正式服务未停稳")
        for unit in ("xlerobot-coordinator.service", "xlerobot-web.service",
                     "xlerobot-s0-bus1.service", "xlerobot-s0-bus2.service"):
            row = self.show(unit)
            require(row["LoadState"] in ("not-found", "loaded") and row["ActiveState"] == "inactive"
                    and row["MainPID"] == "0", "旧栈仍可能重新占用串口")
        handoff = self.show("xlerobot-handoff.service")
        require(handoff["LoadState"] == "loaded" and handoff["ActiveState"] == "active"
                and handoff["SubState"] == "exited" and handoff["MainPID"] == "0", "现有 handoff 状态改变，须重新审查")
        self.command(["sudo", "-n", "pgrep", "-x", "s0_daemon|s1_daemon|robot_rpc_gatew|xlerobot_deploy|supervised_demo"], allowed=(1,))
        snapshot = shared.process_snapshot(-1, self.output,
                    [Path(v) for v in self.plan["binaries"].values()] +
                    [Path(v["path"]) for v in self.plan["tools"].values()])
        self.state["last_process_snapshot"] = snapshot
        self.save()
        require(snapshot["clean"], "普通身份进程清场/读取能力检查失败")
        for side in self.plan["sides"]:
            self.device(side)

    def device(self, side):
        p = arm_profile(side)
        text = self.command(["udevadm", "info", "--query=property", "--name", p.device])
        fields = dict(line.split("=", 1) for line in text.splitlines() if "=" in line)
        for key, val in {"ID_VENDOR_ID": "1a86", "ID_MODEL_ID": "55d3", "ID_SERIAL_SHORT": p.usb_serial,
                         "ID_USB_DRIVER": "cdc_acm"}.items():
            require(fields.get(key) == val, "USB D2 身份改变")
        sys_path = Path("/sys") / fields["DEVPATH"].lstrip("/")
        usb = next((v for v in (sys_path, *sys_path.parents) if (v / "devnum").is_file()), None)
        require(usb is not None and int((usb / "devnum").read_text()) == self.go["physical"][side]["usb_devnum"],
                "USB 枚举与本次物理回执不符")
        out = self.command(["sudo", "-n", "fuser", p.device], allowed=(1,))
        require(not out.strip() and not self.state["steps"][-1]["stderr"].strip(), "串口占用或查询失败")

    def verify_files(self):
        for ref in (self.plan["manifest"], self.plan["bindings"], self.plan["script"], *self.plan["helpers"],
                    *self.plan["tools"].values()):
            pinned(ref)
        manifest = strict_json(pinned(self.plan["manifest"]).read_text())
        bindings = strict_json(pinned(self.plan["bindings"]).read_text())
        for row in manifest["artifacts"].values():
            pinned({"path": row["path"], "sha256": row["sha256"]})
            pinned(row["sidecar"])
        require(shared.file_hash(ROLES) == bindings["roles_sha256"], "roles 配置改变")
        self.calibrations = {}
        for side in self.plan["sides"]:
            p = arm_profile(side)
            require(shared.file_hash(p.config) == bindings["configs"][side], "配置 SHA 改变")
            config = tomllib.loads(p.config.read_text())
            hw, = config["hardware"]
            require(config["robot"]["id"] == p.robot_id and hw["id"] == p.hardware_id
                    and hw["adapter"] == "feetech_sts3215" and hw["address"] == p.device
                    and hw["motor_ids"] == list(range(1, 7)) and hw["auto_enable"] is False
                    and config["s1"]["profile"]["backends"] == ["scripted"], "D2/S1 配置错误")
            cal = pinned(bindings["calibrations"][side])
            require(hw["calibration_paths"] == [str(cal)] and cal.name == p.calibration_name, "标定路径错误")
            self.calibrations[side] = strict_json(cal.read_text())
        return bindings

    def credentials(self):
        roles = tomllib.loads(ROLES.read_text())
        result = {}
        for role, capabilities in {"operator": {"read_state", "invoke_task", "set_enabled", "estop"},
                                   "maintainer": {"clear_estop"}}.items():
            tokens = [key for key, value in roles["tokens"].items() if value == role]
            require(len(tokens) == 1 and capabilities <= set(roles["roles"][role]["capabilities"]),
                    "凭据角色或能力不唯一/缺失")
            result[role] = tokens[0]
        self.secrets = list(roles["tokens"])
        return result

    def read_bus(self, side):
        p = arm_profile(side)
        positions = {}
        for motor in range(1, 9 if side == "left" else 10):
            values = {}
            for register in ("Operating_Mode", "Torque_Enable", "Present_Velocity", "Present_Position"):
                text = self.command([self.plan["tools"]["poke"]["path"], p.device, str(motor), "read", register])
                matches = re.findall(rf"^read {register}@{motor} = (-?\d+)$", text, re.MULTILINE)
                require(len(matches) == 1, "寄存器只读响应不完整")
                values[register] = int(matches[0])
            require(values["Torque_Enable"] == 0 and values["Present_Velocity"] == 0,
                    f"{side} ID{motor} 未确认断扭静止；立即人工核实断电")
            require(values["Operating_Mode"] == (1 if side == "right" and motor >= 7 else 0),
                    f"{side} ID{motor} Operating_Mode 漂移")
            positions[motor] = values["Present_Position"]
        return positions

    def marker(self, side, action):
        p = arm_profile(side)
        return self.command([self.plan["binaries"]["s0_daemon"], "rx-trust", action,
                             "--robot-id", p.robot_id, "--rx-trust-dir", str(p.trust)])

    def marker_check(self, side, expected):
        return shared.marker_snapshot(arm_profile(side).trust, expected=expected, uid=os.getuid(), gid=os.getgid())

    def watch(self, side):
        p = arm_profile(side)
        return state_samples(self.command([self.plan["tools"]["robotctl"]["path"], "watch",
                    "--robot-id", p.robot_id, "--hardware-id", p.hardware_id,
                    "--duration-secs", "2", "--interval-ms", "100"]))

    def start(self, side, role):
        unit = unit_name(self.plan["run_id"], side, role)
        require(self.show(unit)["LoadState"] == "not-found", "transient 名称已存在，拒复用")
        # 请求前登记所有权候选；命令返回失败也必须检查本次 unit 是否已创建并收尾。
        self.created.append(unit)
        self.state["created_units"] = list(self.created)
        self.save()
        argv = self.plan["services"][side][role]
        receipt = {"argv": argv, "started_ns": time.time_ns(), "kind": "systemd-run-wait"}
        self.state["steps"].append(receipt)
        # --wait 保持本轮启动客户端，stop 后必须从该客户端取得真实退出并 wait/reap。
        waiter = subprocess.Popen(argv, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                                  text=True, env=self.env, start_new_session=True)
        receipt["pid"] = waiter.pid
        self.waiters[unit] = (waiter, receipt)
        self.save()
        deadline = time.monotonic() + 60
        while True:
            state = self.show(unit)
            require(waiter.poll() is None, "transient 启动客户端提前退出")
            if state["LoadState"] == "not-found":
                require(time.monotonic() < deadline, "transient 创建未完成")
                time.sleep(0.2)
                continue
            require(state["ActiveState"] != "failed" and state["Restart"] == "no",
                    "transient 启动失败/意外自动重启")
            if state["ActiveState"] == "active":
                require(state["SubState"] == "running" and int(state["MainPID"]) > 0
                        and state["Type"] == "notify" and state["User"] == state["Group"] == "loosqk", "READY 身份不符")
                if role == "s0":
                    self.check_serial_rt(int(state["MainPID"]), arm_profile(side).serial_cpu)
                return state
            require(time.monotonic() < deadline, "READY 超过监督等待窗；先人工断电，禁止下一侧")
            time.sleep(0.2)

    def check_serial_rt(self, pid, cpu):
        tasks = self.command(["sudo", "-n", "ps", "-L", "-p", str(pid), "-o", "tid=,cls=,rtprio=,comm="])
        serial = [row.split() for row in tasks.splitlines() if "serial" in row.lower()]
        require(len(serial) == 1 and serial[0][1:3] == ["FF", "70"], "serial 线程 FIFO70 事实不符")
        status = Path(f"/proc/{pid}/task/{serial[0][0]}/status").read_text()
        require(re.search(rf"^Cpus_allowed_list:\s*{cpu}$", status, re.MULTILINE), "serial CPU 不符")

    def stop_side(self, side):
        errors = []
        for role in ("gateway", "s1", "s0"):
            unit = unit_name(self.plan["run_id"], side, role)
            if unit not in self.created:
                continue
            before = {}
            try:
                waiter_pair = self.waiters.get(unit)
                next_warning = time.monotonic() + 60
                # systemd-run 提交尚未完成时不能把 not-found 当作“未创建”。
                # 保留自有 wait 客户端直至真实创建/退出；不杀客户端来伪造取消创建。
                query_error_recorded = False
                while True:
                    try:
                        before = self.show(unit)
                    except Exception:
                        if not query_error_recorded:
                            errors.append(f"{unit} 创建状态查询失败，原错误保留")
                            query_error_recorded = True
                        if not waiter_pair or waiter_pair[0].poll() is not None:
                            raise
                        # 查询失败不代表尚未创建，更不代表创建已取消。仍持有 waiter。
                        before = {"LoadState": "not-found"}
                    if before["LoadState"] != "not-found" or not waiter_pair or waiter_pair[0].poll() is not None:
                        break
                    if time.monotonic() >= next_warning:
                        self.state.setdefault("warnings", []).append(f"{unit} 创建状态仍未决；需现场断电/介入，继续持有wait")
                        self.save()
                        print("爸爸，systemd 创建状态仍未决；请现场断电并介入，尚未宣称清场。", file=sys.stderr, flush=True)
                        next_warning = time.monotonic() + 60
                    time.sleep(0.2)
                if before["LoadState"] == "not-found":
                    # 退出与状态查询交错时，再查询一次；waiter 的真实结束先于此次查询。
                    before = self.show(unit)
                if before["LoadState"] != "not-found":
                    self.command(["sudo", "-n", "systemctl", "stop", unit], timeout=45)
            except Exception as error:
                errors.append(str(error))
            try:
                if unit not in self.waiters:
                    require(before.get("LoadState") == "not-found", "无启动客户端却存在本次 unit")
                    continue
                waiter, receipt = self.waiters[unit]
                try:
                    stdout, stderr = waiter.communicate(timeout=10)
                except subprocess.TimeoutExpired:
                    waiter.terminate()
                    try:
                        stdout, stderr = waiter.communicate(timeout=5)
                    except subprocess.TimeoutExpired:
                        waiter.kill()
                        stdout, stderr = waiter.communicate()
                    receipt["waiter_interrupted"] = True
                receipt.update(exit_code=waiter.returncode, reaped=True, stdout=self.redact(stdout),
                               stderr=self.redact(stderr), finished_ns=time.time_ns())
                self.save()
                after = self.show(unit)
                require(after["MainPID"] == "0" and after["ActiveState"] in ("inactive", "failed"), "unit 未退出")
                cgroup = before.get("ControlGroup")
                if cgroup:
                    procs = Path("/sys/fs/cgroup") / cgroup.lstrip("/") / "cgroup.procs"
                    require(not procs.exists() or not procs.read_text().strip(), "transient cgroup 有残留")
                self.command(["journalctl", "-u", unit, "--no-pager", "-o", "cat"])
                require(waiter.returncode == 0 and not receipt.get("waiter_interrupted"), "systemd-run --wait 未确认正常退出")
                if after["LoadState"] != "not-found":
                    require(after["Result"] == "success" and after["ExecMainStatus"] == "0", "daemon 非正常退出")
            except Exception as error:
                errors.append(str(error))
        require(not errors, "；".join(errors))

    def run_side(self, side, tokens):
        row = self.state["sides"][side] = {"result": "RUNNING", "authorize_attempts": 0,
                                                  "clear_attempts": 0, "demo_attempts": 0}
        self.save()
        failure = None
        try:
            validate_go(self.go, self.plan, time.time_ns(), os.uname().nodename,
                        Path("/proc/sys/kernel/random/boot_id").read_text().strip())
            self.verify_files()
            self.idle()
            before = self.read_bus(side)
            row["calibration_exceptions"] = validate_positions(side, self.calibrations[side], before)
            p = arm_profile(side)
            row["runtime_preconditions"] = shared.validate_runtime_preconditions(
                shared.inspect_runtime_preconditions(p.trust), p.trust)
            # 默认只接受已知 canonical Dirty；不把未知/缺失授权自动规范化。
            self.marker_check(side, b"1\n")
            for path in (p.trust / "estop_latch", p.trust / "estop_latch.bak"):
                require(path.read_bytes() == b"1\n", "本次预期 EStop=1，变化须重新审查")
            self.marker(side, "status")
            row["authorize_attempts"] += 1
            self.save()
            self.marker(side, "authorize")
            self.marker_check(side, b"0\n")
            for role in ("s0", "s1", "gateway"):
                row[role] = self.start(side, role)
            self.marker_check(side, b"1\n")
            row["before_clear"] = self.watch(side)
            row["clear_attempts"] += 1
            self.save()
            self.command([self.plan["tools"]["robotctl"]["path"], "clear-estop", "--confirmation",
                          "CONFIRM_CLEAR_ESTOP", "--gateway-addr", gateway(side), "--audit-reason",
                          "本次逐侧受监督小幅功能探针"], token=tokens["maintainer"])
            row["before_motion"] = self.watch(side)
            row["demo_attempts"] += 1
            self.save()
            text = self.command([self.plan["tools"]["demo"]["path"], "--phase", "single-arm", "--side", side,
                     f"--{side}-config", str(p.config), f"--{side}-hardware-id", p.hardware_id,
                     f"--{side}-gateway", gateway(side), "--probe-joint", f"{side}_arm_wrist_roll",
                     "--probe-offset-rad", "0.05", "--settle-tolerance-rad", "0.02", "--ack-safety-checklist"],
                     token=tokens["operator"], timeout=45)
            require(f"side={side} Completed(Success) + motion evidence" in text
                    and "disable confirmed PASS" in text, "demo 缺完成/运动/停止证据")
            row["after_motion"] = self.watch(side)
        except BaseException as error:
            failure = f"{type(error).__name__}: {error}"
            print("爸爸，本侧失败，禁止下一侧；若停止未知/进程异常，请立即人工切断总电源。", file=sys.stderr, flush=True)
        finally:
            # clear 的失败回执也不能推出没有副作用。仅调用既有 topic EStop；
            # 输出明确记录该通道，不把发布返回值冒充物理断扭或 RPC Ack。
            if row["clear_attempts"]:
                try:
                    self.command([self.plan["tools"]["robotctl"]["path"], "estop", "--robot-id",
                                  arm_profile(side).robot_id, "--reason", "本次功能探针结束或异常，恢复急停锁存"],
                                 token=tokens["operator"], timeout=10)
                    row["estop_channel"] = "既有 iceoryx2 EStopEvent topic"
                    row["after_estop"] = self.watch(side)
                    for path in (arm_profile(side).trust / "estop_latch",
                                 arm_profile(side).trust / "estop_latch.bak"):
                        require(path.read_bytes() == b"1\n", "EStop 后双份 latch 未确认1")
                    row["latch_restored_by_estop"] = True
                except BaseException as estop_error:
                    failure = (failure or "") + f"；独立 EStop/读回失败：{estop_error}"
                    row["latch_restored_by_estop"] = False
                    print("爸爸，独立 EStop 未确认，请立即人工切断总电源。", file=sys.stderr, flush=True)
            try:
                self.stop_side(side)
            except BaseException as cleanup_error:
                failure = (failure or "") + f"；收尾失败：{cleanup_error}"
            # 某个退出码/日志收集失败不阻断其它清场证据；但串口非独占时绝不读寄存器。
            row["final_torque_off_and_zero_velocity"] = False
            try:
                self.idle()
                row["cleanup_idle"] = True
            except BaseException as idle_error:
                failure = (failure or "") + f"；最终互斥检查失败：{idle_error}"
                row["cleanup_idle"] = False
            if row["cleanup_idle"]:
                if row["authorize_attempts"]:
                    try:
                        try:
                            self.marker_check(side, b"1\n")
                        except ValueError:
                            row["cleanup_revoke_attempts"] = 1
                            self.save()
                            self.marker(side, "revoke")
                            self.marker_check(side, b"1\n")
                        row["final_marker_dirty"] = True
                    except BaseException as marker_error:
                        failure = (failure or "") + f"；残余授权撤销失败：{marker_error}"
                try:
                    row["final_positions_raw"] = self.read_bus(side)
                    row["final_torque_off_and_zero_velocity"] = True
                except BaseException as bus_error:
                    failure = (failure or "") + f"；最终断扭读回失败：{bus_error}"
            row["result"] = "FAIL" if failure else "PASS"
            row["error"] = failure
            self.save()
        require(failure is None, "本側 FAIL；全部后续动作未执行")

    def run(self):
        try:
            account = pwd.getpwnam("loosqk")
            require(os.getuid() == os.geteuid() == account.pw_uid and os.getgid() == os.getegid() == account.pw_gid,
                    "必须以 loosqk 实际身份运行，不 sudo 整个 driver")
            require(os.uname().machine == "aarch64", "仅 Orin ARM 本机执行")
            self.verify_files()
            tokens = self.credentials()
            for side in self.plan["sides"]:
                trust = arm_profile(side).trust
                info = trust.lstat()
                require(stat.S_ISDIR(info.st_mode) and info.st_uid == os.getuid()
                        and info.st_gid == os.getgid() and stat.S_IMODE(info.st_mode) == 0o750, "TRUST 身份错误")
                self.run_side(side, tokens)
            self.state["result"] = "PASS"
            return 0
        except BaseException as error:
            self.state["result"] = "FAIL"
            self.state["error"] = self.redact(f"{type(error).__name__}: {error}")
            return 1
        finally:
            self.state["finished_ns"] = time.time_ns()
            self.save()


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    for flag in ("manifest", "bindings", "robotctl", "demo", "poke", "output"):
        parser.add_argument("--" + flag, type=Path)
    parser.add_argument("--run-id")
    parser.add_argument("--execute", action="store_true")
    parser.add_argument("--approval", type=Path)
    options = parser.parse_args(argv)
    if not all(getattr(options, key) is not None for key in ("manifest", "bindings", "robotctl", "demo", "poke", "output", "run_id")):
        require(not options.execute, "执行参数不完整")
        print(json.dumps({"result": "PLAN_ONLY", "actions_started": 0, "required": ["manifest", "bindings", "robotctl", "demo", "poke", "output", "run-id"],
                          "order": "左 authorize→三 transient→clear-estop→single-arm→停止/寄存器确认；全成功后右侧同序",
                          "execute_requires": "--execute --approval（root 本次 plan_sha256 GO，现场 power/USB 等事实完整）"}, ensure_ascii=False, indent=2))
        return 0
    plan = build_plan(options)
    if not options.execute:
        print(json.dumps({"result": "PLAN_ONLY", "actions_started": 0, "plan_sha256": digest(plan), "plan": plan}, ensure_ascii=False, indent=2))
        return 0
    require(options.approval is not None, "必须指定本次 root GO")
    go = strict_json(options.approval.read_text())
    validate_go(go, plan, time.time_ns(), os.uname().nodename,
                Path("/proc/sys/kernel/random/boot_id").read_text().strip())
    def interrupted(signum, _frame):
        raise InterruptedError(f"收到信号 {signum}")
    signal.signal(signal.SIGTERM, interrupted)
    signal.signal(signal.SIGINT, interrupted)
    return Runner(plan, go).run()


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except (ValueError, OSError, KeyError, TypeError) as error:
        print(f"爸爸，前置拒绝：{type(error).__name__}: {error}", file=sys.stderr)
        raise SystemExit(2)
