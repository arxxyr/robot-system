"""冻结本次 Orin 功能测试客户端；不触及串口、服务或安全状态。"""
import hashlib
import json
from pathlib import Path
import shutil
import subprocess

ROOT = Path('/home/loosqk/repo/robot/robot-system')
OUT = ROOT / 'target/hardware_smoke_20260929'
EXPECTED_HEAD = 'ca14f0e6cf6df8ecc6baaaa8dff2dddb64abbd0a'


def sha(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def main():
    head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip()
    assert head == EXPECTED_HEAD
    assert not subprocess.check_output(['git', 'status', '--porcelain'], cwd=ROOT, text=True).strip()
    target = OUT / 'tools'
    target.mkdir(parents=True, exist_ok=False)
    manifest = {'build_head': head, 'toolchain': 'nightly-2026-09-10', 'artifacts': {}}
    for name, label, features in [('robotctl', 'robotctl', []), ('supervised_demo', 'demo', ['supervised-demo'])]:
        log = ROOT / f'target/hardware_smoke_20260929_{label}_build.jsonl'
        messages = [json.loads(line) for line in log.read_text().splitlines()]
        assert messages[-1] == {'reason': 'build-finished', 'success': True}
        artifacts = [row for row in messages if row.get('reason') == 'compiler-artifact'
                     and row.get('target', {}).get('name') == name and row.get('executable')]
        assert len(artifacts) == 1
        artifact = artifacts[0]
        assert artifact['features'] == features
        assert artifact['profile']['test'] is False and artifact['profile']['opt_level'] == '3'
        source = Path(artifact['executable'])
        assert source == ROOT / 'target/rr-r4db-arm/root/release' / name
        destination = target / name
        shutil.copy2(source, destination)
        assert source.stat().st_ino != destination.stat().st_ino
        assert sha(source) == sha(destination)
        assert destination.read_bytes()[:4] == b'\x7fELF'
        assert int.from_bytes(destination.read_bytes()[18:20], 'little') == 183
        manifest['artifacts'][name] = {'path': str(destination), 'sha256': sha(destination),
                                      'bytes': destination.stat().st_size, 'cargo': artifact,
                                      'build_log_sha256': sha(log)}
    (OUT / 'tools_manifest.json').write_text(json.dumps(manifest, ensure_ascii=False, indent=2) + '\n')
    print(json.dumps({name: {k: row[k] for k in ('path', 'sha256', 'bytes')}
                      for name, row in manifest['artifacts'].items()}, indent=2))


if __name__ == '__main__':
    main()
