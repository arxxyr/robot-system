# 2026-09-29 run_01 硬件证据独立审计

结论：证据支持本次受监督、逐侧各一次 `wrist_roll` 出程/回程探针及收尾 PASS；保留写路径 Unknown 告警观察项，不宣称零告警、完整双臂能力或生产安全验收通过。审计仅读取本地原件与判据源码，未 SSH、未操作串口/硬件、未编辑代码；仅新增本文件。

## 原件身份与授权

| 文件 | SHA-256 |
| --- | --- |
| `run_01.json` | `483da756a459c3864da6e250da452e76fd740ddbcaa53c9af235b0f2acec08ab` |
| `after_run_01.txt` | `749839f298d028b8a2166c59d618d66915b086d434d32b51c8627759e264f320` |
| `run_arm_smoke.py` | `cf56987234d6e55a9e4abcd2054a01280ab487975f1b661f69b499dcd05ba5d5` |
| `prelaunch_01.json` | `38187a76446eb3683243d91102df8fa3b78cbb1736492956cf4a49dcba9a9a94` |
| `go_01.json` | `7d0cfd87530b336ad11c05022c42f1f4f9bc6c66cbad0e26dc06de185092262d` |

独立重算 run 内完整 plan 的规范 JSON SHA 为 `279b720cca9a4ffa893553711892c362766930f1035e5b90ab057652be19cbcb`，与 GO/预启动记录一致；run 内 GO 与独立 GO 文件内容相同。主机、boot、两侧 USB 序列号及新枚举号 19/20 对应；首步骤晚于 GO 签发，结束早于 GO 到期。物理支持/在场事实来自 GO 所引用户回执，并非本审计另行观察。

## 动作与回程

以下步骤号均为 `run_01.json.steps` 的零基下标。总记录 268 个步骤；两侧 authorize、clear、demo 各恰好一次，未见第二次 demo 或脚本中断；不据此推断 adapter 内部所有事务均无重试。

| 侧 | demo 步骤 / PID | 指令与运动证据 | 回程旁证 |
| --- | --- | --- | --- |
| 左 | 66 / 380985 | `left_arm_wrist_roll`，目标偏移 +0.05 rad；最大实测同向位移 +0.0383 rad；Completed(Success)、disable confirmed，exit 0、reaped=true | 前后 watch 腕部位置约 -1.695 → -1.687 rad，差约 0.008 rad |
| 右 | 200 / 381218 | `right_arm_wrist_roll`，目标偏移 +0.05 rad；最大实测同向位移 +0.0414 rad；Completed(Success)、disable confirmed，exit 0、reaped=true | 前后 watch 腕部位置约 -1.801 → -1.798 rad，差约 0.003 rad |

`supervised_demo.rs:564–595` 的 witness 判据要求至少 3 个递增新鲜样本、出程至少 offset−tolerance=0.03 rad、最后新鲜样本距起点不超过 0.02 rad；`998–1007` 在 disable 前采集回程并判定，`1462–1470` 仅在 witness 与 disable 都通过后打印 PASS。日志中的两侧最大位移达到既定阈值；不能将指令 +0.05 rad 说成实际精确移动了 0.05 rad。原件未保存 demo 内每个 witness 样本及精确末次回程差，精确过程重算能力有限；独立 watch 旁证保留了动作后位置，且每侧动作前、动作后、EStop 后各 20 帧均为递增时戳、Safe/TorqueOffConfirmed/Unknown。

右肘原始位置 2995，标定上限 2991；run 明确保留既定 4 tick clamp 例外，不能宣称所有关节均完全位于原始标定范围内。

## 断扭、急停与退出

- 逐项核对末次 `feetech_poke read` 原始 stdout：左总线 ID1–8（步骤 98–129）、右总线 ID1–9（232–267）共 17 电机，Torque_Enable=0、Present_Velocity=0；全部读命令 exit 0、reaped=true。Operating_Mode 左侧 8 个及右侧 ID1–6 为 0，右侧 ID7–9 为 1。每侧在本侧服务退出及串口互斥成立后读回，属于先左后右的末次总线快照，不是 17 电机同一时刻的同时采样。
- 两侧 EStop 步骤 68/202 经既有 topic 发布，随后新鲜状态与双份 latch 读回确认；`after_run_01.txt:77–84` 再次记录两侧 `estop_latch`、`.bak`、`rx_trust_marker`、`.bak` 全部为 `31 0a`，即 `1\n`。topic 发送成功本身不被当作物理断扭证明。
- 六个 `systemd-run --wait` 客户端 PID 为左 380928/380947/380960、右 381126/381145/381162；均 exit 0、reaped=true、无 waiter_interrupted，原始 stderr 均含 `Finished with result: success` 和 `code=exited/status=0`。对应步骤为 51/56/60、185/190/194。
- 两侧 cleanup_idle=true；末次进程快照 clean=true、related/unreadable 均空，两个普通身份拒读对象经有界特权只读探针确认后不相关。最终 pgrep/fuser 的 exit 1 均为无匹配/无占用预期结果。19:44:00 UTC 的 `after_run_01.txt` 显示六个 transient 均 not-found/inactive/dead、MainPID=0，六个正式 unit 均 inactive/dead、MainPID=0。证据支持采集时无本次相关运行残留。
- 本次使用 plan 绑定的 ca14 冻结生产四件；`after_run_01.txt:73–76` 记录正式 `target/release` 四件仍为此前旧产物 SHA，不能把本次测试说成正式安装或正式服务升级。

## 告警与宣称边界

六份 journal 原文共 68 条结构化 WARN（每侧 34），另有 9 处 iceoryx 默认配置 `[W]` 提示；未发现 ERROR 记录。run 顶层 `warnings=[]` 不表示 journal 零警告。

- site4 kind1/2/3、a=1 对应 FIFO、mlockall、CPU 绑定成功（`serial_io_thread.rs:237–263`）。
- site20 的 kind0/4/8/9/11/13/15/17 对应相位切换、EStop claim/义务、连接、可信确认、启动出口/上下文及收敛结果；未见其故障、信任丢失或不可信确认事件（`serial_convergence.rs:1356–1358`）。
- **每侧 17 条 site5 kind0 a63 b0 是必须保留的未归因观察项**：来源是 Goal_Position 写命令错误路径（`feetech/adapter.rs:575–608`）；`record_error` 将无具体通信分类的错误编码为 Unknown=63（同文件 290–299）。`FeetechError::Aborted` 等非通信原因也会落入该编码（`feetech/error.rs:174–201`），执行器对 Emergency/Revoked 中止单独处理（`serial_tick.rs:549–570`）。24 份串口一秒摘要均 dropped=0、comm_level=0、rx_trust=true，使权限撤销/中止成为合理候选，但日志缺原始错误/AbortReason，不能把候选写成已证实根因，也不能据此宣称无写错误。此观察项不抹去本次既定动作与最终断扭判据的 PASS。

头部、底盘未测试主动运动；其记录包括状态读取及启动安全写，不能称全程仅只读。实际使用的 `xlerobot_deploy guard` 在 exec S0 前调用 `ensure_safe_arm`（`deploy/guard.rs:544–546`）：左 ID1–8 写 Torque_Enable=0；右 ID1–6 写 Torque_Enable=0，ID7–9 逐个先 Goal_Velocity=0 再 Torque_Enable=0（`deploy/preflight.rs:176–217`）。这些是安全预检，不是头部/底盘运动功能验证。

本次有限逐侧腕部 PASS 不关闭右 H2 历史整体 FAIL，不关闭 D15；deployable=false 保持。未验证 H2 严格时序、双臂同时动作、全部关节/夹爪动作、头部/底盘主动运动、无人值守或断电硬件 fail-safe。快照不能证明审计之后持续断扭，也不证明物理总电源已切断。
