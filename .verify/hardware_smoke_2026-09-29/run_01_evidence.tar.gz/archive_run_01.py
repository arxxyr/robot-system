"""只读取已完成记录，校验并归档；不连接机器人，也不执行动作。"""
import collections
import datetime
import hashlib
import io
import json
import math
from pathlib import Path
import re
import tarfile

root = Path('target/hardware_smoke_20260929')
out = Path('.verify/hardware_smoke_2026-09-29')
def sha(data):
    return hashlib.sha256(data).hexdigest()
def utc(ns):
    return datetime.datetime.fromtimestamp(ns / 1e9, datetime.timezone.utc).isoformat()
r = json.loads((root / 'run_01.json').read_text())
assert r['result'] == 'PASS' and not r['warnings']
assert sha((root / 'run_01.json').read_bytes()) == (root / 'run_01_remote_sha256.txt').read_text().split()[0]
steps = r['steps']
assert len(steps) == 268 and all(s['reaped'] for s in steps)
nonzero = [s for s in steps if s['exit_code'] != 0]
assert all(s['exit_code'] == 1 and s['argv'][2] in ('pgrep', 'fuser') and not s['stdout'] and not s['stderr'] for s in nonzero)
waiters = [s for s in steps if s.get('kind') == 'systemd-run-wait']
assert len(waiters) == 6 and all(s['exit_code'] == 0 and 'code=exited/status=0' in s['stderr'] for s in waiters)
last_registers = {}
for s in steps:
    a = s['argv']
    if a[0].endswith('/feetech_poke'):
        assert a[3] == 'read' and s['exit_code'] == 0
        value = re.fullmatch(r'read (\w+)@(\d+) = (-?\d+)\n', s['stdout'])
        assert value and (value[1], value[2]) == (a[4], a[2])
        side = 'left' if '5A7C121427' in a[1] else 'right'
        last_registers[(side, int(a[2]), a[4])] = (int(value[3]), s['started_ns'])
final_motors = []
sides = {}
for side, count in [('left', 8), ('right', 9)]:
    s = r['sides'][side]
    assert s['result'] == 'PASS' and s['error'] is None
    assert all(s[k] == 1 for k in ('authorize_attempts', 'clear_attempts', 'demo_attempts'))
    assert all(s[k] for k in ('latch_restored_by_estop', 'final_torque_off_and_zero_velocity', 'cleanup_idle', 'final_marker_dirty'))
    ended = max(w['finished_ns'] for w in waiters if f'-{side}-' in w['argv'][5])
    for motor in range(1, count + 1):
        vals = {reg: last_registers[(side, motor, reg)] for reg in ('Operating_Mode', 'Torque_Enable', 'Present_Velocity', 'Present_Position')}
        assert all(timestamp > ended for value, timestamp in vals.values())
        assert vals['Torque_Enable'][0] == vals['Present_Velocity'][0] == 0
        assert vals['Operating_Mode'][0] == (1 if side == 'right' and motor >= 7 else 0)
        final_motors.append({'side': side, 'motor': motor, 'registers': {k: v[0] for k, v in vals.items()}, 'read_started_utc': utc(min(v[1] for v in vals.values()))})
    demos = [x for x in steps if x['argv'][0].endswith('/supervised_demo') and x['argv'][4] == side]
    assert len(demos) == 1
    demo = demos[0]
    assert 'Completed(Success) + motion evidence' in demo['stdout'] and 'disable confirmed PASS' in demo['stdout']
    excursion = float(re.search(r'max_excursion=\+([0-9.]+) rad', demo['stdout'])[1])
    sides[side] = {'result': s['result'], 'probe_joint': f'{side}_arm_wrist_roll', 'max_excursion_rad': excursion, 'max_excursion_degrees': round(math.degrees(excursion), 3), 'authorize_attempts': 1, 'clear_attempts': 1, 'demo_attempts': 1, 'calibration_exceptions': s['calibration_exceptions'], 'return_within_0_02_rad_confirmed_by_client': True, 'full_witness_frames_archived': False, 'final_latch_and_torque_off_verified': True}
levels = collections.Counter()
for s in steps:
    if 'journalctl' in s['argv']:
        for line in s['stdout'].splitlines():
            try:
                log = json.loads(line)
            except json.JSONDecodeError:
                continue
            levels[log.get('level', 'UNKNOWN')] += 1
snapshot = (root / 'after_run_01.txt').read_text()
assert snapshot.count('MainPID=0') == 12 and snapshot.count('ActiveState=inactive') == 12
assert snapshot.count('31 0a') == 8
initial_hash = sha((out / 'evidence.tar.gz').read_bytes())
assert initial_hash == 'ce5fdf02cc44f4bb47ca187972f8f1bc6b3e03433d653747ca20be068a880900'
summary = {'schema': 'HARDWARE_SMOKE_RUN_01_SUMMARY_V1', 'status': 'ARM_WRIST_PROBES_PASS_WITH_UNRESOLVED_WRITE_DIAGNOSTICS_HEAD_BASE_NO_ACTIVE_MOTION', 'run_id': r['plan']['run_id'], 'started_utc': utc(min(s['started_ns'] for s in steps)), 'finished_utc': utc(r['finished_ns']), 'new_power_cycle_and_usb_replug_confirmed': True, 'plan_sha256': r['go']['plan_sha256'], 'host': r['go']['host'], 'boot_id': r['go']['boot_id'], 'sides': sides, 'final_motors': final_motors, 'expected_idle_nonzero_commands': len(nonzero), 'all_268_command_children_reaped': True, 'all_6_service_waiters_exit_zero': True, 'journal_structured_level_counts': dict(levels), 'formal_binaries_changed': False, 'formal_services_started': False, 'eeprom_written': False, 'head_motion_tested': False, 'base_motion_tested': False, 'all_joint_motion_tested': False, 'D15': 'OPEN', 'right_H2_historical_result': 'FAIL_UNCHANGED', 'source_under_hardware_test': 'ca14f0e6cf6df8ecc6baaaa8dff2dddb64abbd0a', 'current_local_c6e8b2d_hardware_regression': False, 'raw_run_sha256': sha((root / 'run_01.json').read_bytes()), 'previous_stage_evidence_preserved_sha256': initial_hash}
summary['head_base_guard_safety_writes'] = {'head': 'Torque_Enable=0', 'base': 'Goal_Velocity=0; Torque_Enable=0'}
summary['unresolved_write_diagnostics'] = {'site': 5, 'kind': 0, 'a': 63, 'b': 0, 'per_side_count': 17, 'original_error_reason_retained': False, 'root_cause_proven': False}
files = ['run_01.json', 'run_01_remote_sha256.txt', 'run_01_ssh.log', 'go_01.json', 'prelaunch_01.json', 'after_run_01.txt', 'run_arm_smoke.py', 'test_arm_smoke.py', 'plan_final_orin.json', 'bindings.json', 'tools_manifest.json', 'ca14_production.json', 'ca14_verification.txt', 'test_demo.log', 'test_runner_final_local.log', 'test_runner_final_orin.log', 'independent_review.md', 'run_01_independent_review.md', 'read_only_stage_summary.md', 'archive_run_01.py']
blobs = {name: (root / name).read_bytes() for name in files}
blobs['current_handoff.md'] = Path('docs/handoffs/hardware_smoke_2026-09-29_summary.md').read_bytes()
index = {name: {'sha256': sha(data), 'bytes': len(data)} for name, data in blobs.items()}
blobs['index.json'] = (json.dumps(index, ensure_ascii=False, indent=2) + '\n').encode()
archive = out / 'run_01_evidence.tar.gz'
with tarfile.open(archive, 'w:gz') as tar:
    for name, data in blobs.items():
        member = tarfile.TarInfo(name)
        member.size = len(data)
        member.mtime = r['finished_ns'] // 1_000_000_000
        tar.addfile(member, io.BytesIO(data))
with tarfile.open(archive, 'r:gz') as tar:
    assert set(tar.getnames()) == set(blobs)
    for name, item in index.items():
        data = tar.extractfile(name).read()
        assert sha(data) == item['sha256'] and len(data) == item['bytes']
summary['evidence'] = {'path': str(archive), 'sha256': sha(archive.read_bytes()), 'bytes': archive.stat().st_size, 'indexed_files': len(index), 'all_member_hashes_verified': True}
(out / 'run_01_summary.json').write_text(json.dumps(summary, ensure_ascii=False, indent=2) + '\n')
print(json.dumps({'status': summary['status'], 'evidence': summary['evidence'], 'journal_levels': dict(levels)}, ensure_ascii=False))
