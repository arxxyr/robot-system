# 2026-09-29 XLeRobot 硬件检查

本轮用户要求测试机械臂、头部、底盘，并确认持续在场、可立即切断电机电源、双臂空载且有支撑、接触区清空；底盘在地面且周围有空地。

## 当前结果

**仅只读硬件检查通过，运动测试未执行。** 2026-09-29 19:12:18–19:12:19 UTC，在 Orin `ubuntu / loosqk / aarch64` 上完成 17 个电机的 102 项状态/目标寄存器检查，每项另含握手与型号校验。读取工具来自本轮核验的 Rust Feetech 源码快照，未调用寄存器写入。

| 模块 | 总线 / 电机 ID | 型号及通信 | Operating_Mode | Torque_Enable / Present_Velocity | 动作结果 |
| --- | --- | --- | --- | --- | --- |
| 左臂及夹爪 | `5A7C121427` / 1–6 | 全部正常，STS3215 | 全部 0 | 全部 0 / 0 | 未执行 |
| 头部 | `5A7C121427` / 7–8 | 全部正常，STS3215 | 全部 0 | 全部 0 / 0 | 未执行 |
| 右臂及夹爪 | `5A7C122340` / 1–6 | 全部正常，STS3215 | 全部 0 | 全部 0 / 0 | 未执行 |
| 底盘 | `5A7C122340` / 7–9 | 全部正常，STS3215 | 全部 1 | 全部 0 / 0 | 未执行 |

这次采样证明当时通信正常、扭矩使能寄存器为零、反馈速度为零；不证明机械运动能力、持续运行稳定性或硬件 fail-safe。头部和右臂多个 Goal_Position 留为 0，禁止用直接上扭代替当前位追平流程。

初始六个正式控制服务均 inactive/dead、MainPID=0，两条串口无持有者。旧 coordinator/web 均 inactive；handoff 保持 active/exited。两臂原 EStop latch 主备均为 `1\n`，没有清除。本轮未启动正式控制服务、未使能电机、未写 EEPROM、未修改正式配置。

## 动作前置及能力缺口

- 两臂小幅测试仍等待用户完成并确认**本次两臂电机电源重上电及两根 USB 物理拔插**。这是 [RX 信任流程](../../scripts/systemd/README_dimos_replace.md) §5.2 的启动前置；本轮支撑和在场确认不能替代该物理事实，历史重插也不复用。
- 当前正式路径四个 ELF 对应 9 月 8 日 C5 恢复产物，不能按路径名称推断包含 S48 修复。本轮核对了 `ca14f0e` 已冻结生产四件及 sidecar，均与既有归档 SHA 一致；尚未启动或正式安装这些候选件。
- 机械臂计划逐侧执行已有 `supervised_demo --phase single-arm`：腕部从实测锚点 +0.05 rad 再返回，每段 0.5 秒；整臂六电机都会上扭。出程、回程和 Disable 必须有真实反馈，失败禁止执行下一侧。之后经既有 CLI 急停事件恢复双份锁存状态，再回收进程并读回断扭。该 CLI 急停入口是 iceoryx2 事件，不是 RPC Ack；不得以发布成功代替停止确认。
- 初始右肘 raw=2995，标定最大值为 2991。仅记录本次已知的 4 tick 越界；若后续探针允许复用现有 adapter clamp，只允许该关节最多 4 tick，运行前必须重读。其余关节不放宽标定限制。
- **头部不能只换成历史 full 配置后启动。** 现有 D2 身份、guard 和 ClearEStop 恢复事务绑定 arm-only 安全域，头部动作入口需作为独立能力扩展接入。[D2 范围](../../team-swe/specs/v0_5_dimos_replace.md)明确未包含头部/底盘驱动。
- **底盘真实速度执行链尚未实现。** 当前 Feetech adapter 忽略 Velocity/Stop 命令，上扭和失联策略仍采用位置语义。后续需要速度模式校验、零速确认后上扭、真正速度写入以及超时/取消/Disable 收尾；不能直接运行旧上游底盘脚本。当前三轮已经是模式 1，未来受监督测试可设计为不修改 EEPROM，但本轮没有发送速度指令。

本轮不改变右臂 H2 的历史整体 FAIL，不关闭 D15，不宣称生产可部署或无人值守。

## 已完成的软件准备

在 Orin 的干净 `ca14f0e6cf6df8ecc6baaaa8dff2dddb64abbd0a` 源码上，用 `nightly-2026-09-10`、独立 `CARGO_TARGET_DIR=target/rr-r4db-arm/root` 构建并复制冻结客户端，未覆盖正式 `target/release`：

| 工具 | SHA-256 |
| --- | --- |
| robotctl | `704b25479560c503e3949c0621c79ad708186bffefd9a3cdf258ea666cad7285` |
| supervised_demo | `5cd987dc97265326a28aa5f34b3f02f563536704c99e7c49736dee56c3e21cf9` |
| 只读 feetech_poke（S49 快照，dev 构建） | `c4f83e7928a8d1aa8b134708688fdb49b6040eac25520463067029e61b6c7ef2` |

Orin `supervised_demo` release 单元测试：**36 通过、0 失败、0 忽略**。最终逐侧监督脚本的 **17 项纯 mock 测试在本机及 Orin 均通过**，覆盖超时急停、失败后继续收尾、残余授权撤销、创建竞争及前侧失败阻断后侧。之前 15 项通过日志保留；新增用例编写中曾出现一次 NameError，修复后重新验证，不称首轮全部通过。Orin 最终实参 PLAN_ONLY 输出成功，`actions_started=0`。这些都是软件准备结果，不是硬件动作结果。

客户端、构建清单和绑定文件位于 Orin `/home/loosqk/repo/robot/robot-system/target/hardware_smoke_20260929/`。本次逐侧监督脚本默认 PLAN_ONLY，尚无现场重插答复、未生成执行 GO、未消费 RX 一次性授权。

本地原始日志、只读结果 JSON 和准备材料位于 `target/hardware_smoke_20260929/`，已逐文件校验归档到 [证据包](../../.verify/hardware_smoke_2026-09-29/evidence.tar.gz)，机器摘要见 [summary.json](../../.verify/hardware_smoke_2026-09-29/summary.json)。最终独立审查仅接受软件准备，保留 `hardware_ready=false / awaitphysical`。后续动作必须使用新鲜现场事实和新输出目录，不能把本报告的静态读数或软件通过直接升级为硬件 PASS。
