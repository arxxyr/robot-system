# run_01 的 site5 写诊断时序审计

日期：2026-09-29。范围：仅本地读取既有原件与历史源码；未运行硬件、SSH、串口或 Cargo，未修改代码。本文件不构成新动作 GO，也不改变右 H2 整体 FAIL、D15 OPEN、deployable=false。

原件：`run_01.json`，SHA-256 `483da756a459c3864da6e250da452e76fd740ddbcaa53c9af235b0f2acec08ab`。以下源码路径及行号全部对应真机产物来源 **ca14f0e6cf6df8ecc6baaaa8dff2dddb64abbd0a**，用 `git show ca14f0e:<路径>` 核对；不把当前工作区新增的诊断修复反推为历史行为。步骤下标为 JSON 数组从 0 开始的索引。

结论：可以静态锁定 **“权限中止等非通信错误被写成 Unknown”这一诊断分类缺陷**，并确认两侧重复出现相同的“16 条极短前簇 + 1 条紧邻 Disable 完成”模式。`Aborted(Revoked)` 是与控制路径和时序高度吻合的解释；历史事件未保留原错误变体、权限阶段及提交时刻，故不能把 34 条逐条确认为 Revoked，也不能宣布硬件通信根因已经闭环。

## 原件时序

`stamp`、`cleared_at_ns`、`completed_at_ns` 是同次运行的单调时钟纳秒；journal `timestamp` 是日志输出墙钟，不与单调时钟直接相减。pub 线程异步排空诊断环，日志行输出顺序不能替代事件发生时序（`crates/robot-s0/src/pub_thread.rs:481–499`）。

| 事件 | 左臂 | 右臂 | 能证明的范围 |
| --- | --- | --- | --- |
| ClearEStop 完成 | step 64：`2464163249273440` | step 198：`2464179272781056` | 解除锁存成功；这不是 Motion 授权提交 |
| demo 动作前 anchor | step 66：`2464165297456224` | step 200：`2464181347782208` | 两侧当时 mode=1、safety=3；随后 stdout 依次为 Enabled、submitted、PASS |
| site5 前 16 条首／末 stamp | `2464165388346880` → `2464165388363648` | `2464181438674304` → `2464181438690336` | 跨度分别 **16,768 ns / 16,032 ns**；首条比 anchor 晚 **90.890656 ms / 90.892096 ms** |
| S1 注册本次 action | UTC `19:43:10.787330`；`01a0eeb1-47b9-76aa-9087-9f1b2d231bab` | UTC `19:43:26.839780`；`01a0eeb1-866d-78f4-93aa-6216350f3271` | step 77 / 211 的 S1 原日志；没有对应单调 stamp 或逐命令 seq |
| Lower 待决 | UTC `19:43:12.723493`；request `01a0eeb1-4f52-7cf6-ae48-fd1277f25780` | UTC `19:43:28.777355`；request `01a0eeb1-8e08-782d-867c-35620ebb65b9` | 两侧均 `OperatorDisable`、`source_seq=None`、`lower_seq=Some(2)`、`wait_mask=18`、`phase=Idle`、`safety=TorqueOn` |
| site5 第 17 条 stamp | `2464167440830976` | `2464183496178176` | 最后一条写诊断；此前前簇后约 2.05 秒无同类事件 |
| Lower 原物理门完成 | `2464167441344320` | `2464183496221248` | 第 17 条分别早于该完成点 **0.513344 ms / 0.043072 ms**；同 request 的 RR 退休日志 |
| demo 终态 | step 66：Completed(Success)、运动证据、disable confirmed PASS | step 200：相同判据 PASS | 证明动作及 Disable 判据通过；stdout 无逐行时钟，不能还原 grant CAS 精确时刻 |
| 收尾显式 EStop 发布 | step 68：`2464169607746464` | step 202：`2464185685148928` | 晚于全部 34 条 site5；不能用该收尾 EStop 解释前面的写诊断 |

site5 原件在左 step 81、右 step 215 的 S0 journal 中：每侧恰 17 条，**全部 `kind=0,a=63,b=0,seq=0`**。其余结构化 WARN 为每侧 site4 三条、site20 十四条，总计 68 条；不能把顶层 `warnings=[]` 解释为 journal 零告警。两侧各 12 次摘要均 `dropped=0,comm_level=0,rx_trust=true,inhibited=0`；site20 未出现故障 kind2 或不变量 kind3，未出现 ERROR。它们支持“没有记录到持续通信降级／故障收敛”，不提供每条错误的原始类型。

## 历史源码能证明什么

1. **site5 是周期 Goal_Position 调用返回错误，不等于 UART 写失败。** `crates/robot-adapters/feetech/src/adapter.rs:575–609` 的 `write_command` 调用 `sync_write_by_id("Goal_Position", …)`；错误出口在 607 行调用 `record_error(5, &e)`。`bus.rs:483–507` 先编码，再于 506 行申请事务租约，最后才在 507 行执行 transport 写；租约申请失败时不会进入该次串口写。
2. **历史 Unknown 丢失了中止原因。** `adapter.rs:290–299` 把除 StatusError 外的错误统一写成 `kind=0`，对 `comm_kind()==None` 使用 Unknown。`error.rs:174–190` 未将 `Aborted` 分类为通信错误；`crates/robot-core/src/serial_services.rs:8–20` 定义 Unknown=63。因此 Emergency、Timeout、Revoked，以及其他非通信错误均可能被该诊断出口压缩成相同字段。真正业务错误转换仍在 `error.rs:194–203` 保留 `RobotError::Aborted(reason)`，没有因日志 Unknown 而改成通信故障。
3. **权限拒绝会产生上述字段。** `crates/robot-s0/src/serial_preempt.rs:201–237` 申请普通 IO 租约，把普通权限拒绝映射成 `AbortReason::Revoked`；`bus.rs:69–80` 再转换为 `FeetechError::Aborted`。Motion 的最终门检查 Disabled、phase 等（`crates/robot-core/src/control_authority.rs:2080–2112,2173–2191`）。`serial_tick.rs:549–572` 对 Revoked 保持拒绝、不升级为通信故障；其他错误会走故障收敛。该路径与本次无故障记录相符，但诊断字段本身不足以唯一反推拒绝原因。
4. **Enable 前与 Disable 后确有可解释窗口。** `ipc_runtime.rs:1095–1123` 在预约 Enable 前先 Safe→Ready；`state_machine.rs:403–405,502–508` 将 Ready 对应到 ReadyHold。`serial_tick.rs:499–513` 对 ReadyHold 尝试 Motion 写；`serial_convergence.rs:232–234` 的外层允许判断只核收敛 Idle/inhibit，并未代替最终 Motion 授权门。真正清 Disabled 发生在 `control_authority.rs:1497–1540` 的 `commit_enable`。Disable 则在 `ipc_pending.rs:1443–1455` 先调用 authority.disable，后者置 Disabled 并推进 epoch（`control_authority.rs:1267–1273`）；业务输出 Disabled 在原物理门退休回执处理处才提交（`ipc_runtime.rs:374–386`）。因此 ReadyHold／旧输出选择与已收紧权限可短暂并存，最终租约门仍拒绝写入。
5. **16 条不是已证实的 16 次运动命令或固定重试。** `record_error` 在 `adapter.rs:299` 固定传 detail=0，最终成为诊断 `seq`；不能把它与 `Lower seq=2` 或 S1 command seq 对齐。周期上下文也固定 seq=0（`serial_tick.rs:505–510`）。串口 loop 的 deadline 每 tick 累加、过期后不跳帧（`serial_io_thread.rs:298–318`）；写被拒绝后立即返回、跳过本 tick 的读操作（`serial_tick.rs:512–516`），可以形成快速补赶 tick 的短簇。源码没有固定“重试 16 次”规则，日志未记录 tick_seq/deadline，故具体 16 次来源仍是机制解释而非逐 tick 证明。

## 归因边界与最小后续

- **已确认：**历史诊断把中止错误混记 Unknown；34 条精确分组和相对完成时刻；本次动作与收尾按原判据通过。
- **强候选：**每侧前 16 条处于 Motion 尚未授权的 Enable 交接窗口，最后 1 条处于 Disable 已撤销权限、旧输出选择尚未更新的窗口，均被最终租约门拒绝；快速补赶 tick 解释前簇密度。
- **未被原件直接证明：**34 条各自的 AbortReason、Motion grant/revoke 的精确单调时刻、前簇相对于 Enable CAS 的先后关系，以及每条对应的 tick／S1命令。`Enable 原事务已提交`（含 at_ns、epoch）在 `ipc_runtime.rs:358–361` 是 DEBUG，本次 journal 未收录；`source_seq=None` 也不能补出 Enable seq。S1 结束时的 cmd_seq（左 542、右 552）只是退出累计值，不能拿来给 site5 分配命令编号。

最小软件改进是保留独立的中止诊断类型及原因，并用真实 adapter→lease 路径的无硬件回归验证“拒绝发生在 transport 写前，仍保留权限门与业务错误类型”。它能修复可观测性并验证机制，不能回填历史缺失字段，也不能替代未来另行授权的现场验证。本次审计未执行新的硬件测试。
