#!/bin/sh
# 全部检查使用 mock / 单元测试，不启动机器人控制服务。
set -eu
export PATH=/home/loosqk/.cargo/bin:/home/loosqk/.local/bin:$PATH
cd /home/loosqk/repo/robot/robot-system/target/post_e_h2_rt/s50/write_diagnostics_20260929_01
export CARGO_TARGET_DIR="$PWD/build"
export CARGO_BUILD_JOBS=2
py=/home/loosqk/.local/share/uv/python/cpython-3.12-linux-aarch64-gnu/bin/python3.12
"$py" verify_source.py > source_verified_before.json
"$py" gate.py fmt -- cargo +nightly-2026-09-10 fmt --all --check
"$py" gate.py clippy_workspace -- cargo +nightly-2026-09-10 clippy --locked --all --all-targets -- -D warnings
"$py" gate.py test_feetech -- cargo +nightly-2026-09-10 test --locked -p robot-adapter-feetech --tests --features real-hw
"$py" gate.py test_serial_convergence -- cargo +nightly-2026-09-10 test --locked -p robot-s0 --lib --features rt_guard post_e_convergence_acceptance
"$py" verify_source.py > source_verified_after.json
