#!/bin/sh
set -eu
cd /home/loosqk/repo/robot/robot-system
hostname
id -un
git rev-parse HEAD
git status --porcelain
sha256sum target/release/s0_daemon target/release/xlerobot_deploy target/release/s1_daemon target/release/robot_rpc_gateway
systemctl show xlerobot-s0-left-arm.service xlerobot-s0-right-arm.service xlerobot-s1-left.service xlerobot-s1-right.service xlerobot-gateway-left.service xlerobot-gateway-right.service --property=Id,ActiveState,SubState,MainPID
