# 2026-09-29 Feetech 诊断分类：本机独立评审

**结论：最终源码与本机证据独审通过，无阻断；Orin 原生检查未开始。**

本评审只读检查最终源码及既有日志，并独立重算下列 SHA-256；未重新执行测试、Cargo、SSH 或硬件操作。本报告为随后获准写入的唯一评审文件。

| 最终源码 | SHA-256 |
| --- | --- |
| `crates/robot-adapters/feetech/src/adapter.rs` | `3e39280b11fb5b42c407ffa22b3838ebda55f0e61d22c855d30e6d90937e4915` |
| `crates/robot-adapters/feetech/src/diagnostic.rs` | `4868a83662468cd8be7d39c0f361a5ea8c370eaec16b4753e5f03c5a63d3750c` |
| `crates/robot-adapters/feetech/tests/abort_diagnostics.rs` | `1925dc2c2aca824c813193cea2c27f37bec533ad532680b97fa987a3cd9a2ded` |

## 源码结论

- `FeetechDiagnostic` 明确区分通信、事务中止、设备状态、无效参数、目标读回不符和重复连接；参数再分为通用参数、编码值、标定、标定文件和型号。`classify` 穷尽匹配 `FeetechError`，没有无语义兜底。
- 固定编码与 `docs/logging.md` 一致：通信保留 `kind=0`；设备状态保留 `kind=5`；中止为 `kind=7 / a=1..3`；其余明确类别为 `kind=8 / a=1..7`。读回不符独立于参数错误。既有 `kind=6` 扭矩摘要仍可能保留 Unknown，其后完整诊断使用新分类。
- 生产改动仅解释并编码诊断。`From<FeetechError> for RobotError`、`comm_kind`、权限门、故障处理、周期调度、WARN 级别和 16 字节 `DiagEvent` 均未改变；没有屏蔽报警。
- 集成测试通过真实 `ControlAuthority` 的 reserve/start/finish/commit、disable 及真实 adapter/bus 验证权限窗口，拒绝路径锁住零 transport 写，并验证提交后的写入、通信错误、设备状态及参数错误。夹具不含 S0 完整调度与故障状态，不能据此宣称 S0 端到端或硬件验收。

## 已核本机结果

| 证据文件（均在本报告同目录） | 实际结果 |
| --- | --- |
| `clippy_feetech_diag_r5.log` | 最终定向 Clippy 正常完成，无警告 |
| `test_feetech_diag.log` | 库测试 **147 PASS**；随后首轮集成测试在零分配检查中因 **64 字节分配 / SIGABRT 失败**，原件保留 |
| `test_abort_diagnostics_r2.log` | 仅将测试诊断记录器改为固定原子槽后，最终集成测试 **5 PASS** |

不能把初轮完整命令记为通过。最终原子记录器使用固定 `stamp/fields/count`，字段先写、Release 计数、AcqRel 读取；每个夹具单线程生产并在调用返回后读取，符合其使用前提。独立集成测试二进制中的分配检查器未改变既有库测试的 allocator 配置。

零分配测试通过公开 `safety_stop` 入口注入有类型错误，覆盖分类、固定编码、诊断记录和原错误返回；**不证明真实 Safety 域会产生这些中止，也不证明周期命令整条链路零分配**。

## 保留边界

现场历史 34 条 `site=5 / kind=0 / a=63` 已丢失原始错误原因，不能回填为 Revoked；权限窗口软件复现只证明该机制可产生旧编码。写 Revoked 后早退跳读及过期 tick 集中执行保持独立 OPEN，本轮未修复。不得宣称历史通信问题已解决或硬件回归通过。

Orin 连接前置当前因本机 known_hosts 条目变化待核实，原生检查尚未开始；本报告不为其记通过，也不包含新的远端运行结论。
