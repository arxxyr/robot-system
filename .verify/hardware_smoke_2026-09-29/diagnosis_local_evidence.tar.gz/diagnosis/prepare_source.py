"""为只执行软件检查的 Orin 构建保存独立源码快照。"""
import hashlib
import json
from pathlib import Path
import subprocess
import tarfile
import time

root = Path.cwd()
out = root / 'target/hardware_smoke_20260929/diagnosis'
paths = subprocess.check_output(['git', 'ls-files', '-z', '.cargo', '3rd-party', 'Cargo.toml', 'Cargo.lock', 'rust-toolchain.toml', 'CLAUDE.md', 'AGENTS.md', 'crates', 'configs', 'scripts', 'tools']).decode().split('\0')
paths += subprocess.check_output(['git', 'ls-files', '--others', '--exclude-standard', '-z', 'crates']).decode().split('\0')
rows = []
for name in sorted(set(filter(None, paths))):
    path = root / name
    if path.is_symlink():
        rows.append({'path': name, 'link': str(path.readlink())})
    else:
        data = path.read_bytes()
        rows.append({'path': name, 'sha256': hashlib.sha256(data).hexdigest(), 'bytes': len(data)})
manifest = {'base_commit': subprocess.check_output(['git', 'rev-parse', 'HEAD']).decode().strip(), 'scope': '软件诊断回归，不访问真实串口，不正式安装', 'files': rows}
(out / 'source_manifest.json').write_text(json.dumps(manifest, ensure_ascii=False, indent=2) + '\n')
with tarfile.open(out / 'source.tar.gz', 'w:gz', dereference=False) as tar:
    for row in rows:
        info = tar.gettarinfo(str(root / row['path']), row['path'])
        info.mtime = int(time.time())
        if info.isfile():
            with (root / row['path']).open('rb') as f:
                tar.addfile(info, f)
        else:
            tar.addfile(info)
    for name in ('gate.py', 'source_manifest.json', 'verify_source.py'):
        tar.add(out / name, arcname=name)
print(json.dumps({'files': len(rows), 'source_manifest_sha256': hashlib.sha256((out / 'source_manifest.json').read_bytes()).hexdigest(), 'archive_bytes': (out / 'source.tar.gz').stat().st_size}))
