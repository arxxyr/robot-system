import datetime, hashlib, json, pathlib, subprocess, sys, time
root = pathlib.Path(__file__).resolve().parent
label, *command = sys.argv[1:]
if command and command[0] == "--":
    command = command[1:]
log = root / (label + ".log")
receipt = root / (label + ".json")
if log.exists() or receipt.exists():
    raise SystemExit("拒绝覆盖已有检查证据")
started = datetime.datetime.now(datetime.timezone.utc).isoformat()
start_ns = time.monotonic_ns()
print("执行", label, command, flush=True)
with log.open("x") as output:
    process = subprocess.Popen(command, stdout=output, stderr=subprocess.STDOUT)
    code = process.wait()
body = log.read_bytes()
result = {"command":command,"pid":process.pid,"wait_returncode":code,"reaped":True,
          "started_utc":started,"finished_utc":datetime.datetime.now(datetime.timezone.utc).isoformat(),
          "elapsed_ns":time.monotonic_ns()-start_ns,"log":str(log.relative_to(pathlib.Path.cwd())),
          "log_sha256":hashlib.sha256(body).hexdigest(),"log_bytes":len(body)}
receipt.write_text(json.dumps(result,ensure_ascii=False,indent=2)+"\n")
print(json.dumps(result,ensure_ascii=False),flush=True)
print(body.decode(errors="replace")[-14000:] if code else "\n".join(body.decode(errors="replace").splitlines()[-7:]),flush=True)
raise SystemExit(code)
