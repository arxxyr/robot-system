"""封存本机已完成的诊断验证，明确原生门尚未运行。"""
import hashlib
import io
import json
from pathlib import Path
import re
import tarfile

root = Path('target/hardware_smoke_20260929/diagnosis')
out = Path('.verify/hardware_smoke_2026-09-29')
def digest(data):
    return hashlib.sha256(data).hexdigest()
source_paths = ['crates/robot-adapters/feetech/src/adapter.rs', 'crates/robot-adapters/feetech/src/diagnostic.rs', 'crates/robot-adapters/feetech/tests/abort_diagnostics.rs']
source = {p: digest(Path(p).read_bytes()) for p in source_paths}
expected = ['3e39280b11fb5b42c407ffa22b3838ebda55f0e61d22c855d30e6d90937e4915', '4868a83662468cd8be7d39c0f361a5ea8c370eaec16b4753e5f03c5a63d3750c', '1925dc2c2aca824c813193cea2c27f37bec533ad532680b97fa987a3cd9a2ded']
assert list(source.values()) == expected
receipt = json.loads((root / 'root_final_feetech.json').read_text())
assert receipt['wait_returncode'] == 0 and receipt['reaped']
assert digest((root / 'root_final_feetech.log').read_bytes()) == receipt['log_sha256']
counts = [int(n) for n in re.findall(r'test result: ok\. (\d+) passed', (root / 'root_final_feetech.log').read_text())]
assert counts == [147, 5]
assert 'Finished' in (root / 'clippy_feetech_diag_r5.log').read_text()
assert 'error:' not in (root / 'clippy_feetech_diag_r5.log').read_text()
assert 'signal: 6, SIGABRT' in (root / 'test_feetech_diag.log').read_text()
assert 'Host key verification failed' in (root / 'ssh_identity_retry.log').read_text()
initial = {'evidence.tar.gz': 'ce5fdf02cc44f4bb47ca187972f8f1bc6b3e03433d653747ca20be068a880900', 'run_01_evidence.tar.gz': '51fd09e979bc3b4e5002a7d6ef9f17b7784a9e57bc06b57465e62ff5f3dab83b'}
assert all(digest((out / p).read_bytes()) == sha for p, sha in initial.items())
summary = {'schema': 'FEETECH_DIAGNOSTIC_CLASSIFICATION_V1', 'status': 'LOCAL_PASS_ORIN_SSH_HOST_IDENTITY_BLOCKED', 'base_commit': 'c6e8b2defc1edfe819c7783b69f030069b487dcf', 'sources': source, 'classification': ['Communication', 'Aborted', 'DeviceStatus', 'InvalidParameter', 'GoalReadbackMismatch', 'AlreadyConnected'], 'exhaustive_match': True, 'robot_error_conversion_unchanged': True, 'control_authority_and_tick_unchanged': True, 'local_validation': {'fmt': 'PASS', 'clippy_feetech_all_targets_all_features': 'PASS_R5', 'final_library_tests': 147, 'final_integration_tests': 5, 'final_command_exit_code': 0, 'final_command_reaped': True, 'initial_lints_and_allocator_failure_preserved': True, 'allocation_scope': '仅经公开Safety入口注入错误的固定诊断路径；不代表周期命令整链'}, 'orin_validation': {'status': 'NOT_RUN', 'source_transfer_started': False, 'host_key_verification': '跳板机与Orin条目在本机known_hosts中均未找到，严格检查拒绝', 'question_to_user_pending': True}, 'prepared_source_manifest_sha256': digest((root / 'source_manifest.json').read_bytes()), 'hardware_actions_this_diagnosis': False, 'formal_installation_changed': False, 'committed': False, 'commit_blocker': '根workspace Linux Clippy/原生门尚未完成', 'historical_34_errors': '诊断丢因已证实；Revoked窗口高度吻合但不能逐条回填原因', 'open': ['周期写Revoked后跳读及过期tick调度', '右H2历史整体FAIL', 'D15', '头部和底盘主动运动覆盖'], 'preserved_archives': initial}
blobs = {}
for p in sorted(root.iterdir()):
    if p.is_file() and p.suffix in ('.py', '.sh', '.log', '.json', '.md', '.txt'):
        blobs['diagnosis/' + p.name] = p.read_bytes()
for p in source_paths + ['docs/handoffs/hardware_smoke_2026-09-29_summary.md', 'docs/logging.md']:
    blobs[p] = Path(p).read_bytes()
blobs['write_diag_timeline.md'] = Path('target/hardware_smoke_20260929/write_diag_timeline.md').read_bytes()
index = {name: {'sha256': digest(data), 'bytes': len(data)} for name, data in blobs.items()}
blobs['index.json'] = (json.dumps(index, ensure_ascii=False, indent=2) + '\n').encode()
archive = out / 'diagnosis_local_evidence.tar.gz'
with tarfile.open(archive, 'w:gz') as tar:
    for name, data in blobs.items():
        info = tarfile.TarInfo(name)
        info.size = len(data)
        tar.addfile(info, io.BytesIO(data))
with tarfile.open(archive, 'r:gz') as tar:
    assert set(tar.getnames()) == set(blobs)
    for name, item in index.items():
        data = tar.extractfile(name).read()
        assert len(data) == item['bytes'] and digest(data) == item['sha256']
summary['evidence'] = {'path': str(archive), 'sha256': digest(archive.read_bytes()), 'bytes': archive.stat().st_size, 'indexed_files': len(index), 'all_member_hashes_verified': True}
(out / 'diagnosis_summary.json').write_text(json.dumps(summary, ensure_ascii=False, indent=2) + '\n')
print(json.dumps(summary['evidence'], ensure_ascii=False))
