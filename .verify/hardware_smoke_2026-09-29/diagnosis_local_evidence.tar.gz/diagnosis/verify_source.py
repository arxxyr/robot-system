"""核对本次编译输入；不读取机器人安全状态或串口。"""
import hashlib
import json
from pathlib import Path
root = Path.cwd()
manifest = root / 'source_manifest.json'
rows = json.loads(manifest.read_text())['files']
for row in rows:
    p = root / row['path']
    if 'link' in row:
        assert p.is_symlink() and str(p.readlink()) == row['link'], row['path']
    else:
        data = p.read_bytes()
        assert len(data) == row['bytes'] and hashlib.sha256(data).hexdigest() == row['sha256'], row['path']
print(json.dumps({'source_matches': True, 'files': len(rows), 'manifest_sha256': hashlib.sha256(manifest.read_bytes()).hexdigest()}))
