# 2026-09-29 诊断修复：Linux 原生证据独立评审

**结论：冻结诊断修复及三处等价 lint 修改的软件验收通过，无阻断。原失败完整保留；不包含 Rerun，也不构成硬件验收或部署许可。**

本评审只读检查源码、归档和主 agent 执行结果，并独立重算哈希；未重跑 Cargo、SSH、串口或硬件操作。运行环境为本机 Lima Ubuntu ARM：Linux 6.8.0-134-generic / aarch64，nightly-2026-09-29（rustc 1.101.0-nightly c1070d693）。不是 Orin。

## 来源与边界

- `linux_native_raw/index.json` 所列 **36 项**的 SHA-256、字节数独立核对一致；四个外层 `linux_vm_checks*.json` 绑定的日志哈希均一致，均记录真实 `wait` 和 `reaped=true`。
- 原始包 `linux_native_raw.tar.gz` SHA-256：`36c034d5d17bfa92662a1c67f7cf25c59c00c23d705c7a7512b57e002fee916d`。
- r4 `source_manifest.json` SHA-256：`d34cb21d91acfe00505b979d47f12b991cd3b0eb485dea70808c18238a153b5e`；独立读取 `source_r4.tar.gz`，**605 项**逐项匹配（604 个文件及 `AGENTS.md` 符号链接）。运行前后 `linux_source_before.json` / `linux_source_after.json` 均绑定此 manifest，`source_matches=true`。
- 该快照以 `c6e8b2defc1edfe819c7783b69f030069b487dcf` 为基底，限定诊断及 lint 修改；manifest 不含 `crates/robot-viz`。不能把此 Clippy 结果套用到随后正在开发的镜像或整个当前工作区。

| 已核源码（当前文件与 r4 manifest 一致） | SHA-256 |
| --- | --- |
| `crates/robot-adapters/feetech/src/adapter.rs` | `3e39280b11fb5b42c407ffa22b3838ebda55f0e61d22c855d30e6d90937e4915` |
| `crates/robot-adapters/feetech/src/diagnostic.rs` | `4868a83662468cd8be7d39c0f361a5ea8c370eaec16b4753e5f03c5a63d3750c` |
| `crates/robot-adapters/feetech/tests/abort_diagnostics.rs` | `1925dc2c2aca824c813193cea2c27f37bec533ad532680b97fa987a3cd9a2ded` |
| `crates/robot-cli/src/bin/robotctl.rs` | `d247e09f9bb237e280c714ed43ea902a18dcd86bacaecfe8e65b268b8f8b5de2` |
| `crates/robot-s0/src/bin/s0_daemon.rs` | `ba2f8c5a0fb183670b32adc432bc00238332339b23b6f13ff0fbb4283fcb64c7` |

## 修改审查

诊断三文件与此前 `final_local_review.md` 绑定版本完全一致。`record_error` 使用穷尽分类：通信仍为 kind 0，设备状态仍为 kind 5，中止单列 kind 7，其余明确非通信类为 kind 8；原错误返回、权限与安全处理未改。没有静默吞警告，也未回填历史 34 条 Unknown 的原始原因。

三处 lint 修改仅把 `map(...).unwrap_or_default()` 改为 `map_or_else(...)`：CLI 缺位置向量仍返回空 `Vec`；S0 缺 monitor 配置仍使用 `Default::default`，有配置时仍复制同三字段；S0 缺 calibration 数组仍为空 `Vec`，有数组时仍过滤字符串并收集。缺省分支仍惰性执行，没有改变锁、权限、I/O 或调度语义。

## 四轮结果

| 轮次 | 已核原件结果 |
| --- | --- |
| r1 | fmt `--check` 通过；根 Clippy 因 CLI 一处 `map_unwrap_or` 失败，exit 101，后续测试未执行 |
| r2 | fmt `--check` 因 CLI 格式失败，exit 1，后续门未执行 |
| r3 | fmt 通过；根 Clippy 因 S0 两处同 lint 失败，exit 101，后续测试未执行 |
| r4 | fmt → 根 Clippy → Feetech → SerialRT 串行执行，全部 exit 0 且真实 wait/reap；外层 exit 0 |

r4 的内层 JSON、对应完整日志及时间顺序一致：

- `cargo +nightly-2026-09-29 fmt --all` 完成；之后的源码复核仍为同一 manifest。
- `cargo +nightly-2026-09-29 clippy --locked --all --all-targets -- -D warnings` 完成，无 warning/error。
- `cargo +nightly-2026-09-29 test --locked -p robot-adapter-feetech --tests --features real-hw`：库 **147**、abort_diagnostics **5**、PTY/串口软件测试 **12 + 3**，全部通过，无失败/忽略。`real-hw` 为构建 feature，这些结果不代表访问了机器人电机。
- `cargo +nightly-2026-09-29 test --locked -p robot-s0 --lib --features rt_guard post_e_convergence_acceptance`：**42 通过、0 失败、567 过滤**。只证明该定向软件套，不称全部 S0 或全 workspace test 通过。

## 未关闭事项

现场历史 site 5 的 Unknown 已丢失原始错误类型，不能据软件复现断言全部为 Revoked。写 Revoked 后早退跳读、过期 tick 集中执行保持独立未决；本轮只改善诊断分类。新硬件回归、正式产物安装及运行时激活均未执行。右 H2 仍整体 FAIL，D15 OPEN，`deployable=false`。本轮原生结果不覆盖 Rerun、正式部署或上述硬件安全事项。
