"""爸爸，R7 五源只读寄存器的软件验证草稿；等待 root 最终输入，禁止 UART。"""
import importlib.util
import json
import os
from pathlib import Path
import re
import shutil
import signal
import stat
import sys
from types import SimpleNamespace

sys.dont_write_bytecode = True
BASE = Path('/home/loosqk/robot-checks/position-return-20261010-r1/position-return-r7')
BOOT = BASE / 'bootstrap'
SOURCE = BASE / 'source'
OUT = BASE / 'software-r1'
FROZEN = BASE / 'readback-tool-r1'
OLD_SOURCE = Path('/home/loosqk/robot-checks/h2-exit-observation-20261009-r1/source')
HEAD = '894084738d95a7239611c2b8fbecfe081d3a7fc9'
OLD_AGGREGATE = '5970c9bed0ab02f99b47d88d47eb3718c6a748155ca4fafd5c18050a68ec6cf7'
TARGET = Path('/home/loosqk/robot-checks/xlerobot-velocity-foundation-20261008-r7/build')
CACHE = '/home/loosqk/robot-checks/viz-orin-a6957cc-20260930-r1/cargo-home'
RUNNER = Path('/home/loosqk/robot-checks/h2-right-ready-20261009-r1/bootstrap/run_release_v2.py')
RUNNER_SHA = 'd6b20da28de8d5ae077a93cb2fb5ba7f27a66b8145df9e7e91951cb14ac0b12b'
ARTIFACTS_SHA = 'bd2b3f7bb8527cd9ecec73894171638e9cf378656b89e284a585c3baa37b8731'
FIVE = {
    'crates/robot-adapters/feetech/src/registers.rs',
    'crates/robot-adapters/feetech/src/bus.rs',
    'crates/robot-adapters/feetech/src/diagnostic.rs',
    'crates/robot-adapters/feetech/src/bus_raw_read_tests.rs',
    'crates/robot-adapters/feetech/examples/feetech_poke.rs',
}


def module(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    value = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(value)
    return value


a = module('r7_existing_artifacts', OLD_SOURCE / 'scripts/post_e_h2_artifacts.py')
r = module('r7_existing_runner', RUNNER)
a.require(a.sha256(RUNNER) == RUNNER_SHA and a.sha256(Path(a.__file__)) == ARTIFACTS_SHA,
          '原 Runner/helper 身份变化')
# 最终 root 输入尚未存在时在任何 clone/Cargo 前拒绝；本文件现在只在本地准备。
inputs = a.strict_json((BOOT / 'inputs_r7.json').read_text())
a.require(inputs['approved_by'] == 'root' and set(inputs['changed_sources']) == FIVE,
          '必须 root 最终五源输入')
expected = a.read_pinned_json(inputs['expected_source'])
a.require(len(expected['files']) == 597, '必须完整 597 输入')
OUT.mkdir()
r.save(OUT / 'owner.json', r.proc_entry(os.getpid()))
runner = r.Runner(SimpleNamespace(source=OLD_SOURCE, target=TARGET, out=OUT, build_head=HEAD), a)
proxy = {key: 'http://10.0.1.80:10808'
         for key in ('http_proxy', 'https_proxy', 'HTTP_PROXY', 'HTTPS_PROXY')}
runner.env.update(proxy)
runner.shown.update(proxy)


def cargo_home(value):
    runner.env['CARGO_HOME'] = value
    runner.shown['CARGO_HOME'] = value


def text(name, argv, budget=60):
    ref, row = runner.command(name, argv, budget)
    return ref, Path(row['stdout']).read_text()


def source(label):
    _, head = text(label + '_head', ['git', 'rev-parse', 'HEAD'])
    _, status = text(label + '_status', ['git', 'status', '--porcelain=v1', '--untracked-files=all'])
    _, files = text(label + '_files', ['git', 'ls-files', '-z', '--cached', '--others', '--exclude-standard'])
    a.require(head.strip() == HEAD, '独立 clone 的实际原生 HEAD 变化')
    a.require(status == ''.join(' M ' + name + '\n' for name in sorted(FIVE)),
              '独立源必须真实仅五源 dirty，不伪称 clean')
    value = a.snapshot_source(SOURCE, files.rstrip('\0').split('\0'))
    a.require(value == expected, '与 root 最终 597 字节/大小/可执行标志不一致')
    r.save(OUT / (label + '.json'), value)
    return value


def tests(name, argv):
    _, row = runner.command(name, argv, 7200)
    output = Path(row['stdout']).read_text()
    counts = re.findall(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored;', output)
    names = re.findall(r'^test ([^ ]+) \.\.\. ok$', output, re.M)
    a.require(len(counts) == 1 and counts[0][1:] == ('0', '0')
              and len(names) == len(set(names)) == int(counts[0][0]), '测试原结果有失败/跳过/重复')
    result['tests'][name] = {'count': len(names), 'names': names, 'failed': 0, 'ignored': 0}


def interrupted(signum, frame):
    r.INTERRUPTED = signum


for sig in (signal.SIGTERM, signal.SIGINT, signal.SIGHUP):
    signal.signal(sig, interrupted)

result = {'status': 'FAIL', 'deployable': False, 'started_at': r.utc(),
          'scope': '五源只读寄存器软件门；无 UART、控制动作、正式安装或服务操作；非全 workspace/H2',
          'native_git_head': HEAD, 'native_worktree': 'five changed sources; not clean',
          'host_git_head': inputs['host_git_head'], 'input_ref': inputs['expected_source'],
          'runner_sha256': RUNNER_SHA, 'artifacts_module_sha256': ARTIFACTS_SHA,
          'tests': {}, 'proxy_runtime_overrides': proxy,
          'cargo_home_by_stage': {'nightly_update': '/home/loosqk/.cargo', 'cargo': CACHE}}
before = compiler = cargo = artifact = None
try:
    a.require(not SOURCE.exists() and not FROZEN.exists(), '新源码/冻结目录已经存在，拒绝重试')
    runner.command('clone_native_source', ['git', 'clone', '--no-hardlinks', str(OLD_SOURCE), str(SOURCE)], 300)
    runner.options.source = SOURCE
    base_source = runner.source('clone_before')
    a.require(len(base_source['files']) == 597 and base_source['source_manifest_sha256'] == OLD_AGGREGATE,
              '旧894基础输入不同')
    replacements = []
    for name in sorted(FIVE):
        ref = inputs['changed_sources'][name]
        data = Path(ref['path']).read_bytes()
        a.require(stat.S_ISREG(Path(ref['path']).lstat().st_mode) and len(data) == ref['bytes']
                  and a.sha256(Path(ref['path'])) == ref['sha256'], 'root最终源引用不同')
        path = SOURCE / name
        replacements.append({'path': name, 'old_sha256': a.sha256(path), 'new_sha256': ref['sha256']})
        with path.open('wb') as stream:
            stream.write(data)
            stream.flush()
            os.fsync(stream.fileno())
    r.save(OUT / 'five_source_replacements.json', replacements)
    before = source('source_before')
    cargo_home('/home/loosqk/.cargo')
    runner.command('nightly_update', ['rustup', 'update', 'nightly', '--no-self-update'], 7200)
    cargo_home(CACHE)
    _, value = text('rustc_before', ['rustc', '-vV'])
    compiler = a.parse_rustc_identity(value)
    a.require(compiler['host'] == 'aarch64-unknown-linux-gnu' and 'nightly' in compiler['release'],
              '实际编译器非 ARM64 nightly')
    _, cargo = text('cargo_before', ['cargo', '-V'])
    runner.command('fmt', ['cargo', 'fmt', '--all'], 300)
    a.require(source('fmt_after') == before, '实际 fmt 改动输入，停止后续检查')
    runner.command('clippy', ['cargo', 'clippy', '--all', '--all-targets', '--', '-D', 'warnings'], 7200)
    tests('feetech_default', ['cargo', 'test', '--locked', '-p', 'robot-adapter-feetech', '--lib', '--', '--test-threads=1'])
    tests('feetech_real_hw', ['cargo', 'test', '--locked', '-p', 'robot-adapter-feetech', '--lib', '--features', 'real-hw', '--', '--test-threads=1'])
    tests('poke_tests', ['cargo', 'test', '--locked', '-p', 'robot-adapter-feetech', '--example', 'feetech_poke', '--features', 'real-hw', '--', '--test-threads=1'])
    release_ref, row = runner.command('release_poke', ['cargo', 'build', '--locked', '--release', '-p', 'robot-adapter-feetech', '--example', 'feetech_poke', '--features', 'real-hw', '--message-format=json-render-diagnostics'], 7200)
    records = [json.loads(line) for line in Path(row['stdout']).read_text().splitlines() if line.strip()]
    outputs = [item for item in records if item.get('reason') == 'compiler-artifact'
               and item.get('executable') and item.get('target', {}).get('name') == 'feetech_poke']
    a.require(len(outputs) == 1 and outputs[0]['target']['kind'] == ['example']
              and 'real-hw' in outputs[0]['features'] and outputs[0]['profile']['opt_level'] == '3'
              and not outputs[0]['profile']['debug_assertions'] and not outputs[0]['profile']['test'],
              '实际 release Cargo 产物合同不同')
    actual = Path(outputs[0]['executable'])
    a.require(actual == TARGET / 'release/examples/feetech_poke', 'Cargo实际输出路径不同')
    identity = a.elf_identity(actual)
    FROZEN.mkdir()
    frozen = FROZEN / 'feetech_poke'
    with actual.open('rb') as incoming, frozen.open('xb') as outgoing:
        shutil.copyfileobj(incoming, outgoing)
    frozen.chmod(identity['mode'])
    a.require(a.elf_identity(frozen) == identity == a.elf_identity(actual), '冻结时 ELF 变化')
    artifact = {'path': str(frozen), **identity, 'cargo_path': str(actual),
                'compiler': compiler, 'native_git_head': HEAD, 'native_worktree': 'five dirty sources',
                'source_manifest_sha256': before['source_manifest_sha256'],
                'cargo_artifact': outputs[0], 'completion': release_ref, 'deployable': False}
    r.save(FROZEN / 'feetech_poke.build.json', artifact)
    for name in ('help', 'Minimum_Starting_Torque', 'Integral_Limit', 'Angle_Resolution'):
        runner.command('probe_' + name, [sys.executable, str(BOOT / 'expected_exit2_probe_r7.py'), name, identity['sha256']], 60)
    a.require(a.elf_identity(frozen) == identity == a.elf_identity(actual), '软件探针后 ELF 变化')
    distinct = sorted({name for group in result['tests'].values() for name in group['names']})
    result.update(status='PASS', artifact=artifact, artifact_before_after='PASS',
                  distinct_test_names=distinct, distinct_method_count=len(distinct))
except BaseException as error:
    result['error'] = repr(error)
finally:
    try:
        a.require(before is not None and source('source_after') == before, '源码首尾变化或起始采样未完成')
        result['source_before_after'] = 'PASS'
    except BaseException as error:
        result.update(status='FAIL', source_after_error=repr(error))
    try:
        cargo_home(CACHE)
        _, value = text('rustc_after', ['rustc', '-vV'])
        a.require(compiler is not None and a.parse_rustc_identity(value) == compiler, '编译器首尾不同')
        _, after = text('cargo_after', ['cargo', '-V'])
        a.require(cargo is not None and after == cargo, 'Cargo 首尾不同')
        result['compiler_window'] = 'PASS'
    except BaseException as error:
        result.update(status='FAIL', compiler_after_error=repr(error))
    result.update(finished_at=r.utc(), receipts=runner.receipts, interrupted_signal=r.INTERRUPTED)
    r.save(OUT / 'result.json', result)
    print(json.dumps(result, ensure_ascii=False), flush=True)
raise SystemExit(0 if result['status'] == 'PASS' else 1)
