#!/bin/bash
# 爸爸，R7仅独立软件验证；禁止UART/安装/服务操作。
set -euC
umask 077
export PATH=/home/loosqk/.cargo/bin:/home/loosqk/.local/bin:$PATH
export PYTHONDONTWRITEBYTECODE=1
tmux set-option -w -t "$TMUX_PANE" remain-on-exit on
exec /home/loosqk/.local/share/uv/python/cpython-3.12.13-linux-aarch64-gnu/bin/python3 /home/loosqk/robot-checks/position-return-20261010-r1/position-return-r7/bootstrap/quality_build_once_r7.py > /home/loosqk/robot-checks/position-return-20261010-r1/position-return-r7/bootstrap/quality-owner-r7.log 2>&1
