"""有限软件探针：只允许冻结poke的help和三项诊断寄存器拒写，不接真实设备。"""
import hashlib, importlib.util, json, os, signal, stat, subprocess, sys, time
from pathlib import Path
BASE=Path('/home/loosqk/robot-checks/position-return-20261010-r1/position-return-r7');BOOT=BASE/'bootstrap';OUT=BASE/'software-r1'
spec=importlib.util.spec_from_file_location('natural_runner',Path('/home/loosqk/robot-checks/h2-right-ready-20261009-r1/bootstrap/run_release_v2.py'));h=importlib.util.module_from_spec(spec);spec.loader.exec_module(h)
name=sys.argv[1];expected_sha=sys.argv[2];binary=BASE/'readback-tool-r1/feetech_poke';missing=Path('/dev/never-open')
assert name in {'help','Minimum_Starting_Torque','Integral_Limit','Angle_Resolution'}
assert not binary.is_symlink() and stat.S_ISREG(binary.lstat().st_mode) and hashlib.sha256(binary.read_bytes()).hexdigest()==expected_sha
assert not os.path.lexists(missing)
argv=[str(binary),'--help'] if name=='help' else [str(binary),str(missing),'8','write',name,'1']
folder=OUT/('expected_'+name);folder.mkdir();row={'argv':argv,'expected_exit_code':2,'binary_sha256':expected_sha,'missing_device':str(missing),'missing_device_before':True,'syscall_trace':'UNAVAILABLE_NOT_CLAIMED','signals':[],'pid':None,'reaped':False,'started_monotonic_ns':time.monotonic_ns()}
old={}
def interrupted(signum,frame):row['signals'].append(signum)
for sig in (signal.SIGINT,signal.SIGTERM,signal.SIGHUP):old[sig]=signal.signal(sig,interrupted)
read_fd,write_fd=os.pipe();child=None
try:
 with (folder/'stdout.log').open('xb') as so,(folder/'stderr.log').open('xb') as se:
  bootstrap=[sys.executable,'-c',h.BOOTSTRAP,str(read_fd),*argv]
  child=subprocess.Popen(bootstrap,cwd=BASE/'source',stdin=subprocess.DEVNULL,stdout=so,stderr=se,start_new_session=True,pass_fds=(read_fd,));os.close(read_fd);read_fd=None
  row['pid']=child.pid;row['identity']=h.proc_entry(child.pid);assert row['identity']['sid']==child.pid
  row['identity']['boot_id']=Path('/proc/sys/kernel/random/boot_id').read_text().strip();row['bootstrap_argv']=bootstrap
  h.save(folder/'launch.json',row);assert not row['signals'];assert os.write(write_fd,b'G')==1;os.close(write_fd);write_fd=None
  deadline=row['started_monotonic_ns']+60_000_000_000
  while not row['reaped']:
   try:row['exit_code']=child.wait(timeout=0.25);row['reaped']=True
   except subprocess.TimeoutExpired:pass
  row['budget_exceeded']=time.monotonic_ns()>deadline;row['session_residual']=h.session_members(child.pid)
 row['missing_device_after']=not os.path.lexists(missing);row['binary_same_after']=hashlib.sha256(binary.read_bytes()).hexdigest()==expected_sha
 for stream in ['stdout','stderr']:
  p=folder/(stream+'.log');b=p.read_bytes();row[stream+'_sha256']=hashlib.sha256(b).hexdigest();row[stream+'_bytes']=len(b)
 text=(folder/'stderr.log').read_text()
 if name=='help':assert 'usage:' in text and ' read ' in text and ' write ' in text
 else:
  assert '本项目诊断专用寄存器禁止写入：'+name in text and 'open serial' not in text
 row['status']='PASS_EXPECTED_EXIT2_EARLY_REFUSAL';assert row['exit_code']==2 and not row['budget_exceeded'] and not row['session_residual'] and not row['signals'] and row['missing_device_after'] and row['binary_same_after']
 row['zero_uart_evidence']='同源main在RealSerialTransport::open前返回具体错误；实际exit2和错误文本、不存在路径前后、已通过四写API零TX/lease及poke preflight测试；没有syscall trace，不声称系统调用级观测'
except BaseException as error:
 row.update(status='FAIL',error=repr(error))
finally:
 for fd in (read_fd,write_fd):
  if fd is not None:os.close(fd)
 if child is not None and not row['reaped']:
  row['exit_code']=child.wait();row['reaped']=True
 row['ended_monotonic_ns']=time.monotonic_ns();h.save(folder/'completion.json',row)
 for sig,handler in old.items():signal.signal(sig,handler)
print(json.dumps({'name':name,'status':row['status'],'exit_code':row.get('exit_code'),'reaped':row['reaped']},ensure_ascii=False),flush=True)
raise SystemExit(0 if row['status']=='PASS_EXPECTED_EXIT2_EARLY_REFUSAL' else 1)
