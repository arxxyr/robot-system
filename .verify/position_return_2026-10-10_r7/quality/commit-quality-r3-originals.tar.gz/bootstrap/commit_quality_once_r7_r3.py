import hashlib,importlib.util,json,signal
from pathlib import Path
from types import SimpleNamespace
base=Path('/home/loosqk/robot-checks/position-return-20261010-r1/position-return-r7');source=base/'source';out=base/'commit-quality-r3'
head='894084738d95a7239611c2b8fbecfe081d3a7fc9';target=Path('/home/loosqk/robot-checks/xlerobot-velocity-foundation-20261008-r7/build');cache='/home/loosqk/robot-checks/viz-orin-a6957cc-20260930-r1/cargo-home'
def module(name,path):
 spec=importlib.util.spec_from_file_location(name,path);value=importlib.util.module_from_spec(spec);spec.loader.exec_module(value);return value
a=module('commit_r7_existing_artifacts',Path('/home/loosqk/robot-checks/h2-exit-observation-20261009-r1/source/scripts/post_e_h2_artifacts.py'))
r=module('commit_r7_existing_runner',Path('/home/loosqk/robot-checks/h2-right-ready-20261009-r1/bootstrap/run_release_v2.py'))
a.require(a.sha256(Path(r.__file__))=='d6b20da28de8d5ae077a93cb2fb5ba7f27a66b8145df9e7e91951cb14ac0b12b' and a.sha256(Path(a.__file__))=='bd2b3f7bb8527cd9ecec73894171638e9cf378656b89e284a585c3baa37b8731','原Runner/helper变化')
expected_path=base/'bootstrap/host_source_r7.json';a.require(a.sha256(expected_path)=='11b35136d17d1a2352edb41739900536a418591b7f3f52b864561e93562be98f','597原清单变化');expected=a.strict_json(expected_path.read_text())
inputs=a.strict_json((base/'bootstrap/inputs_r7.json').read_text());five=set(inputs['changed_sources']);out.mkdir()
runner=r.Runner(SimpleNamespace(source=source,target=target,out=out,build_head=head),a);runner.env['CARGO_HOME']=cache;runner.shown['CARGO_HOME']=cache;runner.env['PATH']='/home/loosqk/.cargo/bin:/home/loosqk/.local/bin:'+runner.env['PATH'];runner.shown['PATH']=runner.env['PATH']
result={'status':'FAIL','scope':'仅本次提交前fmt→根Clippy，无UART/重跑测试/release/正式安装','started_at':r.utc(),'native_git_head':head,'native_worktree':'five changed sources; not clean','source_file_count':597,'source_manifest_sha256':expected['source_manifest_sha256'],'compiler_expected':'32dba69d69c5b10ea89a4042de8d0619f7756203'}
def text(name,argv):
 ref,row=runner.command(name,argv,7200);return Path(row['stdout']).read_text()
def snapshot(label):
 h=text(label+'_head',['git','rev-parse','HEAD']);s=text(label+'_status',['git','status','--porcelain=v1','--untracked-files=all']);files=text(label+'_files',['git','ls-files','-z','--cached','--others','--exclude-standard'])
 a.require(h.strip()==head and s==''.join(' M '+n+'\n' for n in sorted(five)),'实际894+五dirty变化')
 value=a.snapshot_source(source,files.rstrip('\0').split('\0'));a.require(value==expected and len(value['files'])==597 and value['source_manifest_sha256']=='913f4353a925acf0e4762e01b54f6264b682ae4635da43783405a8cf1ac038c8','597源首尾不一致');r.save(out/(label+'.json'),value);return value
try:
 before=snapshot('source_before');compiler=a.parse_rustc_identity(text('rustc_before',['rustc','-vV']))
 a.require(compiler['commit_hash']==result['compiler_expected'] and compiler['host']=='aarch64-unknown-linux-gnu','实际编译器变化')
 runner.command('fmt',['cargo','fmt','--all'],300)
 fmt_after=a.snapshot_source(source,list(expected['files']));r.save(out/'fmt_after.json',fmt_after);a.require(fmt_after==before,'fmt改变输入，停止Clippy')
 runner.command('clippy',['cargo','clippy','--all','--all-targets','--','-D','warnings'],7200)
 after=snapshot('source_after');a.require(after==before,'fmt后输入变化')
 compiler_after=a.parse_rustc_identity(text('rustc_after',['rustc','-vV']));a.require(compiler_after==compiler,'编译器首尾变化')
 result.update(status='PASS',compiler=compiler,source_before_after='PASS',compiler_before_after='PASS')
except BaseException as error:result['error']=repr(error)
finally:
 result.update(finished_at=r.utc(),receipts=runner.receipts);r.save(out/'result.json',result);print(json.dumps(result,ensure_ascii=False),flush=True)
raise SystemExit(0 if result['status']=='PASS' else 1)
