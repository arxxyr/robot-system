#!/bin/bash
set -eu
umask 077
export PYTHONDONTWRITEBYTECODE=1
tmux set-option -p remain-on-exit on
exec /home/loosqk/.local/share/uv/python/cpython-3.12.13-linux-aarch64-gnu/bin/python3 /home/loosqk/robot-checks/position-return-20261010-r1/register-diagnostic-r7/readonly15_r7.py --config /home/loosqk/robot-checks/position-return-20261010-r1/register-diagnostic-r7/config.readonly15.r7.json --execute > /home/loosqk/robot-checks/position-return-20261010-r1/register-diagnostic-r7/readonly15-launch-record-r7/driver.log 2>&1
