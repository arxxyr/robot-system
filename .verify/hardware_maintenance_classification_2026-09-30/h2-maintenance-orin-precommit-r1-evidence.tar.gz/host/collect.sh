set -eu
export PATH=/home/loosqk/.cargo/bin:/home/loosqk/.local/bin:$PATH
export PYTHONDONTWRITEBYTECODE=1
cd /home/loosqk/robot-checks/h2-maintenance-precommit-20260930-r1/bootstrap
printf '%s\n' 'c347f5828aca642484cef1460a7a28cdcfede52c1d19c3bc8aa97d65cf603650  collect_native.py' | sha256sum -c -
exec uv run --no-project python collect_native.py --base /home/loosqk/robot-checks/h2-maintenance-precommit-20260930-r1 --out /home/loosqk/robot-checks/h2-maintenance-precommit-20260930-native-r1.tar.gz --collect
