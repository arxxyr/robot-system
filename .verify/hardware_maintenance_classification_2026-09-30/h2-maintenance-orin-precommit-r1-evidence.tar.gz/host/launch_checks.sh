set -eu
export PATH=/home/loosqk/.cargo/bin:/home/loosqk/.local/bin:$PATH
export CARGO_HOME=/home/loosqk/robot-checks/viz-orin-a6957cc-20260930-r1/cargo-home
export CARGO_NET_OFFLINE=true
export RUSTUP_AUTO_INSTALL=0
export PYTHONDONTWRITEBYTECODE=1
test "$(hostname)" = ubuntu
test "$(id -u)" = 1000
test "$(id -g)" = 1000
test "$(cat /proc/sys/kernel/random/boot_id)" = 6cf7ee3e-a3c5-4c91-80bc-4ca924818b53
cd /home/loosqk/robot-checks/h2-maintenance-precommit-20260930-r1/bootstrap
printf '%s\n' '0a749558b43197a989ccc050ceef56b1ea267a75d7c50d3a39c7cd78bdab2155  run_checks.py' '1674be3c565d67f76eb8649f63cf2316ddee0664e844729cb1713a118a920c0c  protection_expected.json' | sha256sum -c -
exec taskset -c 0-3 uv run --no-project python run_checks.py
