set -eu
export PATH=/home/loosqk/.cargo/bin:/home/loosqk/.local/bin:$PATH
test "$(hostname)" = ubuntu
test "$(id -u)" = 1000
test "$(id -g)" = 1000
test "$(cat /proc/sys/kernel/random/boot_id)" = 6cf7ee3e-a3c5-4c91-80bc-4ca924818b53
TASK_BASE=/home/loosqk/robot-checks/h2-maintenance-precommit-20260930-r1
test ! -e "$TASK_BASE"
mkdir "$TASK_BASE"
mkdir "$TASK_BASE/bootstrap"
mkdir "$TASK_BASE/candidate"
