"""自有软件证据外包：保留原回执，不重复包含巨大解包树。"""
import hashlib,io,json,stat,tarfile
from pathlib import Path
root=Path.cwd();base=root/'target/h2-maintenance-orin-precommit-r1';archive=root/'target/h2-maintenance-orin-precommit-r1-evidence.tar.gz';index_path=root/'target/h2-maintenance-orin-precommit-r1-evidence.index.json'
def sha(data):return hashlib.sha256(data).hexdigest()
paths=[p for p in base.rglob('*') if p.is_file() and 'native-extracted' not in p.parts and p.name!='source.bundle' and p.suffix!='.pyc']
entries={}
for p in sorted(paths):
    assert p.resolve()==p and stat.S_ISREG(p.lstat().st_mode)
    data=p.read_bytes();entries[str(p.relative_to(base))]={'sha256':sha(data),'bytes':len(data),'executable':bool(p.stat().st_mode&stat.S_IXUSR)}
index={'schema':'H2_MAINTENANCE_R5_ORIN_PRECOMMIT_OUTER_ARCHIVE_V1','source_sha256':'167dc63b2a274b53d9c53fe72c811d242d8ca96d5f031e1bf0ea9981cbd78e18','files':entries}
raw=(json.dumps(index,sort_keys=True,ensure_ascii=False,indent=2)+'\n').encode()
with index_path.open('xb') as stream:stream.write(raw)
with tarfile.open(archive,'x:gz') as tar:
    for name,entry in entries.items():
        data=(base/name).read_bytes();assert sha(data)==entry['sha256'] and len(data)==entry['bytes'];item=tarfile.TarInfo(name);item.size=len(data);item.mode=0o755 if entry['executable'] else 0o644;tar.addfile(item,io.BytesIO(data))
    item=tarfile.TarInfo('outer-index.json');item.size=len(raw);item.mode=0o644;tar.addfile(item,io.BytesIO(raw))
seen=set()
with tarfile.open(archive,'r:gz') as tar:
    for item in tar:
        assert item.isfile() and item.name not in seen;seen.add(item.name);blob=tar.extractfile(item).read()
        if item.name=='outer-index.json':assert blob==raw
        else:
            entry=entries[item.name];assert sha(blob)==entry['sha256'] and len(blob)==entry['bytes'] and bool(item.mode&stat.S_IXUSR)==entry['executable']
assert seen==set(entries)|{'outer-index.json'}
result={'status':'PASS','archive':{'path':str(archive),'sha256':sha(archive.read_bytes()),'bytes':archive.stat().st_size},'index':{'path':str(index_path),'sha256':sha(raw),'bytes':len(raw)},'files':len(entries),'tar_members':len(seen),'sha_bytes_mode_verified':True}
p=base/'outer_archive_verification.json'
with p.open('x') as stream:json.dump(result,stream,ensure_ascii=False,indent=2);stream.write('\n')
print(json.dumps(result,ensure_ascii=False))
