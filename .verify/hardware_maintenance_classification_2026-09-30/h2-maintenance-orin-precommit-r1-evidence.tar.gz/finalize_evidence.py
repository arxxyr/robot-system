"""补充纯软件包收口；不回填原V2、不改源或硬件原件。"""
import hashlib,json,subprocess,sys
from pathlib import Path
BASE=Path(__file__).resolve().parent;EX=BASE/'native-extracted';V2=BASE.parent/'h2-trace-v2-orin-r1';REMOTE=Path('/home/loosqk/robot-checks/h2-maintenance-precommit-20260930-r1');MAIN=Path('/Users/loosqk/repo/rust/robot-system');sys.path.insert(0,str(MAIN/'scripts'));import post_e_h2_artifacts as a

def require(ok,msg):
    if not ok:raise ValueError(msg)
def ref(p):
    with p.open('rb') as stream:digest=hashlib.file_digest(stream,'sha256').hexdigest()
    return {'path':str(p),'sha256':digest,'bytes':p.stat().st_size}
def read(p):return json.loads(p.read_text())
def local(p):return EX/Path(p).relative_to(REMOTE)
r=read(EX/'checks-r1/result.json');require(r['status']=='PASS','追加未通过');commands=[]
for phase,key in [('maintenance','maintenance_receipts'),('precommit','precommit_receipts')]:
    for pinned in r[key]:
        p=local(pinned['path']);require(ref(p)['sha256']==pinned['sha256'],'completion引用变化');row=read(p);launch=read(local(row['launch_receipt']));require(row['exit_code']==0 and row['reaped'] and row['signals']==[] and row.get('runner_error') is None and not row['budget_exceeded'],'真实回收失败')
        require(row['deadline_monotonic_ns']==row['started_monotonic_ns']+row['timeout_seconds']*1_000_000_000 and row['elapsed_ns']==row['ended_monotonic_ns']-row['started_monotonic_ns'] and row['session_residual_before_cleanup']==[] and row['session_residual_after_cleanup']==[],'预算/会话不同')
        for field in ('name','argv','cwd','env','removed_env_keys','started_at','started_monotonic_ns','timeout_seconds','stdout','stderr','launch_receipt','completion_receipt','pid','identity','deadline_monotonic_ns'):require(row[field]==launch[field],'launch不一致')
        require(launch['reaped'] is False and launch['exit_code'] is None and row['exec_gate_released'] is True,'启动门错误')
        for name in ('stdout','stderr'):
            value=ref(local(row[name]));require(value['sha256']==row[name+'_sha256'] and value['bytes']==row[name+'_bytes'],'原日志变化')
        commands.append({'phase':phase,'name':row['name'],'argv':row['argv'],'pid':row['pid'],'exit_code':0,'reaped':True,'timeout_seconds':row['timeout_seconds'],'elapsed_ns':row['elapsed_ns'],'receipt':ref(p)})
require(len(commands)==22,'不是22直接child');source=read(EX/'checks-r1/precommit/source_before.json');require(source==read(EX/'checks-r1/precommit/source_after.json')==read(V2/'expected_source.json'),'source不一致')
require(read(EX/'checks-r1/formal_before.json')==read(EX/'checks-r1/formal_after.json')==read(V2/'native-extracted/post-release-r1/identities_after.json')['formal'],'正式4件与V2或前后不同')
require(read(EX/'checks-r1/protection_before.json')==read(EX/'checks-r1/protection_after.json')==read(BASE/'protection_expected.json'),'保护与pinned或前后不同')
require(read(EX/'checks-r1/candidate_before.json')==read(EX/'checks-r1/candidate_after.json')==read(BASE/'candidate_inputs.json'),'候选前后不同')
outer=[]
for p in sorted((BASE/'host').glob('*.owner/result.json')):
    value=read(p);require(value['status']=='PASS' and value['phase']=='REAPED' and value['wait_returncode']==0 and value['reaped'] and value['received_signals']=={} and value['owner_sent_signals']==[] and value['errors']==[],'本地owner失败');log=ref(p.parent/'child.log');require(log['sha256']==value['log']['sha256'] and log['bytes']==value['log']['bytes'],'ownerlog变化');outer.append({'receipt':ref(p),'owner_pid':value['owner_pid'],'child_pid':value['pid'],'wait_returncode':0,'reaped':True})
require(len(outer)==9,'本地owner数量');require(read(BASE/'native-evidence.metadata.json')==json.loads((BASE/'host/collect_native.owner/child.log').read_text().splitlines()[-1]),'下载metadata与实际collector不同')
names=subprocess.check_output(['git','ls-files','-z'],cwd=MAIN).decode().rstrip('\0').split('\0');require(a.snapshot_source(MAIN,names)==source,'当前main589漂移')
summary={'schema':'HARDWARE_MAINTENANCE_R5_ORIN_SOFTWARE_PRECOMMIT_V1','status':'SOFTWARE_PASS_PENDING_INDEPENDENT_AND_ROOT_ACCEPTANCE','scope':'维护r5独立三文件35方法/defaultPLAN及同589本轮提交前门；无UART、真实bindings/GO、安装或服务启动。','source':{'head':'1c5758f97b7c502a38c850e8352ce970216bea53','files':589,'aggregate':source['source_manifest_sha256'],'source_before_after_equal':True,'current_main_589_equal':True,'base_v2_summary':ref(V2/'summary.json'),'base_v2_unchanged':True},'maintenance':r['maintenance'],'precommit':r['precommit'],'checks_result':ref(EX/'checks-r1/result.json'),'identity':{'host':'ubuntu','uid':1000,'gid':1000,'boot':'6cf7ee3e-a3c5-4c91-80bc-4ca924818b53','uv':(EX/'checks-r1/maintenance/uv_identity/stdout.log').read_text(),'python':(EX/'checks-r1/maintenance/python_identity/stdout.log').read_text()},'formal':{'head':'ca14f0e6cf6df8ecc6baaaa8dff2dddb64abbd0a','clean':True,'four_sha_equal_to_v2_and_before_after':True,'four_files':read(EX/'checks-r1/formal_after.json'),'six_services':'loaded/inactive/dead/MainPID0','services_receipt':ref(EX/'checks-r1/precommit/formal_services/completion.json'),'control_processes_after':r['control_processes_after']},'protection':{'reference':ref(BASE/'protection_expected.json'),'original_reference_source':str(MAIN/'target/hardware_verify_20260930_r2/maintenance/bindings.json'),'fields':'path/hex/SHA/bytes/mode/uid/gid/inode逐字段','file_count':12,'locks_read_only_not_held':4,'exact_pinned_and_before_after_equal':True,'before':ref(EX/'checks-r1/protection_before.json'),'after':ref(EX/'checks-r1/protection_after.json')},'true_waits':{'direct_receipts':22,'maintenance':4,'precommit_and_formal':18,'commands':commands,'local_owned_receipts':9,'local_owners':outer,'kill_retry_signals':False},'evidence':{'native_archive':ref(BASE/'native-evidence.tar.gz'),'native_index':ref(BASE/'native-evidence.index.json'),'native_metadata':ref(BASE/'native-evidence.metadata.json'),'verification':ref(BASE/'native_archive_verification.json'),'files':105,'directories':30,'members':136,'extracted':str(EX)},'mechanisms':{'wrapper':ref(BASE/'run_checks.py'),'helper_frozen':ref(V2/'run_release_v2.py'),'candidate_review':ref(BASE/'independent_review_r5.json'),'collector':ref(BASE/'collect_native.py'),'collector_delta':ref(BASE/'collector_delta.diff')},'count_boundary':'35为独立维护方法，不混入原1c的71、12owner或历史194；本补充不重跑六配方/7help/mock/tonic。','unchanged_hardware':'原H2与维护run02整体FAIL、D15 OPEN/DEFERRED、deployable=false保持；未动作、未消费旧watch/GO。'}
with (BASE/'summary.json').open('x') as stream:json.dump(summary,stream,ensure_ascii=False,indent=2);stream.write('\n')
print(json.dumps({'summary':ref(BASE/'summary.json'),'direct_waits':22,'local_owned_waits':9,'formal_and_protection_equal':True},ensure_ascii=False))
