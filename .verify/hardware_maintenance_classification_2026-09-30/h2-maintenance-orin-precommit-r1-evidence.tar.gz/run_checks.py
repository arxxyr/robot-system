"""独立维护r5软件验证与提交前门；不消费bindings/GO，不访问UART或改变保护。"""
import hashlib,importlib.util,json,os,re,signal,stat,sys
from pathlib import Path
from types import SimpleNamespace
sys.dont_write_bytecode=True
BASE=Path('/home/loosqk/robot-checks/h2-maintenance-precommit-20260930-r1');FROZEN=Path('/home/loosqk/robot-checks/h2-trace-owner-v2-20260930-r1');SOURCE=FROZEN/'source';CANDIDATE=BASE/'candidate';CACHE=Path('/home/loosqk/robot-checks/h2-nightly-v2-20260930-r1/build');FORMAL=Path('/home/loosqk/repo/robot/robot-system');HEAD='1c5758f97b7c502a38c850e8352ce970216bea53'
def module(name,path):
    spec=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);return m
helper=module('quality_runner',FROZEN/'bootstrap/run_release_v2.py');a=module('quality_artifacts',SOURCE/'scripts/post_e_h2_artifacts.py');require=a.require
require(a.sha256(FROZEN/'bootstrap/run_release_v2.py')=='dad9bbc9405b8fac4d60d6efe794b36750e6a6f9ce9fdeba3debf7d3e1b9a471','runner不同')
OUT=BASE/'checks-r1';OUT.mkdir();(OUT/'maintenance').mkdir();(OUT/'precommit').mkdir()
opts=lambda source,out:SimpleNamespace(source=source,out=out,target=CACHE,build_head=HEAD,formal_root=FORMAL)
r=helper.Runner(opts(SOURCE,OUT/'precommit'),a);c=helper.Runner(opts(CANDIDATE,OUT/'maintenance'),a)
inputs=a.strict_json((BASE/'bootstrap/candidate_inputs.json').read_text());protection=a.strict_json((BASE/'bootstrap/protection_expected.json').read_text());result={'status':'FAIL','scope':'独立维护r5 35方法/defaultPLAN与同589提交前门；无硬件、真实bindings/GO、UART或安装。','self_sha256':a.sha256(Path(__file__)),'maintenance_receipts':[],'precommit_receipts':[]};source=None;compiler=None;old={}
def interrupted(signum,frame):helper.INTERRUPTED=signum
def candidate_snapshot():
    actual={}
    for name,item in inputs.items():
        path=CANDIDATE/name;require(path.resolve()==path and stat.S_ISREG(path.lstat().st_mode),'候选不是普通文件');actual[name]={'sha256':a.sha256(path),'bytes':path.stat().st_size}
    require(actual==inputs,'候选SHA/bytes漂移');return actual
def identity(info):return (info.st_dev,info.st_ino,info.st_mode,info.st_uid,info.st_gid,info.st_size,info.st_mtime_ns,info.st_ctime_ns)
def protection_snapshot():
    actual={}
    for side,files in protection.items():
        actual[side]={}
        for name,expected in files.items():
            p=Path(expected['path']);require(p.resolve()==p and stat.S_ISREG(p.lstat().st_mode),'保护引用不是普通文件');first=p.lstat();fd=os.open(p,os.O_RDONLY|os.O_NOFOLLOW)
            with os.fdopen(fd,'rb') as stream:
                require(identity(os.fstat(stream.fileno()))==identity(first),'保护打开身份变化');data=stream.read(expected['bytes']+1);require(identity(os.fstat(stream.fileno()))==identity(first),'保护读取身份变化')
            require(identity(p.lstat())==identity(first),'保护读取后变化');actual[side][name]={'path':str(p),'hex':data.hex(),'sha256':hashlib.sha256(data).hexdigest(),'bytes':len(data),'mode':stat.S_IMODE(first.st_mode),'uid':first.st_uid,'gid':first.st_gid,'inode':first.st_ino};require(actual[side][name]==expected,'保护前值不同:'+str(p))
    return actual
def formal_snapshot():return a.validate_target_isolation(CACHE,{name:FORMAL/'target/release'/name for name in a.INSTALLED_NAMES})['installed']
try:
    for sig in (signal.SIGTERM,signal.SIGINT,signal.SIGHUP):old[sig]=signal.signal(sig,interrupted)
    candidate_before=candidate_snapshot();helper.save(OUT/'candidate_before.json',candidate_before);initial_formal=formal_snapshot();helper.save(OUT/'formal_before.json',initial_formal);initial_protection=protection_snapshot();helper.save(OUT/'protection_before.json',initial_protection)
    _,u=c.command('uv_identity',['uv','--version']);_,p=c.command('python_identity',['uv','run','--no-project','python','-c','import sys,platform,json;print(json.dumps({"executable":sys.executable,"version":platform.python_version()}))'])
    _,t=c.command('deterministic_35',['uv','run','--no-project','python','-m','unittest','discover','-s','scripts/tests','-p','test_hardware_maintenance.py'],300);text=Path(t['stderr']).read_text();require(re.findall(r'Ran (\d+) tests? in ',text)==['35'] and re.search(r'^OK\s*$',text,re.M),'不是35方法通过')
    _,p=c.command('default_plan',['uv','run','--no-project','python','scripts/run_hardware_maintenance.py'],300);plan=a.strict_json(Path(p['stdout']).read_text());require(plan['result']=='PLAN_ONLY' and plan['actions_started']==0,'默认不是零动作PLAN')
    result['maintenance']={'methods':35,'failed':0,'default_plan':plan,'candidate_inputs':candidate_before,'physical_uart':False,'real_bindings_or_go':False}
    source=r.source('source_before');require(source==a.strict_json((FROZEN/'release-r1/source_before.json').read_text()),'源与冻结不同')
    _,p=r.command('rustc_before',['rustc','-vV']);compiler=a.parse_rustc_identity(Path(p['stdout']).read_text());_,p=r.command('cargo_before',['cargo','-V']);cargo_before=Path(p['stdout']).read_bytes()
    r.command('latest_nightly_update',['rustup','update','nightly','--no-self-update'],300)
    _,p=r.command('rustc_after_update',['rustc','-vV']);compiler_updated=a.parse_rustc_identity(Path(p['stdout']).read_text());_,p=r.command('cargo_after_update',['cargo','-V']);cargo_updated=Path(p['stdout']).read_bytes()
    r.command('fmt',['cargo','fmt','--all'],300);r.command('clippy',['cargo','clippy','--locked','--all','--all-targets','--','-D','warnings'],7200)
    _,p=r.command('rustc_after',['rustc','-vV']);require(a.parse_rustc_identity(Path(p['stdout']).read_text())==compiler_updated,'门后rustc变化');_,p=r.command('cargo_after',['cargo','-V']);require(Path(p['stdout']).read_bytes()==cargo_updated,'门后cargo变化');require(compiler_updated==compiler==a.strict_json((FROZEN/'release-r1/production.json').read_text())['rustc_identity'] and cargo_before==cargo_updated,'latest更新改变V2编译器，须另新冻结')
    result['precommit']={'fmt':'PASS','root_clippy_all_all_targets_deny_warnings':'PASS','latest_nightly_actual_update':True,'compiler':compiler_updated,'compiler_before_update_after_equal':True,'source_files':589,'aggregate':source['source_manifest_sha256']}
    r.command('formal_head',['git','-C',str(FORMAL),'rev-parse','HEAD']);_,p=r.command('formal_status',['git','-C',str(FORMAL),'status','--porcelain=v1','--untracked-files=all']);require(Path(p['stdout']).read_bytes()==b'','正式非clean')
    _,p=r.command('formal_services',['systemctl','show','xlerobot-s0-left-arm.service','xlerobot-s0-right-arm.service','xlerobot-s1-left.service','xlerobot-s1-right.service','xlerobot-gateway-left.service','xlerobot-gateway-right.service','-p','Id','-p','LoadState','-p','ActiveState','-p','SubState','-p','MainPID']);text=Path(p['stdout']).read_text();require(text.count('MainPID=0')==6 and text.count('ActiveState=inactive')==6 and text.count('SubState=dead')==6 and text.count('LoadState=loaded')==6,'六服务未停止')
    require((OUT/'precommit/formal_head/stdout.log').read_text().strip()=='ca14f0e6cf6df8ecc6baaaa8dff2dddb64abbd0a','正式HEAD变化')
    remaining=[]
    for path in Path('/proc').iterdir():
        if not path.name.isdigit():continue
        try:argv=(path/'cmdline').read_bytes().replace(b'\0',b' ').decode(errors='replace')
        except FileNotFoundError:continue
        if re.search(r'(^|/)(s0_daemon|s1_daemon|robot_rpc_gateway|comm_fault_e2e|xlerobot_deploy|feetech_poke)( |$)',argv):remaining.append({'pid':int(path.name),'argv':argv})
    require(not remaining,'仍有控制进程');result['control_processes_after']=remaining
    result['status']='PASS'
except BaseException as error:result['error']=repr(error)
finally:
    for name,check in [('source_after',lambda:r.source('source_after')),('candidate_after',candidate_snapshot),('formal_after',formal_snapshot),('protection_after',protection_snapshot)]:
        try:
            value=check();helper.save(OUT/(name+'.json'),value)
            expected={'source_after':source,'candidate_after':locals().get('candidate_before'),'formal_after':locals().get('initial_formal'),'protection_after':locals().get('initial_protection')}[name];require(expected is not None and value==expected,name+'变化');result[name]='PASS'
        except BaseException as error:result.update(status='FAIL');result[name]=repr(error)
    result['maintenance_receipts']=c.receipts;result['precommit_receipts']=r.receipts;helper.save(OUT/'result.json',result)
    for sig,handler in old.items():signal.signal(sig,handler)
print(json.dumps(result,ensure_ascii=False),flush=True);raise SystemExit(0 if result['status']=='PASS' else 1)
