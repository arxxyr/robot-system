"""收口本轮独立Orin软件原件；不改源或既有V2回执。"""
import hashlib,json,re,stat,subprocess,sys
from pathlib import Path
BASE=Path(__file__).resolve().parent;EX=BASE/'native-extracted';MAIN=Path('/Users/loosqk/repo/rust/robot-system');REMOTE=Path('/home/loosqk/robot-checks/h2-trace-owner-v2-20260930-r1');HEAD='1c5758f97b7c502a38c850e8352ce970216bea53';AGGREGATE='83048e983bb7a13c2f75ae23e593ec301f129b10b412db8f4f80176ca434f62f'
sys.dont_write_bytecode=True;sys.path.insert(0,str(MAIN/'scripts'));import post_e_h2_artifacts as a

def require(ok,message):
    if not ok:raise ValueError(message)
def ref(path):
    with path.open('rb') as stream:digest=hashlib.file_digest(stream,'sha256').hexdigest()
    return {'path':str(path),'sha256':digest,'bytes':path.stat().st_size}
def save(path,value):
    with path.open('x') as stream:json.dump(value,stream,ensure_ascii=False,indent=2,allow_nan=False);stream.write('\n')
def local(path):return EX/Path(path).relative_to(REMOTE)
def read(path):return json.loads(path.read_text())
source=read(EX/'release-r1/source_before.json');require(source==read(BASE/'expected_source.json') and len(source['files'])==589 and source['source_manifest_sha256']==AGGREGATE,'source身份错误')
results={name:read(EX/name/filename) for name,filename in [('release-r1','result.json'),('post-release-r1','post_release_result.json'),('directed-owner-r1','result.json'),('source-inputs-r1','result.json')]}
commands=[]
for tree,result in results.items():
    require(result['status']=='PASS','原件未通过:'+tree)
    require(source==read(EX/tree/'source_before.json')==read(EX/tree/'source_after.json'),'source窗口不同:'+tree)
    for reference in result['receipts']:
        p=local(reference['path']);require(ref(p)['sha256']==reference['sha256'],'completion绑定变化');r=read(p);launch=read(local(r['launch_receipt']))
        require(r['exit_code']==0 and r['reaped'] and r['signals']==[] and r.get('runner_error') is None and r.get('budget_exceeded') is False,'自然回收/预算失败')
        require(r['identity']['pid']==r['pid'] and r['identity']['boot_id']=='6cf7ee3e-a3c5-4c91-80bc-4ca924818b53' and r['identity']['sid']==r['pid'],'child身份变化')
        require(r['session_residual_before_cleanup']==[] and r['session_residual_after_cleanup']==[] and r['deadline_monotonic_ns']==r['started_monotonic_ns']+r['timeout_seconds']*1_000_000_000 and r['elapsed_ns']==r['ended_monotonic_ns']-r['started_monotonic_ns'],'回收/原预算账本不同')
        for key in ('name','argv','cwd','env','removed_env_keys','started_at','started_monotonic_ns','timeout_seconds','stdout','stderr','launch_receipt','completion_receipt','pid','identity','deadline_monotonic_ns'):
            require(r[key]==launch[key],'launch字段变化:'+key)
        require(launch['reaped'] is False and launch['exit_code'] is None and launch['signals']==[] and r['exec_gate_released'] is True,'实际启动门证据错误')
        for stream in ('stdout','stderr'):
            item=ref(local(r[stream]));require(item['bytes']==r[stream+'_bytes'] and item['sha256']==r[stream+'_sha256'],'原日志不同')
        commands.append({'tree':tree,'name':r['name'],'argv':r['argv'],'pid':r['pid'],'exit_code':0,'reaped':True,'timeout_seconds':r['timeout_seconds'],'elapsed_ns':r['elapsed_ns'],'budget_exceeded':False,'receipt':ref(p)})
require(len(commands)==52,'直接child数量错误')
artifacts={};recipes=[];compiler=None
for kind in ('production','measurement'):
    m=read(EX/'release-r1'/f'{kind}.json');require(m['schema']=='P7_RELEASE_ARTIFACTS_V2' and m['build_head']==HEAD and m['build_root']==str(REMOTE/'source') and m['source_manifest_sha256']==AGGREGATE and m['deployable'] is False,'V2身份错误')
    if compiler is None:compiler=m['rustc_identity']
    require(m['rustc_identity']==compiler,'两清单编译器不同')
    for build,reference in m['builds'].items():
        p=local(reference['path']);require(ref(p)['sha256']==reference['sha256'],'build绑定不同');r=read(p);require(r['argv']==a.build_argv(kind,build),'配方错误');records=[json.loads(line) for line in local(r['stdout']).read_text().splitlines() if line.strip()];require([row for row in records if row.get('reason')=='build-finished']==[{'reason':'build-finished','success':True}],'Cargo未唯一完成')
        if kind=='production':require(all(not feature.startswith('test-') for row in records if row.get('reason')=='compiler-artifact' for feature in row['features']),'生产test feature泄漏')
        recipes.append({'kind':kind,'build':build,'argv':r['argv'],'receipt':ref(p)})
    for name,item in m['artifacts'].items():
        p=local(item['path']);identity=a.elf_identity(p);require(all(identity[key]==item[key] for key in ('sha256','bytes','mode','elf_machine')),'冻结ELF不同');require(read(local(item['sidecar']['path']))=={k:v for k,v in item.items() if k!='sidecar'} and ref(local(item['sidecar']['path']))['sha256']==item['sidecar']['sha256'],'sidecar不同');require(item['features']==item['compiler_artifact']['features'] and sorted(item['features'])==sorted(a.BUILD_SPECS[kind][item['build']][3]),'feature闭包不同');require(item['profile']=='release' and item['build_head']==HEAD and item['source_manifest_sha256']==AGGREGATE and item['compiler_artifact']['profile']=={'opt_level':'3','debuginfo':0,'debug_assertions':False,'overflow_checks':False,'test':False},'profile不同')
        records=[json.loads(line) for line in local(read(local(m['builds'][item['build']]['path']))['stdout']).read_text().splitlines() if line.strip()];require(records.count(item['compiler_artifact'])==1,'产物原Cargo JSON不唯一');artifacts[kind+'/'+name]={**identity,'path':str(p),'remote_path':item['path'],'features':item['features'],'compiler_artifact':item['compiler_artifact']}
require(len(recipes)==6 and len(artifacts)==7,'配方/冻件数错误')
for tree in results:
    for label in ('rustc_before','rustc_after'):
        p=EX/tree/label/'stdout.log'
        if p.exists():require(a.parse_rustc_identity(p.read_text())==compiler,'编译器窗口不同')
python_stderr=(EX/'release-r1/python_tests/stderr.log').read_text();counts=re.findall(r'Ran (\d+) tests? in ',python_stderr);require(counts==['71'] and re.search(r'^OK\s*$',python_stderr,re.M),'Python计数不符')
post=results['post-release-r1'];require(post['mock']=={'cases':1,'groups':4,'samples':8,'physical_uart':False,'hardware_pass':False} and post['loopback']=={'tests':6,'scenes':9,'all_servers_joined':True},'post结果边界错误')
owner=results['directed-owner-r1'];require((owner['tests'],owner['failed'],owner['ignored'])==(12,0,0),'owner计数不符')
before=(BASE/'host/identity_before.owner/child.log').read_text();after=(BASE/'host/identity_after.owner/child.log').read_text();prefix=before.split('rustc ')[0];require(after.startswith(prefix),'正式/主机前后不同');require(prefix.count('ActiveState=inactive')==6 and prefix.count('MainPID=0')==6 and prefix.count('SubState=dead')==6,'六服务状态错误')
require(after.split('rustc ')[1].split('cargo ')[0]==before.split('rustc ')[1].split('cargo ')[0],'首末rustc不同')
outer=[];failures=[]
for p in sorted((BASE/'host').glob('*.owner/result.json')):
    r=read(p);require(r['reaped'] and r['phase']=='REAPED' and r['owner_sent_signals']==[] and r['received_signals']=={} and r['errors']==[],'本地owner回收错误');item=ref(p.parent/'child.log');require(item['sha256']==r['log']['sha256'] and item['bytes']==r['log']['bytes'],'owner日志变化');entry={'receipt':ref(p),'status':r['status'],'owner_pid':r['owner_pid'],'child_pid':r['pid'],'wait_returncode':r['wait_returncode'],'reaped':True};outer.append(entry)
    if r['status']!='PASS':failures.append(entry)
require(len(failures)==1 and failures[0]['receipt']['path'].endswith('/early_release_download.owner/result.json') and failures[0]['wait_returncode']==1,'原FAIL边界错误')
collect_log=(BASE/'host/collect_native.owner/child.log').read_text().splitlines();require(json.loads(collect_log[-1])==read(BASE/'native-evidence.metadata.json'),'远端collector和下载metadata不同')
main_names=subprocess.check_output(['git','ls-files','-z'],cwd=MAIN).decode().rstrip('\0').split('\0');main_source=a.snapshot_source(MAIN,main_names);require(main_source==source,'当前main589发生变化');main_head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=MAIN).decode().strip();main_status=subprocess.check_output(['git','status','--porcelain=v1','--untracked-files=all'],cwd=MAIN).decode()
summary={'schema':'H2_TRACE_OWNER_ORIN_V2_SOFTWARE_V1','status':'SOFTWARE_PASS_PENDING_INDEPENDENT_AND_ROOT_ACCEPTANCE','scope':'本轮HEAD1c独立Orin源、六配方/七件V2原生冻结及必要纯软件门；无UART/安装/服务启动/硬件GO。','source':{'head':HEAD,'remote_root':str(REMOTE/'source'),'files':589,'aggregate':AGGREGATE,'sla_sha256':source['files']['crates/robot-tests/src/comm_fault/sla.rs']['sha256'],'s1_sha256':source['files']['crates/robot-s1/src/events_drain/runtime.rs']['sha256'],'fresh_all_windows_equal':True,'inputs_originals':str(EX/'source-inputs-r1/files'),'main_current_head':main_head,'main_current_status':main_status,'main_current_589_equal':True,'bundle_sha256':'c4d8624cc5a49c0016fda7a748a877f888ec2bf56b8f9668fc9bc567eda789f2','bundle_bytes':402333155,'clone_method':'从formal ca14 --no-hardlinks独立clone，校验增量bundle后detach1c；无alternates，formal只读。'},'compiler':{'floating_nightly_actual_update':ref(EX/'bootstrap/update-nightly.log'),'identity':compiler,'before_after_equal':True,'rustc_before':ref(EX/'bootstrap/nightly_before.txt'),'rustc_after':ref(EX/'bootstrap/nightly_after.txt'),'cargo_before':ref(EX/'bootstrap/cargo_before.txt'),'cargo_after':ref(EX/'bootstrap/cargo_after.txt')},'recipes':recipes,'artifacts':artifacts,'checks':{'fmt':'PASS','root_clippy_all_all_targets_warnings_deny':'PASS','python':{'passed':71,'source':'冻结1c既有scripts/tests，不包含独立维护候选。'},'default_plan_only':'PASS','help':7,'mock':post['mock'],'tonic':post['loopback'],'owner_tests':{'passed':12,'failed':0,'ignored':0,'subset_of_previous_full_suite':194,'full_suite_this_round':'NOT_RUN','test_threads_override':None},'full_workspace':'NOT_RUN','long_load':'NOT_RUN'},'true_waits':{'direct_child_receipts':52,'by_phase':{name:len(result['receipts']) for name,result in results.items()},'direct_commands':commands,'local_owned_receipts':len(outer),'local_owners':outer,'sent_signals':[],'automatic_kill_retry':False,'budgets':'原timeout_seconds/deadline/elapsed完整保留，超限自然wait后FAIL；本轮无超限。'},'formal':{'head':'ca14f0e6cf6df8ecc6baaaa8dff2dddb64abbd0a','clean':True,'four_installed_sha_before_after_equal':True,'six_services':'loaded/inactive/dead/MainPID0','control_processes_after':[],'identity_before':ref(BASE/'host/identity_before.owner/child.log'),'identity_after':ref(BASE/'host/identity_after.owner/child.log'),'identity_prefix_equal_bytes':len(prefix.encode()),'protection':'本V2不添加现场/D15门，root后续追加包独立只读比对。'},'evidence':{'native_archive':ref(BASE/'native-evidence.tar.gz'),'native_index':ref(BASE/'native-evidence.index.json'),'native_metadata':ref(BASE/'native-evidence.metadata.json'),'verification':ref(BASE/'native_archive_verification.json'),'indexed_files':877,'directory_members':187,'tar_members':1065,'extracted':str(EX)},'temporary_mechanisms':{'runner':ref(BASE/'run_release_v2.py'),'runner_delta':ref(BASE/'runner_delta.diff'),'runner_static_review':ref(BASE/'runner_static_independent_review.json'),'post_checks':ref(BASE/'post_release_checks.py'),'directed_owner':ref(BASE/'directed_owner_checks.py'),'snapshot_inputs':ref(BASE/'snapshot_inputs.py'),'collector':ref(BASE/'collect_native.py'),'collector_delta':ref(BASE/'collector_delta.diff')},'original_failures_preserved':failures,'boundaries':{'physical_h2':'既有整体FAIL保持，本轮未硬件重测。','maintenance_run02':'既有左腕回程+6超过4的FAIL保持。','d15':'OPEN/DEFERRED','deployable':False,'commit_push_install':'NOT_RUN','maintenance_new_python_candidate':'另源/另门/另包，不混入本1c V2或71Python。','poweroff_fact':'PENDING，本轮不消费旧watch/GO。'}}
save(BASE/'summary.json',summary);print(json.dumps({'summary':ref(BASE/'summary.json'),'direct_waits':52,'local_owners':len(outer),'original_failures':len(failures),'source_589_equal':True},ensure_ascii=False))
