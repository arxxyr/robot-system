"""本候选新源12项owner定向；不冒称194或全仓，不访问UART。"""
import importlib.util,json,re,signal,sys
from pathlib import Path
from types import SimpleNamespace
sys.dont_write_bytecode=True
BASE=Path('/home/loosqk/robot-checks/h2-trace-owner-v2-20260930-r1');SOURCE=BASE/'source';OUT=BASE/'directed-owner-r1';CACHE=Path('/home/loosqk/robot-checks/h2-nightly-v2-20260930-r1/build');HEAD='1c5758f97b7c502a38c850e8352ce970216bea53'
def module(name,path):
    spec=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);return m
helper=module('directed_runner',BASE/'bootstrap/run_release_v2.py');a=module('directed_artifacts',SOURCE/'scripts/post_e_h2_artifacts.py');OUT.mkdir()
options=SimpleNamespace(source=SOURCE,out=OUT,target=CACHE,build_head=HEAD,formal_root=Path('/home/loosqk/repo/robot/robot-system'));runner=helper.Runner(options,a)
result={'status':'FAIL','scope':'新source/编译器绑定的12项owner定向软件oracle；12是完整194的子集，本次未跑194/全仓/硬件。','runner_sha256':a.sha256(BASE/'bootstrap/run_release_v2.py'),'source_head':HEAD,'receipts':[]};before=None;compiler=None;old={}
def interrupted(signum,frame):helper.INTERRUPTED=signum
try:
    for sig in (signal.SIGTERM,signal.SIGINT,signal.SIGHUP):old[sig]=signal.signal(sig,interrupted)
    before=runner.source('source_before');a.require(before==a.strict_json((BASE/'release-r1/source_before.json').read_text()),'定向源与V2不一致')
    _,r=runner.command('rustc_before',['rustc','-vV']);compiler=a.parse_rustc_identity(Path(r['stdout']).read_text());a.require(compiler==a.strict_json((BASE/'release-r1/production.json').read_text())['rustc_identity'],'定向编译器不一致')
    _,c=runner.command('cargo_before',['cargo','-V']);cargo=Path(c['stdout']).read_bytes()
    _,t=runner.command('owner_tests',['cargo','test','--locked','-p','robot-tests','--no-default-features','--features','comm-fault-e2e,real-hw','--bin','comm_fault_e2e','owner_tests'],7200)
    text=Path(t['stdout']).read_text();summaries=re.findall(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored;',text);a.require(summaries==[('12','0','0')],'不是完整12/0/0定向');a.require(len(re.findall(r'test comm_fault::sla::owner_tests::[^ ]+ \.\.\. ok',text))==12,'缺owner测试名字')
    _,r=runner.command('rustc_after',['rustc','-vV']);a.require(a.parse_rustc_identity(Path(r['stdout']).read_text())==compiler,'定向后编译器漂移')
    _,c=runner.command('cargo_after',['cargo','-V']);a.require(Path(c['stdout']).read_bytes()==cargo,'cargo窗口漂移')
    result.update(status='PASS',tests=12,failed=0,ignored=0,compiler_before_after_equal=True)
except BaseException as error:result['error']=repr(error)
finally:
    try:
        after=runner.source('source_after');a.require(before is not None and after==before,'定向后源码变化');result['source_before_after_equal']=True
    except BaseException as error:result.update(status='FAIL',source_after_error=repr(error))
    result['receipts']=runner.receipts;helper.save(OUT/'result.json',result)
    for sig,handler in old.items():signal.signal(sig,handler)
print(json.dumps(result,ensure_ascii=False),flush=True);raise SystemExit(0 if result['status']=='PASS' else 1)
