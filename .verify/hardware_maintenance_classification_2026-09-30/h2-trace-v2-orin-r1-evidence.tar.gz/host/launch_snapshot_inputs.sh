set -eu
export PATH=/home/loosqk/.cargo/bin:/home/loosqk/.local/bin:$PATH
export CARGO_HOME=/home/loosqk/robot-checks/viz-orin-a6957cc-20260930-r1/cargo-home
export CARGO_NET_OFFLINE=true
export RUSTUP_AUTO_INSTALL=0
export PYTHONDONTWRITEBYTECODE=1
BASE=/home/loosqk/robot-checks/h2-trace-owner-v2-20260930-r1
cd "$BASE/bootstrap"
printf '%s\n' '69d471d07f140abb4863e8f9a0726ac25937d2f452d3705c32edcd30f1991e69  snapshot_inputs.py' 'dad9bbc9405b8fac4d60d6efe794b36750e6a6f9ce9fdeba3debf7d3e1b9a471  run_release_v2.py' | sha256sum -c -
exec taskset -c 0-3 uv run --no-project python snapshot_inputs.py
