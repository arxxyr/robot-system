set -eu
export PATH=/home/loosqk/.cargo/bin:/home/loosqk/.local/bin:$PATH
export CARGO_HOME=/home/loosqk/robot-checks/viz-orin-a6957cc-20260930-r1/cargo-home
export CARGO_NET_OFFLINE=true
export RUSTUP_AUTO_INSTALL=0
export PYTHONDONTWRITEBYTECODE=1
BASE=/home/loosqk/robot-checks/h2-trace-owner-v2-20260930-r1
cd "$BASE/bootstrap"
printf '%s\n' '2c0388a6affa90993282cfb44976b9c025fc05b2b5a94dc4ba71cc38d33651ab  collect_native.py' | sha256sum -c -
exec uv run --no-project python collect_native.py --base "$BASE" --out /home/loosqk/robot-checks/h2-trace-owner-v2-20260930-native-r1.tar.gz --collect
