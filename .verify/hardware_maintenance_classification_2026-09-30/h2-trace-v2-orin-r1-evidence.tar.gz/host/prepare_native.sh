set -eu
export PATH=/home/loosqk/.cargo/bin:/home/loosqk/.local/bin:$PATH
test "$(hostname)" = ubuntu
test "$(id -un)" = loosqk
test "$(cat /proc/sys/kernel/random/boot_id)" = 6cf7ee3e-a3c5-4c91-80bc-4ca924818b53
FORMAL=/home/loosqk/repo/robot/robot-system
TASK_ROOT=/home/loosqk/robot-checks/h2-trace-owner-v2-20260930-r1
test "$(git -C "$FORMAL" rev-parse HEAD)" = ca14f0e6cf6df8ecc6baaaa8dff2dddb64abbd0a
test -z "$(git -C "$FORMAL" status --porcelain=v1 --untracked-files=all)"
ps -eo pid,ppid,args | awk '$0 ~ /[c]argo (build|test|clippy)|[r]un_release_v2.py --run-builds|[p]ost_release_checks.py --run-checks/ {print; found=1} END {exit found ? 1 : 0}'
test ! -e "$TASK_ROOT"
mkdir "$TASK_ROOT"
mkdir "$TASK_ROOT/bootstrap"
rustc +nightly -Vv > "$TASK_ROOT/bootstrap/nightly_before.txt"
cargo +nightly -V > "$TASK_ROOT/bootstrap/cargo_before.txt"
sha256sum /home/loosqk/.rustup/toolchains/nightly-aarch64-unknown-linux-gnu/bin/rustc /home/loosqk/.rustup/toolchains/nightly-aarch64-unknown-linux-gnu/bin/cargo > "$TASK_ROOT/bootstrap/nightly_before_files.sha256"
rustup update nightly --no-self-update > "$TASK_ROOT/bootstrap/update-nightly.log" 2>&1
cat "$TASK_ROOT/bootstrap/update-nightly.log"
rustc +nightly -Vv > "$TASK_ROOT/bootstrap/nightly_after.txt"
cargo +nightly -V > "$TASK_ROOT/bootstrap/cargo_after.txt"
cat "$TASK_ROOT/bootstrap/nightly_after.txt" "$TASK_ROOT/bootstrap/cargo_after.txt"
