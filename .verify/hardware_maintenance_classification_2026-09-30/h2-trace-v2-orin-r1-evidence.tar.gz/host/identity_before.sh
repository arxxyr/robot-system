set -eu
export PATH=/home/loosqk/.cargo/bin:/home/loosqk/.local/bin:$PATH
hostname
id -un
uname -smr
cat /proc/sys/kernel/random/boot_id
test "$(hostname)" = ubuntu
test "$(id -un)" = loosqk
test "$(uname -m)" = aarch64
test "$(cat /proc/sys/kernel/random/boot_id)" = 6cf7ee3e-a3c5-4c91-80bc-4ca924818b53
FORMAL=/home/loosqk/repo/robot/robot-system
git -C "$FORMAL" rev-parse HEAD
git -C "$FORMAL" status --porcelain=v1 --untracked-files=all
test "$(git -C "$FORMAL" rev-parse HEAD)" = ca14f0e6cf6df8ecc6baaaa8dff2dddb64abbd0a
test -z "$(git -C "$FORMAL" status --porcelain=v1 --untracked-files=all)"
sha256sum "$FORMAL/target/release/s0_daemon" "$FORMAL/target/release/xlerobot_deploy" "$FORMAL/target/release/s1_daemon" "$FORMAL/target/release/robot_rpc_gateway"
systemctl show xlerobot-s0-left-arm.service xlerobot-s0-right-arm.service xlerobot-s1-left.service xlerobot-s1-right.service xlerobot-gateway-left.service xlerobot-gateway-right.service -p Id -p LoadState -p ActiveState -p SubState -p MainPID
pgrep -af '(^|/)(s0_daemon|s1_daemon|robot_rpc_gateway|comm_fault_e2e|xlerobot_deploy|feetech_poke)( |$)' || test "$?" -eq 1
ps -eo pid,ppid,args | awk '$0 ~ /[c]argo (build|test|clippy)|[r]un_release_v2.py --run-builds|[p]ost_release_checks.py --run-checks/ {print; found=1} END {exit found ? 1 : 0}'
test ! -e /home/loosqk/robot-checks/h2-trace-owner-v2-20260930-r1
rustc +nightly -Vv
cargo +nightly -V
uv --version
df -B1 /home/loosqk
