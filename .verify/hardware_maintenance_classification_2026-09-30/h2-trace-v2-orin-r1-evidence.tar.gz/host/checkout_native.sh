set -eu
export PATH=/home/loosqk/.cargo/bin:/home/loosqk/.local/bin:$PATH
BASE=/home/loosqk/robot-checks/h2-trace-owner-v2-20260930-r1
FORMAL=/home/loosqk/repo/robot/robot-system
cd "$BASE/bootstrap"
printf '%s\n' 'c4d8624cc5a49c0016fda7a748a877f888ec2bf56b8f9668fc9bc567eda789f2  source.bundle' 'dad9bbc9405b8fac4d60d6efe794b36750e6a6f9ce9fdeba3debf7d3e1b9a471  run_release_v2.py' '4f567265b93687411324811363ab4d79a1730ff5a0d41bb745a37942c385449e  post_release_checks.py' 'edfc9ecba590c8357f7ae7af1d3db7cd36508094a285a98f06ef82105b4cd025  expected_source.json' | sha256sum -c -
test "$(hostname)" = ubuntu
test "$(id -un)" = loosqk
test "$(cat /proc/sys/kernel/random/boot_id)" = 6cf7ee3e-a3c5-4c91-80bc-4ca924818b53
test "$(git -C "$FORMAL" rev-parse HEAD)" = ca14f0e6cf6df8ecc6baaaa8dff2dddb64abbd0a
test -z "$(git -C "$FORMAL" status --porcelain=v1 --untracked-files=all)"
test ! -e "$BASE/source"
git clone --no-hardlinks --no-checkout "$FORMAL" "$BASE/source"
git -C "$BASE/source" bundle verify "$BASE/bootstrap/source.bundle"
git -C "$BASE/source" fetch "$BASE/bootstrap/source.bundle" HEAD
git -C "$BASE/source" checkout --detach 1c5758f97b7c502a38c850e8352ce970216bea53
test ! -e "$BASE/source/.git/objects/info/alternates"
cd "$BASE/source"
uv run --no-project python - <<'VERIFY_SOURCE'
import sys,json,subprocess
from pathlib import Path
sys.dont_write_bytecode=True
sys.path.insert(0,'scripts')
import post_e_h2_artifacts as a
root=Path.cwd()
assert subprocess.check_output(['git','rev-parse','HEAD']).decode().strip()=='1c5758f97b7c502a38c850e8352ce970216bea53'
assert subprocess.check_output(['git','status','--porcelain=v1','--untracked-files=all'])==b''
names=subprocess.check_output(['git','ls-files','-z']).decode().rstrip('\0').split('\0')
actual=a.snapshot_source(root,names)
assert actual==json.loads((root.parent/'bootstrap/expected_source.json').read_text())
assert len(actual['files'])==589
with (root.parent/'bootstrap/source_transfer_verified.json').open('x') as stream:json.dump(actual,stream,ensure_ascii=False,indent=2);stream.write('\n')
print(json.dumps({'status':'PASS','head':'1c5758f97b7c502a38c850e8352ce970216bea53','files':589,'aggregate':actual['source_manifest_sha256']}))
VERIFY_SOURCE
test "$(git -C "$FORMAL" rev-parse HEAD)" = ca14f0e6cf6df8ecc6baaaa8dff2dddb64abbd0a
test -z "$(git -C "$FORMAL" status --porcelain=v1 --untracked-files=all)"
