set -eu
export PATH=/home/loosqk/.cargo/bin:/home/loosqk/.local/bin:$PATH
export CARGO_HOME=/home/loosqk/robot-checks/viz-orin-a6957cc-20260930-r1/cargo-home
export CARGO_NET_OFFLINE=true
export RUSTUP_AUTO_INSTALL=0
export PYTHONDONTWRITEBYTECODE=1
BASE=/home/loosqk/robot-checks/h2-trace-owner-v2-20260930-r1
cd "$BASE/bootstrap"
printf '%s\n' 'dad9bbc9405b8fac4d60d6efe794b36750e6a6f9ce9fdeba3debf7d3e1b9a471  run_release_v2.py' '4f567265b93687411324811363ab4d79a1730ff5a0d41bb745a37942c385449e  post_release_checks.py' | sha256sum -c -
exec taskset -c 0-3 uv run --no-project python post_release_checks.py --run-checks --release "$BASE/release-r1" --out "$BASE/post-release-r1" --helper "$BASE/bootstrap/run_release_v2.py" --source "$BASE/source" --target /home/loosqk/robot-checks/h2-nightly-v2-20260930-r1/build --build-head 1c5758f97b7c502a38c850e8352ce970216bea53 --formal-root /home/loosqk/repo/robot/robot-system
