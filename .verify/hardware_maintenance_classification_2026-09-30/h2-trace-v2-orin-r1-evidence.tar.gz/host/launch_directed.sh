set -eu
export PATH=/home/loosqk/.cargo/bin:/home/loosqk/.local/bin:$PATH
export CARGO_HOME=/home/loosqk/robot-checks/viz-orin-a6957cc-20260930-r1/cargo-home
export CARGO_NET_OFFLINE=true
export RUSTUP_AUTO_INSTALL=0
export PYTHONDONTWRITEBYTECODE=1
BASE=/home/loosqk/robot-checks/h2-trace-owner-v2-20260930-r1
cd "$BASE/bootstrap"
printf '%s\n' 'e076c576f55c6f5cdfbe30c0212aa49fd45f1e8bd4c94a7662fdb53246396ace  directed_owner_checks.py' | sha256sum -c -
exec taskset -c 0-3 uv run --no-project python directed_owner_checks.py
