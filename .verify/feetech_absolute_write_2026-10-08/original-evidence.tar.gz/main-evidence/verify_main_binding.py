"""把实际主树格式化后的输入与已有同源原生质量门绑定，不重跑或改写旧门。"""
import hashlib
import importlib.util
import json
import subprocess
from pathlib import Path

root = Path('/Users/loosqk/repo/rust/robot-system')
area = root / 'target/absolute_write_integration_2026-10-08'
spec = importlib.util.spec_from_file_location('artifacts', root / 'scripts/post_e_h2_artifacts.py')
helpers = importlib.util.module_from_spec(spec)
spec.loader.exec_module(helpers)
children = []

def call(argv):
    child = subprocess.Popen(argv, cwd=root, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    out, err = child.communicate()
    children.append({'argv': argv, 'pid': child.pid, 'exit_code': child.returncode,
                     'actual_wait_reap': True})
    assert child.returncode == 0, err.decode()
    return out.decode()

names = call(['git', 'ls-files', '-z', '--cached', '--others', '--exclude-standard']).rstrip('\0').split('\0')
source = helpers.snapshot_source(root, names)
expected = json.loads((area / 'native-r3/expected_source.json').read_text())
assert source == expected
compiler = call(['rustc', '+nightly', '-Vv'])
assert 'commit-hash: 1d81eb4ad9cd207e3e638bd32b17ec4fce8412a6' in compiler
pins = {
    'native_combined_r4/precommit_quality_binding_r1.json': 'b51212bcf6e91fd668814db3245b5f4c47d91674d46c548770481e93d8fd4ea5',
    'native_combined_r4/summary_r1.json': 'cf8e43f6d484f2a6275ae958f7293d63ffe7d57b8a1b49f1b1e881ac9087d46f',
    'independent_native_r1/review.json': 'a5de15531da5c9e39acf948d42fc2a89781130e38cc3327f95fd1252dffef56c',
}
for path, sha in pins.items():
    assert hashlib.sha256((area / path).read_bytes()).hexdigest() == sha
receipt = {
    'status': 'PASS_MAIN_POST_FMT_SAME_INPUT_AS_ACTUAL_NATIVE_FMT_THEN_ROOT_CLIPPY',
    'source_count': len(source['files']),
    'source_manifest_sha256': source['source_manifest_sha256'],
    'actual_main_fmt': 'cargo +nightly fmt --all，实际exit0；不是Mac根Clippy',
    'quality_reuse': 'Orin r2实际fmt后默认与real-hw根Clippy exit0；输入全量一致，未重跑，不称新鲜单轮全过',
    'compiler_raw': compiler,
    'pins': pins,
    'children': children,
    'limits': '未做新硬件、正式安装、部署或推送；完整workspace和RT/H2未重测',
}
with (area / 'root_main_quality_binding_r1.json').open('x') as output:
    json.dump(receipt, output, ensure_ascii=False, indent=2)
    output.write('\n')
print(json.dumps({k: receipt[k] for k in ('status', 'source_count', 'source_manifest_sha256')}, ensure_ascii=False))
