import datetime
import hashlib
import json
import re
from pathlib import Path

MAIN = Path('/Users/loosqk/repo/rust/robot-system')
BASE = MAIN / 'target/absolute_write_integration_2026-10-08'
OUT = BASE / 'independent_native_r1'
EXPECTED = BASE / 'native-r3/expected_source.json'
FROZEN_LOCAL = Path('/Users/loosqk/.codex/worktrees/feetech-absolute-write/robot-system/target/absolute_write/freeze_r1')


def read(path):
    return json.loads(path.read_text())


def ref(path):
    data = path.read_bytes()
    return {'path': str(path), 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()}


expected = read(EXPECTED)
assert expected == read(BASE / 'native-r2/expected_source.json') == read(FROZEN_LOCAL / 'expected_source_r1.json')
assert len(expected['files']) == 596
assert expected['source_manifest_sha256'] == hashlib.sha256(json.dumps(expected['files'], sort_keys=True, separators=(',', ':')).encode()).hexdigest() == 'bfe2318fd0bbac6e5f3c34766237ceca634f72331091053b7d2450e5b0ee0f40'
roster = read(BASE / 'native-r3/test_roster.json')
assert roster == read(BASE / 'native-r2/test_roster.json') == read(FROZEN_LOCAL / 'test_roster_r1.json')
matrices = []
source_windows = []
results = []
owner_facts = []
for batch, count, final_status, terminal_exit in [('native-r2', 9, 'FAIL', 1), ('native-r3', 10, 'PASS', 0)]:
    directory = BASE / batch
    qa = directory / 'orin-download/qa'
    result = read(qa / 'result.json')
    results.append(result)
    assert result['status'] == final_status
    assert result['deployable'] is False and result['interrupted_signal'] is None
    assert result['compiler_window'] == result['source_window'] == 'PASS'
    assert result['origin']['native_git_head'] is None
    completions = list(qa.glob('*/completion.json'))
    assert len(completions) == len(result['receipts']) == count
    receipts = {Path(row['path']).parent.name: row for row in result['receipts']}
    rows = []
    for path in completions:
        row = read(path)
        assert ref(path)['sha256'] == receipts[row['name']]['sha256']
        assert row['exit_code'] == 0 and row['reaped']
        assert row['signals'] == [] and row['exec_gate_released']
        assert not row['budget_exceeded']
        assert row['session_residual_before_cleanup'] == row['session_residual_after_cleanup'] == []
        assert row['started_monotonic_ns'] < row['ended_monotonic_ns'] <= row['deadline_monotonic_ns']
        launch = read(path.parent / 'launch.json')
        assert launch['pid'] == row['pid'] and launch['argv'] == row['argv'] and launch['cwd'] == row['cwd']
        for channel in ['stdout', 'stderr']:
            actual = ref(path.parent / (channel + '.log'))
            assert actual['bytes'] == row[channel + '_bytes'] and actual['sha256'] == row[channel + '_sha256']
        assert row['argv'][0] in ['cargo', 'rustc']
        rows.append({'name': row['name'], 'pid': row['pid'], 'argv': row['argv'], 'exit_code': row['exit_code'], 'natural_reap': True, 'source_before': ref(qa / (row['name'] + '_source_before.json')), 'source_after': ref(qa / (row['name'] + '_source_after.json')), 'completion': ref(path), 'stdout': ref(path.parent / 'stdout.log'), 'stderr': ref(path.parent / 'stderr.log'), 'started_ns': row['started_monotonic_ns'], 'ended_ns': row['ended_monotonic_ns']})
    rows.sort(key=lambda row: row['started_ns'])
    assert len({row['pid'] for row in rows}) == count
    for first, second in zip(rows, rows[1:]):
        assert first['ended_ns'] <= second['started_ns']
    matrices.append({'batch': batch, 'commands': rows})
    windows = list(qa.glob('*source*.json'))
    assert len(windows) == count * 2 + 2
    for path in windows:
        assert read(path) == expected
        source_windows.append(ref(path))
    assert (qa / 'rustc_before/stdout.log').read_bytes() == (qa / 'rustc_after/stdout.log').read_bytes()
    assert (qa / 'cargo_before/stdout.log').read_bytes() == (qa / 'cargo_after/stdout.log').read_bytes()
    raw = (qa / 'rustc_before/stdout.log').read_text()
    assert 'commit-hash: 1d81eb4ad9cd207e3e638bd32b17ec4fce8412a6' in raw
    assert 'host: aarch64-unknown-linux-gnu' in raw
    owner = read(directory / 'tool_owner_wait.json')
    terminal = owner['actual_waits'][-1] if batch == 'native-r2' else owner['actual_terminal_wait']
    assert terminal['exit_code'] == terminal_exit
    reported = json.loads(terminal['output'])
    assert reported['phase'] == 'REAPED' and reported['reaped'] and reported['wait_returncode'] == terminal_exit
    assert reported['owner_sent_signals'] == [] and reported['errors'] == []
    owner_facts.append({'batch': batch, 'session': owner['initial']['session_id'], 'owner_pid': reported['owner_pid'], 'SSH_pid': reported['pid'], 'actual_owner_wait_exit': terminal_exit, 'remote_state': reported['remote_state'], 'fact': '自有回收；NOT_VERIFIED不是现场正式健康', 'ref': ref(directory / 'tool_owner_wait.json')})
assert len(source_windows) == 42
assert sum(len(matrix['commands']) for matrix in matrices) == 19
r2 = BASE / 'native-r2/orin-download/qa'
r3 = BASE / 'native-r3/orin-download/qa'
assert (r2 / 'rustc_before/stdout.log').read_bytes() == (r3 / 'rustc_before/stdout.log').read_bytes()
assert (r2 / 'cargo_before/stdout.log').read_bytes() == (r3 / 'cargo_before/stdout.log').read_bytes()
assert [row['name'] for row in matrices[0]['commands']][2:5] == ['fmt', 'clippy_default', 'clippy_real_hw']
for name in ['clippy_default', 'clippy_real_hw']:
    argv = read(r2 / name / 'completion.json')['argv']
    assert '--all' in argv and '--all-targets' in argv and '-D' in argv and 'warnings' in argv
    assert '-p' not in argv


def listed(qa, name, names):
    text = (qa / name / 'stdout.log').read_text()
    actual = re.findall(r'^(.+): test$', text, re.MULTILINE)
    assert len(actual) == len(set(actual)) == len(names)
    assert sorted(actual) == sorted(names)
    assert re.search(rf'^{len(names)} tests, 0 benchmarks$', text, re.MULTILINE)


def ran(qa, name, names):
    text = (qa / name / 'stdout.log').read_text()
    actual = re.findall(r'^test (.+) \.\.\. (\S+)$', text, re.MULTILINE)
    assert len(actual) == len({name for name, _ in actual}) == len(names)
    assert sorted(name for name, _ in actual) == sorted(names)
    assert all(status == 'ok' for _, status in actual)
    assert re.search(rf'^test result: ok\. {len(names)} passed; 0 failed; 0 ignored; 0 measured; 0 filtered out;', text, re.MULTILINE)


listed(r2, 'feetech_default_list', roster['lib_default'])
ran(r2, 'feetech_default', roster['lib_default'])
listed(r3, 'feetech_real_hw_list', roster['lib_real_hw'])
ran(r3, 'feetech_real_hw', roster['lib_real_hw'])
qualified = {'lib:' + name for name in roster['lib_default']}
for name, names in roster['integration'].items():
    listed(r3, name + '_list', names)
    ran(r3, name, names)
    qualified.update(name + ':' + entry for entry in names)
assert len(qualified) == 217 and roster['lib_default'] == roster['lib_real_hw']
assert len(set(roster['new_method_subset'])) == 29
negatives = []
for batch, qa, name in [('r2', r2, 'feetech_default'), ('r3', r3, 'feetech_real_hw')]:
    text = (qa / name / 'stderr.log').read_text()
    matches = re.findall(r'^分配负控：pid=(\d+)，status=(signal: 6 \(SIGABRT\)(?: \(core dumped\))?)，已自然wait/reap，stdout=(\d+)B，stderr=(\d+)B：memory allocation of 8 bytes failed$', text, re.MULTILINE)
    assert len(matches) == 1
    pid, status, stdout_bytes, stderr_bytes = matches[0]
    assert int(pid) > 0 and int(stderr_bytes) > 0
    negatives.append({'batch': batch, 'pid': int(pid), 'status': status, 'stdout_bytes': int(stdout_bytes), 'stderr_bytes': int(stderr_bytes), 'signal': 6, 'natural_wait_reap_recorded_by_test': True, 'raw_ref': ref(qa / name / 'stderr.log'), 'nested_raw_boundary': '合并stderr保真实完成行与8B事实；子stdout/完整stderr未作为独立文件导出，不是新Rust方法。core dumped仅状态显示，不证明core文件。'})
assert results[0]['error'] == "ValueError('feetech_default 负控实际状态不同')"
assert 'status == \'signal: 6 (SIGABRT)\'' in (BASE / 'native-r2/run_absolute.py').read_text()
assert "re.fullmatch(r'signal: 6 \\(SIGABRT\\)( \\(core dumped\\))?', status)" in (BASE / 'native-r3/run_absolute.py').read_text()
facts = read(BASE / 'native-r2/actual_quality_default200_facts_r1.json')
assert facts['status'] == 'R2_BATCH_FAIL_PRESERVED_WITH_ACTUAL_QUALITY_AND_DEFAULT200_PASS'
assert facts['original_result']['sha256'] == ref(r2 / 'result.json')['sha256']
report = {
    'schema': 'absolute_write_independent_native_review_r1',
    'status': 'PASS_SCOPED_COMBINED_R2_R3_SOFTWARE_R2_BATCH_FAIL_PRESERVED_PENDING_MAIN_BINDING',
    'created_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'source': {'count': 596, 'aggregate': expected['source_manifest_sha256'], 'exact_windows': len(source_windows), 'expected_ref': ref(EXPECTED), 'native_git_head': None, 'kind': 'exported snapshot'},
    'compiler': {'commit_hash': '1d81eb4ad9cd207e3e638bd32b17ec4fce8412a6', 'host': 'aarch64-unknown-linux-gnu', 'all_batch_rustc_cargo_before_after_exact': True, 'new_rustup_update': False},
    'quality': {'r2_fmt_then_two_root_clippy': 'actual_exit0', 'r2_default_lib': 200, 'r3_real_hw_lib': 200, 'same_lib_methods_counted_once': True, 'new_subset': 29, 'integration': {'comm_fault_transport': 12, 'abort_diagnostics': 5}, 'distinct_suite_qualified_methods': len(qualified), 'ignored': 0, 'single_batch_all_pass': False},
    'natural_reap': {'direct_native_commands': 19, 'all_launch_completion_output_refs_checked': True, 'signals': [], 'all_actual_exit0_budget_ok_no_session_residual': True, 'local_run_owners': owner_facts},
    'allocator_negatives': negatives,
    'r2_history': {'raw_result_ref': ref(r2 / 'result.json'), 'status': 'FAIL', 'actual_error': results[0]['error'], 'reason': '实际200方法及负控已通过；严格解析原先不接受Linux额外core dumped显示，r3仅显式optional该尾缀，signal6/8B/wait等门不变。', 'separate_facts_ref': ref(BASE / 'native-r2/actual_quality_default200_facts_r1.json')},
    'r3_raw_result_ref': ref(r3 / 'result.json'),
    'roster_ref': ref(BASE / 'native-r3/test_roster.json'),
    'blockers': [],
    'scope': ['仅同源Orin软件组件质量与测试；不是单轮全过或完整workspace测试/release。', '本审无Cargo/SSH/UART/源码修改；原件实际argv仅编译器/Cargo软件门，无新现场/固件版本/动作/正式健康/安装或部署宣称。', '本轮零UART不覆盖旧硬件FAIL；D15 OPEN/DEFERRED、deployable=false保持。main整合与提交前质量另绑定。'],
    'detail_matrix_ref': ref(OUT / 'command_matrix.json') if (OUT / 'command_matrix.json').exists() else None,
}
(OUT / 'command_matrix.json').write_text(json.dumps({'commands': matrices, 'source_windows': source_windows}, ensure_ascii=False, indent=2) + '\n')
report['detail_matrix_ref'] = ref(OUT / 'command_matrix.json')
(OUT / 'review.json').write_text(json.dumps(report, ensure_ascii=False, indent=2) + '\n')
(OUT / 'review.md').write_text('爸爸，Orin两批同源软件独核PASS，r2原批次FAIL保留。r2实际fmt→两根Clippy→default200均exit0；r3完成同名real-hw200及12+5 integration，去重217不同suite方法、0ignored，29新为子集。\n\n19实际原生命令launch/completion/日志逐核，均自然exit0/reap、未超预算、无session残留；42源码窗口同596/bfe231，nightly1d81与Cargo首尾及跨批一致。两个真实8B负控PID515272/516138由原stderr记录wait/SIGABRT；core dumped只是状态显示。r2严格解析误拒原因及原exit1 owner保留，不称单轮全过。\n\n本审未重跑Cargo/SSH/UART。无新现场、固件读回、动作、正式健康或部署声明；main质量绑定另验，旧硬件FAIL/D15 OPEN_DEFERRED/deployable=false不变。\n')
index = {'schema': 'absolute_write_independent_native_review_index_r1', 'files': [ref(OUT / name) for name in ['review.json', 'review.md', 'command_matrix.json', 'verify_and_write.py']]}
(OUT / 'index.json').write_text(json.dumps(index, ensure_ascii=False, indent=2) + '\n')
print(json.dumps({'review': ref(OUT / 'review.json'), 'md': ref(OUT / 'review.md'), 'index': ref(OUT / 'index.json'), 'methods': len(qualified), 'source_windows': len(source_windows)}, ensure_ascii=False))
