"""原r2 FAIL保持；只读闭合其真实200和质量门，再准备剩余r3门，不执行SSH/Cargo。"""
import ast
import hashlib
import importlib.util
import json
import re
import shutil
from pathlib import Path

AREA = Path('/Users/loosqk/repo/rust/robot-system/target/absolute_write_integration_2026-10-08')
OLD = AREA / 'native-r2'
RAW = OLD / 'orin-download/qa'
OUT = AREA / 'native-r3'
OUT.mkdir()
BASE2 = '/home/loosqk/robot-checks/feetech-absolute-write-20261008-r2'
BASE3 = '/home/loosqk/robot-checks/feetech-absolute-write-20261008-r3'


def pin(p):
    data = p.read_bytes()
    return {'path': str(p), 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()}


def save(p, value):
    with p.open('x') as f:
        json.dump(value, f, ensure_ascii=False, indent=2)
        f.write('\n')


spec = importlib.util.spec_from_file_location('a', OLD / 'artifacts.py')
a = importlib.util.module_from_spec(spec)
spec.loader.exec_module(a)
expected = json.loads((OLD / 'expected_source.json').read_text())
roster = json.loads((OLD / 'test_roster.json').read_text())
result = json.loads((RAW / 'result.json').read_text())
assert result['status'] == 'FAIL' and result['error'] == "ValueError('feetech_default 负控实际状态不同')"
assert result['source_window'] == result['compiler_window'] == 'PASS'
assert len(result['receipts']) == 9
rows = []
for ref in result['receipts']:
    local = RAW / Path(ref['path']).relative_to(Path(BASE2) / 'qa')
    assert pin(local)['sha256'] == ref['sha256']
    row = json.loads(local.read_text())
    assert row['exit_code'] == 0 and row['reaped'] and not row.get('runner_error')
    assert not row['budget_exceeded'] and not row['signals']
    assert not row['session_residual_before_cleanup'] and not row['session_residual_after_cleanup']
    for channel in ['stdout', 'stderr']:
        file = RAW / Path(row[channel]).relative_to(Path(BASE2) / 'qa')
        assert pin(file)['bytes'] == row[channel + '_bytes'] and pin(file)['sha256'] == row[channel + '_sha256']
    rows.append(row)
source_windows = list(RAW.glob('*source*.json'))
assert len(source_windows) == 20
assert all(json.loads(p.read_text()) == expected for p in source_windows)
before = (RAW / 'rustc_before/stdout.log').read_text()
after = (RAW / 'rustc_after/stdout.log').read_text()
assert before == after
compiler = a.parse_rustc_identity(before)
assert compiler['commit_hash'] == '1d81eb4ad9cd207e3e638bd32b17ec4fce8412a6'
assert (RAW / 'cargo_before/stdout.log').read_bytes() == (RAW / 'cargo_after/stdout.log').read_bytes()
names = re.findall(r'^test (.+?) \.\.\. ok$', (RAW / 'feetech_default/stdout.log').read_text(), re.M)
assert len(names) == len(set(names)) == 200 and set(names) == set(roster['lib_default'])
assert re.search(r'^test result: ok\. 200 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out;', (RAW / 'feetech_default/stdout.log').read_text(), re.M)
negative_raw = (RAW / 'feetech_default/stderr.log').read_text()
matches = re.findall(r'^分配负控：pid=(\d+)，status=([^\n]+?)，已自然wait/reap，stdout=(\d+)B，stderr=(\d+)B：memory allocation of 8 bytes failed$', negative_raw, re.M)
assert len(matches) == 1
pid, status, stdout_bytes, stderr_bytes = matches[0]
signal_match = re.fullmatch(r'signal: (6) \((SIGABRT)\)( \(core dumped\))?', status)
assert signal_match is not None and int(pid) > 0 and int(stderr_bytes) > 0
assert [r['name'] for r in rows] == ['rustc_before', 'cargo_before', 'fmt', 'clippy_default', 'clippy_real_hw', 'feetech_default_list', 'feetech_default', 'rustc_after', 'cargo_after']
assert rows[2]['ended_monotonic_ns'] < rows[3]['started_monotonic_ns'] < rows[4]['started_monotonic_ns']
facts = {'status': 'R2_BATCH_FAIL_PRESERVED_WITH_ACTUAL_QUALITY_AND_DEFAULT200_PASS', 'original_result': pin(RAW / 'result.json'), 'compiler': compiler, 'source_count': 596, 'source_aggregate': expected['source_manifest_sha256'], 'owned_native_commands': 9, 'all_actual_zero_natural_reap_no_residual': True, 'source_windows': [pin(p) for p in sorted(source_windows)], 'actual_quality': ['fmt0', 'root_clippy_default0', 'root_clippy_real_hw0'], 'actual_test': {'lib_default_exact_names': names, 'passed': 200, 'failed': 0, 'ignored': 0, 'negative_child_pid': int(pid), 'negative_raw_status': status, 'signal': 6, 'core_dumped_display_marker': True, 'allocation_negative_bytes': 8, 'raw_stdout_bytes': int(stdout_bytes), 'raw_stderr_bytes': int(stderr_bytes), 'actual_wait_by_test_and_empty_native_session': True}, 'reason': '负控真实SIGABRT6+8B+wait已满足；仅Linux固定(core dumped)显示后缀被r2 Display全等误拒', 'NOT_RUN': ['feetech_real_hw_list', 'feetech_real_hw', 'comm_fault_transport_list', 'comm_fault_transport', 'abort_diagnostics_list', 'abort_diagnostics'], 'raw_not_rewritten': True}
save(OLD / 'actual_quality_default200_facts_r1.json', facts)

for name in ['artifacts.py', 'natural_runner.py', 'host_owner.py', 'expected_source.json', 'source_export.json', 'source-inputs.tar.gz', 'test_roster.json', 'candidate_manifest_r1.json', 'identity_read.sh']:
    shutil.copy2(OLD / name, OUT / name)
    assert pin(OLD / name)['sha256'] == pin(OUT / name)['sha256']
for name in ['receive_source.py', 'create_remote.sh']:
    code = (OLD / name).read_text().replace(BASE2, BASE3)
    with (OUT / name).open('x') as f:
        f.write(code)
code = (OLD / 'run_absolute.py').read_text().replace(BASE2, BASE3).replace('FEETECH_ABSOLUTE_WRITE_NATIVE_QA_R2', 'FEETECH_ABSOLUTE_WRITE_NATIVE_QA_R3_REMAINING_ONLY')
code = code.replace("status == 'signal: 6 (SIGABRT)'", "re.fullmatch(r'signal: 6 \\(SIGABRT\\)( \\(core dumped\\))?', status) is not None")
code = code.replace("'raw_status': status, 'signal': 6", "'raw_status': status, 'core_dumped_display_marker': status.endswith(' (core dumped)'), 'signal': 6")
begin = code.index("    step('fmt',")
end = code.index("    real = default +", begin)
code = code[:begin]+"    base = ['cargo', '+nightly', 'test', '--locked', '-p', 'robot-adapter-feetech']\n    default = base + ['--lib']\n"+code[end:]
code = code.replace("scope': 'fmt/根默认与real-hw Clippy/两完整200 lib/12与5 integration；217不同suite方法，非完整workspace/release/hardware'", "scope': '仅r2未执行real-hw200/12与5 integration；quality/default200引用同596同1d81的r2真实原件，非单轮全过/完整workspace/release/hardware'")
code = code.replace("'lib_default': 200, 'lib_real_hw_same_methods': 200", "'lib_default_r2_prior_actual_pass': 200, 'lib_real_hw_r3': 200")
ast.parse(code)
with (OUT / 'run_absolute.py').open('x') as f:
    f.write(code)
pure = [n for n in ast.parse(code).body if isinstance(n, ast.FunctionDef) and n.name in {'list_blocks', 'run_blocks'}]
namespace = {'re': re, 'require': lambda value, message: None if value else (_ for _ in []).throw(ValueError(message))}
exec(compile(ast.Module(body=pure, type_ignores=[]), '<pure-parser>', 'exec'), namespace)
got = namespace['run_blocks']((RAW / 'feetech_default/stdout.log').read_text())
assert len(got) == 1 and {m['name'] for m in got[0]['methods']} == set(roster['lib_default'])
for good in ['signal: 6 (SIGABRT)', 'signal: 6 (SIGABRT) (core dumped)']:
    assert re.fullmatch(r'signal: 6 \(SIGABRT\)( \(core dumped\))?', good)
for bad in ['signal: 9 (SIGKILL)', 'signal: 6 (SIGABRT) unknown', 'signal: 6 (SIGABRT) (core dumped) extra', 'signal: 7 (SIGABRT)', 'exit status: 0']:
    assert not re.fullmatch(r'signal: 6 \(SIGABRT\)( \(core dumped\))?', bad)
save(OUT / 'parser_preflight.json', {'status': 'PASS_PURE_FIXTURE_EXISTING_R2_RAW_NO_NEW_RUST_EXECUTION', 'fixed_optional_core_dumped_only': True, 'actual_raw': pin(RAW / 'feetech_default/stderr.log'), 'r2_facts': pin(OLD / 'actual_quality_default200_facts_r1.json'), 'signal6_SIGABRT_8B_wait_required_unchanged': True, 'unknown_trailing_or_signal_rejected': True})
hash_names = ['artifacts.py', 'natural_runner.py', 'expected_source.json', 'source_export.json', 'source-inputs.tar.gz', 'test_roster.json', 'candidate_manifest_r1.json', 'receive_source.py', 'run_absolute.py']
launch = 'set -eu\nexport PATH=/home/loosqk/.cargo/bin:/home/loosqk/.local/bin:$PATH\nexport CARGO_HOME=/home/loosqk/robot-checks/viz-orin-a6957cc-20260930-r1/cargo-home\nexport CARGO_NET_OFFLINE=true\nexport RUSTUP_AUTO_INSTALL=0\nexport PYTHONDONTWRITEBYTECODE=1\ncd ' + BASE3 + '/bootstrap\nsha256sum -c - <<\'SHA_INPUTS\'\n'
launch += '\n'.join(pin(OUT / name)['sha256'] + '  ' + name for name in hash_names)
launch += '\nSHA_INPUTS\nuv run --no-project python receive_source.py\nexec taskset -c 0-3 uv run --no-project python run_absolute.py\n'
with (OUT / 'launch_absolute.sh').open('x') as f:
    f.write(launch)
save(OUT / 'execution_plan.json', {'status': 'PREPARED_NOT_RUN_ROOT_APPROVED_R3_REMAINING_ONLY', 'remote_base': BASE3, 'prior_original_batch': pin(RAW / 'result.json'), 'prior_actual_facts': pin(OLD / 'actual_quality_default200_facts_r1.json'), 'candidate_manifest': pin(OUT / 'candidate_manifest_r1.json'), 'source': pin(OUT / 'expected_source.json'), 'parser_preflight': pin(OUT / 'parser_preflight.json'), 'runner': pin(OUT / 'run_absolute.py'), 'commands': ['rustc_before', 'cargo_before', 'feetech_real_hw_list', 'feetech_real_hw', 'comm_fault_transport_list', 'comm_fault_transport', 'abort_diagnostics_list', 'abort_diagnostics', 'rustc_after', 'cargo_after'], 'budgets_seconds': {'metadata_each': 60, 'list_or_run_each': 900}, 'planned_commands': 10, 'planned_source_windows': 22, 'source_count': 596, 'source_aggregate': expected['source_manifest_sha256'], 'actual_expected_compiler_commit': compiler['commit_hash'], 'no_fmt_Clippy_defaultlib_repeat': True, 'software_acceptance_two_batches_not_single_pass': True, 'native_git_head': None, 'no_hardware_UART_service_release_workspace_install_push': True})
print(json.dumps({'r2_facts': pin(OLD / 'actual_quality_default200_facts_r1.json'), 'r3_plan': pin(OUT / 'execution_plan.json'), 'r3_helper': pin(OUT / 'run_absolute.py'), 'commands': 10, 'source_windows': 22, 'r2_status': 'ORIGINAL_FAIL_PRESERVED'}, ensure_ascii=False))
