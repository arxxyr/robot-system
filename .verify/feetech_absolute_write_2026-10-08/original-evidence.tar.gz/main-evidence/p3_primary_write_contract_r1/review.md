爸爸，已保存一手材料确认两种写法副作用不同；**“Mode1独写46/47前必须将旧位置/时间清零”没有被原件确立**，也未证明任意旧值下等价。

| 原件 | 能支持的具体合同 |
|---|---|
| [官表2.2/2.3](/Users/loosqk/repo/rust/robot-system/target/feetech_firmware_contract_2026-10-08/web/official-sms-sts-memory-table.md:51)，51/63–66行 | Mode1是恒速；41=ACC一字节、42/43=目标位置、46/47=可读写运行速度两字节。46-only不更新ACC或42–45。 |
| [官表65行](/Users/loosqk/repo/rust/robot-system/target/feetech_firmware_contract_2026-10-08/web/official-sms-sts-memory-table.md:65)，[SDK头34行](/Users/loosqk/repo/rust/robot-system/target/feetech_firmware_contract_2026-10-08/web/ftservo_linux--src--SMS_STS.h:34) | 厂家44/45是PWM开环速度，仅说明在PWM开环模式生效、初始1000；SDK沿用GOAL_TIME名称，不能直接视作当前“目标时间”。 |
| [Linux SDK](/Users/loosqk/repo/rust/robot-system/target/feetech_firmware_contract_2026-10-08/web/ftservo_linux--src--SMS_STS.cpp:79)，79–96/104–116行；[Python SDK](/Users/loosqk/repo/rust/robot-system/target/feetech_firmware_contract_2026-10-08/web/ftservo_python--scservo_sdk--sms_sts.py:104)，104–107行 | 恒速接口从41连写7B：`[ACC,0,0,0,0,speedLo,speedHi]`，修改ACC并将42/43、44/45写0。 |

SDK的零值是该接口输出事实，不能推出46-only的强制预清零条款；官表也未明确保证残留目标位置对Mode1毫无影响。P3若选择46-only，应宣称独立字段写合同；SDK等价或额外清零写需要另有依据。

身份：官表response的`version=181`与mdcontent逐字吻合（文档版本，非现场固件）；Linux commit `06fd3356`、Python `cbcfa646`原件bytes/SHA同下载清单。未读现场FW、未联网设备/下发UART/改代码；SDK例子不作为现场固件证明。
