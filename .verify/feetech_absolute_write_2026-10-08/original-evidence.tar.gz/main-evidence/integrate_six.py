"""root 验收 Orin 后精确整合六源，备份旧值，失败时恢复。"""
import importlib.util
import json
import os
import stat
import subprocess
from pathlib import Path

root = Path('/Users/loosqk/repo/rust/robot-system')
candidate = Path('/Users/loosqk/.codex/worktrees/feetech-absolute-write/robot-system')
area = root / 'target/absolute_write_integration_2026-10-08'
spec = importlib.util.spec_from_file_location('artifact_helpers', root / 'scripts/post_e_h2_artifacts.py')
a = importlib.util.module_from_spec(spec)
spec.loader.exec_module(a)
manifest_path = candidate / 'target/absolute_write/freeze_r1/candidate_manifest_r1.json'
assert a.sha256(manifest_path) == '83a068bed6f05d97dd9a62fe558b932f6c7dc875915180c0d04b24548fd2638d'
manifest = json.loads(manifest_path.read_text())
expected = a.read_pinned_json(manifest['expected_source'])
approval = json.loads((area / 'root_native_acceptance_r1.json').read_text())
assert approval['status'] == 'PASS_SCOPED_SOFTWARE_APPROVED_FOR_MAIN_INTEGRATION'
assert approval['source_manifest_sha256'] == expected['source_manifest_sha256']
children = []

def git(*args):
    child = subprocess.Popen(['git', *args], cwd=root, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    out, err = child.communicate()
    children.append({'argv': ['git', *args], 'pid': child.pid,
                     'exit_code': child.returncode, 'actual_wait_reap': True})
    if child.returncode:
        raise RuntimeError(err.decode())
    return out.decode()

def snapshot():
    names = git('ls-files', '-z', '--cached', '--others', '--exclude-standard').rstrip('\0').split('\0')
    return a.snapshot_source(root, names)

assert git('rev-parse', 'HEAD').strip() == manifest['baseline_main_actual_git_head']
assert git('status', '--porcelain=v1', '--untracked-files=all') == ''
before = snapshot()
assert before['source_manifest_sha256'] == manifest['baseline_source_aggregate']
backup = area / 'main_backup_r1'
backup.mkdir()
payloads = {}
old = {}
for name, row in manifest['changed_sources'].items():
    target = root / name
    source = candidate / name
    assert not target.is_symlink() and not source.is_symlink()
    assert before['files'][name] == row['old']
    assert source.stat().st_size == row['new']['bytes'] and a.sha256(source) == row['new']['sha256']
    assert bool(source.stat().st_mode & stat.S_IXUSR) == row['new']['executable']
    old[name] = (target.read_bytes(), stat.S_IMODE(target.stat().st_mode))
    payloads[name] = (source.read_bytes(), stat.S_IMODE(source.stat().st_mode))
    saved = backup / name
    saved.parent.mkdir(parents=True, exist_ok=True)
    saved.write_bytes(old[name][0])
    saved.chmod(old[name][1])

def replace(path, data, mode):
    temp = path.with_name(path.name + '.absolute_integrate_tmp')
    with temp.open('xb') as output:
        output.write(data)
    temp.chmod(mode)
    os.replace(temp, path)

written = []
try:
    for name, value in payloads.items():
        replace(root / name, *value)
        written.append(name)
    after = snapshot()
    assert after == expected
    changed = git('diff', '--name-only').splitlines()
    assert set(changed) == set(payloads)
except BaseException:
    for name in reversed(written):
        replace(root / name, *old[name])
    raise

receipt = {'status': 'PASS_EXACT_SIX_OVERLAYS_SAME_NATIVE_SOURCE',
           'base_head': manifest['baseline_main_actual_git_head'], 'source_count': 596,
           'before': before, 'after': after, 'changed_sources': written,
           'root_acceptance_sha256': a.sha256(area / 'root_native_acceptance_r1.json'),
           'git_children': children, 'limits': '仅源码整合，未运行新测试或硬件、未安装、未推送'}
with (area / 'root_integration_r1.json').open('x') as output:
    json.dump(receipt, output, ensure_ascii=False, indent=2)
    output.write('\n')
print(json.dumps({key: receipt[key] for key in ('status', 'source_count', 'changed_sources')}, ensure_ascii=False))
