# 串口来源绝对期限组件：Orin 软件验收范围

爸爸，本轮只验证已冻结的串口组件及其必要回归，不接触串口或电机。

主树基线为 `66d39b8af6a61cc778371239447d5f8edd4d792d`，596 个构建输入的聚合为 `b919cd320dd81693ae49612dcd0778b98e6ee97191d2344bdf87cefd69c2eed0`。候选目录的 Git HEAD 仍为 e6d6d11；其中已导入主树十一项 P1 源码，不能将目录 HEAD 冒作主树版本。

只叠加本轮冻结的六项 Feetech 源码：transport、bus、error、diagnostic、lib、post_e_transport_acceptance。独立静态复核通过后才启动 Orin 验收。其余主树输入须逐项一致；运行前后记录实际浮动 nightly 的 rustc/cargo 身份，复用现有已更新工具链，不记录为又一次 rustup update。

验收顺序为 fmt、根 all-target Clippy、根 real-hw all-target Clippy、Feetech 完整默认库、完整 real-hw 库、通信租约与诊断集成测试。真实 allocator 守门必须有效；故意分配的负控以实际 SIGABRT 和回收为正确结果，不能把它计作退出零的子进程。重复 feature 执行及名称过滤子集不累计不同方法数。

使用独立检查目录和既有构建缓存。保留本机 r1–r6、两次 allocator 定位的原结果以及实际已运行但未完成的事实澄清；失败不回填 PASS。每个启动的自有命令自然等待并回收；观察超时不能据此另启重复运行。

本轮不运行完整 workspace、H2 六配方或硬件动作，不修改正式安装、服务、保护文件、USB 配置，也不提交或推送远端。根质量门通过后，root 再整合六源、绑定主树质量证据并执行本地阶段提交。

软件通过仅证明来源期限与调用预算的检查、已知发送进度及租约回收。它不能撤回已发字节，不能承诺内核硬截止，也不证明第三方串口后端内部零分配、轮速为零或物理断电。现场已确认人工断电；头部回程、右轮停止、右 H2 历史失败与 D15 OPEN/DEFERRED、deployable=false 保持。
