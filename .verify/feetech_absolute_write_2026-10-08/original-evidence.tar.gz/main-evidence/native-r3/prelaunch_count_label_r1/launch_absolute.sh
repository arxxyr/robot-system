set -eu
export PATH=/home/loosqk/.cargo/bin:/home/loosqk/.local/bin:$PATH
export CARGO_HOME=/home/loosqk/robot-checks/viz-orin-a6957cc-20260930-r1/cargo-home
export CARGO_NET_OFFLINE=true
export RUSTUP_AUTO_INSTALL=0
export PYTHONDONTWRITEBYTECODE=1
cd /home/loosqk/robot-checks/feetech-absolute-write-20261008-r3/bootstrap
sha256sum -c - <<'SHA_INPUTS'
bd2b3f7bb8527cd9ecec73894171638e9cf378656b89e284a585c3baa37b8731  artifacts.py
dad9bbc9405b8fac4d60d6efe794b36750e6a6f9ce9fdeba3debf7d3e1b9a471  natural_runner.py
8a8dd46bc4e4dec3ee61ae59946a0ec93ea590795de535c5ff6f0b8a5152f3d2  expected_source.json
61512df3368bb90d08baa20725764c7bf3c5ed059cfd15a92cf0827c4ce8e488  source_export.json
a9ee65762cc7215487a6a8654ae4ef647eb18eee81ddb06f19e8ed66a5e57c1e  source-inputs.tar.gz
abf4ed4f073425bc8c6c465964d4bc583e08570d886bdea3e2c29459008a9b1f  test_roster.json
83a068bed6f05d97dd9a62fe558b932f6c7dc875915180c0d04b24548fd2638d  candidate_manifest_r1.json
b4601df5d5dfb293ae58ac9c53de4f9c661b0601beb527722354aadd01608d89  receive_source.py
eba03c99483b2537b67e2dd35f6faf23bd6b24b269c93afb11a7b6dccf824228  run_absolute.py
SHA_INPUTS
uv run --no-project python receive_source.py
exec taskset -c 0-3 uv run --no-project python run_absolute.py
