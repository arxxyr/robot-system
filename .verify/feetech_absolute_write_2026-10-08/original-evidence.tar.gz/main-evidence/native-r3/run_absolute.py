"""Feetech来源期限冻结596的限定原生软件门；无设备/服务/正式安装。"""
import importlib.util
import json
import os
import platform
import re
import signal
import stat
from pathlib import Path
from types import SimpleNamespace

BASE = Path('/home/loosqk/robot-checks/feetech-absolute-write-20261008-r3')
BOOT = BASE / 'bootstrap'
SOURCE = BASE / 'source'
OUT = BASE / 'qa'


def module(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    value = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(value)
    return value


h = module('natural_runner', BOOT / 'natural_runner.py')
a = module('artifacts', BOOT / 'artifacts.py')
require = a.require
require(a.sha256(BOOT / 'natural_runner.py') == 'dad9bbc9405b8fac4d60d6efe794b36750e6a6f9ce9fdeba3debf7d3e1b9a471', '原natural runner不同')
require(a.sha256(BOOT / 'artifacts.py') == 'bd2b3f7bb8527cd9ecec73894171638e9cf378656b89e284a585c3baa37b8731', '原artifact helper不同')
require(a.sha256(BOOT / 'test_roster.json') == 'abf4ed4f073425bc8c6c465964d4bc583e08570d886bdea3e2c29459008a9b1f', '冻结精确方法名单不同')
require(a.sha256(BOOT / 'candidate_manifest_r1.json') == '83a068bed6f05d97dd9a62fe558b932f6c7dc875915180c0d04b24548fd2638d', '冻结六源manifest不同')
expected = a.strict_json((BOOT / 'expected_source.json').read_text())
export = a.strict_json((BOOT / 'source_export.json').read_text())
roster = a.strict_json((BOOT / 'test_roster.json').read_text())
require(len(expected['files']) == 596 and expected['source_manifest_sha256'] == 'bfe2318fd0bbac6e5f3c34766237ceca634f72331091053b7d2450e5b0ee0f40', '输入不是冻结596')
OUT.mkdir()
runner = h.Runner(SimpleNamespace(source=SOURCE, out=OUT, target=Path('/home/loosqk/robot-checks/xlerobot-velocity-foundation-20261008-r7/build')), a)
result = {'schema': 'FEETECH_ABSOLUTE_WRITE_NATIVE_QA_R3_REMAINING_ONLY', 'status': 'FAIL', 'deployable': False, 'origin': export['origin'], 'receipts': [], 'tests': {}, 'scope': '仅r2未执行real-hw200/12与5 integration；quality/default200引用同596同1d81的r2真实原件，非单轮全过/完整workspace/release/hardware', 'new_rustup_update': False, 'floating_nightly': True}


def source(label):
    require(not os.path.lexists(SOURCE / '.git'), '导出目录不能冒称Git checkout')
    names = []
    for root, dirs, files in os.walk(SOURCE, followlinks=False):
        for name in dirs:
            require(not (Path(root) / name).is_symlink(), '源目录含链接')
        for name in files:
            path = Path(root) / name
            require(stat.S_ISREG(path.lstat().st_mode) and not path.is_symlink(), '输入非普通文件')
            names.append(path.relative_to(SOURCE).as_posix())
    value = a.snapshot_source(SOURCE, names)
    h.save(OUT / (label + '.json'), value)
    require(len(names) == 596 and set(names) == set(expected['files']) and value == expected, '596输入bytes/SHA/exec/集合变化')
    return value


def step(name, argv, budget):
    source(name + '_source_before')
    try:
        return runner.command(name, argv, budget)
    finally:
        source(name + '_source_after')

def list_blocks(text):
    blocks = []
    end = 0
    for match in re.finditer('^(\\d+) tests?, (\\d+) benchmarks?\\s*$', text, re.M):
        part = text[end:match.start()]
        names = re.findall('^(.+): test$', part, re.M)
        require(len(names) == len(set(names)) == int(match[1]) and int(match[2]) == 0, '实际list计数/重复/benchmark不同')
        blocks.append(names)
        end = match.end()
    return blocks

def run_blocks(text):
    blocks = []
    end = 0
    pattern = '^test result: ok\\. (\\d+) passed; (\\d+) failed; (\\d+) ignored; (\\d+) measured; (\\d+) filtered out;.*$'
    for match in re.finditer(pattern, text, re.M):
        part = text[end:match.start()]
        rows = re.findall('^test (.+) \\.\\.\\. (ok|ignored(?:,.*)?)$', part, re.M)
        names = [r[0] for r in rows]
        counts = [int(v) for v in match.groups()]
        require(len(names) == len(set(names)) and counts[1] == counts[3] == 0, '实际结果重复/failed/measured不同')
        require(sum((v == 'ok' for _, v in rows)) == counts[0] and sum((v.startswith('ignored') for _, v in rows)) == counts[2], '结果行与计数不同')
        blocks.append({'methods': [{'name': n, 'raw_status': status} for n, status in rows], 'counts': dict(zip(['passed', 'failed', 'ignored', 'measured', 'filtered_out'], counts))})
        end = match.end()
    require(blocks, '没有完整实际测试结果')
    return blocks


def run_list(name, argv, wanted):
    _, row = step(name, argv, 900)
    actual = list_blocks(Path(row['stdout']).read_text())
    require(len(actual) == 1 and len(actual[0]) == len(wanted) and set(actual[0]) == set(wanted), name + ' 精确方法名单不同')
    result['tests'][name] = {'actual_list': actual[0], 'exact_expected_roster': True}


def run_one(name, argv, wanted, require_negative=False):
    _, row = step(name, argv, 900)
    actual = run_blocks(Path(row['stdout']).read_text())
    require(len(actual) == 1 and actual[0]['counts'] == {'passed': len(wanted), 'failed': 0, 'ignored': 0, 'measured': 0, 'filtered_out': 0}, name + ' 数量/ignored不同')
    require({r['name'] for r in actual[0]['methods']} == set(wanted), name + ' 原方法名单不同')
    record = {'actual_suites': actual, 'exact_expected_roster': True}
    if require_negative:
        raw = Path(row['stderr']).read_text()
        matches = re.findall(r'^分配负控：pid=(\d+)，status=([^\n]+?)，已自然wait/reap，stdout=(\d+)B，stderr=(\d+)B：memory allocation of 8 bytes failed$', raw, re.M)
        require(len(matches) == 1, name + ' 缺真实8B分配负控完成输出')
        pid, status, stdout_bytes, stderr_bytes = matches[0]
        require(int(pid) > 0 and re.fullmatch(r'signal: 6 \(SIGABRT\)( \(core dumped\))?', status) is not None and int(stderr_bytes) > 0, name + ' 负控实际状态不同')
        record['allocator_negative_child'] = {'pid': int(pid), 'raw_status': status, 'core_dumped_display_marker': status.endswith(' (core dumped)'), 'signal': 6, 'reaped_by_test_wait_with_output': True, 'stdout_bytes': int(stdout_bytes), 'stderr_bytes': int(stderr_bytes), 'expected_nonzero_signal_termination': True, 'not_an_additional_Rust_method': True, 'raw_completion_in_stderr': True}
    result['tests'][name] = record


before = compiler = cargo = None
old_handlers = {}


def interrupted(signum, frame):
    h.INTERRUPTED = signum


try:
    for sig in (signal.SIGINT, signal.SIGTERM, signal.SIGHUP):
        old_handlers[sig] = signal.signal(sig, interrupted)
    identity = {'hostname': platform.node(), 'arch': platform.machine(), 'uid': os.getuid(), 'gid': os.getgid(), 'boot_id': Path('/proc/sys/kernel/random/boot_id').read_text().strip()}
    require(identity == {'hostname': 'ubuntu', 'arch': 'aarch64', 'uid': 1000, 'gid': 1000, 'boot_id': '6cf7ee3e-a3c5-4c91-80bc-4ca924818b53'}, 'Orin身份不同')
    require(os.environ.get('CARGO_HOME') == '/home/loosqk/robot-checks/viz-orin-a6957cc-20260930-r1/cargo-home' and os.environ.get('CARGO_NET_OFFLINE') == 'true', '既有离线cache不同')
    result['identity'] = identity
    before = source('source_before')
    _, row = step('rustc_before', ['rustc', '+nightly', '-vV'], 60)
    compiler = a.parse_rustc_identity(Path(row['stdout']).read_text())
    require(compiler['commit_hash'] == '1d81eb4ad9cd207e3e638bd32b17ec4fce8412a6', '实际nightly不再1d81')
    _, row = step('cargo_before', ['cargo', '+nightly', '-V'], 60)
    cargo = Path(row['stdout']).read_bytes()
    require(b'-nightly' in cargo, 'Cargo不是nightly')
    base = ['cargo', '+nightly', 'test', '--locked', '-p', 'robot-adapter-feetech']
    default = base + ['--lib']
    real = default + ['--features', 'real-hw']
    run_list('feetech_real_hw_list', real + ['--', '--list'], roster['lib_real_hw'])
    run_one('feetech_real_hw', real + ['--', '--test-threads=1', '--nocapture'], roster['lib_real_hw'], True)
    for test in ['comm_fault_transport', 'abort_diagnostics']:
        argv = base + ['--test', test]
        wanted = roster['integration'][test]
        run_list(test + '_list', argv + ['--', '--list'], wanted)
        run_one(test, argv + ['--', '--test-threads=1', '--nocapture'], wanted)
    result.update(status='PASS', compiler_before=compiler, cargo_before=cargo.decode(), source_count=596, source_aggregate=before['source_manifest_sha256'], count_policy={'lib_default_r2_prior_actual_pass': 200, 'lib_real_hw_r3': 200, 'old_lib': 171, 'new_method_subset': 29, 'integration': [12, 5], 'distinct_suite_methods': 217, 'r3_actual_negative_control_children': 1, 'r2_prior_actual_negative_control_children': 1, 'combined_negative_control_children': 2, 'ignored': 0})
except BaseException as error:
    result['error'] = repr(error)
finally:
    try:
        _, row = step('rustc_after', ['rustc', '+nightly', '-vV'], 60)
        actual_compiler = a.parse_rustc_identity(Path(row['stdout']).read_text())
        require(compiler is not None and actual_compiler == compiler, 'rustc首尾不同或初始缺失')
        _, row = step('cargo_after', ['cargo', '+nightly', '-V'], 60)
        require(cargo is not None and Path(row['stdout']).read_bytes() == cargo, 'Cargo首尾不同或初始缺失')
        result.update(compiler_after=actual_compiler, compiler_window='PASS')
    except BaseException as error:
        result.update(status='FAIL', compiler_window_error=repr(error))
    try:
        require(before is not None and source('source_after') == before, '源码首尾不同或初始缺失')
        result['source_window'] = 'PASS'
    except BaseException as error:
        result.update(status='FAIL', source_window_error=repr(error))
    result['receipts'] = runner.receipts
    result['interrupted_signal'] = h.INTERRUPTED
    h.save(OUT / 'result.json', result)
    for sig, handler in old_handlers.items():
        signal.signal(sig, handler)
print(json.dumps({'status': result['status'], 'error': result.get('error'), 'receipts': len(result['receipts']), 'source_window': result.get('source_window'), 'compiler_window': result.get('compiler_window'), 'completed_test_steps': list(result['tests'])}, ensure_ascii=False), flush=True)
raise SystemExit(0 if result['status'] == 'PASS' else 1)
