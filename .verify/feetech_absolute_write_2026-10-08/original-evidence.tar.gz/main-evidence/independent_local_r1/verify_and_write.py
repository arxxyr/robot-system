import datetime
import hashlib
import json
import re
from pathlib import Path

MAIN = Path('/Users/loosqk/repo/rust/robot-system')
CAND = Path('/Users/loosqk/.codex/worktrees/feetech-absolute-write/robot-system')
FREEZE = CAND / 'target/absolute_write/freeze_r1'
QA = CAND / 'target/absolute_write/local_qa_r7'
OUT = MAIN / 'target/absolute_write_integration_2026-10-08/independent_local_r1'


def read(path):
    return json.loads(path.read_text())


def ref(path):
    data = path.read_bytes()
    return {'path': str(path), 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()}


def check_ref(row):
    actual = ref(Path(row['path']))
    assert all(actual[key] == row[key] for key in ['path', 'bytes', 'sha256']), row['path']


def typed_refs(value):
    if isinstance(value, dict):
        if isinstance(value.get('path'), str) and isinstance(value.get('bytes'), int) and isinstance(value.get('sha256'), str):
            yield value
        for item in value.values():
            yield from typed_refs(item)
    elif isinstance(value, list):
        for item in value:
            yield from typed_refs(item)


manifest = read(FREEZE / 'candidate_manifest_r1.json')
summary = read(FREEZE / 'summary_r1.json')
roster = read(FREEZE / 'test_roster_r1.json')
result = read(QA / 'result.json')
assert ref(FREEZE / 'candidate_manifest_r1.json')['sha256'] == '83a068bed6f05d97dd9a62fe558b932f6c7dc875915180c0d04b24548fd2638d'
assert ref(FREEZE / 'summary_r1.json')['sha256'] == '0c0a67db8546d141e571bb07ab3dca14d38bc2d24342bc5e031b4aa330fd4db4'
assert ref(FREEZE / 'test_roster_r1.json')['sha256'] == 'abf4ed4f073425bc8c6c465964d4bc583e08570d886bdea3e2c29459008a9b1f'
refs = list(typed_refs([manifest, summary, roster]))
for row in refs:
    check_ref(row)
six_before = []
for name, row in manifest['changed_sources'].items():
    path = CAND / name
    actual = ref(path)
    assert actual['bytes'] == row['new']['bytes'] and actual['sha256'] == row['new']['sha256']
    assert bool(path.stat().st_mode & 0o111) == row['new']['executable']
    six_before.append(actual)
assert len(six_before) == 6
expected = read(Path(manifest['expected_source']['path']))
aggregate = hashlib.sha256(json.dumps(expected['files'], sort_keys=True, separators=(',', ':')).encode()).hexdigest()
assert aggregate == expected['source_manifest_sha256'] == manifest['candidate_source_aggregate'] == 'bfe2318fd0bbac6e5f3c34766237ceca634f72331091053b7d2450e5b0ee0f40'
assert len(expected['files']) == 596
for row in manifest['source_windows']:
    assert read(Path(row['path'])) == expected
assert len(manifest['source_windows']) == 11
assert read(QA / 'source_after.json') == expected
commands = result['commands']
assert len(commands) == len({row['pid'] for row in commands}) == 16
for row in commands:
    directory = QA / row['name']
    assert read(directory / 'completion.json') == row
    launch = read(directory / 'launch.json')
    for key, value in launch.items():
        if key != 'reaped':
            assert row[key] == value
    assert not launch['reaped'] and row['reaped']
    assert row['actual_exit'] == 0 and row['signals_sent'] == []
    assert row['started_monotonic_ns'] < row['finished_monotonic_ns']
    for key in ['stdout', 'stderr']:
        check_ref(row[key])
for first, second in zip(commands, commands[1:]):
    assert first['finished_monotonic_ns'] <= second['started_monotonic_ns']
assert [row['name'] for row in commands][3:6] == ['fmt', 'clippy_default', 'clippy_real_hw']
assert (QA / 'rustc_before/stdout.log').read_bytes() == (QA / 'rustc_after/stdout.log').read_bytes()
assert (QA / 'cargo_before/stdout.log').read_bytes() == (QA / 'cargo_after/stdout.log').read_bytes()
assert result['compiler'] == manifest['compiler']
assert result['compiler']['commit_hash'] == '1d81eb4ad9cd207e3e638bd32b17ec4fce8412a6'
assert result['compiler']['host'] == 'aarch64-apple-darwin'
owner = read(QA / 'tool_owner_wait.json')
assert owner['actual_terminal_wait']['exit_code'] == 0
assert read(FREEZE / 'tool_owner_wait.json')['actual_terminal_wait']['exit_code'] == 0


def listed(name):
    text = (QA / name / 'stdout.log').read_text()
    values = re.findall(r'^(.+): test$', text, re.MULTILINE)
    assert len(values) == len(set(values))
    assert re.search(rf'^{len(values)} tests, 0 benchmarks$', text, re.MULTILINE)
    return sorted(values)


def ran(name, expected_names, filtered=0):
    text = (QA / name / 'stdout.log').read_text()
    values = re.findall(r'^test (.+) \.\.\. (\S+)$', text, re.MULTILINE)
    assert len(values) == len({name for name, _ in values})
    assert all(status == 'ok' for _, status in values)
    assert sorted(name for name, _ in values) == sorted(expected_names)
    assert re.search(rf'^test result: ok\. {len(values)} passed; 0 failed; 0 ignored; 0 measured; {filtered} filtered out;', text, re.MULTILINE)
    return sorted(name for name, _ in values)


for field in ['lib_default', 'lib_real_hw', 'absolute_named_subset']:
    assert listed(field + '_list') == sorted(roster[field])
    ran(field, roster[field], 176 if field == 'absolute_named_subset' else 0)
assert sorted(roster['lib_default']) == sorted(roster['lib_real_hw']) and len(roster['lib_default']) == 200
old = read(Path(roster['original_old_roster']['path']))['all_names']['feetech_lib']
assert sorted(old) == sorted(set(roster['lib_default']) - set(roster['new_method_subset'])) and len(old) == 171
assert len(set(roster['new_method_subset'])) == 29
assert set(roster['absolute_named_subset']) <= set(roster['lib_default']) and len(roster['absolute_named_subset']) == 24
assert len(set(roster['absolute_named_subset']) & set(roster['new_method_subset'])) == 21
transport = (CAND / 'crates/robot-adapters/feetech/src/post_e_transport_acceptance.rs').read_text()
new_absolute_names = re.findall(r'#\[test\]\s+fn\s+(\w+)', transport[transport.index('mod absolute {'):])
declared = ['transport::post_e_acceptance::absolute::' + name for name in new_absolute_names]
declared.append('adapter::diagnostic::tests::absolute_error_conversion_and_diagnostic_reason_are_exhaustive')
assert sorted(declared) == sorted(roster['new_method_subset'])
qualified = {'lib:' + name for name in roster['lib_default']}
for field, names in roster['integration'].items():
    ran(field, names)
    qualified.update(field + ':' + name for name in names)
assert len(qualified) == roster['distinct_suite_qualified_methods'] == 217
assert len(roster['integration']['comm_fault_transport']) == 12 and len(roster['integration']['abort_diagnostics']) == 5
guards = ['transport::post_e_acceptance::absolute::absolute_production_hot_core_and_bus_paths_run_under_real_allocator_guard', 'adapter::tests::safety_stop_fast_is_alloc_free', 'adapter::tests::sync_write_by_id_into_is_alloc_free', 'adapter::diagnostic::tests::absolute_error_conversion_and_diagnostic_reason_are_exhaustive']
for name in guards:
    assert name in roster['lib_default']
lib = (CAND / 'crates/robot-adapters/feetech/src/lib.rs').read_text()
assert '#[cfg(test)]\n#[global_allocator]\nstatic TEST_ALLOCATOR: assert_no_alloc::AllocDisabler' in lib
assert 'std::hint::black_box(Box::new(7_u64))' in transport
assert 'let child = child.wait_with_output().unwrap();' in transport
assert 'memory allocation of 8 bytes failed' in transport
assert 'assert_eq!(child.status.signal(), Some(unix_abort_signal()))' in transport
assert 'Some(libc' not in transport
history = []
for name, row in summary['historical_failures_preserved'].items():
    check_ref(row)
    original = read(Path(row['path']))
    history.append({'name': name, 'status': original['status'], 'ref': row})
clarifications = []
for name in ['local_qa_r5', 'local_qa_r6', 'allocator_locate_r1']:
    path = CAND / 'target/absolute_write' / name / 'test_started_clarification.json'
    clarification = read(path)
    for row in typed_refs(clarification):
        check_ref(row)
    clarifications.append(ref(path))
six_after = [ref(Path(row['path'])) for row in six_before]
assert six_before == six_after
root_binding = MAIN / 'target/absolute_write_integration_2026-10-08/root_frozen_verification_r1.json'
review = {
    'schema': 'absolute_write_independent_local_review_r1',
    'status': 'PASS_SCOPED_STATIC_AND_LOCAL_SOFTWARE_NO_BLOCKER_PENDING_ORIN_AND_MAIN_BINDING',
    'created_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'author': '/root/firmware_acceptance',
    'basis': [ref(FREEZE / name) for name in ['candidate_manifest_r1.json', 'summary_r1.json', 'test_roster_r1.json', 'expected_source_r1.json']],
    'root_source_tar_binding_ref_not_repeated': ref(root_binding),
    'source_read_window': {'six_before_after_equal': True, 'six_sources': six_after, 'candidate_count': 596, 'aggregate': aggregate, 'actual_11_source_windows_exact': True},
    'static_incremental_findings': [
        '合法count先记录got，再ClockRegressed→SourceExpired→CallBudgetExpired，最后0/terminalIO/retry；非法count优先保got不变与观测事实。固定原双截止/min及last_io_error保当次IO事实，无fallback/replay/flush。',
        '两碰撞方法已补source/call等号和晚到及完整固定字段；API注释现明确Some probe真实性由调用方保证。',
        '诊断11cause×四progress oracle搬到原adapter私有diagnostic::tests，未公开生产mod；该表guard真实执行，RobotError/小诊断不冒充完整wanted/got保存。',
        '两fixture Mutex首次锁在guard外完成，不改生产lease/算法。MockHandle drain用原capacity空Vec替换，原字节原样取走/内部为空语义保持；replacement分配在捕获阶段，drain本身不是零alloc。',
    ],
    'actual_quality': {'host': result['compiler']['host'], 'compiler': result['compiler']['commit_hash'], 'rustc_and_cargo_before_after_same': True, 'new_rustup_update': False, 'fmt_then_two_Feetech_clippy': 'actual_exit_0', 'root_workspace_clippy_this_local_batch': 'NOT_RUN', 'actual_default_lib': 200, 'actual_real_hw_lib': 200, 'same_lib_names_counted_once': True, 'old_exact_names': 171, 'new_subset': 29, 'absolute_filtered_subset': 24, 'integration': {'comm_fault_transport': 12, 'abort_diagnostics': 5}, 'distinct_suite_qualified_methods': 217, 'ignored': 0},
    'allocator_evidence': {'registered': 'lib.rs cfg(test)唯一AllocDisabler', 'actual_guard_methods_passed_in_both_complete_lib_runs': guards, 'negative': '真实Box(8B)子进程、wait_with_output、SIGABRT和固定stderr断言由通过harness执行；一个方法内样本，不计额外Rust方法。', 'raw_child_boundary': '成功harness捕获内部PID/raw，未--nocapture导出，不能称有每次负控独立PID/stdout/stderr原件。foreign serialport自身分配未证明。'},
    'owned_children': {'direct_r7_children': 16, 'all_completion_launch_log_refs_verified': True, 'all_natural_exit_zero_reap': True, 'signals_sent': [], 'r7_tool_session': owner['initial']['session_id'], 'actual_tool_wait_exit': 0},
    'history_originals': history,
    'test_started_clarifications_separate': clarifications,
    'blockers': [],
    'limits': ['本机scoped软件PASS；Orin/Linux/root Clippy/main整合尚待各自实际绑定。无完整workspace测试/release/正式安装/push。', '零UART按实际直接argv及测试夹具边界；real-hw表示编译feature，不是硬件运行。', '不认证来源/探针/时钟物理同源，不承诺内核原子硬截止、撤回已发字节、pending实际撤销或完整B1。', '旧r1-r6及定位原件不回填；r6的34B是mock日志容量丢失，伴随64B不独立归因；此前lib guard未注册事实保留。', '旧硬件FAIL与人工断电收尾不形成新GO；D15 OPEN/DEFERRED、deployable=false保持。'],
    'result_ref': ref(QA / 'result.json'),
    'tool_wait_ref': ref(QA / 'tool_owner_wait.json'),
    'verified_typed_refs_count': len(refs),
}
(OUT / 'review.json').write_text(json.dumps(review, ensure_ascii=False, indent=2) + '\n')
(OUT / 'review.md').write_text('爸爸，冻结六源静态与本机软件独核PASS，无实质阻断；Orin和主树整合仍待实际绑定。\n\n双截止/四优先级与进度事实正确，诊断测试仍在原私有模块，fixture锁初始化和mock drain容量替换符合限定修复；drain本身会分配。实际fmt后两Feetech Clippy为0；default/real-hw同200名单计一次，29新为子集，另12+5独立integration，共217不同suite方法、0ignored。\n\n唯一lib AllocDisabler已实际覆盖新增guard、诊断表及旧两alloc_free方法；真实8B负控在方法内spawn/wait/SIGABRT断言通过，成功harness未导出每次独立PID/raw。16直接自有child自然exit0/reap，编译器/11输入窗/六源读取首尾一致。\n\n旧FAIL与guard历史不回填；无UART、运行时接入、硬件或部署宣称，D15 OPEN/DEFERRED、deployable=false保持。\n')
index = {'schema': 'absolute_write_independent_local_review_index_r1', 'files': [ref(OUT / name) for name in ['review.json', 'review.md', 'verify_and_write.py']]}
(OUT / 'index.json').write_text(json.dumps(index, ensure_ascii=False, indent=2) + '\n')
print(json.dumps({'review': ref(OUT / 'review.json'), 'md': ref(OUT / 'review.md'), 'index': ref(OUT / 'index.json'), 'actual_distinct_methods': len(qualified), 'direct_children': len(commands)}, ensure_ascii=False))
