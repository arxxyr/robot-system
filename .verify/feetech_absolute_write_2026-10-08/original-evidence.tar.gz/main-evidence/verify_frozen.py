"""核对冻结候选、主树前置和导出；仅写本次核查回执。"""
import hashlib
import importlib.util
import json
import stat
import subprocess
import tarfile
from pathlib import Path, PurePosixPath

root = Path('/Users/loosqk/repo/rust/robot-system')
candidate = Path('/Users/loosqk/.codex/worktrees/feetech-absolute-write/robot-system')
frozen = candidate / 'target/absolute_write/freeze_r1'
area = root / 'target/absolute_write_integration_2026-10-08'
spec = importlib.util.spec_from_file_location('artifact_helpers', root / 'scripts/post_e_h2_artifacts.py')
a = importlib.util.module_from_spec(spec)
spec.loader.exec_module(a)
children = []

def git(cwd, *args):
    child = subprocess.Popen(['git', *args], cwd=cwd, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    out, err = child.communicate()
    children.append({'argv': ['git', *args], 'cwd': str(cwd), 'pid': child.pid,
                     'exit_code': child.returncode, 'actual_wait_reap': True})
    if child.returncode:
        raise RuntimeError(err.decode())
    return out.decode()

def snapshot(cwd):
    names = git(cwd, 'ls-files', '-z', '--cached', '--others', '--exclude-standard').rstrip('\0').split('\0')
    return a.snapshot_source(cwd, names)

manifest_path = frozen / 'candidate_manifest_r1.json'
assert a.sha256(manifest_path) == '83a068bed6f05d97dd9a62fe558b932f6c7dc875915180c0d04b24548fd2638d'
manifest = json.loads(manifest_path.read_text())
expected = a.read_pinned_json(manifest['expected_source'])
assert git(root, 'rev-parse', 'HEAD').strip() == manifest['baseline_main_actual_git_head']
assert git(root, 'status', '--porcelain=v1', '--untracked-files=all') == ''
before = snapshot(root)
assert before['source_manifest_sha256'] == manifest['baseline_source_aggregate']
assert len(before['files']) == len(expected['files']) == 596
assert set(before['files']) == set(expected['files'])
differences = {name for name in before['files'] if before['files'][name] != expected['files'][name]}
assert differences == set(manifest['changed_sources']) and len(differences) == 6
for name, row in manifest['changed_sources'].items():
    assert before['files'][name] == row['old'] and expected['files'][name] == row['new']
assert snapshot(candidate) == expected
summary = json.loads((frozen / 'summary_r1.json').read_text())
export = summary['source_export']
assert a.sha256(Path(export['path'])) == export['sha256']
assert Path(export['path']).stat().st_size == export['bytes']
seen = set()
with tarfile.open(export['path'], 'r:gz') as archive:
    for member in archive:
        name = member.name
        parts = PurePosixPath(name)
        assert member.isfile() and not parts.is_absolute() and '..' not in parts.parts
        assert name not in seen and name in expected['files']
        seen.add(name)
        data = archive.extractfile(member).read()
        row = expected['files'][name]
        assert len(data) == row['bytes'] and hashlib.sha256(data).hexdigest() == row['sha256']
        assert bool(member.mode & stat.S_IXUSR) == row['executable']
assert seen == set(expected['files'])
assert snapshot(root) == before and snapshot(candidate) == expected
assert git(root, 'status', '--porcelain=v1', '--untracked-files=all') == ''
receipt = {'status': 'PASS_FROZEN_MAIN_PRECONDITIONS_AND_EXPORT', 'source_count': 596,
           'baseline_aggregate': before['source_manifest_sha256'],
           'candidate_aggregate': expected['source_manifest_sha256'],
           'exact_changed_sources': sorted(differences), 'export_members': len(seen),
           'manifest_sha256': a.sha256(manifest_path), 'git_children': children,
           'limits': '仅身份/原件核查；不冒称编译、运行时或硬件通过'}
with (area / 'root_frozen_verification_r1.json').open('x') as output:
    json.dump(receipt, output, ensure_ascii=False, indent=2)
    output.write('\n')
print(json.dumps(receipt, ensure_ascii=False))
