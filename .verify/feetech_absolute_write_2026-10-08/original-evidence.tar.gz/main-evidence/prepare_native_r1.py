"""仅本机准备冻结596输入与限定Orin软件门；此脚本不执行SSH/Cargo。"""
import ast
import hashlib
import json
import shutil
import stat
from pathlib import Path

MAIN = Path('/Users/loosqk/repo/rust/robot-system')
WORK = Path('/Users/loosqk/.codex/worktrees/feetech-absolute-write/robot-system')
FROZEN = WORK / 'target/absolute_write/freeze_r1'
OLD = MAIN / 'target/b1_freshness_integration_2026-10-08/native-r5'
OUT = MAIN / 'target/absolute_write_integration_2026-10-08/native-r1'
OUT.mkdir()
BASE = '/home/loosqk/robot-checks/feetech-absolute-write-20261008-r1'


def pin(path):
    data = path.read_bytes()
    return {'path': str(path), 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest(), 'mode': stat.S_IMODE(path.stat().st_mode)}


def save(path, value):
    with path.open('x') as f:
        json.dump(value, f, ensure_ascii=False, indent=2)
        f.write('\n')


for original, name in [(OLD / 'artifacts.py', 'artifacts.py'), (OLD / 'natural_runner.py', 'natural_runner.py'), (OLD / 'host_owner.py', 'host_owner.py'), (FROZEN / 'expected_source_r1.json', 'expected_source.json'), (FROZEN / 'test_roster_r1.json', 'test_roster.json'), (FROZEN / 'source_export_r1.tar.gz', 'source-inputs.tar.gz'), (FROZEN / 'candidate_manifest_r1.json', 'candidate_manifest_r1.json')]:
    shutil.copy2(original, OUT / name)
    assert pin(original)['sha256'] == pin(OUT / name)['sha256']
manifest = json.loads((OUT / 'candidate_manifest_r1.json').read_text())
expected = json.loads((OUT / 'expected_source.json').read_text())
roster = json.loads((OUT / 'test_roster.json').read_text())
assert manifest['candidate_source_aggregate'] == expected['source_manifest_sha256'] == 'bfe2318fd0bbac6e5f3c34766237ceca634f72331091053b7d2450e5b0ee0f40'
assert len(expected['files']) == 596 and len(roster['lib_default']) == 200 and len(roster['new_method_subset']) == 29
meta = {
    'source_manifest': expected,
    'archive': {key: pin(OUT / 'source-inputs.tar.gz')[key] for key in ['sha256', 'bytes']},
    'artifacts_sha256': pin(OUT / 'artifacts.py')['sha256'],
    'files': {name: {**item, 'mode': 0o755 if item['executable'] else 0o644} for name, item in expected['files'].items()},
    'origin': {'main_head_actual': '66d39b8af6a61cc778371239447d5f8edd4d792d', 'main_inputs': '596/b919cd320dd81693ae49612dcd0778b98e6ee97191d2344bdf87cefd69c2eed0', 'candidate_git_head_actual': 'e6d6d111091b29b791bae0375b209692fdf3eed5', 'candidate_origin': 'e6 + main11P1逐项导入 + 本轮六Feetech源', 'native_git_head': None, 'source_kind': 'exported snapshot', 'source_count': 596},
}
save(OUT / 'source_export.json', meta)
for name in ['receive_source.py', 'create_remote.sh']:
    code = (OLD / name).read_text().replace('/home/loosqk/robot-checks/b1-freshness-composite-20261008-r5', BASE)
    with (OUT / name).open('x') as f:
        f.write(code)

# 复用同一个真实自然wait与输入核验helper；新runner只保留本组件精确名单门。
old_code = (OLD / 'run_composite.py').read_text()
parsed = ast.parse(old_code)
pure = [node for node in parsed.body if isinstance(node, ast.FunctionDef) and node.name in {'list_blocks', 'run_blocks'}]
assert len(pure) == 2
parser_code = '\n\n'.join(ast.unparse(node) for node in pure)
code = '''"""Feetech来源期限冻结596的限定原生软件门；无设备/服务/正式安装。"""
import importlib.util
import json
import os
import platform
import re
import signal
import stat
from pathlib import Path
from types import SimpleNamespace

BASE = Path(REMOTE_BASE)
BOOT = BASE / 'bootstrap'
SOURCE = BASE / 'source'
OUT = BASE / 'qa'


def module(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    value = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(value)
    return value


h = module('natural_runner', BOOT / 'natural_runner.py')
a = module('artifacts', BOOT / 'artifacts.py')
require = a.require
require(a.sha256(BOOT / 'natural_runner.py') == RUNNER_SHA, '原natural runner不同')
require(a.sha256(BOOT / 'artifacts.py') == ARTIFACTS_SHA, '原artifact helper不同')
require(a.sha256(BOOT / 'test_roster.json') == ROSTER_SHA, '冻结精确方法名单不同')
require(a.sha256(BOOT / 'candidate_manifest_r1.json') == MANIFEST_SHA, '冻结六源manifest不同')
expected = a.strict_json((BOOT / 'expected_source.json').read_text())
export = a.strict_json((BOOT / 'source_export.json').read_text())
roster = a.strict_json((BOOT / 'test_roster.json').read_text())
require(len(expected['files']) == 596 and expected['source_manifest_sha256'] == SOURCE_AGG, '输入不是冻结596')
OUT.mkdir()
runner = h.Runner(SimpleNamespace(source=SOURCE, out=OUT, target=Path('/home/loosqk/robot-checks/xlerobot-velocity-foundation-20261008-r7/build')), a)
result = {'schema': 'FEETECH_ABSOLUTE_WRITE_NATIVE_QA_R1', 'status': 'FAIL', 'deployable': False, 'origin': export['origin'], 'receipts': [], 'tests': {}, 'scope': 'fmt/根默认与real-hw Clippy/两完整200 lib/12与5 integration；217不同suite方法，非完整workspace/release/hardware', 'new_rustup_update': False, 'floating_nightly': True}


def source(label):
    require(not os.path.lexists(SOURCE / '.git'), '导出目录不能冒称Git checkout')
    names = []
    for root, dirs, files in os.walk(SOURCE, followlinks=False):
        for name in dirs:
            require(not (Path(root) / name).is_symlink(), '源目录含链接')
        for name in files:
            path = Path(root) / name
            require(stat.S_ISREG(path.lstat().st_mode) and not path.is_symlink(), '输入非普通文件')
            names.append(path.relative_to(SOURCE).as_posix())
    value = a.snapshot_source(SOURCE, names)
    h.save(OUT / (label + '.json'), value)
    require(len(names) == 596 and set(names) == set(expected['files']) and value == expected, '596输入bytes/SHA/exec/集合变化')
    return value


def step(name, argv, budget):
    source(name + '_source_before')
    try:
        return runner.command(name, argv, budget)
    finally:
        source(name + '_source_after')

PARSER_CODE


def run_list(name, argv, wanted):
    _, row = step(name, argv, 900)
    actual = list_blocks(Path(row['stdout']).read_text())
    require(len(actual) == 1 and len(actual[0]) == len(wanted) and set(actual[0]) == set(wanted), name + ' 精确方法名单不同')
    result['tests'][name] = {'actual_list': actual[0], 'exact_expected_roster': True}


def run_one(name, argv, wanted, require_negative=False):
    _, row = step(name, argv, 900)
    actual = run_blocks(Path(row['stdout']).read_text())
    require(len(actual) == 1 and actual[0]['counts'] == {'passed': len(wanted), 'failed': 0, 'ignored': 0, 'measured': 0, 'filtered_out': 0}, name + ' 数量/ignored不同')
    require({r['name'] for r in actual[0]['methods']} == set(wanted), name + ' 原方法名单不同')
    record = {'actual_suites': actual, 'exact_expected_roster': True}
    if require_negative:
        raw = Path(row['stderr']).read_text()
        matches = re.findall(r'^分配负控：pid=(\d+)，status=([^\n]+?)，已自然wait/reap，stdout=(\d+)B，stderr=(\d+)B：memory allocation of 8 bytes failed$', raw, re.M)
        require(len(matches) == 1, name + ' 缺真实8B分配负控完成输出')
        pid, status, stdout_bytes, stderr_bytes = matches[0]
        require(int(pid) > 0 and status == 'signal: 6 (SIGABRT)' and int(stderr_bytes) > 0, name + ' 负控实际状态不同')
        record['allocator_negative_child'] = {'pid': int(pid), 'raw_status': status, 'signal': 6, 'reaped_by_test_wait_with_output': True, 'stdout_bytes': int(stdout_bytes), 'stderr_bytes': int(stderr_bytes), 'expected_nonzero_signal_termination': True, 'not_an_additional_Rust_method': True, 'raw_completion_in_stderr': True}
    result['tests'][name] = record


before = compiler = cargo = None
old_handlers = {}


def interrupted(signum, frame):
    h.INTERRUPTED = signum


try:
    for sig in (signal.SIGINT, signal.SIGTERM, signal.SIGHUP):
        old_handlers[sig] = signal.signal(sig, interrupted)
    identity = {'hostname': platform.node(), 'arch': platform.machine(), 'uid': os.getuid(), 'gid': os.getgid(), 'boot_id': Path('/proc/sys/kernel/random/boot_id').read_text().strip()}
    require(identity == {'hostname': 'ubuntu', 'arch': 'aarch64', 'uid': 1000, 'gid': 1000, 'boot_id': '6cf7ee3e-a3c5-4c91-80bc-4ca924818b53'}, 'Orin身份不同')
    require(os.environ.get('CARGO_HOME') == '/home/loosqk/robot-checks/viz-orin-a6957cc-20260930-r1/cargo-home' and os.environ.get('CARGO_NET_OFFLINE') == 'true', '既有离线cache不同')
    result['identity'] = identity
    before = source('source_before')
    _, row = step('rustc_before', ['rustc', '+nightly', '-vV'], 60)
    compiler = a.parse_rustc_identity(Path(row['stdout']).read_text())
    require(compiler['commit_hash'] == '1d81eb4ad9cd207e3e638bd32b17ec4fce8412a6', '实际nightly不再1d81')
    _, row = step('cargo_before', ['cargo', '+nightly', '-V'], 60)
    cargo = Path(row['stdout']).read_bytes()
    require(b'-nightly' in cargo, 'Cargo不是nightly')
    step('fmt', ['cargo', '+nightly', 'fmt', '--all'], 300)
    step('clippy_default', ['cargo', '+nightly', 'clippy', '--locked', '--all', '--all-targets', '--', '-D', 'warnings'], 7200)
    step('clippy_real_hw', ['cargo', '+nightly', 'clippy', '--locked', '--all', '--all-targets', '--features', 'robot-adapter-feetech/real-hw', '--', '-D', 'warnings'], 7200)
    base = ['cargo', '+nightly', 'test', '--locked', '-p', 'robot-adapter-feetech']
    default = base + ['--lib']
    run_list('feetech_default_list', default + ['--', '--list'], roster['lib_default'])
    run_one('feetech_default', default + ['--', '--test-threads=1', '--nocapture'], roster['lib_default'], True)
    real = default + ['--features', 'real-hw']
    run_list('feetech_real_hw_list', real + ['--', '--list'], roster['lib_real_hw'])
    run_one('feetech_real_hw', real + ['--', '--test-threads=1', '--nocapture'], roster['lib_real_hw'], True)
    for test in ['comm_fault_transport', 'abort_diagnostics']:
        argv = base + ['--test', test]
        wanted = roster['integration'][test]
        run_list(test + '_list', argv + ['--', '--list'], wanted)
        run_one(test, argv + ['--', '--test-threads=1', '--nocapture'], wanted)
    result.update(status='PASS', compiler_before=compiler, cargo_before=cargo.decode(), source_count=596, source_aggregate=before['source_manifest_sha256'], count_policy={'lib_default': 200, 'lib_real_hw_same_methods': 200, 'old_lib': 171, 'new_method_subset': 29, 'integration': [12, 5], 'distinct_suite_methods': 217, 'negative_control_children': 2, 'ignored': 0})
except BaseException as error:
    result['error'] = repr(error)
finally:
    try:
        _, row = step('rustc_after', ['rustc', '+nightly', '-vV'], 60)
        actual_compiler = a.parse_rustc_identity(Path(row['stdout']).read_text())
        require(compiler is not None and actual_compiler == compiler, 'rustc首尾不同或初始缺失')
        _, row = step('cargo_after', ['cargo', '+nightly', '-V'], 60)
        require(cargo is not None and Path(row['stdout']).read_bytes() == cargo, 'Cargo首尾不同或初始缺失')
        result.update(compiler_after=actual_compiler, compiler_window='PASS')
    except BaseException as error:
        result.update(status='FAIL', compiler_window_error=repr(error))
    try:
        require(before is not None and source('source_after') == before, '源码首尾不同或初始缺失')
        result['source_window'] = 'PASS'
    except BaseException as error:
        result.update(status='FAIL', source_window_error=repr(error))
    result['receipts'] = runner.receipts
    result['interrupted_signal'] = h.INTERRUPTED
    h.save(OUT / 'result.json', result)
    for sig, handler in old_handlers.items():
        signal.signal(sig, handler)
print(json.dumps({'status': result['status'], 'error': result.get('error'), 'receipts': len(result['receipts']), 'source_window': result.get('source_window'), 'compiler_window': result.get('compiler_window'), 'completed_test_steps': list(result['tests'])}, ensure_ascii=False), flush=True)
raise SystemExit(0 if result['status'] == 'PASS' else 1)
'''
for key, value in {'REMOTE_BASE': repr(BASE), 'RUNNER_SHA': repr(pin(OUT / 'natural_runner.py')['sha256']), 'ARTIFACTS_SHA': repr(pin(OUT / 'artifacts.py')['sha256']), 'ROSTER_SHA': repr(pin(OUT / 'test_roster.json')['sha256']), 'MANIFEST_SHA': repr(pin(OUT / 'candidate_manifest_r1.json')['sha256']), 'SOURCE_AGG': repr(expected['source_manifest_sha256']), 'PARSER_CODE': parser_code}.items():
    code = code.replace(key, value)
ast.parse(code)
with (OUT / 'run_absolute.py').open('x') as f:
    f.write(code)

namespace = {'re': __import__('re'), 'require': lambda condition, message: None if condition else (_ for _ in []).throw(ValueError(message))}
exec(compile(ast.Module(body=pure, type_ignores=[]), '<pure-parser-only>', 'exec'), namespace)
qa = WORK / 'target/absolute_write/local_qa_r7'
for label, wanted in [('lib_default', roster['lib_default']), ('lib_real_hw', roster['lib_real_hw']), ('comm_fault_transport', roster['integration']['comm_fault_transport']), ('abort_diagnostics', roster['integration']['abort_diagnostics'])]:
    blocks = namespace['run_blocks']((qa / label / 'stdout.log').read_text())
    assert len(blocks) == 1 and blocks[0]['counts'] == {'passed': len(wanted), 'failed': 0, 'ignored': 0, 'measured': 0, 'filtered_out': 0}
    assert {m['name'] for m in blocks[0]['methods']} == set(wanted)
for label, wanted in [('lib_default_list', roster['lib_default']), ('lib_real_hw_list', roster['lib_real_hw'])]:
    blocks = namespace['list_blocks']((qa / label / 'stdout.log').read_text())
    assert len(blocks) == 1 and set(blocks[0]) == set(wanted)
save(OUT / 'parser_preflight.json', {'status': 'PASS_PURE_PARSER_EXISTING_R7_RAW_NOT_NATIVE_EXECUTION', 'lib': [200, 200], 'integration': [12, 5], 'ignored': 0, 'run_and_list_exact': True, 'test_roster': pin(OUT / 'test_roster.json'), 'Rust_or_SSH_started': 0})
hash_names = ['artifacts.py', 'natural_runner.py', 'expected_source.json', 'source_export.json', 'source-inputs.tar.gz', 'test_roster.json', 'candidate_manifest_r1.json', 'receive_source.py', 'run_absolute.py']
launch = 'set -eu\nexport PATH=/home/loosqk/.cargo/bin:/home/loosqk/.local/bin:$PATH\nexport CARGO_HOME=/home/loosqk/robot-checks/viz-orin-a6957cc-20260930-r1/cargo-home\nexport CARGO_NET_OFFLINE=true\nexport RUSTUP_AUTO_INSTALL=0\nexport PYTHONDONTWRITEBYTECODE=1\ncd ' + BASE + '/bootstrap\nsha256sum -c - <<\'SHA_INPUTS\'\n'
launch += '\n'.join(pin(OUT / name)['sha256'] + '  ' + name for name in hash_names)
launch += '\nSHA_INPUTS\nuv run --no-project python receive_source.py\nexec taskset -c 0-3 uv run --no-project python run_absolute.py\n'
with (OUT / 'launch_absolute.sh').open('x') as f:
    f.write(launch)
save(OUT / 'execution_plan.json', {
    'status': 'PREPARED_NOT_RUN_PENDING_FROZEN_STATIC_ACCEPTANCE', 'remote_base': BASE,
    'scope': pin(MAIN / 'target/absolute_write_integration_2026-10-08/root_native_scope.md'),
    'manifest': pin(OUT / 'candidate_manifest_r1.json'), 'source': pin(OUT / 'expected_source.json'), 'export': pin(OUT / 'source_export.json'),
    'runner': pin(OUT / 'natural_runner.py'), 'run_helper': pin(OUT / 'run_absolute.py'), 'host_owner': pin(OUT / 'host_owner.py'), 'launch': pin(OUT / 'launch_absolute.sh'),
    'budgets_seconds': {'compiler_metadata_each': 60, 'fmt': 300, 'root_clippy_each': 7200, 'test_list_or_run_each': 900},
    'planned_external_commands': 15, 'planned_source_windows': 32,
    'expected_identity': {'hostname': 'ubuntu', 'arch': 'aarch64', 'uid': 1000, 'gid': 1000, 'boot_id': '6cf7ee3e-a3c5-4c91-80bc-4ca924818b53'},
    'expected_compiler_commit': '1d81eb4ad9cd207e3e638bd32b17ec4fce8412a6',
    'rosters': {'lib_default': 200, 'lib_real_hw_same_methods': 200, 'new_subset': 29, 'comm_fault_transport': 12, 'abort_diagnostics': 5, 'distinct_suite_methods': 217, 'ignored': 0},
    'allocator_negative': '默认/real-hw完整lib各真实8B child SIGABRT6，test wait_with_output；stdout方法数不加，实际完成输出及pid/bytes保stderr，native session无残留门',
    'source_and_compiler_before_after_required': True, 'native_git_head': None, 'new_rustup_update': False,
    'strict_ssh_options': ['BatchMode=yes', 'StrictHostKeyChecking=yes', 'ConnectTimeout=15'],
    'no_hardware_release_workspace_service_install_push': True,
})
print(json.dumps({'plan': pin(OUT / 'execution_plan.json'), 'runner': pin(OUT / 'run_absolute.py'), 'source': expected['source_manifest_sha256'], 'commands': 15, 'tests': [200, 200, 12, 5], 'distinct': 217, 'status': 'NOT_RUN'}, ensure_ascii=False))
