"""本机紧凑封存已验收的绝对期限写入阶段；不运行编译或远端操作。"""
import hashlib
import json
import stat
import tarfile
from pathlib import Path

MAIN = Path('/Users/loosqk/repo/rust/robot-system')
AREA = MAIN / 'target/absolute_write_integration_2026-10-08'
WORK = Path('/Users/loosqk/.codex/worktrees/feetech-absolute-write/robot-system/target/absolute_write')
OUT = MAIN / '.verify/feetech_absolute_write_2026-10-08'
AGGREGATE = 'bfe2318fd0bbac6e5f3c34766237ceca634f72331091053b7d2450e5b0ee0f40'
COMMIT = '1d81eb4ad9cd207e3e638bd32b17ec4fce8412a6'


def require(value, message):
    if not value:
        raise ValueError(message)


def identity(path):
    entry = path.lstat()
    require(stat.S_ISREG(entry.st_mode) and not path.is_symlink(), '封存输入不是普通文件')
    data = path.read_bytes()
    return {'path': str(path), 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest(), 'mode': stat.S_IMODE(entry.st_mode)}


def read(path):
    return json.loads(path.read_text())


def save(path, value):
    with path.open('x') as stream:
        json.dump(value, stream, ensure_ascii=False, indent=2)
        stream.write('\n')


expected = read(AREA / 'native-r3/expected_source.json')
require(len(expected['files']) == 596 and expected['source_manifest_sha256'] == AGGREGATE, '冻结输入不是596/bfe')


def main_input():
    for name, wanted in expected['files'].items():
        actual = identity(MAIN / name)
        require(actual['sha256'] == wanted['sha256'] and actual['bytes'] == wanted['bytes'] and bool(actual['mode'] & 0o111) == wanted['executable'], '主树编译输入与冻结件不同：' + name)
    return {'count': 596, 'aggregate': AGGREGATE, 'all_sha_bytes_exec_equal': True}


main_before = main_input()
acceptance = read(AREA / 'root_native_acceptance_r1.json')
integration = read(AREA / 'root_integration_r1.json')
quality = read(AREA / 'root_main_quality_binding_r1.json')
require(acceptance['status'] == 'PASS_SCOPED_SOFTWARE_APPROVED_FOR_MAIN_INTEGRATION', '缺root软件验收')
require(integration['status'] == 'PASS_EXACT_SIX_OVERLAYS_SAME_NATIVE_SOURCE' and integration['after'] == expected, 'root整合不是同源六处')
require(quality['status'] == 'PASS_MAIN_POST_FMT_SAME_INPUT_AS_ACTUAL_NATIVE_FMT_THEN_ROOT_CLIPPY' and quality['source_manifest_sha256'] == AGGREGATE, '缺root主树质量绑定')
require(read(WORK / 'local_qa_r7/result.json')['status'] == 'PASS_LOCAL_SCOPED_SOFTWARE', 'Mac最终QA未PASS')
require(read(AREA / 'native_combined_r4/summary_r1.json')['status'] == 'PASS_SCOPED_SOFTWARE_TWO_BATCHES_WITH_ORIGINAL_R2_FAIL_PRESERVED', '缺两批准确摘要')

members = {}
origins = []
snapshot_member = 'source/source_export_r1.tar.gz'
snapshot_identity = identity(WORK / 'freeze_r1/source_export_r1.tar.gz')


def add(path, member):
    require(member not in members, '重复归档成员名')
    observed = identity(path)
    if path.name in {'source_export_r1.tar.gz', 'source-inputs.tar.gz'}:
        require(observed['sha256'] == snapshot_identity['sha256'] and observed['bytes'] == snapshot_identity['bytes'], '重复源码包字节不一致')
        if snapshot_member not in members:
            members[snapshot_member] = path
        mapped = snapshot_member
    else:
        members[member] = path
        mapped = member
    origins.append({**observed, 'archive_member': mapped})


def add_tree(path, prefix):
    for item in sorted(path.rglob('*')):
        if item.is_file() and '__pycache__' not in item.parts:
            add(item, prefix + '/' + item.relative_to(path).as_posix())


add_tree(AREA, 'main-evidence')
for directory in ['baseline_r1', 'freeze_r1', 'local_qa_r1', 'local_qa_r2', 'local_qa_r3', 'local_qa_r4', 'local_qa_r5', 'local_qa_r6', 'local_qa_r7', 'allocator_locate_r1', 'allocator_locate_r2']:
    add_tree(WORK / directory, 'candidate-evidence/' + directory)
for script in sorted(WORK.glob('*.py')):
    add(script, 'candidate-evidence/helpers/' + script.name)
plans = MAIN / 'target/b1_freshness_integration_2026-10-08'
for name in ['absolute_write_plan_r1.json', 'root_decisions_r1.json', 'root_priority_decision_r1.json', 'root_priority_decision_r1.md', 'absolute_write_oracle_static_review_r1.json']:
    path = plans / name
    if path.exists():
        add(path, 'planning/' + name)
manual_cut = MAIN / 'target/hardware_readonly_2026-10-08/selected_motion_preparation_r1/root_manual_power_cut_receipt_r1.json'
add(manual_cut, 'hardware-context/root_manual_power_cut_receipt_r1.json')
old_roster = Path(read(WORK / 'freeze_r1/test_roster_r1.json')['original_old_roster']['path'])
add(old_roster, 'historical-roster/firmware_171_plus_poke6.json')


def reference(path):
    rows = [row for row in origins if row['path'] == str(path)]
    require(len(rows) == 1, '必要原件未封存或重复登记：' + str(path))
    row = rows[0]
    return {key: row[key] for key in ['archive_member', 'bytes', 'sha256']}


OUT.mkdir()
archive_path = OUT / 'original-evidence.tar.gz'
with tarfile.open(archive_path, 'w:gz', compresslevel=6) as archive:
    for member, path in sorted(members.items()):
        archive.add(path, arcname=member, recursive=False)
require([identity(Path(row['path'])) for row in origins] == [{key: row[key] for key in ['path', 'bytes', 'sha256', 'mode']} for row in origins], '封包前后原件身份变化')
verified = []
with tarfile.open(archive_path, 'r:gz') as archive:
    archived = archive.getmembers()
    require(len(archived) == len(members) and len({item.name for item in archived}) == len(members), '归档成员数量/唯一性不同')
    require({item.name for item in archived} == set(members), '归档成员集合不同')
    for item in archived:
        require(item.isfile() and not item.name.startswith('/') and '..' not in Path(item.name).parts, '归档成员非法')
        data = archive.extractfile(item).read()
        original = identity(members[item.name])
        require(len(data) == original['bytes'] and hashlib.sha256(data).hexdigest() == original['sha256'] and item.mode == original['mode'], '归档成员字节/SHA/mode不同')
        verified.append({'archive_member': item.name, 'bytes': len(data), 'sha256': original['sha256'], 'mode': item.mode})
main_after = main_input()
require(main_after == main_before, '封包前后596主树输入变化')
index_path = OUT / 'original-evidence.index.json'
save(index_path, {'status': 'PASS_ARCHIVED_MEMBERS_AND_ORIGINAL_IDENTITIES_UNCHANGED', 'original_count': len(origins), 'unique_archive_members': len(members), 'origins': origins, 'members': verified, 'source_tar_policy': '同一596源码tar三份原件按相同bytes/SHA映射到一个成员，不重复展开源码/Cargo target', 'direct_required_refs_archived': True, 'all_external_historical_refs_claimed_closed': False})
verification_path = OUT / 'archive-verification.json'
save(verification_path, {'status': 'PASS', 'archive': identity(archive_path), 'index': identity(index_path), 'all_archive_member_bytes_sha_mode_match': True, 'original_before_after_equal': True, 'source_tar_duplicate_identities_verified': True, 'main_input_before': main_before, 'main_input_after': main_after, 'local_only_no_cargo_ssh_uart': True})
summary = {
    'schema': 'FEETECH_ABSOLUTE_WRITE_STAGE_SUMMARY_R1',
    'status': 'MAIN_INTEGRATED_SCOPED_SOFTWARE_PASS_TWO_NATIVE_BATCHES',
    'date': '2026-10-08', 'commit_status': 'PENDING_ROOT_COMMIT', 'deployable': False,
    'implemented': '六源新增借RobotClock的SourceWriteDeadline、共享bounded partial-write核心、强制显式Some探针的普通写bus入口、固定11原因及进度诊断；旧Position/Safety/Confirm写调用保持原API。',
    'contract': ['source/call严格now>=拒；来源期限和transport调用预算固定、不续期、不整帧重放', '非法count原因优先且got不增；合法Ok更新got后按clock回退/source/call到期优先，保wanted/got/previous_at/observed/last_io_error及write_attempted', '新API参数/寄存器拒写检查保持原优先，只限NormalEffectful/PeriodicWrite；无显式probe固定NoAuthorityProbe，在lease/transport前拒', 'Some探针不认证真实性；clock回退只覆盖core观测窗，call预算从transport start计，编码/lease耗时由source期限限制'],
    'source': {'count': 596, 'aggregate': AGGREGATE, 'baseline_main_head': integration['base_head'], 'candidate_actual_head': 'e6d6d111091b29b791bae0375b209692fdf3eed5', 'native_git_head': None, 'changed_sources': integration['changed_sources'], 'manifest': reference(WORK / 'freeze_r1/candidate_manifest_r1.json'), 'expected_source': reference(WORK / 'freeze_r1/expected_source_r1.json'), 'unique_full_source_tar': reference(WORK / 'freeze_r1/source_export_r1.tar.gz'), 'root_integration': reference(AREA / 'root_integration_r1.json')},
    'validation': {'Mac': {'different_suite_methods': 217, 'default_lib': 200, 'real_hw_same_lib': 200, 'integration': [12, 5], 'owned_external_commands': 16, 'ignored': 0, 'result': reference(WORK / 'local_qa_r7/result.json')}, 'Orin': {'different_suite_methods': 217, 'r2_actual': 'fmt→默认根Clippy→real-hw根Clippy→默认库200，实际均exit0；负控固定Display后缀被误拒造成原batch FAIL', 'r3_actual': '仅未执行real-hw库200和12/5 integration实际PASS，未重跑已通过质量/default库', 'native_owned_commands': 19, 'source_windows': 42, 'local_ssh_scp_owners': 9, 'all_owned_children_natural_reap': True, 'r2_quality_owner_exit1_preserved': True, 'negative_control_children': 2, 'negative_signal': 6, 'negative_allocation_bytes': 8, 'ignored': 0, 'actual_summary': reference(AREA / 'native_combined_r4/summary_r1.json'), 'actual_roster': reference(AREA / 'native_combined_r4/actual_method_roster_r1.json')}, 'dedup': '每平台200+12+5=217；default/real-hw200同名只计一次，29新增为200子集，24过滤子集不累计；Mac与Orin不相加，两个负控child不另计Rust方法', 'compiler': {'commit': COMMIT, 'Mac_host': 'aarch64-apple-darwin', 'Orin_host': 'aarch64-unknown-linux-gnu', 'floating_nightly': True, 'new_rustup_update_this_stage': False, 'native_raw_across_batches_identical': True}},
    'precommit_quality': {'status': quality['status'], 'actual_main_fmt': quality['actual_main_fmt'], 'reuse': quality['quality_reuse'], 'all_596_post_fmt_same_as_native': True, 'root_binding': reference(AREA / 'root_main_quality_binding_r1.json'), 'native_quality': reference(AREA / 'native_combined_r4/precommit_quality_binding_r1.json')},
    'review': {'independent_local': reference(AREA / 'independent_local_r1/review.json'), 'independent_native': reference(AREA / 'independent_native_r1/review.json'), 'root_acceptance': reference(AREA / 'root_native_acceptance_r1.json')},
    'history': {'Mac_r1_r6_and_allocator_locate': '所有result/log/wait及已启动未完成澄清均原件封存；helper拒绝、lint/compile失败、fixture64B与旧mock日志34B真实allocator FAIL不覆盖', 'native_r1': '本机准备SyntaxError；SSH/Cargo实际0启动，QA NOT_RUN', 'native_r2': '原batch FAIL/owner exit1完整保留；实际200和两个质量门不被误拒抹去', 'local_summary_prep_r1_r3': '三次本机汇总schema误读原件另封；SSH/Cargo/UART均0启动，不当真实测试失败'},
    'allocator_boundary': '本lib cfg(test)唯一真实AllocDisabler，原热路径及新29方法复验通过；MockHandle::drain_tx更换Vec时在非热捕获接口预留原容量，drain本身有分配。foreign backend自行构造String错误的分配不由固定fixture证明零分配；旧无global allocator历史不回填真零分配。',
    'hardware_context': {'new_actions_this_stage': False, 'head1': '原回程+8超±4/800ms FAIL', 'right9': '原Torque0/GoalVelocity0/PresentVelocity=-50 STOP FAIL；不推断来源/实际运动', 'human_power_cut': '用户确认两个电机电源已切断、机械臂支撑；root收到06:35:40UTC，实际切电时刻/独立遥测未测，旧NEEDS/PENDING原件不改，无新GO', 'receipt': reference(manual_cut), 'D15': 'OPEN/DEFERRED', 'H2_and_left_wrist': '原FAIL保持', 'Firmware': '现场版本未读、Phase12未改'},
    'limits': ['未接S0/S1/P1C生产事件桥、真实轮速TX或Enable/authority/Phase/EEPROM配置；不是完整B1', '未完整workspace/release/H2六配方或真实RT/新硬件门，未正式安装、服务激活、部署或push', '本轮无UART操作；无syscalltrace，不以缺少设备命令冒称系统调用证据', '封必要完整QA/历史原件与直接summary refs；内部绝对旧路径由index按origin映射，不宣称全部跨阶段历史refs归档闭包', 'root主树fmt原始tool输出未作为单独stdout/stderr附件提供，本包保其实际质量receipt及两个身份child记录，不能虚构额外原件'],
    'archive': {'original_evidence': identity(archive_path), 'index': identity(index_path), 'verification': identity(verification_path), 'source_tar_copies_collapsed': 3, 'original_count': len(origins), 'unique_archive_members': len(members)},
}
save(OUT / 'summary.json', summary)
require([identity(Path(row['path'])) for row in origins] == [{key: row[key] for key in ['path', 'bytes', 'sha256', 'mode']} for row in origins], '写摘要后原件变化')
print(json.dumps({'summary': identity(OUT / 'summary.json'), 'archive': identity(archive_path), 'index': identity(index_path), 'verification': identity(verification_path), 'original_count': len(origins), 'unique_members': len(members)}, ensure_ascii=False))
