"""只在本机读取原件并封同源两批摘要；不执行 Cargo、SSH 或设备操作。"""
import ast
import hashlib
import json
import re
import tarfile
from pathlib import Path

AREA = Path('/Users/loosqk/repo/rust/robot-system/target/absolute_write_integration_2026-10-08')
OUT = AREA / 'native_combined_r1'
EXPECTED_AGGREGATE = 'bfe2318fd0bbac6e5f3c34766237ceca634f72331091053b7d2450e5b0ee0f40'
EXPECTED_COMMIT = '1d81eb4ad9cd207e3e638bd32b17ec4fce8412a6'
OUT.mkdir()


def pin(path):
    data = path.read_bytes()
    return {'path': str(path), 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()}


def load(path):
    return json.loads(path.read_text())


def save(name, value):
    path = OUT / name
    with path.open('x') as stream:
        json.dump(value, stream, ensure_ascii=False, indent=2)
        stream.write('\n')
    return pin(path)


def require(value, message):
    if not value:
        raise ValueError(message)


# 冻结输入和已有原件先登记身份；新摘要不改变任何旧文件。
original_files = sorted(path for number in [2, 3] for path in (AREA / f'native-r{number}').rglob('*') if path.is_file())
original_identity = [pin(path) for path in original_files]
expected = load(AREA / 'native-r3/expected_source.json')
roster = load(AREA / 'native-r3/test_roster.json')
require(len(expected['files']) == 596 and expected['source_manifest_sha256'] == EXPECTED_AGGREGATE, '冻结源不是596/bfe')
for name in ['expected_source.json', 'test_roster.json', 'candidate_manifest_r1.json', 'source-inputs.tar.gz']:
    require((AREA / 'native-r2' / name).read_bytes() == (AREA / 'native-r3' / name).read_bytes(), name + ' 跨批不同')
require(pin(AREA / 'native-r3/candidate_manifest_r1.json')['sha256'] == '83a068bed6f05d97dd9a62fe558b932f6c7dc875915180c0d04b24548fd2638d', '冻结六源manifest变化')
require(pin(AREA / 'native-r3/test_roster.json')['sha256'] == 'abf4ed4f073425bc8c6c465964d4bc583e08570d886bdea3e2c29459008a9b1f', '冻结名单变化')

# 仅导入纯日志解析函数；不能导入会访问 /proc 或启动 command 的模块正文。
tree = ast.parse((AREA / 'native-r3/run_absolute.py').read_text())
pure = [node for node in tree.body if isinstance(node, ast.FunctionDef) and node.name in {'list_blocks', 'run_blocks'}]
namespace = {'re': re, 'require': require}
exec(compile(ast.Module(body=pure, type_ignores=[]), '<纯本机解析>', 'exec'), namespace)


def negative(raw):
    matches = re.findall(r'^分配负控：pid=(\d+)，status=([^\n]+?)，已自然wait/reap，stdout=(\d+)B，stderr=(\d+)B：memory allocation of 8 bytes failed$', raw, re.M)
    require(len(matches) == 1, '缺真实8B负控完成日志')
    pid, status, stdout_bytes, stderr_bytes = matches[0]
    require(int(pid) > 0 and re.fullmatch(r'signal: 6 \(SIGABRT\)( \(core dumped\))?', status) is not None and int(stderr_bytes) > 0, '负控信号或固定Display不同')
    return {'pid': int(pid), 'raw_status': status, 'signal': 6, 'allocation_bytes': 8, 'stdout_bytes': int(stdout_bytes), 'stderr_bytes': int(stderr_bytes), 'test_wait_with_output_reported_natural_reap': True, 'not_an_additional_Rust_method': True}


def exact_suite(raw, name, wanted):
    list_path = raw / (name + '_list') / 'stdout.log'
    run_path = raw / name / 'stdout.log'
    listed = namespace['list_blocks'](list_path.read_text())
    runs = namespace['run_blocks'](run_path.read_text())
    require(len(listed) == len(runs) == 1 and len(listed[0]) == len(wanted) and set(listed[0]) == set(wanted), name + ' 实际list不同')
    require(runs[0]['counts'] == {'passed': len(wanted), 'failed': 0, 'ignored': 0, 'measured': 0, 'filtered_out': 0}, name + ' 实际run计数不同')
    require({method['name'] for method in runs[0]['methods']} == set(wanted), name + ' 实际run名单不同')
    return {'list': pin(list_path), 'run_stdout': pin(run_path), 'run_stderr': pin(raw / name / 'stderr.log'), 'methods': listed[0], 'counts': runs[0]['counts']}


batches = []
all_rows = []
all_windows = []
all_owners = []
for number, order in [
    (2, ['rustc_before', 'cargo_before', 'fmt', 'clippy_default', 'clippy_real_hw', 'feetech_default_list', 'feetech_default', 'rustc_after', 'cargo_after']),
    (3, ['rustc_before', 'cargo_before', 'feetech_real_hw_list', 'feetech_real_hw', 'comm_fault_transport_list', 'comm_fault_transport', 'abort_diagnostics_list', 'abort_diagnostics', 'rustc_after', 'cargo_after']),
]:
    directory = AREA / f'native-r{number}'
    raw = directory / 'orin-download/qa'
    remote_qa = Path(f'/home/loosqk/robot-checks/feetech-absolute-write-20261008-r{number}/qa')
    result = load(raw / 'result.json')
    require(result['source_window'] == result['compiler_window'] == 'PASS', '源/编译器窗FAIL')
    require(result['identity'] == {'hostname': 'ubuntu', 'arch': 'aarch64', 'uid': 1000, 'gid': 1000, 'boot_id': '6cf7ee3e-a3c5-4c91-80bc-4ca924818b53'}, '原生机器身份不同')
    if number == 2:
        require(result['status'] == 'FAIL' and result['error'] == "ValueError('feetech_default 负控实际状态不同')", 'r2原FAIL变化')
    else:
        require(result['status'] == 'PASS' and 'error' not in result, 'r3非PASS')
    rows = []
    for reference in result['receipts']:
        completion = raw / Path(reference['path']).relative_to(remote_qa)
        require(pin(completion)['sha256'] == reference['sha256'], 'completion引用SHA不同')
        row = load(completion)
        require(row['exit_code'] == 0 and row['reaped'] and not row.get('runner_error'), '原生命令未成功自然回收')
        require(not row['budget_exceeded'] and not row['signals'] and not row['session_residual_before_cleanup'] and not row['session_residual_after_cleanup'], '预算/信号/残留不同')
        for channel in ['stdout', 'stderr']:
            channel_path = raw / Path(row[channel]).relative_to(remote_qa)
            channel_pin = pin(channel_path)
            require(channel_pin['bytes'] == row[channel + '_bytes'] and channel_pin['sha256'] == row[channel + '_sha256'], '原始日志身份不同')
        launch = raw / Path(row['launch_receipt']).relative_to(remote_qa)
        launch_row = load(launch)
        require(launch_row['pid'] == row['pid'] and launch_row['argv'] == row['argv'] and launch_row['identity'] == row['identity'], '启动/回收PID或argv不同')
        rows.append({'batch': number, 'name': row['name'], 'completion': pin(completion), 'launch': pin(launch), 'argv': row['argv'], 'pid': row['pid'], 'start_ticks': row['identity']['start_ticks'], 'exit_code': 0, 'natural_reap': True, 'started_monotonic_ns': row['started_monotonic_ns'], 'ended_monotonic_ns': row['ended_monotonic_ns']})
    require([row['name'] for row in rows] == order, '实际命令顺序不同')
    require(all(left['ended_monotonic_ns'] < right['started_monotonic_ns'] for left, right in zip(rows, rows[1:])), '原生命令重叠')
    windows = sorted(raw.glob('*source*.json'))
    require(len(windows) == 2 + 2 * len(rows) and all(load(path) == expected for path in windows), '596源码窗口不同')
    for which in ['rustc', 'cargo']:
        before = (raw / f'{which}_before/stdout.log').read_bytes()
        require(before == (raw / f'{which}_after/stdout.log').read_bytes(), '编译器首尾不同')
        require(before == (AREA / 'native-r2/orin-download/qa' / f'{which}_before/stdout.log').read_bytes(), '跨批编译器raw不同')
    require(result['compiler_before'] == result['compiler_after'] and result['compiler_before']['commit_hash'] == EXPECTED_COMMIT and result['compiler_before']['host'] == 'aarch64-unknown-linux-gnu', 'native compiler身份不同')
    owners = []
    for owner_result in sorted(directory.glob('*.owner/result.json')):
        owner = load(owner_result)
        wanted_exit = 1 if number == 2 and owner_result.parent.name == 'orin_quality.owner' else 0
        require(owner['phase'] == 'REAPED' and owner['reaped'] and owner['wait_returncode'] == wanted_exit and not owner['owner_sent_signals'] and not owner['received_signals'] and not owner['errors'], '本机真实owner/wait不符合')
        log_path = Path(owner['log']['path'])
        require(pin(log_path)['sha256'] == owner['log']['sha256'] and pin(log_path)['bytes'] == owner['log']['bytes'], 'owner日志身份不同')
        tool_path = directory / ('tool_owner_wait.json' if owner_result.parent.name in {'orin_quality.owner', 'orin_remaining.owner'} else owner_result.parent.stem + '.tool_wait.json')
        tool = load(tool_path)
        require(tool['actual_terminal_wait']['exit_code'] == wanted_exit, 'tool实际终态wait不同')
        owners.append({'batch': number, 'result': pin(owner_result), 'actual_tool_wait': pin(tool_path), 'owner_pid': owner['owner_pid'], 'child_pid': owner['pid'], 'wait_returncode': wanted_exit, 'natural_reap': True, 'status': owner['status'], 'finished_utc': owner['finished_utc']})
    require(len(owners) == (5 if number == 2 else 4), '本机owner数不同')
    batches.append({'batch': number, 'original_status': result['status'], 'original_result': pin(raw / 'result.json'), 'original_error': result.get('error'), 'owned_native_command_count': len(rows), 'source_window_count': len(windows), 'rows': rows, 'source_windows': [pin(path) for path in windows], 'owners': owners})
    all_rows.extend(rows)
    all_windows.extend(pin(path) for path in windows)
    all_owners.extend(owners)

default = exact_suite(AREA / 'native-r2/orin-download/qa', 'feetech_default', roster['lib_default'])
real_hw = exact_suite(AREA / 'native-r3/orin-download/qa', 'feetech_real_hw', roster['lib_real_hw'])
require(set(default['methods']) == set(real_hw['methods']) and len(default['methods']) == 200, '两个feature的方法集合不同')
default['allocator_negative'] = negative(Path(default['run_stderr']['path']).read_text())
real_hw['allocator_negative'] = negative(Path(real_hw['run_stderr']['path']).read_text())
integration = {name: exact_suite(AREA / 'native-r3/orin-download/qa', name, names) for name, names in roster['integration'].items()}
unique = sorted(['lib::' + name for name in default['methods']] + [suite + '::' + name for suite, result in integration.items() for name in result['methods']])
require(len(unique) == len(set(unique)) == 217 and len(roster['new_method_subset']) == 29 and len(roster['old_lib_methods']) == 171, '不同方法计数不闭合')
require(set(roster['new_method_subset']).isdisjoint(roster['old_lib_methods']) and set(roster['new_method_subset']) | set(roster['old_lib_methods']) == set(default['methods']), '29新+171旧不是200完整分割')
require(len(all_rows) == 19 and len(all_windows) == 42 and len(all_owners) == 9, '两批命令/窗口/owner计数不同')

# 读取唯一源码包核596普通成员，绝不重复解包到磁盘。
archive_path = AREA / 'native-r3/source-inputs.tar.gz'
with tarfile.open(archive_path, 'r:gz') as archive:
    members = archive.getmembers()
    require(len(members) == 596 and len({member.name for member in members}) == 596 and {member.name for member in members} == set(expected['files']), 'source tar成员不同')
    for member in members:
        require(member.isfile() and not member.name.startswith('/') and '..' not in Path(member.name).parts, 'source tar非法成员')
        data = archive.extractfile(member).read()
        source_row = expected['files'][member.name]
        require(len(data) == source_row['bytes'] and hashlib.sha256(data).hexdigest() == source_row['sha256'] and bool(member.mode & 0o111) == source_row['executable'], 'source tar字节/SHA/exec不同')

method_pin = save('actual_method_roster_r1.json', {'status': 'PASS_EXACT_LIST_AND_RUN_TWO_BATCHES', 'default': default, 'real_hw_same_200': real_hw, 'integration': integration, 'suite_qualified_unique_217': unique, 'old_171_and_new_29_partition_exact': True, 'feature_duplicate_200_not_counted_again': True, 'negative_control_children_2_not_added': True})
quality_pin = save('precommit_quality_binding_r1.json', {'status': 'PASS_ACTUAL_R2_QUALITY_SAME_INPUTS_R3_WITH_ORIGINAL_BATCH_FAIL_PRESERVED', 'candidate_manifest': pin(AREA / 'native-r3/candidate_manifest_r1.json'), 'expected_source': pin(AREA / 'native-r3/expected_source.json'), 'source_count': 596, 'source_aggregate': EXPECTED_AGGREGATE, 'actual_compiler_commit': EXPECTED_COMMIT, 'actual_quality_sequence': [row for row in all_rows if row['name'] in {'fmt', 'clippy_default', 'clippy_real_hw'}], 'actual_quality_order': 'r2真实fmt结束后默认根Clippy，结束后real-hw根Clippy；均exit0/natural reap，未重复运行', 'source_windows_42': all_windows, 'compiler_raw_cross_batch_identical': True, 'main_integration_still_required': 'root之后逐项核主树596 bytes/SHA/exec同冻结bfe才能绑定；本回执不声称主树已整合六源', 'original_r2_FAIL': batches[0]['original_result']})
summary = {
    'status': 'PASS_SCOPED_SOFTWARE_TWO_BATCHES_WITH_ORIGINAL_R2_FAIL_PRESERVED',
    'date': '2026-10-08',
    'origin': load(AREA / 'native-r3/source_export.json')['origin'],
    'source_count': 596, 'source_aggregate': EXPECTED_AGGREGATE,
    'source_export_tar': pin(archive_path), 'source_tar_596_bytes_sha_exec_verified_without_extraction': True,
    'candidate_manifest': pin(AREA / 'native-r3/candidate_manifest_r1.json'),
    'frozen_expected_roster': pin(AREA / 'native-r3/test_roster.json'),
    'actual_method_roster': method_pin, 'precommit_quality_binding': quality_pin,
    'batches': batches, 'owned_native_commands': 19, 'source_windows': 42,
    'local_ssh_scp_owners': 9, 'all_owned_children_natural_reap': True,
    'local_owner_exit_policy': 'r2 orin_quality实际exit1原FAIL，其余8 owner实际exit0；所有均真实自然wait/reap，无信号/残留',
    'compiler_commit': EXPECTED_COMMIT, 'compiler_host': 'aarch64-unknown-linux-gnu',
    'compiler_raw_before_after_and_across_batches_identical': True,
    'floating_nightly': True, 'new_rustup_update_this_two_batch_run': False,
    'actual_tests': {'default_lib_r2': 200, 'real_hw_lib_r3_same_methods': 200, 'integration_r3': {'comm_fault_transport': 12, 'abort_diagnostics': 5}, 'distinct_suite_methods': 217, 'old_lib': 171, 'new_subset': 29, 'ignored': 0, 'nested_negative_controls': [default['allocator_negative'], real_hw['allocator_negative']]},
    'batch_boundary': 'r2原batch FAIL仅负控Linux固定(core dumped)Display误拒；其fmt/两根Clippy/default200实际PASS。r3只剩余real-hw200+12/5 actualPASS。两批同596/1d81合并限定软件验收，不称单轮全过。',
    'parser_preflight': pin(AREA / 'native-r3/parser_preflight.json'),
    'r2_actual_fact_receipt': pin(AREA / 'native-r2/actual_quality_default200_facts_r1.json'),
    'implemented_scope': '显式RobotClock/source绝对期限、固定call预算、不续期/不整帧重放、固定失败metadata、强制Some执行权探针的限定普通写入入口；真实test allocator及原热路径复验',
    'limits': [
        '只软件候选，不接S0/P1C/runtime或VelocityTX；不赋予Enable/Phase/EEPROM写授权',
        'Probe真实性/clock同源由调用方保证；clock回退仅本core观测窗口，call预算从transport start计',
        'native timeout不是可撤回已发字节的OS原子硬截止；foreign backend自行String错误分配未由fixture证明零分配',
        'MockHandle::drain_tx保留容量会在非热捕获调用时分配，不能称drain本身无分配',
        '未执行完整workspace/release/H2六配方/真实硬件门、未正式配置/服务/安装/push',
        '无UART命令或设备操作；没有syscall trace，不冒称trace证明',
        '本机r1-r6及定位原FAIL、native-r1准备FAIL/native-r2原FAIL分别保留；未运行门不回填',
        'H2/左腕/头部/右轮既有硬件FAIL、D15 OPEN/DEFERRED、deployable=false保持；用户人工断电不构成新GO',
    ],
    'deployable': False, 'resources_returned_after_actual_scp_reap': load(AREA / 'native-r3/download_originals.owner/result.json')['finished_utc'],
}
summary_pin = save('summary_r1.json', summary)
require([pin(path) for path in original_files] == original_identity, '封摘要前后原件身份变化')
index_pin = save('artifact_index_r1.json', {'status': 'PASS_ORIGINAL_IDENTITIES_UNCHANGED_BEFORE_AFTER_LOCAL_SEAL', 'originals': original_identity, 'new_summary': summary_pin, 'new_method_roster': method_pin, 'new_quality_binding': quality_pin, 'index_scope': 'native-r2/r3本机全部原件及新摘要；只身份索引，未复制/解包源码或Cargo target；冻结manifest内历史外部refs不因当前存在冒称已归档'})
verification_pin = save('seal_verification_r1.json', {'status': 'PASS', 'original_count': len(original_identity), 'originals_before_after_equal': True, 'artifact_index': index_pin, 'summary': summary_pin, 'method_roster': method_pin, 'quality_binding': quality_pin, 'script': pin(Path(__file__)), 'local_only_no_new_ssh_cargo_uart': True})
print(json.dumps({'summary': summary_pin, 'method_roster': method_pin, 'quality_binding': quality_pin, 'index': index_pin, 'seal_verification': verification_pin, 'originals': len(original_identity), 'commands': 19, 'windows': 42, 'unique_methods': 217}, ensure_ascii=False))
