爸爸，root已定案期限写入返回后的错误优先级，当前仅批准实现合同，未实现或测试。

非法 count 优先返回 `InvalidWriteCount`，保 reported 原值、已观测时刻，got 不累加。合法 count 先更新 got，再检查 `ClockRegressed → SourceExpired → CallBudgetExpired`，最后处理 `WriteZero`、terminal IO 与重试。

当次 native Write 返回 Err，先保存固定字段 `last_io_error: Option<io::ErrorKind>`；之后若返回期限或时钟主错误，该字段仍保原 IO 原因，无堆分配或新增原因。

必须观察四个并发样本：Ok0 与到期、BrokenPipe 与到期、合法 partial 与时钟回退、非法 count 与其他后验失败。原25方法仅为方案名单，最终方法数量以实现manifest与真实测试名单为准。原方案、独核附件和已封P1包保持原字节。
