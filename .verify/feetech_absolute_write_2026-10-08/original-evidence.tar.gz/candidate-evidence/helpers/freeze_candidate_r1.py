"""纯本机封存六源候选：读取Git身份、完整输入、真实完成及准确名单；不启动Cargo。"""
import datetime
import gzip
import hashlib
import importlib.util
import io
import json
import re
import subprocess
import tarfile
from pathlib import Path

WORK = Path('/Users/loosqk/.codex/worktrees/feetech-absolute-write/robot-system')
MAIN = Path('/Users/loosqk/repo/rust/robot-system')
ROOT = WORK / 'target/absolute_write'
QA = ROOT / 'local_qa_r7'
OUT = ROOT / 'freeze_r1'
OUT.mkdir()
spec = importlib.util.spec_from_file_location('artifacts', MAIN / 'target/b1_freshness_integration_2026-10-08/native-r5/artifacts.py')
a = importlib.util.module_from_spec(spec)
spec.loader.exec_module(a)


def save(path, value):
    with path.open('x') as f:
        json.dump(value, f, ensure_ascii=False, indent=2)
        f.write('\n')


def pin(path):
    path = Path(path)
    data = path.read_bytes()
    return {'path': str(path), 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()}


def owned_read(name, cwd, argv):
    folder = OUT / name
    folder.mkdir()
    row = {'argv': argv, 'cwd': str(cwd), 'started_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'signals_sent': []}
    with (folder / 'stdout.log').open('xb') as stdout, (folder / 'stderr.log').open('xb') as stderr:
        child = subprocess.Popen(argv, cwd=cwd, stdin=subprocess.DEVNULL, stdout=stdout, stderr=stderr)
        row['pid'] = child.pid
        save(folder / 'launch.json', row)
        row['actual_exit'] = child.wait()
        row['reaped'] = True
    row['finished_utc'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
    row['stdout'] = pin(folder / 'stdout.log')
    row['stderr'] = pin(folder / 'stderr.log')
    save(folder / 'completion.json', row)
    assert row['actual_exit'] == 0
    return (folder / 'stdout.log').read_bytes()


candidate_head = owned_read('candidate_head', WORK, ['git', 'rev-parse', 'HEAD']).decode().strip()
main_head = owned_read('main_head', MAIN, ['git', 'rev-parse', 'HEAD']).decode().strip()
main_status = owned_read('main_status', MAIN, ['git', 'status', '--porcelain=v1', '-z'])
names = owned_read('candidate_inventory', WORK, ['git', 'ls-files', '-z', '--cached', '--others', '--exclude-standard']).decode().rstrip('\0').split('\0')
main_names = owned_read('main_inventory', MAIN, ['git', 'ls-files', '-z', '--cached', '--others', '--exclude-standard']).decode().rstrip('\0').split('\0')
assert candidate_head == 'e6d6d111091b29b791bae0375b209692fdf3eed5'
assert main_head == '66d39b8af6a61cc778371239447d5f8edd4d792d'
assert main_status == b''
current = a.snapshot_source(WORK, names)
main = a.snapshot_source(MAIN, main_names)
baseline = json.loads((ROOT / 'baseline_r1/after_source.json').read_text())
assert main == baseline
assert len(current['files']) == len(main['files']) == 596
tested = json.loads((QA / 'source_after.json').read_text())
assert current == tested
source_windows = []
for path in sorted(QA.glob('*_source_after.json')):
    assert json.loads(path.read_text()) == current, path
    source_windows.append(pin(path))
assert len(source_windows) == 11
assert json.loads((QA / 'fmt_source_after.json').read_text()) == current
save(OUT / 'expected_source_r1.json', current)
save(OUT / 'main_baseline_binding_r1.json', {'status': 'PASS', 'actual_main_head': main_head, 'actual_candidate_head': candidate_head, 'origin': 'e6 + 11逐项P1输入导入；与已提交66完整596编译输入相同，然后只修改六Feetech源', 'main_source': main, 'main_status': 'clean', 'baseline_receipt': pin(ROOT / 'baseline_r1/result.json')})

result = json.loads((QA / 'result.json').read_text())
assert result['status'] == 'PASS_LOCAL_SCOPED_SOFTWARE'
assert len(result['commands']) == 16
assert result['compiler']['host'] == 'aarch64-apple-darwin'
assert result['compiler']['commit_hash'] == '1d81eb4ad9cd207e3e638bd32b17ec4fce8412a6'
for row in result['commands']:
    assert row['actual_exit'] == 0 and row['reaped'] is True and row['signals_sent'] == []
    for channel in ['stdout', 'stderr']:
        assert pin(row[channel]['path']) == row[channel]
for name in ['rustc', 'cargo']:
    assert (QA / (name + '_before/stdout.log')).read_bytes() == (QA / (name + '_after/stdout.log')).read_bytes()
assert result['commands'][3]['name'] == 'fmt'
assert result['commands'][4]['name'] == 'clippy_default'
assert result['commands'][3]['finished_monotonic_ns'] < result['commands'][4]['started_monotonic_ns']


def parse_list(step):
    raw = (QA / step / 'stdout.log').read_text()
    methods = re.findall(r'^([^\n]+): test$', raw, re.M)
    assert len(methods) == len(set(methods))
    return sorted(methods)


def parse_run(step, expected_count):
    raw = (QA / step / 'stdout.log').read_text()
    methods = re.findall(r'^test ([^\n]+?) \.\.\. ok$', raw, re.M)
    assert len(methods) == len(set(methods)) == expected_count
    assert raw.count('test result: ok.') == 1
    assert re.search(rf'^test result: ok\. {expected_count} passed; 0 failed; 0 ignored; 0 measured;', raw, re.M)
    return sorted(methods)


default = parse_run('lib_default', 200)
real_hw = parse_run('lib_real_hw', 200)
subset = parse_run('absolute_named_subset', 24)
assert default == real_hw
assert default == parse_list('lib_default_list') == parse_list('lib_real_hw_list')
assert subset == parse_list('absolute_named_subset_list')
assert set(subset).issubset(default)
transport_names = re.findall(r'^    fn ((?:absolute_|deadline_bus_)[a-z0-9_]+)\(', (WORK / 'crates/robot-adapters/feetech/src/post_e_transport_acceptance.rs').read_text(), re.M)
new_methods = sorted(['transport::post_e_acceptance::absolute::' + name for name in transport_names] + ['adapter::diagnostic::tests::absolute_error_conversion_and_diagnostic_reason_are_exhaustive'])
assert len(transport_names) == 28 and len(new_methods) == 29
assert set(new_methods).issubset(default)
old_roster_path = MAIN / 'target/feetech_firmware_integration_2026-10-08/native-r1/test_roster_and_overlap.json'
old_roster = json.loads(old_roster_path.read_text())
old = sorted(name.removeprefix('lib::') for name in old_roster['all_names']['feetech_lib'])
assert len(old) == 171
assert sorted(set(default) - set(new_methods)) == old
integration = {
    'comm_fault_transport': parse_run('comm_fault_transport', 12),
    'abort_diagnostics': parse_run('abort_diagnostics', 5),
}
roster = {
    'status': 'PASS_ACTUAL_EXACT_ROSTERS',
    'lib_default': default, 'lib_real_hw': real_hw, 'absolute_named_subset': subset,
    'new_method_subset': new_methods, 'new_methods': 29,
    'old_lib_methods': 171, 'original_old_roster': pin(old_roster_path),
    'integration': integration, 'lib_features_have_identical_200_names': True,
    'distinct_suite_qualified_methods': 217,
    'not_added_again': '24包含21新+3旧，另8新deadline_bus由完整200覆盖；默认/real-hw的200同名，只计一次；新增29是200子集；12/5按独立integration suite计。负控child是一个lib方法内样本。',
    'ignored': 0,
}
save(OUT / 'test_roster_r1.json', roster)

six = [name for name in current['files'] if current['files'][name] != baseline['files'][name]]
assert sorted(six) == sorted([
    'crates/robot-adapters/feetech/src/bus.rs',
    'crates/robot-adapters/feetech/src/diagnostic.rs',
    'crates/robot-adapters/feetech/src/error.rs',
    'crates/robot-adapters/feetech/src/lib.rs',
    'crates/robot-adapters/feetech/src/post_e_transport_acceptance.rs',
    'crates/robot-adapters/feetech/src/transport.rs',
])
manifest = {
    'status': 'FROZEN_LOCAL_SCOPED_SOFTWARE_PASS_PENDING_INDEPENDENT_REVIEW',
    'actual_candidate_git_head': candidate_head, 'baseline_main_actual_git_head': main_head,
    'baseline_source_count': 596, 'baseline_source_aggregate': baseline['source_manifest_sha256'],
    'candidate_source_count': 596, 'candidate_source_aggregate': current['source_manifest_sha256'],
    'compiler': result['compiler'], 'new_rustup_update_this_batch': False,
    'rust_toolchain_floating_nightly': True,
    'changed_sources': {name: {'old': baseline['files'][name], 'new': current['files'][name], 'source_path': str(WORK / name)} for name in six},
    'expected_source': pin(OUT / 'expected_source_r1.json'), 'roster': pin(OUT / 'test_roster_r1.json'),
    'local_qa_result': pin(QA / 'result.json'), 'local_tool_owner_actual_terminal_wait': pin(QA / 'tool_owner_wait.json'),
    'source_windows': source_windows, 'scope': '六源隔离候选；原生Linux/Orin门未执行，尚未集成main，无commit/push/硬件/部署',
}
save(OUT / 'candidate_manifest_r1.json', manifest)

# 单次完整输入导出。只包含固定596个编译输入，不带Git、target、旧source树或凭证。
export = OUT / 'source_export_r1.tar.gz'
index = []
with export.open('xb') as sink:
    with gzip.GzipFile(fileobj=sink, mode='wb', mtime=0, filename='') as zipped:
        with tarfile.open(fileobj=zipped, mode='w') as tar:
            for name, expected in sorted(current['files'].items()):
                data = (WORK / name).read_bytes()
                assert len(data) == expected['bytes'] and hashlib.sha256(data).hexdigest() == expected['sha256']
                item = tarfile.TarInfo(name)
                item.size = len(data)
                item.mode = 0o755 if expected['executable'] else 0o644
                item.mtime = 0
                tar.addfile(item, io.BytesIO(data))
                index.append({'name': name, **expected, 'tar_mode': item.mode})
with tarfile.open(export, 'r:gz') as tar:
    members = tar.getmembers()
    assert len(members) == 596 and len({m.name for m in members}) == 596
    for item, expected in zip(members, index):
        assert item.name == expected['name'] and item.isfile() and item.mode == expected['tar_mode']
        data = tar.extractfile(item).read()
        assert len(data) == expected['bytes'] and hashlib.sha256(data).hexdigest() == expected['sha256']
after = a.snapshot_source(WORK, names)
assert after == current
save(OUT / 'source_export_index_r1.json', {'tar': pin(export), 'members': index, 'source_manifest_sha256': current['source_manifest_sha256']})
save(OUT / 'source_export_verification_r1.json', {'status': 'PASS', 'members': 596, 'all_regular_unique': True, 'member_bytes_sha_executable_match': True, 'source_before_after_same': True, 'tar': pin(export), 'index': pin(OUT / 'source_export_index_r1.json')})
summary = {
    'status': 'PASS_LOCAL_SCOPED_SOFTWARE_FROZEN_PENDING_REVIEW',
    'manifest': pin(OUT / 'candidate_manifest_r1.json'),
    'test_roster': pin(OUT / 'test_roster_r1.json'),
    'source_export': pin(export), 'source_export_index': pin(OUT / 'source_export_index_r1.json'),
    'source_export_verification': pin(OUT / 'source_export_verification_r1.json'),
    'actual_quality': 'fmt0→限定Feetech默认Clippy0→real-hw Clippy0；200+200同名完整lib、24子集、12/5integration实际0，217不同suite方法，0ignored',
    'owned_children': 'r7脚本16 metadata/Cargo实际child全部自然wait/reap；本封包5只读Git child全部自然wait/reap。lib分配负控使用wait_with_output，实际test断言8B SIGABRT；成功harness捕获该内部输出未显式导出每次PID/raw，不冒充它们有完整独立child原件。',
    'source_count': 596, 'source_manifest_sha256': current['source_manifest_sha256'],
    'changes': ['借原RobotClock/来源绝对期限，新trait默认Unsupported拒绝，不回退旧写', '同一真实bounded core保双截止/partial进度，post-return优先规则与固定metadata；bus强制显式probe，仅NormalEffectful/PeriodicWrite', '固定kind9的11原因/四进度，唯一lib真实AllocDisabler，29新增oracle', 'MockHandle非热drain构造replacement保容量；drain本身会分配，不声称无分配'],
    'historical_failures_preserved': {name: pin(ROOT / name / 'result.json') for name in ['local_qa_r1', 'local_qa_r2', 'local_qa_r3', 'local_qa_r4', 'local_qa_r5', 'allocator_locate_r1', 'allocator_locate_r2', 'local_qa_r6']},
    'history_limits': ['r1仅本机编译器helper误拒，fmt/build/test未启动；r2-r4真实lint/compile失败，tests未启动', 'r5定向suite实际SIGABRT64B，12已观测ok无整suite PASS；原默认NOT_RUN字段另澄清，定位锁后exact通过', 'r6旧fast-stop mock capture因drain丢容量真实34B失败；伴随64B abort不得单独归因；旧方法此前未注册真实allocator，不能回填真零分配'],
    'limits': ['本机macOS aarch64/actual nightly1d81，无本轮rustup update；无Orin/Linux门、无完整workspace/rootClippy/release', '固定fixture共享生产core；foreign backend自身String/错误分配未由本测试证明无alloc', 'clock回退只覆盖本core观测窗；call budget起点为transport start，编码/lease由source截止约束', 'Some probe不认证真实性；借时钟不认证来源，不承诺内核原子硬截止或撤回已发字节', '未接S0/P1C/runtime/VelocityTX/Enable授权/Phase写，无SSH/UART/服务/正式安装/提交/推送', 'H2/左腕/头部旧FAIL保留，D15 OPEN/DEFERRED，deployable=false；独立人工断电回执不是新GO'],
}
save(OUT / 'summary_r1.json', summary)
print(json.dumps({'manifest': pin(OUT / 'candidate_manifest_r1.json'), 'summary': pin(OUT / 'summary_r1.json'), 'source': current['source_manifest_sha256'], 'six': manifest['changed_sources'], 'roster': pin(OUT / 'test_roster_r1.json'), 'export': pin(export)}, ensure_ascii=False), flush=True)
