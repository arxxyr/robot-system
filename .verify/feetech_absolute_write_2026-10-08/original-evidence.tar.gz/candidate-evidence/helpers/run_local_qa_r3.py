"""本机限定软件门：串行真实子进程wait，不接设备、不更新工具链。"""
import datetime
import hashlib
import importlib.util
import json
import os
import subprocess
import time
from pathlib import Path

WORK = Path('/Users/loosqk/.codex/worktrees/feetech-absolute-write/robot-system')
NATIVE = Path('/Users/loosqk/repo/rust/robot-system/target/b1_freshness_integration_2026-10-08/native-r5')
OUT = WORK / 'target/absolute_write/local_qa_r3'
OUT.mkdir()
spec = importlib.util.spec_from_file_location('artifacts', NATIVE / 'artifacts.py')
a = importlib.util.module_from_spec(spec)
spec.loader.exec_module(a)
commands = []


def save(p, value):
    with p.open('x') as f:
        json.dump(value, f, ensure_ascii=False, indent=2)
        f.write('\n')


def run(name, argv):
    directory = OUT / name
    directory.mkdir()
    env = os.environ.copy()
    env.update(RUSTUP_TOOLCHAIN='nightly', RUSTUP_AUTO_INSTALL='0', CARGO_NET_OFFLINE='true', CARGO_TERM_COLOR='never', PYTHONDONTWRITEBYTECODE='1')
    row = {'name': name, 'argv': argv, 'cwd': str(WORK), 'started_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'started_monotonic_ns': time.monotonic_ns(), 'signals_sent': [], 'reaped': False, 'env_overrides': {k: env[k] for k in ['RUSTUP_TOOLCHAIN', 'RUSTUP_AUTO_INSTALL', 'CARGO_NET_OFFLINE', 'CARGO_TERM_COLOR']}}
    with (directory / 'stdout.log').open('xb') as stdout, (directory / 'stderr.log').open('xb') as stderr:
        child = subprocess.Popen(argv, cwd=WORK, env=env, stdin=subprocess.DEVNULL, stdout=stdout, stderr=stderr, start_new_session=True)
        row['pid'] = child.pid
        save(directory / 'launch.json', row)
        row['actual_exit'] = child.wait()
        row['reaped'] = True
    row['finished_monotonic_ns'] = time.monotonic_ns()
    row['finished_utc'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
    for channel in ['stdout', 'stderr']:
        p = directory / (channel + '.log')
        row[channel] = {'path': str(p), 'bytes': p.stat().st_size, 'sha256': hashlib.sha256(p.read_bytes()).hexdigest()}
    save(directory / 'completion.json', row)
    commands.append(row)
    print(json.dumps({'name': name, 'actual_exit': row['actual_exit'], 'reaped': True}), flush=True)
    return row


inventory = run('git_inventory_before', ['git', 'ls-files', '-z', '--cached', '--others', '--exclude-standard'])
names = (OUT / 'git_inventory_before/stdout.log').read_text().rstrip('\0').split('\0')
before = a.snapshot_source(WORK, names)
save(OUT / 'source_before_fmt.json', before)
result = {'status': 'FAIL', 'source_count_before': len(before['files']), 'no_Orin_SSH_UART': True, 'new_rustup_update': False, 'floating_nightly': True, 'prior_failures': [str(WORK / 'target/absolute_write/local_qa_r1/result.json'), str(WORK / 'target/absolute_write/local_qa_r2/result.json')], 'compiler_parser_scope': 'strict_macOS_raw_fields_not_Linux_ELF', 'tests': 'NOT_RUN'}
try:
    assert inventory['actual_exit'] == 0
    assert run('rustc_before', ['rustc', '+nightly', '-vV'])['actual_exit'] == 0
    assert run('cargo_before', ['cargo', '+nightly', '-V'])['actual_exit'] == 0
    raw = (OUT / 'rustc_before/stdout.log').read_text()
    fields = dict(line.split(': ', 1) for line in raw.splitlines()[1:] if ': ' in line)
    assert fields['host'] == 'aarch64-apple-darwin'
    assert fields['release'] == '1.101.0-nightly'
    compiler = {'commit_hash': fields['commit-hash'], 'host': fields['host'], 'release': fields['release'], 'commit_date': fields['commit-date'], 'llvm_version': fields['LLVM version'], 'raw': raw}
    assert len(raw.splitlines()) == 7
    assert compiler['commit_hash'] == '1d81eb4ad9cd207e3e638bd32b17ec4fce8412a6'
    result['compiler'] = compiler
    steps = [
        ('fmt', ['cargo', '+nightly', 'fmt', '--all']),
        ('clippy_default', ['cargo', '+nightly', 'clippy', '--locked', '-p', 'robot-adapter-feetech', '--all-targets', '--', '-D', 'warnings']),
        ('clippy_real_hw', ['cargo', '+nightly', 'clippy', '--locked', '-p', 'robot-adapter-feetech', '--all-targets', '--features', 'real-hw', '--', '-D', 'warnings']),
        ('absolute_list', ['cargo', '+nightly', 'test', '--locked', '-p', 'robot-adapter-feetech', '--lib', 'post_e_acceptance::absolute::', '--', '--list']),
        ('absolute_tests', ['cargo', '+nightly', 'test', '--locked', '-p', 'robot-adapter-feetech', '--lib', 'post_e_acceptance::absolute::', '--', '--test-threads=1']),
        ('lib_default_list', ['cargo', '+nightly', 'test', '--locked', '-p', 'robot-adapter-feetech', '--lib', '--', '--list']),
        ('lib_default', ['cargo', '+nightly', 'test', '--locked', '-p', 'robot-adapter-feetech', '--lib', '--', '--test-threads=1']),
        ('lib_real_hw_list', ['cargo', '+nightly', 'test', '--locked', '-p', 'robot-adapter-feetech', '--lib', '--features', 'real-hw', '--', '--list']),
        ('lib_real_hw', ['cargo', '+nightly', 'test', '--locked', '-p', 'robot-adapter-feetech', '--lib', '--features', 'real-hw', '--', '--test-threads=1']),
        ('comm_fault_transport', ['cargo', '+nightly', 'test', '--locked', '-p', 'robot-adapter-feetech', '--test', 'comm_fault_transport', '--', '--test-threads=1']),
        ('abort_diagnostics', ['cargo', '+nightly', 'test', '--locked', '-p', 'robot-adapter-feetech', '--test', 'abort_diagnostics', '--', '--test-threads=1']),
    ]
    result['planned_commands'] = [name for name, _ in steps]
    for name, argv in steps:
        row = run(name, argv)
        save(OUT / (name + '_source_after.json'), a.snapshot_source(WORK, names))
        if row['actual_exit'] != 0:
            result['failure_step'] = name
            raise ValueError('实际命令失败，后续门未执行')
    result.update(status='PASS_LOCAL_SCOPED_SOFTWARE', tests='ACTUALLY_COMPLETED_PARSE_PENDING')
except BaseException as error:
    result['error'] = repr(error)
finally:
    run('rustc_after', ['rustc', '+nightly', '-vV'])
    run('cargo_after', ['cargo', '+nightly', '-V'])
    assert (OUT / 'rustc_before/stdout.log').read_bytes() == (OUT / 'rustc_after/stdout.log').read_bytes()
    assert (OUT / 'cargo_before/stdout.log').read_bytes() == (OUT / 'cargo_after/stdout.log').read_bytes()
    save(OUT / 'source_after.json', a.snapshot_source(WORK, names))
    result['commands'] = commands
    result['all_requested_children_natural_reap'] = all(r['reaped'] for r in commands)
    result['compiler_window'] = 'PASS'
    save(OUT / 'result.json', result)
    print(json.dumps({'status': result['status'], 'failure_step': result.get('failure_step'), 'commands': len(commands), 'tests': result['tests']}), flush=True)
raise SystemExit(0 if result['status'].startswith('PASS') else 1)
