"""同源 Lima 提交前fmt/根Clippy/uv合同门；不改旧原件或硬件。"""
import hashlib,importlib.util,json,os,platform,socket,sys
from pathlib import Path
from types import SimpleNamespace
sys.dont_write_bytecode=True
BASE=Path('/home/loosqk.guest/robot-checks/h2-trace-owner-20260930-r4');SOURCE=BASE/'source';OUT=BASE/'root-precommit';CACHE=Path('/home/loosqk.guest/robot-checks/build')
CONTROL=OUT/'control';AGG='83048e983bb7a13c2f75ae23e593ec301f129b10b412db8f4f80176ca434f62f'
def require(ok,msg):
    if not ok:raise ValueError(msg)
def identity(path):
    b=path.read_bytes();return {'path':str(path),'sha256':hashlib.sha256(b).hexdigest(),'bytes':len(b)}
def save(path,val):
    with path.open('x') as s:json.dump(val,s,ensure_ascii=False,indent=2,allow_nan=False);s.write('\n')
def module(name,path):
    spec=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);return m
def fixture_identity():
    root=BASE/'synthetic-owner-fixture';return {str(p.relative_to(root)):{k:v for k,v in identity(p).items() if k!='path'} for p in sorted(root.rglob('*')) if p.is_file()}
require(platform.system()=='Linux' and platform.machine()=='aarch64' and socket.gethostname()=='lima-robot-viz-check' and os.getuid()==501,'隔离Lima身份错误')
require(identity(CONTROL/'owner.py')['sha256']=='96d1c8ed14fa94e62cbfcb0ea28ff60f628bdcf0d76cf3796d968602ce14938a','owner错误')
os.chdir(SOURCE);owner=module('root_precommit_owner',CONTROL/'owner.py');a=module('root_precommit_contract',SOURCE/'scripts/post_e_h2_artifacts.py')
os.environ['PATH']='/home/loosqk.guest/.cargo/bin:/home/loosqk.guest/.local/bin:'+os.environ['PATH'];env,shown,removed=a.fixed_build_environment(CACHE);os.environ.clear();os.environ.update(env)
result={'status':'RUNNING','scope':'隔离Lima提交前门与uv合成软件合同，非新硬件','identity':{'hostname':socket.gethostname(),'machine':platform.machine(),'uid':os.getuid(),'boot_id':Path('/proc/sys/kernel/random/boot_id').read_text().strip()},'commands':[],'environment':shown,'removed_environment_keys':removed,'rust_test_threads_present':'RUST_TEST_THREADS' in os.environ,'deployable':False}
def command(name,argv):
    code=owner.run(SimpleNamespace(label=name,command=argv,observe_seconds=5,input=None));p=CONTROL/(name+'.owner/result.json');r=json.loads(p.read_text());result['commands'].append({'name':name,'argv':argv,'receipt':identity(p),'exit_code':code,'reaped':r['reaped']})
    require(code==0 and r['wait_returncode']==0 and r['phase']=='REAPED' and r['reaped'] and r['owner_sent_signals']==[] and r['received_signals']=={} and r['errors']==[],'未自然成功完成:'+name);return (p.parent/'child.log').read_bytes()
before=None;names=None;fixture_before=None;oracle_before=None
try:
    names=command('inventory_before',['git','ls-files','-z']).decode().rstrip('\0').split('\0');before=a.snapshot_source(SOURCE,names)
    require(before['source_manifest_sha256']==AGG and before==json.loads((CONTROL/'main_source_before.json').read_text()),'主/guest不是589逐项同源');save(OUT/'source_before.json',before)
    head=command('head_before',['git','rev-parse','HEAD']);require(head.decode().strip()=='4a8e171f27bf18625973aa4f3a6097e9b9fbed18','guestHEAD变化')
    status=command('status_before',['git','status','--porcelain=v1','--untracked-files=all']);require(status==b' M crates/robot-s1/src/events_drain/runtime.rs\n M crates/robot-tests/src/comm_fault/sla.rs\n','guest范围变化')
    command('nightly_update',['rustup','update','nightly','--no-self-update'])
    rustc=command('rustc_before',['rustc','-Vv']);cargo=command('cargo_before',['cargo','-V'])
    require(rustc==(BASE/'control/rustc_before.owner/child.log').read_bytes() and cargo==(BASE/'control/cargo_before.owner/child.log').read_bytes(),'实际nightly已变，旧suite不能复用')
    command('fmt',['cargo','fmt','--all']);require(a.snapshot_source(SOURCE,names)==before,'guestfmt改变源')
    command('root_clippy',['cargo','clippy','--locked','--offline','--all','--all-targets','--','-D','warnings'])
    fixture_before=fixture_identity();oracle_before=identity(BASE/'control/python_oracle.py');save(OUT/'fixture_before.json',fixture_before)
    require(oracle_before['sha256']==identity(CONTROL/'python_oracle.py')['sha256'],'未使用冻结同oracle')
    result['uv_identity']=command('uv_identity',['uv','--version']).decode()
    result['python_identity']=json.loads(command('uv_python_identity',['uv','run','--no-project','python','-c','import sys,json; print(json.dumps({"executable":sys.executable,"version":sys.version,"version_info":list(sys.version_info)}))']).decode().splitlines()[-1])
    command('python_oracle_uv',['uv','run','--no-project','python',str(BASE/'control/python_oracle.py'),str(SOURCE),str(BASE/'synthetic-owner-fixture'),str(OUT/'python-oracle-uv-final')])
    result['python_oracle_uv']=json.loads((OUT/'python-oracle-uv-final/result.json').read_text());require(result['python_oracle_uv']['status']=='PASS','uv严格合同未通过')
    fixture_after=fixture_identity();save(OUT/'fixture_after.json',fixture_after);require(fixture_before==fixture_after and identity(BASE/'control/python_oracle.py')==oracle_before,'原fixture/oracle改变')
    result.update(fixture_before_after_equal=True,oracle_before_after_equal=True,oracle=oracle_before)
    require(command('rustc_after',['rustc','-Vv'])==rustc and command('cargo_after',['cargo','-V'])==cargo,'编译器窗口改变');result['compiler_before_after_equal']=True
    after_names=command('inventory_after',['git','ls-files','-z']).decode().rstrip('\0').split('\0');require(after_names==names,'fresh inventory变化')
    require(command('head_after',['git','rev-parse','HEAD'])==head and command('status_after',['git','status','--porcelain=v1','--untracked-files=all'])==status,'验证后身份改变')
    command('diff_check',['git','diff','--check']);result.update(status='PASS',source_manifest_sha256=AGG,source_before_after_equal=True)
except BaseException as e:result.update(status='FAIL',error=repr(e))
finally:
    if names is not None:
        after=a.snapshot_source(SOURCE,names);save(OUT/'source_after.json',after);result['source_before_after_equal']=after==before
        if after!=before:result['status']='FAIL'
    save(OUT/'result.json',result)
print(json.dumps(result,ensure_ascii=False),flush=True);raise SystemExit(0 if result['status']=='PASS' else 1)
