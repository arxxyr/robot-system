"""主树提交前fmt及逐文件身份；只写隔离证据目录。"""
import hashlib,importlib.util,json,os,subprocess,sys
from pathlib import Path
from types import SimpleNamespace
sys.dont_write_bytecode=True
ROOT=Path('/Users/loosqk/repo/rust/robot-system');OUT=ROOT/'target/h2_trace_root_integration';CONTROL=OUT/'control'
def module(name,path):
    spec=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);return m
def identity(path):
    b=path.read_bytes();return {'path':str(path),'sha256':hashlib.sha256(b).hexdigest(),'bytes':len(b)}
def save(path,value):
    with path.open('x') as s:json.dump(value,s,ensure_ascii=False,indent=2,allow_nan=False);s.write('\n')
def require(ok,message):
    if not ok:raise ValueError(message)
os.chdir(ROOT);a=module('precommit_contract',ROOT/'scripts/post_e_h2_artifacts.py');owner=module('precommit_owner',CONTROL/'owner.py');result={'status':'RUNNING','scope':'主树提交前fmt与身份，不改源码语义、不提交','commands':[]}
require(identity(CONTROL/'owner.py')['sha256']=='96d1c8ed14fa94e62cbfcb0ea28ff60f628bdcf0d76cf3796d968602ce14938a','owner错')
def command(name,argv):
    rc=owner.run(SimpleNamespace(label=name,command=argv,observe_seconds=5,input=None));p=CONTROL/(name+'.owner/result.json');r=json.loads(p.read_text());result['commands'].append({'name':name,'argv':argv,'receipt':identity(p),'exit_code':rc,'reaped':r['reaped']})
    require(rc==0 and r['wait_returncode']==0 and r['phase']=='REAPED' and r['reaped'] and r['owner_sent_signals']==[] and r['received_signals']=={} and r['errors']==[],'命令失败:'+name);return (p.parent/'child.log').read_bytes()
before=None;names=None
try:
    names=command('main_inventory_before',['git','ls-files','-z']).decode().rstrip('\0').split('\0');before=a.snapshot_source(ROOT,names);save(OUT/'main_source_before.json',before)
    require(before['source_manifest_sha256']=='83048e983bb7a13c2f75ae23e593ec301f129b10b412db8f4f80176ca434f62f','主树非冻结同源')
    head=command('main_head',['git','rev-parse','HEAD']);require(head.decode().strip()=='148663b88753c182192b2c1420eb4be68c065e53','主树HEAD改变')
    status=command('main_status_before',['git','status','--porcelain=v1','--untracked-files=all']);require(status==b' M crates/robot-tests/src/comm_fault/sla.rs\n','主树范围变化')
    command('main_nightly_update',['rustup','update','nightly','--no-self-update'])
    rustc=command('main_rustc',['rustc','-Vv']);cargo=command('main_cargo',['cargo','-V']);require(b'nightly' in rustc,'非nightly')
    command('main_fmt',['cargo','fmt','--all'])
    after_names=command('main_inventory_after',['git','ls-files','-z']).decode().rstrip('\0').split('\0');require(after_names==names,'inventory改变')
    after=a.snapshot_source(ROOT,after_names);require(after==before,'主树fmt改变输入身份')
    require(command('main_status_after',['git','status','--porcelain=v1','--untracked-files=all'])==status,'主树fmt改变状态')
    result.update(status='PASS',source_before_after_equal=True,source_manifest_sha256=before['source_manifest_sha256'],sla=identity(ROOT/'crates/robot-tests/src/comm_fault/sla.rs'),head=head.decode().strip())
except BaseException as e:result.update(status='FAIL',error=repr(e))
finally:
    if names is not None:
        after=a.snapshot_source(ROOT,names);save(OUT/'main_source_after.json',after);result['source_before_after_equal']=after==before
        if after!=before:result['status']='FAIL'
    save(OUT/'main_fmt_result.json',result)
print(json.dumps(result,ensure_ascii=False));raise SystemExit(0 if result['status']=='PASS' else 1)
