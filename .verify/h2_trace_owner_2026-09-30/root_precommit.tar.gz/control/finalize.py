"""提交前原件校验、摘要与独立小包；原冻结包不修改。"""
import hashlib,io,json,stat,tarfile
from pathlib import Path,PurePosixPath
ROOT=Path('/Users/loosqk/repo/rust/robot-system');BASE=ROOT/'target/h2_trace_root_integration';OUT=BASE/'native-extracted';OUT.mkdir()
def sha(b):return hashlib.sha256(b).hexdigest()
def ref(p):
    b=p.read_bytes();return {'path':str(p),'sha256':sha(b),'bytes':len(b)}
def save(p,v):
    with p.open('x') as s:json.dump(v,s,ensure_ascii=False,indent=2,allow_nan=False);s.write('\n')
col=json.loads((BASE/'control/collect_guest.owner/child.log').read_text());archive=BASE/'root_precommit.native.tar.gz';idx=BASE/'root_precommit.native.index.json';raw=idx.read_bytes();index=json.loads(raw)
assert ref(archive)['sha256']==col['archive']['sha256'] and ref(archive)['bytes']==col['archive']['bytes'];assert ref(idx)['sha256']==col['index']['sha256'] and len(raw)==col['index']['bytes']
seen=set()
with tarfile.open(archive,'r:gz') as tar:
    for item in tar:
        name=item.name;p=PurePosixPath(name);assert item.isfile() and name not in seen and not p.is_absolute() and '..' not in p.parts and str(p)==name;seen.add(name);b=tar.extractfile(item).read()
        if name=='index.json':assert b==raw;info={'executable':False}
        else:
            info=index['files'][name];assert sha(b)==info['sha256'] and len(b)==info['bytes']
        assert bool(item.mode&stat.S_IXUSR)==info['executable'];dst=OUT/name;dst.parent.mkdir(parents=True,exist_ok=True)
        with dst.open('xb') as s:s.write(b)
        dst.chmod(0o755 if info['executable'] else 0o644)
assert seen==set(index['files'])|{'index.json'}
r=json.loads((OUT/'result.json').read_text());m=json.loads((BASE/'main_fmt_result.json').read_text());assert r['status']==m['status']=='PASS'
assert json.loads((OUT/'source_before.json').read_text())==json.loads((OUT/'source_after.json').read_text())==json.loads((BASE/'main_source_before.json').read_text())==json.loads((BASE/'main_source_after.json').read_text())
assert r['source_before_after_equal'] and r['compiler_before_after_equal'] and r['fixture_before_after_equal'] and r['oracle_before_after_equal']
# 全部真实回执逐份核日志，无信号/无回收错误。
receipts=[]
for p in sorted(BASE.rglob('*.owner/result.json')):
    v=json.loads(p.read_text());assert v['phase']=='REAPED' and v['reaped'] and v['wait_returncode']==0 and v['owner_sent_signals']==[] and v['received_signals']=={} and v['errors']==[];b=(p.parent/'child.log').read_bytes();assert len(b)==v['log']['bytes'] and sha(b)==v['log']['sha256'];receipts.append({'path':str(p.relative_to(BASE)),'owner_pid':v['owner_pid'],'child_pid':v['pid'],'wait_returncode':0,'reaped':True})
assert len(receipts)==30
prior=Path('/Users/loosqk/.codex/worktrees/serial-periodic-recovery/robot-system/target/h2-trace-owner');old_oracle=json.loads((prior/'linux-r4/native-extracted/r4/python-oracle/result.json').read_text());assert old_oracle==r['python_oracle_uv']
assert ref(prior/'summary.json')['sha256']=='4c62e24b74960801c3fc6b7b963ff4c9e10966450ed944d28b8d12fc199980ce'
assert ref(prior.parent/'h2-trace-owner-evidence.tar.gz')['sha256']=='1e1942aad80ebf775ca47144c5fb6a242568fdb77118dbeed3ea334864fb1721'
summary={'schema':'H2_TRACE_ROOT_PRECOMMIT_V1','status':'PASS','scope':'提交前fmt/根Clippy与uv合同补验，纯软件；不重跑194/长载，不是新硬件。','main_head':m['head'],'main_fmt':ref(BASE/'main_fmt_result.json'),'guest_result':ref(OUT/'result.json'),'main_guest_source_equal':True,'source_files':589,'aggregate':r['source_manifest_sha256'],'sla':ref(ROOT/'crates/robot-tests/src/comm_fault/sla.rs'),'compiler_and_source_before_after_equal':True,'nightly_updated_both_hosts':True,'guest_rustc':(OUT/'control/rustc_before.owner/child.log').read_text(),'guest_cargo':(OUT/'control/cargo_before.owner/child.log').read_text(),'commands':'主树cargo fmt --all，guest cargo fmt --all → cargo clippy --locked --offline --all --all-targets -- -D warnings','uv_python_oracle':{'status':'PASS','uv':r['uv_identity'],'python':r['python_identity'],'oracle':r['oracle'],'result':ref(OUT/'python-oracle-uv-final/result.json'),'same_as_original_r4_contract_result':True,'fixture_before_after_equal':True,'source_and_compiler_before_after_equal':True,'scope':'同冻结oracle及4401epoch/4000formal合成fixture，以uv入口全新输出重复严格合同验证，不累计新Rust测试/硬件PASS。','invocation':next(x['argv'] for x in r['commands'] if x['name']=='python_oracle_uv')},'native_archive':ref(archive),'native_index':ref(idx),'indexed_files':len(index['files']),'members':len(seen),'identity_and_mode_verified':True,'actual_owned_receipts':len(receipts),'receipts':receipts,'owned_sessions_remaining':[],'native_process_check':ref(OUT/'owned_sessions_after.json'),'frozen_previous_summary_and_archive_unchanged':True,'integration':'root负责提交，无源码内容变化、安装、Orin/UART访问或commit/push。'}
save(BASE/'summary.json',summary)
# 小包仅包含本次原件和摘要，不重复解包树。
paths=[p for p in BASE.rglob('*') if p.is_file() and 'native-extracted' not in p.parts];entries={}
for p in sorted(paths):
    b=p.read_bytes();entries[str(p.relative_to(BASE))]={'sha256':sha(b),'bytes':len(b),'executable':bool(p.stat().st_mode&stat.S_IXUSR)}
outer_index={'schema':'H2_TRACE_ROOT_PRECOMMIT_OUTER_V1','files':entries};raw_index=(json.dumps(outer_index,sort_keys=True,ensure_ascii=False,indent=2)+'\n').encode();pack=ROOT/'target/h2_trace_root_precommit.tar.gz';packidx=ROOT/'target/h2_trace_root_precommit.index.json'
with packidx.open('xb') as s:s.write(raw_index)
with tarfile.open(pack,'x:gz') as tar:
    for name,item in entries.items():
        b=(BASE/name).read_bytes();assert sha(b)==item['sha256'];meta=tarfile.TarInfo(name);meta.size=len(b);meta.mode=0o755 if item['executable'] else 0o644;tar.addfile(meta,io.BytesIO(b))
    meta=tarfile.TarInfo('outer-index.json');meta.size=len(raw_index);meta.mode=0o644;tar.addfile(meta,io.BytesIO(raw_index))
seen=set()
with tarfile.open(pack,'r:gz') as tar:
    for item in tar:
        assert item.isfile() and item.name not in seen;seen.add(item.name);b=tar.extractfile(item).read()
        if item.name=='outer-index.json':assert b==raw_index
        else:
            expected=entries[item.name];assert sha(b)==expected['sha256'] and len(b)==expected['bytes'] and bool(item.mode&stat.S_IXUSR)==expected['executable']
assert seen==set(entries)|{'outer-index.json'}
verification={'status':'PASS','archive':ref(pack),'index':ref(packidx),'files':len(entries),'members':len(seen),'sha_bytes_mode_verified':True,'summary':ref(BASE/'summary.json')};save(BASE/'outer_archive_verification.json',verification);print(json.dumps(verification,ensure_ascii=False,indent=2))
