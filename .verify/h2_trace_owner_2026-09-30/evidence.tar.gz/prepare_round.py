"""生成全新隔离软件源与控制脚本，不覆盖既有原件。"""
from pathlib import Path
import hashlib,json,importlib.util,subprocess,base64,sys
sys.dont_write_bytecode=True
root=Path.cwd();round_name=sys.argv[1];base=root/('target/h2-trace-owner/linux-'+round_name+'/control');base.mkdir(parents=True)
old=root/'target/h2-trace-owner/linux-r2/control'
source=root/'crates/robot-tests/src/comm_fault/sla.rs';sha=hashlib.sha256(source.read_bytes()).hexdigest()
runner=(old/'run_linux.py').read_text().replace('h2-trace-owner-20260930-r2','h2-trace-owner-20260930-'+round_name).replace('9671029e2bcc3b34684d98e77f2ba2cb970e81a634ad27eed2697fcbb646905b',sha)
(base/'run_linux.py').write_text(runner)
for name,p in [('owner.py',old/'owner.py'),('runtime.rs',root/'crates/robot-s1/src/events_drain/runtime.rs'),('sla.rs',source),('python_oracle.py',root/'target/h2-trace-owner/python_oracle.py')]:
    (base/name).write_bytes(p.read_bytes())
spec=importlib.util.spec_from_file_location('contract',root/'scripts/post_e_h2_artifacts.py');a=importlib.util.module_from_spec(spec);spec.loader.exec_module(a)
names=subprocess.run(['git','ls-files','-z'],check=True,capture_output=True).stdout.decode().rstrip('\0').split('\0');expected=a.snapshot_source(root,names)
(base/'expected_inputs.json').write_text(json.dumps(expected,ensure_ascii=False,indent=2)+'\n')
(base/'candidate.patch').write_bytes(subprocess.run(['git','diff','--','crates/robot-tests/src/comm_fault/sla.rs'],check=True,capture_output=True).stdout)
files={p.name:base64.b64encode(p.read_bytes()).decode() for p in base.iterdir() if p.is_file()}
remote='/home/loosqk.guest/robot-checks/h2-trace-owner-20260930-'+round_name
script="set -eu\nexport PATH=/home/loosqk.guest/.cargo/bin:/home/loosqk.guest/.local/bin:$PATH\nuv run --no-project python - <<'SETUP_PY'\nimport base64,pathlib\nbase=pathlib.Path("+repr(remote)+")\nbase.mkdir()\ncontrol=base/'control'\ncontrol.mkdir()\nfiles="+repr(files)+"\nfor name,encoded in files.items():\n    with (control/name).open('xb') as stream:\n        stream.write(base64.b64decode(encoded,validate=True))\nSETUP_PY\nexec uv run --no-project python "+remote+"/control/run_linux.py\n"
(base/'setup_and_run.sh').write_text(script)
print(json.dumps({'sla':sha,'bytes':source.stat().st_size,'aggregate':expected['source_manifest_sha256'],'files':len(expected['files'])}))
