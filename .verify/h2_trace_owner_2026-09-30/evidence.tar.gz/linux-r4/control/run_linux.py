"""隔离 Lima H2 trace owner 软件验收；每条命令复用已审非 kill owner，自然 wait 后才接下一条。"""

import hashlib
import importlib.util
import json
import os
from pathlib import Path
import platform
import re
import socket
import sys
from types import SimpleNamespace

sys.dont_write_bytecode = True
BASE = Path("/home/loosqk.guest/robot-checks/h2-trace-owner-20260930-r4")
SOURCE = BASE / "source"
CONTROL = BASE / "control"
CACHE = Path("/home/loosqk.guest/robot-checks/build")
HEAD = "4a8e171f27bf18625973aa4f3a6097e9b9fbed18"
RELATIVE = "crates/robot-tests/src/comm_fault/sla.rs"
S1_RELATIVE = "crates/robot-s1/src/events_drain/runtime.rs"
FINAL_SOURCE_SHA = "167dc63b2a274b53d9c53fe72c811d242d8ca96d5f031e1bf0ea9981cbd78e18"
OWNER_SHA = "96d1c8ed14fa94e62cbfcb0ea28ff60f628bdcf0d76cf3796d968602ce14938a"


def require(condition, message):
    if not condition:
        raise ValueError(message)


def identity(path):
    raw = path.read_bytes()
    return {"path": str(path), "sha256": hashlib.sha256(raw).hexdigest(), "bytes": len(raw)}


def save(path, value):
    with path.open("x") as stream:
        json.dump(value, stream, ensure_ascii=False, indent=2, allow_nan=False)
        stream.write("\n")


def load_module(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def main():
    require(platform.system() == "Linux" and platform.machine() == "aarch64"
            and socket.gethostname() == "lima-robot-viz-check" and os.getuid() == 501,
            "拒绝非指定隔离 Lima 身份")
    require(not SOURCE.exists() and CACHE.is_dir(), "源码目录必须全新；只复用既有 Cargo 缓存")
    require(identity(CONTROL / "owner.py")["sha256"] == OWNER_SHA, "非 kill owner 身份错误")
    owner = load_module("h2_trace_owned_command", CONTROL / "owner.py")
    os.chdir(BASE)
    result = {"status": "RUNNING", "scope": "隔离 Linux 软件，未 SSH robot/Orin 或访问硬件",
              "head": HEAD, "identity": {"hostname": socket.gethostname(), "machine": platform.machine(),
                                         "uid": os.getuid(), "boot_id": Path("/proc/sys/kernel/random/boot_id").read_text().strip()},
              "commands": [], "source": str(SOURCE), "cache": str(CACHE), "deployable": False}

    def command(name, argv):
        code = owner.run(SimpleNamespace(label=name, command=argv, observe_seconds=5.0, input=None))
        receipt = CONTROL / (name + ".owner/result.json")
        row = json.loads(receipt.read_text())
        result["commands"].append({"name": name, "argv": argv, "receipt": identity(receipt),
                                    "exit_code": code, "reaped": row["reaped"]})
        require(code == 0 and row["status"] == "PASS" and row["phase"] == "REAPED"
                and row["reaped"] is True and row["wait_returncode"] == 0
                and row["owner_sent_signals"] == [] and row["received_signals"] == {}
                and row["errors"] == [], "命令未自然成功完成：" + name)
        return (CONTROL / (name + ".owner/child.log")).read_bytes()

    before = None
    artifacts = None
    inventory = None
    try:
        command("clone", ["git", "clone", "--no-hardlinks", "/Users/loosqk/repo/rust/robot-system", str(SOURCE)])
        command("checkout", ["git", "-C", str(SOURCE), "checkout", "--detach", HEAD])
        require(command("baseline_status", ["git", "-C", str(SOURCE), "status", "--porcelain=v1",
                                             "--untracked-files=all"]) == b"", "原始 checkout 不 clean")
        require(identity(CONTROL / "sla.rs")["sha256"] == FINAL_SOURCE_SHA, "最终补丁身份错误")
        (SOURCE / RELATIVE).write_bytes((CONTROL / "sla.rs").read_bytes())
        require(identity(CONTROL / "runtime.rs")["sha256"] == "f0aaae567e7100ed903acef64504c038ce9f0cda6cd5b394ab8539afecbd0a40", "冻结S1身份变化")
        (SOURCE / S1_RELATIVE).write_bytes((CONTROL / "runtime.rs").read_bytes())
        os.chdir(SOURCE)
        os.environ["PATH"] = "/home/loosqk.guest/.cargo/bin:/home/loosqk.guest/.local/bin:" + os.environ["PATH"]
        artifacts = load_module("h2_trace_source_contract", SOURCE / "scripts/post_e_h2_artifacts.py")
        env, shown, removed = artifacts.fixed_build_environment(CACHE)
        os.environ.clear()
        os.environ.update(env)
        result.update(build_environment=shown, removed_environment_keys=removed,
                      rust_test_threads_present="RUST_TEST_THREADS" in os.environ)
        require("RUST_TEST_THREADS" not in os.environ, "不得设置测试线程覆盖")
        inventory = command("inventory_before", ["git", "ls-files", "-z"]).decode().rstrip("\0").split("\0")
        before = artifacts.snapshot_source(SOURCE, inventory)
        expected = json.loads((CONTROL / "expected_inputs.json").read_text())
        require(before == expected, "Linux 逐文件输入与本机最终候选不同")
        save(BASE / "source_before.json", before)
        result["source_manifest_sha256"] = before["source_manifest_sha256"]
        require(command("head_before", ["git", "rev-parse", "HEAD"]).decode().strip() == HEAD, "HEAD 不符")
        status = command("status_before", ["git", "status", "--porcelain=v1", "--untracked-files=all"])
        require(status == (" M " + S1_RELATIVE + "\n M " + RELATIVE + "\n").encode(), "只有最终测试夹具允许修改")
        command("nightly_update", ["rustup", "update", "nightly", "--no-self-update"])
        command("nightly_components", ["rustup", "component", "add", "--toolchain", "nightly", "rustfmt", "clippy"])
        rustc_before = command("rustc_before", ["rustc", "-Vv"])
        cargo_before = command("cargo_before", ["cargo", "-V"])
        require(b"nightly" in rustc_before and b"host: aarch64-unknown-linux-gnu" in rustc_before,
                "实际工具链不符")
        command("fmt", ["cargo", "fmt", "--all"])
        require(artifacts.snapshot_source(SOURCE, inventory) == before, "fmt 改变候选输入")
        command("clippy_all", ["cargo", "clippy", "--locked", "--offline", "--all", "--all-targets", "--", "-D", "warnings"])
        command("clippy_feature", ["cargo", "clippy", "--locked", "--offline", "-p", "robot-tests", "--features", "comm-fault-e2e", "--all-targets", "--", "-D", "warnings"])
        os.environ["H2_OWNER_SOFTWARE_FIXTURE_DIR"] = str(BASE / "synthetic-owner-fixture")
        result["fixture_export_environment"] = {"H2_OWNER_SOFTWARE_FIXTURE_DIR": os.environ["H2_OWNER_SOFTWARE_FIXTURE_DIR"]}
        test_log = command("feature_suite", ["cargo", "test", "--locked", "--offline", "-p", "robot-tests", "--features", "comm-fault-e2e", "--bin", "comm_fault_e2e"])
        os.environ.pop("H2_OWNER_SOFTWARE_FIXTURE_DIR")
        text = test_log.decode(errors="strict")
        groups = re.findall(r"test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored;", text)
        require(len(groups) == 1 and int(groups[0][0]) >= 12 and groups[0][1:] == ("0", "0"), "完整feature suite未全过")
        owner_passes = re.findall(r"test comm_fault::sla::owner_tests::[^ ]+ \.\.\. ok", text)
        require(len(owner_passes) == 12, "12项owner oracle必须为完整suite已验子集")
        result["feature_suite"] = {"passed": int(groups[0][0]), "failed": 0, "ignored": 0, "test_threads_override": None, "owner_tests_subset": 12}
        command("python_oracle", [sys.executable, str(CONTROL / "python_oracle.py"), str(SOURCE), str(BASE / "synthetic-owner-fixture"), str(BASE / "python-oracle")])
        result["python_oracle"] = json.loads((BASE / "python-oracle/result.json").read_text())
        require(command("rustc_after", ["rustc", "-Vv"]) == rustc_before
                and command("cargo_after", ["cargo", "-V"]) == cargo_before, "验证窗口编译器改变")
        result["compiler_before_after_equal"] = True
        command("diff_check", ["git", "diff", "--check"])
        inventory_after = command("inventory_after", ["git", "ls-files", "-z"]).decode().rstrip("\0").split("\0")
        require(inventory_after == inventory, "验证后 fresh Git inventory 改变")
        require(command("head_after", ["git", "rev-parse", "HEAD"]).decode().strip() == HEAD
                and command("status_after", ["git", "status", "--porcelain=v1", "--untracked-files=all"]) == status,
                "验证后 Git 身份改变")
        result["status"] = "PASS"
    except BaseException as error:
        result.update(status="FAIL", error=repr(error))
    finally:
        if artifacts is not None and inventory is not None:
            try:
                after = artifacts.snapshot_source(SOURCE, inventory)
                save(BASE / "source_after.json", after)
                result["source_before_after_equal"] = before is not None and before == after
                if result["source_before_after_equal"] is not True:
                    result["status"] = "FAIL"
            except BaseException as error:
                result.update(status="FAIL", source_after_error=repr(error))
        save(BASE / "result.json", result)
    print(json.dumps(result, ensure_ascii=False), flush=True)
    return 0 if result["status"] == "PASS" else 1


if __name__ == "__main__":
    raise SystemExit(main())
