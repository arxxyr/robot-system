"""候选新源码三件独立冻结与一次短 mock；不含 real-hw、不触 UART。"""
from collections import Counter
import hashlib,importlib.util,json,os,platform,shutil,socket,sys,tomllib
from pathlib import Path
from types import SimpleNamespace
sys.dont_write_bytecode=True
BASE=Path('/home/loosqk.guest/robot-checks/h2-trace-owner-20260930-r4')
SOURCE=BASE/'source';CONTROL=BASE/'post-control';OUT=BASE/'post-mock';BINS=OUT/'frozen';CACHE=Path('/home/loosqk.guest/robot-checks/build')
SHA='167dc63b2a274b53d9c53fe72c811d242d8ca96d5f031e1bf0ea9981cbd78e18'

def require(ok,message):
    if not ok: raise ValueError(message)
def identity(path):
    data=path.read_bytes();return {'path':str(path),'sha256':hashlib.sha256(data).hexdigest(),'bytes':len(data)}
def save(path,value):
    with path.open('x') as stream: json.dump(value,stream,ensure_ascii=False,indent=2,allow_nan=False);stream.write('\n')
def load(name,path):
    spec=importlib.util.spec_from_file_location(name,path);mod=importlib.util.module_from_spec(spec);spec.loader.exec_module(mod);return mod

def main():
    require(platform.system()=='Linux' and platform.machine()=='aarch64' and socket.gethostname()=='lima-robot-viz-check' and os.getuid()==501,'隔离身份不符')
    require(json.loads((BASE/'result.json').read_text())['status']=='PASS','前门必须全PASS')
    require(identity(SOURCE/'crates/robot-tests/src/comm_fault/sla.rs')['sha256']==SHA,'冻结源码不同')
    OUT.mkdir();BINS.mkdir();os.chdir(SOURCE)
    owner=load('post_owned_command',CONTROL/'owner.py');require(identity(CONTROL/'owner.py')['sha256']=='96d1c8ed14fa94e62cbfcb0ea28ff60f628bdcf0d76cf3796d968602ce14938a','owner身份不符')
    a=load('post_source_contract',SOURCE/'scripts/post_e_h2_artifacts.py')
    os.environ['PATH']='/home/loosqk.guest/.cargo/bin:/home/loosqk.guest/.local/bin:'+os.environ['PATH']
    env,shown,removed=a.fixed_build_environment(CACHE);os.environ.clear();os.environ.update(env)
    result={'status':'RUNNING','scope':'隔离Lima三件软件构建、冻结、唯一AC12短mock；无Orin/UART/硬件宣称','commands':[],'artifacts':{},'environment':shown,'removed_environment_keys':removed,'deployable':False}
    def command(name,argv):
        code=owner.run(SimpleNamespace(label=name,command=argv,observe_seconds=5,input=None));receipt=CONTROL/(name+'.owner/result.json');row=json.loads(receipt.read_text())
        result['commands'].append({'name':name,'argv':argv,'receipt':identity(receipt),'exit_code':code,'reaped':row['reaped']})
        require(code==0 and row['phase']=='REAPED' and row['wait_returncode']==0 and row['reaped'] and row['owner_sent_signals']==[] and row['received_signals']=={} and row['errors']==[],'命令未自然成功完成:'+name)
        return (CONTROL/(name+'.owner/child.log')).read_bytes()
    before=None;inventory=None
    try:
        inventory=command('inventory_before',['git','ls-files','-z']).decode().rstrip('\0').split('\0')
        before=a.snapshot_source(SOURCE,inventory);require(before==json.loads((BASE/'source_before.json').read_text()),'独立后验源变化');save(OUT/'source_before.json',before)
        rustc=command('rustc_before',['rustc','-Vv']);cargo=command('cargo_before',['cargo','-V'])
        require(rustc==(BASE/'control/rustc_before.owner/child.log').read_bytes() and cargo==(BASE/'control/cargo_before.owner/child.log').read_bytes(),'验证编译器改变')
        recipes=[('s0','robot-s0','s0_daemon',['mock','rt_guard','test-comm-fault-hook'],['mock','rt_guard','test-comm-fault-hook']),('gateway','robot-rpc','robot_rpc_gateway',['test-comm-fault-hook'],['test-comm-fault-hook']),('tool','robot-tests','comm_fault_e2e',['comm-fault-e2e'],['comm-fault-e2e','comm-fault-rpc'])]
        for label,package,name,requested,expected in recipes:
            argv=['cargo','build','--locked','--offline','--message-format=json','-p',package,'--bin',name,'--no-default-features','--features',','.join(requested)]
            log=command('build_'+label,argv);messages=[json.loads(line) for line in log.decode().splitlines() if line.startswith('{')]
            ends=[row for row in messages if row.get('reason')=='build-finished'];require(len(ends)==1 and ends[0]['success'] is True,'Cargo build-finished错误')
            binaries=[row for row in messages if row.get('reason')=='compiler-artifact' and row.get('target',{}).get('name')==name and row.get('executable')]
            require(len(binaries)==1,'实际bin不是唯一');artifact=binaries[0]
            require(artifact['target']['kind']==['bin'] and artifact['profile']['test'] is False and sorted(artifact['features'])==expected,'Cargo profile/features错误')
            source=Path(artifact['executable']);require(source==CACHE/'debug'/name and source.is_file(),'实际构建路径错误');info=identity(source)
            require(source.read_bytes()[:4]==b'\x7fELF','非ELF');shutil.copy2(source,BINS/name);frozen=identity(BINS/name)
            require(info['sha256']==frozen['sha256'] and info['bytes']==frozen['bytes'],'冻结身份不符')
            manifest={**frozen,'features':expected,'profile':'dev','command':argv,'exit_code':0,'head':'4a8e171f27bf18625973aa4f3a6097e9b9fbed18','source_manifest_sha256':before['source_manifest_sha256'],'cargo_artifact':artifact,'receipt':result['commands'][-1]['receipt'],'compiler_sha256':hashlib.sha256(rustc).hexdigest()}
            save(BINS/(name+'.build.json'),manifest);result['artifacts'][name]={**manifest,'sidecar':identity(BINS/(name+'.build.json'))}
        command('mock_ac12',[str(BINS/'comm_fault_e2e'),'--phase','mock','--case','AC-12','--bin-dir',str(BINS),'--evidence-dir',str(OUT/'mock-ac12')])
        report=json.loads((OUT/'mock-ac12/report.json').read_text());result['mock']=validate_mock(report,{'artifacts':result['artifacts']},OUT/'mock-ac12');result['report']=identity(OUT/'mock-ac12/report.json')
        final=json.loads((OUT/'mock-ac12/000_runtime_sla_probe/final_trace.json').read_text())
        require(final['event_capture_error'] is None and final['owner_count']==8 and final['final_events_drained'] is True,'新owner门未通过')
        result['final_trace']=final
        alive=[]
        for p in Path('/proc').iterdir():
            if not p.name.isdigit():continue
            try:
                executable=(p/'exe').resolve(strict=True)
                if executable in [BINS/name for name in result['artifacts']]:alive.append({'pid':int(p.name),'exe':str(executable)})
            except (FileNotFoundError,PermissionError,ProcessLookupError):pass
        save(OUT/'processes_after.json',alive);require(alive==[],'冻结三件仍运行')
        for name,manifest in result['artifacts'].items():require(identity(BINS/name)['sha256']==manifest['sha256'],'运行后冻结件变化')
        require(command('rustc_after',['rustc','-Vv'])==rustc and command('cargo_after',['cargo','-V'])==cargo,'编译器窗口变化')
        command('diff_check',['git','diff','--check']);result['status']='PASS'
    except BaseException as error:result.update(status='FAIL',error=repr(error))
    finally:
        if before is not None:
            after=a.snapshot_source(SOURCE,inventory);save(OUT/'source_after.json',after);result['source_before_after_equal']=after==before
            if after!=before:result['status']='FAIL'
        save(OUT/'result.json',result)
    print(json.dumps(result,ensure_ascii=False),flush=True);return 0 if result['status']=='PASS' else 1

def validate_mock(report, measurement, evidence_root):
    """只接受唯一 AC-12/13 软件场景，不能将空报告或物理场景计入通过。"""
    require(report["schema_version"] == 1 and report["status"] == "PASS", "mock 报告未通过")
    invocation = report["invocation"]
    require(invocation["phase"] == "Mock" and invocation["case_filter"] == "AC-12"
            and invocation["config"] is None and invocation["config_sha256"] is None
            and invocation["hardware_id"] is None, "不是批准的无现场参数 mock")
    tool = measurement["artifacts"]["comm_fault_e2e"]
    require(invocation["current_exe"] == tool["path"] and invocation["current_exe_sha256"] == tool["sha256"],
            "mock 运行工具与冻结件不符")
    require(report["hardware"] == {"H1": "NEEDS_HUMAN", "H2": "NEEDS_HUMAN", "H3": "NEEDS_HUMAN", "D15": "OPEN"},
            "软件报告错误宣称硬件通过")
    expected = measurement["artifacts"]
    require(len(report["artifacts"]) == 3 and {row["name"] for row in report["artifacts"]} == set(expected),
            "mock 三件来源集合不符")
    for row in report["artifacts"]:
        item = expected[row["name"]]
        require(row["path"] == item["path"] and row["sha256"] == item["sha256"]
                and row["build"] == {key: value for key, value in item.items() if key != "sidecar"},
                "mock 三件来源与完整 sidecar 不符")
    require(len(report["cases"]) == 1, "mock 不是唯一批准 case")
    case = report["cases"][0]
    require(case["case"] == "runtime_estop_sampling_and_recovery" and case["ac"] == "AC-12/13"
            and case["status"] == "PASS", "mock 场景身份或结果不符")
    data = case["evidence"]
    env, measured = data["environment"], data["measurement"]
    require(env["runtime_only"] is True and env["hardware_only"] is False and env["physical_uart"] is False
            and env["mock_lease"] is True and env["s48_cache_observation"] is False, "mock 环境越界")
    require(measured["runtime_only"] is True and measured["hardware_only"] is False
            and measured["mock_lease"] is True and measured["trace_dropped"] == 0, "mock 测量来源或事件丢失")
    groups = measured["groups"]
    require(len(groups) == 8 and Counter((row["external"], row["in_flight"]) for row in groups)
            == Counter({(False, False): 2, (False, True): 2, (True, False): 2, (True, True): 2}),
            "mock 未完整取得四组各两样本")
    for row in groups:
        require(row["matched"] is True and row["mock_lease"] is True and row["real_rpc_recovery_verified"] is True
                and row["requested_in_flight"] == row["in_flight"], "mock 样本或实际恢复未匹配")
    require(data["final_state"]["ok"] is True and data["final_trace"]["valid"] is True
            and data["final_trace"]["children_stopped"] is True, "mock 最终停止或回收证据失败")
    wire = data["feetech_wire_check"]
    require(wire["hardware_only"] is False and wire["physical_measurement"] is False
            and wire["dropped"] == 0 and wire["truncated"] == 0, "wire 软件记录边界不符")
    directory = evidence_root / "000_runtime_sla_probe"
    require(measured["events_csv"] == str(directory / "events.csv"), "mock 原事件路径越界")
    config = tomllib.loads((directory / "robot.toml").read_text())
    require(len(config["hardware"]) == 1 and config["hardware"][0]["adapter"] == "mock_serial_rt"
            and config["hardware"][0]["auto_enable"] is False
            and "address" not in config["hardware"][0], "mock 实际配置不是无设备软件 adapter")
    for name, expected_value in (("environment.json", env), ("final_stop.json", data["final_state"]),
                                 ("final_trace.json", data["final_trace"])):
        require(json.loads((directory / name).read_text()) == expected_value, "mock 原始文件与报告不一致：" + name)
    require((directory / "events.csv").is_file(), "mock 原事件文件缺失")
    return {"cases": 1, "groups": 4, "samples": 8, "physical_uart": False, "hardware_pass": False}


if __name__ == "__main__":
    raise SystemExit(main())
