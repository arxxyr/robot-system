# H2 trace owner 软件候选

入口为 summary.json，集成文件仅 sla.rs／sla.patch。当前候选源 167dc63b2a27，589 编译输入聚合 83048e983bb7；与主 HEAD148663b 比较仅 sla.rs 不同，588 项输入相同。

隔离 Lima 更新浮动 nightly 后，fmt、根 Clippy、feature Clippy、完整默认并行194项通过（12个owner测试为子集）；原Python严格门验证4401合成epoch、四组4000原正式集合、mismatch与预热排除，旧CAS统计拒绝／完整Rust派生统计通过，5严格反例拒绝。三件无real-hw实际构建和冻结、短AC12 mock四组各2样本及真实收尾通过。

四轮原件和3ELF保存在linux-r4/native-evidence.tar.gz及index，1065项身份核验、80真实VM命令回执；解包在linux-r4/native-extracted。r2/r3 lint FAIL原件保留，未声称单轮全过。受控reservation oracle不是真实RT私有hook；Python完整report使用明确合成fixture，不能作为硬件H2证据。

新增工具容量门为44000 owner、8192 events/epoch、256B行及四组×三kind各8192 distinct bins；越界保留原件并FAIL，不截断。原RT环、SLA/采样/P99及Python严格规则不变。旧H2整体FAIL、D15 OPEN/DEFERRED、deployable=false不变；本轮无硬件、Orin、安装或发布。

候选保持冻结，待独审/root验收与阶段集成；不自动提交或合并。
