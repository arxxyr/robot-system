"""验证原件索引与安全解包；不执行归档源码或ELF。"""
import hashlib,json,stat,tarfile
from pathlib import Path,PurePosixPath
root=Path.cwd();base=root/'target/h2-trace-owner/linux-r4';out=base/'native-extracted';out.mkdir()
def require(ok,message):
    if not ok:raise ValueError(message)
def sha(data):return hashlib.sha256(data).hexdigest()
archive=base/'native-evidence.tar.gz';index_path=base/'native-evidence.index.json';data=archive.read_bytes();raw=index_path.read_bytes()
require(sha(data)=='39197009b3f8715f65ff8e0b57637db697e0ffaca322c0ff16fae495622af470' and len(data)==95468912,'archive身份不符')
require(sha(raw)=='f9942d1c6f6af5f222e48ec751ee7b800f4a61e65911e0cbf621d92072aaa069' and len(raw)==217717,'index身份不符')
index=json.loads(raw);require(index['schema']=='H2_TRACE_OWNER_LINUX_NATIVE_ARCHIVE_INDEX_V1','schema错');items=index['files'];require(len(items)==1065,'索引计数错');seen=set()
with tarfile.open(archive,'r:gz') as tar:
    for item in tar:
        name=item.name;p=PurePosixPath(name);require(not p.is_absolute() and '..' not in p.parts and str(p)==name and name not in seen and item.isfile(),'归档路径或类型错误');seen.add(name);content=tar.extractfile(item).read()
        if name=='index.json':require(content==raw,'内嵌index变化');expected={'executable':False}
        else:
            expected=items[name];require(len(content)==expected['bytes'] and sha(content)==expected['sha256'],'原件identity不同:'+name)
        require(bool(item.mode&stat.S_IXUSR)==expected['executable'],'mode错误')
        dest=out/name;dest.parent.mkdir(parents=True,exist_ok=True)
        with dest.open('xb') as stream:stream.write(content)
        dest.chmod(0o755 if expected['executable'] else 0o644)
require(seen==set(items)|{'index.json'},'归档缺失/多文件')
receipts=[]
for p in out.rglob('*.owner/result.json'):
    r=json.loads(p.read_text());require(r['reaped'] and r['phase']=='REAPED' and r['owner_sent_signals']==[] and r['received_signals']=={} and r['errors']==[],'回收边界不符')
    log=p.parent/'child.log';content=log.read_bytes();require(len(content)==r['log']['bytes'] and sha(content)==r['log']['sha256'],'回执日志身份不符');receipts.append({'path':str(p.relative_to(out)),'owner_pid':r['owner_pid'],'child_pid':r['pid'],'wait_returncode':r['wait_returncode'],'reaped':True})
result={'status':'PASS','archive_sha256':sha(data),'files':len(items),'tar_members':len(seen),'identity_and_mode_verified':True,'true_owned_receipts':len(receipts),'receipts':receipts,'extracted':str(out)}
p=base/'native_archive_verification.json'
with p.open('x') as stream:json.dump(result,stream,ensure_ascii=False,indent=2);stream.write('\n')
print(json.dumps({k:v for k,v in result.items() if k!='receipts'}))
