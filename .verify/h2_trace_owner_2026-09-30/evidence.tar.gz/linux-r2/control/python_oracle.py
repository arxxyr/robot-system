"""仅合成软件合同 oracle：调用未改的严格 reporter，不执行硬件或改旧原件。"""
import copy
import csv
import hashlib
import io
import json
from pathlib import Path
import sys

sys.dont_write_bytecode = True
source, fixture_root, output = map(Path, sys.argv[1:])
sys.path.insert(0, str(source / "scripts"))
sys.path.insert(0, str(source / "scripts/tests"))
import post_e_h2_report as report
from test_run_post_e_h2 import report_fixture


def save(path, value):
    with path.open("x") as stream:
        json.dump(value, stream, ensure_ascii=False, indent=2)
        stream.write("\n")


def reference(path):
    data = path.read_bytes()
    return {"path": str(path), "sha256": hashlib.sha256(data).hexdigest(), "bytes": len(data)}


def read_events(path):
    result = {}
    for row in csv.DictReader(path.read_text().splitlines()):
        for name in ("attempt", "sample_seq", "stamp_ns", "source", "normal_seq", "generation", "a", "b"):
            row[name] = int(row[name])
        result.setdefault(row["sample_seq"], []).append(row)
    return result


fixture = json.loads((fixture_root / "fixture.json").read_text())
assert fixture["kind"] == "SYNTHETIC_OWNER_SOFTWARE_ORACLE" and fixture["physical_uart"] is False
events = read_events(fixture_root / "events.csv")
attempts = fixture["attempts"]
assert len(attempts) == 4401 and len(events) == 4401
assert sum(row["matched"] is False for row in attempts) == 1
for row in attempts:
    report.verify_trace(events[row["sequence"]], row)
formal = {row["sequence"] for row in attempts if row["matched"] and not row["warmup"]}
assert len(formal) == 4000
derivation = json.loads((fixture_root / "cas_derivation.json").read_text())
for group in derivation["groups"]:
    members = {row["sequence"] for row in attempts if row["external"] == group["external"]
               and row["requested_in_flight"] == group["in_flight"] and row["matched"] and not row["warmup"]}
    assert members == set(group["formal_sequences"]) and len(members) == 1000
    original = copy.deepcopy(group["capture"])
    derived = copy.deepcopy(group["derived"])
    for field, kind in (("acquire_cas_retries", "NormalAcquire"), ("serial_claim_cas_retries", "SerialClaim"),
                        ("ipc_claim_cas_retries", "IpcClaim")):
        values = [event["a"] for seq in members for event in events[seq] if event["kind"] == kind]
        assert derived[field] == report.distribution(values) if values else derived[field] is None
        original.pop(field)
        derived.pop(field)
    assert original == derived

# 完整既有 reporter fixture，独立证明旧采集统计拒绝、真实 Rust 同步分布通过。
output.mkdir()
full = output / "full-reporter-fixture"
full.mkdir()
expected = report_fixture(full)
baseline = report.verify_report(full, expected)
evidence = full / report.arm_profile("left").evidence_directory
payload = json.loads((full / "report.json").read_text())
measurement = payload["cases"][0]["evidence"]["measurement"]
groups_before = copy.deepcopy(measurement["groups"])
attempts_bytes = (evidence / "attempts.jsonl").read_bytes()
capture_csv = (evidence / "events.csv").read_bytes()
(output / "report-captured.json").write_bytes((full / "report.json").read_bytes())
(output / "events-captured.csv").write_bytes(capture_csv)
reader = csv.DictReader(io.StringIO(capture_csv.decode()))
fieldnames = reader.fieldnames
rows = list(reader)
for row in [json.loads(line) for line in attempts_bytes.decode().splitlines() if json.loads(line)["attempt"] == 100]:
    matching = next(event for event in rows if event["sample_seq"] == str(row["sequence"]) and event["kind"] == "IpcClaim")
    late = dict(matching, stamp_ns=str(row["t0_ns"] + 250), a="0", b="0")
    rows.append(late)
rows.sort(key=lambda row: (int(row["sample_seq"]), int(row["stamp_ns"])))


def encoded(values):
    stream = io.StringIO()
    writer = csv.DictWriter(stream, fieldnames=fieldnames, lineterminator="\n")
    writer.writeheader()
    writer.writerows(values)
    return stream.getvalue().encode()


complete_csv = encoded(rows)
(evidence / "events.csv").write_bytes(complete_csv)
(output / "events-complete.csv").write_bytes(complete_csv)
try:
    report.verify_report(full, expected)
    raise AssertionError("旧 end-attempt CAS 分布不应通过完整迟到数据")
except ValueError as error:
    old_error = str(error)
    assert "CAS 分布与原trace不同" in old_error
    save(output / "old-cas-stats-rejected.json", {"kind":"EXPECTED_SOFTWARE_REJECTION", "error":old_error})
for group, rust_group in zip(measurement["groups"], fixture["derived_measurement"]["groups"]):
    assert (group["external"], group["in_flight"]) == (rust_group["external"], rust_group["in_flight"])
    for field in ("acquire_cas_retries", "serial_claim_cas_retries", "ipc_claim_cas_retries"):
        group[field] = rust_group[field]
    (evidence / f"sla_{str(group['external']).lower()}_{str(group['in_flight']).lower()}.json").write_text(json.dumps(group))
(full / "report.json").write_text(json.dumps(payload))
accepted = report.verify_report(full, expected)
for before, after in zip(groups_before, measurement["groups"]):
    for field in ("acquire_cas_retries", "serial_claim_cas_retries", "ipc_claim_cas_retries"):
        before.pop(field)
    non_cas = {key:value for key,value in after.items() if key not in ("acquire_cas_retries", "serial_claim_cas_retries", "ipc_claim_cas_retries")}
    assert before == non_cas
assert (evidence / "attempts.jsonl").read_bytes() == attempts_bytes
negatives = []
base_row = next(row for row in rows if row["kind"] == "IpcClaim" and row["b"] == "1")
for label, mutated in (
    ("fault", dict(base_row, kind="FaultIpcCommit")),
    ("unknown_kind", dict(base_row, kind="W4TokenBefore")),
    ("wrong_generation", dict(base_row, generation="999")),
    ("unregistered_epoch", dict(base_row, sample_seq="999999")),
    ("duplicate_success_claim", dict(base_row)),
):
    negative_rows = rows + [mutated]
    negative_rows.sort(key=lambda row: (int(row["sample_seq"]), int(row["stamp_ns"])))
    blob = encoded(negative_rows)
    (output / (label + ".csv")).write_bytes(blob)
    (evidence / "events.csv").write_bytes(blob)
    try:
        report.verify_report(full, expected)
        raise AssertionError("严格报告器漏拒：" + label)
    except ValueError as error:
        negatives.append({"scenario":label,"status":"EXPECTED_REJECTION","error":str(error)})
(evidence / "events.csv").write_bytes(complete_csv)
assert report.verify_report(full, expected) == accepted
result = {"status":"PASS", "kind":"SYNTHETIC_SOFTWARE_ORACLE", "physical_uart":False,
    "rust_trace_verified_epochs":len(attempts), "original_formal_sequences":4000, "groups":4,
    "class_mismatch_retries_preserved":1,
    "full_reporter_baseline":"PASS", "old_cas_stats":"EXPECTED_REJECTION", "old_cas_error":old_error,
    "rust_derived_cas_complete_report":"PASS", "sla_non_cas_and_attempts_unchanged":True,
    "strict_negatives":negatives, "reporter":reference(source / "scripts/post_e_h2_report.py")}
save(output / "result.json", result)
print(json.dumps(result, ensure_ascii=False))
