"""收口当前软件证据；不重跑测试、不改源码或旧硬件证据。"""
import hashlib,json,subprocess,sys
from pathlib import Path
sys.dont_write_bytecode=True
root=Path(__file__).resolve().parents[2];base=Path(__file__).resolve().parent;ex=base/'linux-r4/native-extracted'
sys.path.insert(0,str(root/'scripts'));import post_e_h2_artifacts as a
relative='crates/robot-tests/src/comm_fault/sla.rs';s1='crates/robot-s1/src/events_drain/runtime.rs'
def ref(path):
    blob=path.read_bytes();return {'path':str(path),'sha256':hashlib.sha256(blob).hexdigest(),'bytes':len(blob)}
def save(path,val):
    with path.open('x') as s:json.dump(val,s,ensure_ascii=False,indent=2,allow_nan=False);s.write('\n')
def git(*args):return subprocess.check_output(['git',*args],cwd=root)
source=a.snapshot_source(root,git('ls-files','-z').decode().rstrip('\0').split('\0'))
assert git('rev-parse','HEAD').decode().strip()=='4a8e171f27bf18625973aa4f3a6097e9b9fbed18'
assert git('status','--porcelain=v1','--untracked-files=all').decode()==' M '+s1+'\n M '+relative+'\n'
assert ref(root/relative)['sha256']=='167dc63b2a274b53d9c53fe72c811d242d8ca96d5f031e1bf0ea9981cbd78e18' and ref(root/s1)['sha256']=='f0aaae567e7100ed903acef64504c038ce9f0cda6cd5b394ab8539afecbd0a40'
assert len(source['files'])==589 and source['source_manifest_sha256']=='83048e983bb7a13c2f75ae23e593ec301f129b10b412db8f4f80176ca434f62f'
assert source==json.loads((ex/'r4/source_before.json').read_text())==json.loads((ex/'r4/source_after.json').read_text())
result=json.loads((ex/'r4/result.json').read_text());mock=json.loads((ex/'r4/post-mock/result.json').read_text());post=json.loads((ex/'r4/archive_postchecks.json').read_text());verify=json.loads((base/'linux-r4/native_archive_verification.json').read_text())
assert all(r['status']=='PASS' for r in (result,mock,post,verify))
assert result['feature_suite']=={'passed':194,'failed':0,'ignored':0,'test_threads_override':None,'owner_tests_subset':12}
assert post['owned_sessions_remaining']==[] and verify['true_owned_receipts']==80
with (base/'sla.patch').open('xb') as stream:stream.write(git('diff','--',relative))
checks=[]
for name in ('nightly_update','nightly_components','fmt','clippy_all','clippy_feature','feature_suite','python_oracle'):
    command=next(row for row in result['commands'] if row['name']==name);r=ex/('r4/control/'+name+'.owner/result.json')
    assert command['exit_code']==0 and command['reaped']
    checks.append({'name':name,'argv':command['argv'],'receipt':ref(r),'log':ref(r.parent/'child.log')})
previous=[]
for n in range(1,5):
    rr=json.loads((ex/f'r{n}/result.json').read_text());previous.append({'round':n,'status':rr['status'],'result':ref(ex/f'r{n}/result.json'),'error':rr.get('error'),'aggregate':rr['source_manifest_sha256'],'source_before_after_equal':rr['source_before_after_equal']})
outer=[]
for r in sorted(base.rglob('*.owner/result.json')):
    if 'native-extracted' in r.parts:continue
    value=json.loads(r.read_text());outer.append({'receipt':ref(r),'phase':value['phase'],'wait_returncode':value['wait_returncode'],'reaped':value['reaped'],'owner_pid':value['owner_pid'],'child_pid':value.get('pid'),'errors':value['errors']})
summary={'schema':'H2_TRACE_OWNER_SOFTWARE_CANDIDATE_V1','status':'SOFTWARE_CANDIDATE_PASS_PENDING_INDEPENDENT_AND_ROOT_ACCEPTANCE',
    'scope':'仅通信故障验收工具的事件归属、完整尾窗和CAS证据派生；隔离Lima软件，无Orin/UART、主树修改、commit/push或安装。',
    'source':{'candidate_head':result['head'],'sla':ref(root/relative),'frozen_s1_already_integrated_by_root':ref(root/s1),'files':589,'aggregate':source['source_manifest_sha256'],'fresh_before_after_equal':True,'compiler_before_after_equal':True,'main_input_comparison':ref(base/'source_comparison.json'),'integration_file':relative,'patch':ref(base/'sla.patch')},
    'changes':['真实Arm+matchingReady后注册整次run有界owner；无当前attempt兜底、组间淘汰或Disarm/control注册。','每批原始事件先完整保存；unknown owner:null与stickyFAIL；归属、generation、kind及成功claim唯一性仍严格验证。','collect/wait/afterDisarm共用capture路由，只将当前sample_seq交给原analyze；旧owner迟到事件保原归属。','两children实际stop/reap成功后仅一次最终drain；不新增等待或修改原时序预算。','raw/capture/spool保观测顺序，派生新events.csv按每epoch稳定stamp排序；同stamp保原顺序。','保存原sla_*_capture.json；按原matched且非warmup正式集合，从完整spool有界重算三CAS分布，A/B、population、attempt/mismatch及P99预算逐项不变。'],
    'new_tool_capacity_contract':{'owner_count':44000,'event_count_per_epoch':8192,'event_row_max_bytes':256,'distinct_retry_bins_per_kind_per_group':8192,'groups':4,'retry_kinds':3,'overflow_behavior':'完整保留raw/spool并sticky FAIL，不截断、回退或放宽采样','bounded_read':'读取前regular/bytes门，打开FD复核regular，take(limit+1)限制读取期间增长','arithmetic':'CAS计数、分箱累计和百分位索引乘法均checked，溢出硬拒'},
    'unchanged_contracts':['RT authority、事件环实现、普通/高队列与生产执行代码未改。','原analyze严格门与Python reporter逐字不动。','原100预热+1000正式、最大尝试、等待2秒及SLA A/B/P99预算不变。','原硬件trace/run/FAIL未修改；新工具数据契约不能将旧H2判PASS。'],
    'linux':{'identity':result['identity'],'nightly_update_actually_executed':True,'rustc':(ex/'r4/control/rustc_before.owner/child.log').read_text(),'cargo':(ex/'r4/control/cargo_before.owner/child.log').read_text(),'checks':checks,'feature_suite_default_parallel':result['feature_suite'],'test_count_rule':'12 owner是194子集；r1九项为旧候选重复机制验证，不累加为最终不同测试。','removed_environment_keys':result['removed_environment_keys'],'rust_test_threads_present':False,'source_before_after_equal':True,'compiler_before_after_equal':True},
    'deterministic_oracles':{'owner_tests_subset':12,'route':'生产同一route callback正控与旧owner错gen/fault/unknown全批落盘负控','pause_oracle':'受控队列暂停reservation，不是真实RT ring私有hook，不声称复现实际调度抢占点','tail_child':'真实/bin/sh子进程自然wait/reap后的末epoch尾事件及一次drain','synchronize_cas':'真实方法四组×1000正式，4401epoch含1个requested inflight/actual idle mismatch；预热888888与mismatch999999迟到CAS不污染rank/max。','histogram':'空/单元素/同值/偶数/重复/101边界逐字段与原distribution相等及容量/算术溢出负控'},
    'python_contract_oracle':{**result['python_oracle'],'result_original':ref(ex/'r4/python-oracle/result.json'),'rust_fixture':ref(ex/'r4/synthetic-owner-fixture/fixture.json'),'fixture_boundary':'明确合成软件fixture；4401真实Rust生成同规则epoch供未改verify_trace验证；另用既有合成report_fixture作完整verify_report，导入真实Rust派生CAS三分布；非硬件证据。','strict_negative_count':5,'standalone_count_rule':'194 suite后的独立Python合同场景，不累计为Rust测试数。'},
    'short_mock':{'status':'PASS','result':ref(ex/'r4/post-mock/result.json'),'report':ref(ex/'r4/post-mock/mock-ac12/report.json'),'samples':8,'groups':4,'per_group_samples':2,'physical_uart':False,'hardware_pass':False,'three_recipes_no_real_hw':True,'artifacts':mock['artifacts'],'final_trace':mock['final_trace'],'true_tool_wait_receipt':ref(ex/'r4/post-control/mock_ac12.owner/result.json'),'compiled_source_before_after_equal':mock['source_before_after_equal'],'processes_after':[]},
    'original_rounds_preserved':previous,'local_outer_receipts':outer,
    'evidence':{'native_archive':ref(base/'linux-r4/native-evidence.tar.gz'),'native_index':ref(base/'linux-r4/native-evidence.index.json'),'native_archive_verification':ref(base/'linux-r4/native_archive_verification.json'),'native_extracted':str(ex),'index_files':1065,'tar_members':1066,'actual_vm_owned_wait_receipts':80,'archive_postchecks':ref(ex/'r4/archive_postchecks.json'),'owned_sessions_remaining':[]},
    'boundaries':{'full_workspace_tests':'NOT_RUN','long_load':'NOT_RUN','real_rt_ring_pause':'NOT_TESTED','orin_native_build':'NOT_RUN','physical_h2':'原整体FAIL保持，未重测','d15':'OPEN/DEFERRED','deployable':False,'commit_push_install':'NOT_RUN','integration':'root只集成冻结sla.rs；S1已另阶段收口，不夹带旧runtime补丁。'}}
save(base/'summary.json',summary)
(base/'README.md').write_text('''# H2 trace owner 软件候选

入口为 summary.json，集成文件仅 sla.rs／sla.patch。当前候选源 167dc63b2a27，589 编译输入聚合 83048e983bb7；与主 HEAD148663b 比较仅 sla.rs 不同，588 项输入相同。

隔离 Lima 更新浮动 nightly 后，fmt、根 Clippy、feature Clippy、完整默认并行194项通过（12个owner测试为子集）；原Python严格门验证4401合成epoch、四组4000原正式集合、mismatch与预热排除，旧CAS统计拒绝／完整Rust派生统计通过，5严格反例拒绝。三件无real-hw实际构建和冻结、短AC12 mock四组各2样本及真实收尾通过。

四轮原件和3ELF保存在linux-r4/native-evidence.tar.gz及index，1065项身份核验、80真实VM命令回执；解包在linux-r4/native-extracted。r2/r3 lint FAIL原件保留，未声称单轮全过。受控reservation oracle不是真实RT私有hook；Python完整report使用明确合成fixture，不能作为硬件H2证据。

新增工具容量门为44000 owner、8192 events/epoch、256B行及四组×三kind各8192 distinct bins；越界保留原件并FAIL，不截断。原RT环、SLA/采样/P99及Python严格规则不变。旧H2整体FAIL、D15 OPEN/DEFERRED、deployable=false不变；本轮无硬件、Orin、安装或发布。

候选保持冻结，待独审/root验收与阶段集成；不自动提交或合并。
''')
print(json.dumps({'summary':ref(base/'summary.json'),'source':ref(root/relative),'patch':ref(base/'sla.patch'),'readme':ref(base/'README.md')},ensure_ascii=False,indent=2))
