"""收集四轮原件和最终源/三件；原FAIL保留，不含Git或Cargo缓存。"""
import hashlib,importlib.util,io,json,os,socket,stat,sys,tarfile
from pathlib import Path
from types import SimpleNamespace
sys.dont_write_bytecode=True
ROOT=Path('/home/loosqk.guest/robot-checks')
BASES=[ROOT/('h2-trace-owner-20260930-r'+str(n)) for n in range(1,5)]
OUTPUT=ROOT/'h2-trace-owner-20260930-native-r4.tar.gz';INDEX=ROOT/'h2-trace-owner-20260930-native-r4.index.json';POST=BASES[-1]/'archive_postchecks.json'
AGGREGATE='83048e983bb7a13c2f75ae23e593ec301f129b10b412db8f4f80176ca434f62f'
def require(ok,message):
    if not ok: raise ValueError(message)
def raw(path):
    require(path.is_absolute() and path==path.resolve(),'路径不规范');meta=path.lstat();require(stat.S_ISREG(meta.st_mode) and meta.st_nlink==1,'非独立普通文件:'+str(path));return path.read_bytes()
def digest(data):return hashlib.sha256(data).hexdigest()
def module(name,path):
    spec=importlib.util.spec_from_file_location(name,path);result=importlib.util.module_from_spec(spec);spec.loader.exec_module(result);return result
require(socket.gethostname()=='lima-robot-viz-check' and os.getuid()==501,'Lima身份错误')
require(not OUTPUT.exists() and not INDEX.exists() and not POST.exists(),'全新归档输出')
completed=[json.loads(raw(base/'result.json')) for base in BASES];require([r['status'] for r in completed]==['PASS','FAIL','FAIL','PASS'],'四轮实际边界不同')
postmock=json.loads(raw(BASES[-1]/'post-mock/result.json'));require(postmock['status']=='PASS','短mock未通过')
sessions=set();receipts=0
for result in completed+[postmock]:
    for command in result['commands']:
        receipt=command['receipt'];path=Path(receipt['path']);data=raw(path);require(any(path.is_relative_to(base) for base in BASES) and digest(data)==receipt['sha256'] and len(data)==receipt['bytes'],'回执身份变化')
        row=json.loads(data);require(row['reaped'] is True and row['phase']=='REAPED' and row['owner_sent_signals']==[] and row['received_signals']=={} and row['errors']==[] and row['wait_returncode']==command['exit_code'],'真实回收边界不符')
        log=row['log'];blob=raw(Path(log['path']));require(len(blob)==log['bytes'] and digest(blob)==log['sha256'],'日志身份变化');sessions.add(row['child_session_id']);receipts+=1
control=BASES[-1]/'control';owner=module('collector_owner',control/'owner.py');os.chdir(BASES[-1]/'source');fresh={}
for name,argv in [('inventory',['git','ls-files','-z']),('head',['git','rev-parse','HEAD']),('status',['git','status','--porcelain=v1','--untracked-files=all']),('rustc',['rustc','-Vv']),('cargo',['cargo','-V'])]:
    if name in ('rustc','cargo'):argv[0]='/home/loosqk.guest/.cargo/bin/'+name
    code=owner.run(SimpleNamespace(label='collector_'+name,command=argv,observe_seconds=5,input=None));require(code==0,'fresh查询失败');fresh[name]=raw(control/('collector_'+name+'.owner/child.log'))
require(fresh['head'].decode().strip()==completed[-1]['head'],'HEAD变化');require(fresh['status']==b' M crates/robot-s1/src/events_drain/runtime.rs\n M crates/robot-tests/src/comm_fault/sla.rs\n','范围变化')
require(fresh['rustc']==raw(control/'rustc_before.owner/child.log') and fresh['cargo']==raw(control/'cargo_before.owner/child.log'),'编译器窗口变化')
inventory=fresh['inventory'].decode().rstrip('\0').split('\0');a=module('collector_contract',BASES[-1]/'source/scripts/post_e_h2_artifacts.py');source=a.snapshot_source(BASES[-1]/'source',inventory)
require(len(source['files'])==589 and source['source_manifest_sha256']==AGGREGATE and all(source==json.loads(raw(BASES[-1]/name)) for name in ('source_before.json','source_after.json','post-mock/source_before.json','post-mock/source_after.json')),'fresh源前后变化')
remaining=[]
for entry in Path('/proc').iterdir():
    if not entry.name.isdigit():continue
    try:
        fields=(entry/'stat').read_text().rsplit(') ',1)[1].split();sid=int(fields[3])
        if sid in sessions:remaining.append({'pid':int(entry.name),'sid':sid,'start_ticks':int(fields[19]),'state':fields[0]})
    except FileNotFoundError:pass
require(not remaining,'实际owned会话仍有进程')
post={'status':'PASS','fresh_source':source,'fresh_git_head':fresh['head'].decode().strip(),'fresh_git_status':fresh['status'].decode(),'owned_sessions_remaining':remaining,'receipt_count':receipts,'owned_session_count':len(sessions),'identity':completed[-1]['identity'],'source_and_compiler_before_after_equal':True}
with POST.open('x') as stream:json.dump(post,stream,ensure_ascii=False,indent=2);stream.write('\n')
files={};executable={}
def add(path,name):
    require(name not in files,'路径重复');files[name]=raw(path);executable[name]=bool(path.lstat().st_mode&stat.S_IXUSR)
for n,base in enumerate(BASES,1):
    paths=[base/name for name in ('result.json','source_before.json','source_after.json')]
    paths += [p for p in (base/'control').rglob('*') if p.is_file()]
    if n==4:
        paths += [POST]
        for tree in ('synthetic-owner-fixture','python-oracle','post-control','post-mock'):
            paths += [p for p in (base/tree).rglob('*') if p.is_file()]
    for path in paths:add(path,'r'+str(n)+'/'+str(path.relative_to(base)))
for name,item in source['files'].items():
    path=BASES[-1]/'source'/name;blob=raw(path);require(digest(blob)==item['sha256'] and len(blob)==item['bytes'],'打包源变化');add(path,'candidate-source-inputs/'+name)
for name in inventory:
    if name.startswith('scripts/'):
        add(BASES[-1]/'source'/name,'candidate-reporter-scripts/'+name.removeprefix('scripts/'))
for name,manifest in postmock['artifacts'].items():
    data=files['r4/post-mock/frozen/'+name];require(digest(data)==manifest['sha256'] and len(data)==manifest['bytes'] and data[:4]==b'\x7fELF','冻结ELF改变')
index={'schema':'H2_TRACE_OWNER_LINUX_NATIVE_ARCHIVE_INDEX_V1','files':{name:{'sha256':digest(data),'bytes':len(data),'executable':executable[name]} for name,data in sorted(files.items())}}
index_raw=(json.dumps(index,ensure_ascii=False,sort_keys=True,indent=2)+'\n').encode()
with INDEX.open('xb') as stream:stream.write(index_raw)
with tarfile.open(OUTPUT,'x:gz') as archive:
    for name,data in sorted({**files,'index.json':index_raw}.items()):
        item=tarfile.TarInfo(name);item.size=len(data);item.mode=0o755 if name!='index.json' and executable[name] else 0o644;archive.addfile(item,io.BytesIO(data))
require(all(digest(raw(BASES[-1]/'source'/name))==item['sha256'] for name,item in source['files'].items()),'归档后源变化')
print(json.dumps({'status':'PASS','archive':{'path':str(OUTPUT),'sha256':digest(raw(OUTPUT)),'bytes':OUTPUT.stat().st_size},'index':{'path':str(INDEX),'sha256':digest(index_raw),'bytes':len(index_raw)},'files':len(files),'source_files':589,'aggregate':AGGREGATE,'original_failures_preserved':True,'receipt_count':receipts},ensure_ascii=False))
