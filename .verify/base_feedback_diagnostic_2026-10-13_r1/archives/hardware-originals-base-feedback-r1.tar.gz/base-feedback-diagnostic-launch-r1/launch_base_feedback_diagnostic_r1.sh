#!/bin/bash
# 爸爸，保持stdin连接tmux的PTY，只有本轮全部pins绑定后才执行；正文/只读候选入口保持。
set -eu
export PYTHONDONTWRITEBYTECODE=1
exec /home/loosqk/.local/share/uv/python/cpython-3.12.13-linux-aarch64-gnu/bin/python3 -c 'import os,subprocess
FIELD_STAMP=1791865615000000000
FIELD_EXPECTED=('"'"'5d6f7e68c7555d7eb620728765e2af7f9ced248825d081e9f29e2937d845a9c4'"'"', 1657)
GO_EXPECTED=('"'"'2dab3897be052cf3e4e5ad16926a4e6e322f3c4baf1a6bcf357b3fc8db05879f'"'"', 1742)
BINDING_EXPECTED=('"'"'d1e8eb9bda1c75cc1e5cef6917d4f498286096f4b363ae6be5d236811f5d0bb1'"'"', 30279)
PLAN_EXPECTED=('"'"'c54f3b7040d2091472455f3c7afcc6e9070c3db014076609c92e3b3885f7a5eb'"'"', 38380)
PLAN_CANONICAL_SHA='"'"'05aabc77ba6429248b896f2a90aefdf1c53a1ad4c7c134e93657a22f6d9eee6d'"'"'
NATIVE_PREPARATION_EXPECTED=('"'"'9c3238de926387745babc135484e0eb566850ca80d1f12ff4662d1c9288a9cdb'"'"', 4803)
assert type(FIELD_STAMP) is int and FIELD_STAMP>0 and all(v is not None for v in (FIELD_EXPECTED,GO_EXPECTED,BINDING_EXPECTED,PLAN_EXPECTED,NATIVE_PREPARATION_EXPECTED)) and type(PLAN_CANONICAL_SHA) is str and len(PLAN_CANONICAL_SHA)==64, '"'"'爸爸，只读反馈launcher未绑定本轮现场/GO/软件准备，零I/O拒绝。'"'"'
log=os.open('"'"'/home/loosqk/robot-checks/base-feedback-diagnostic-r1/base-feedback-diagnostic-launch-r1/driver.log'"'"',os.O_WRONLY|os.O_CREAT|os.O_EXCL,0o600)
os.dup2(log,1);os.dup2(log,2);os.close(log)
subprocess.run(['"'"'tmux'"'"','"'"'set-option'"'"','"'"'-p'"'"','"'"'-t'"'"',os.environ['"'"'TMUX_PANE'"'"'],'"'"'remain-on-exit'"'"','"'"'on'"'"'],check=True)
os.execv('"'"'/home/loosqk/.local/share/uv/python/cpython-3.12.13-linux-aarch64-gnu/bin/python3'"'"',['"'"'/home/loosqk/.local/share/uv/python/cpython-3.12.13-linux-aarch64-gnu/bin/python3'"'"','"'"'/home/loosqk/robot-checks/base-feedback-r1-software/candidate/base_feedback_diagnostic_r1.py'"'"','"'"'--raw-helper'"'"','"'"'/home/loosqk/robot-checks/position-return-20261010-r1/base-zero-diagnostic-r1/helpers/raw_right9_from_r14_r1.py'"'"','"'"'--maintenance'"'"','"'"'/home/loosqk/robot-checks/position-return-20261010-r1/software-facts-r1/scripts/run_hardware_maintenance.py'"'"','"'"'--bindings'"'"','"'"'/home/loosqk/robot-checks/base-feedback-diagnostic-r1/maintenance_bindings_base_feedback_diagnostic_r1.json'"'"','"'"'--output'"'"','"'"'/home/loosqk/robot-checks/base-feedback-diagnostic-r1/base-feedback-diagnostic-r1'"'"','"'"'--artifact-root'"'"','"'"'/home/loosqk/robot-checks/base-feedback-diagnostic-r1'"'"','"'"'--execute'"'"','"'"'--approval'"'"','"'"'/home/loosqk/robot-checks/base-feedback-diagnostic-r1/base-feedback-diagnostic-r1.go.json'"'"'])'
