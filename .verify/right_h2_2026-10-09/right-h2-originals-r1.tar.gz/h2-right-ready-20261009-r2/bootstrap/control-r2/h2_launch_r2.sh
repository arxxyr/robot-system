#!/bin/bash
# 草案：只有 root 收到本次现场事实后，才填入两个实际 SHA 并生成 h2_launch.sh。
set -euC
umask 077
export PATH=/home/loosqk/.cargo/bin:/home/loosqk/.local/bin:$PATH
export PYTHONDONTWRITEBYTECODE=1
base=/home/loosqk/robot-checks/h2-right-ready-20261009-r2
tmux set-option -w -t "$TMUX_PANE" remain-on-exit on
exec > "$base/bootstrap/h2-driver-r2.log" 2>&1
h2_python=$(uv python find 3.12)
exec taskset -c 0-3 "$h2_python" "$base/bootstrap/control-r2/prelaunch_go.py" \
  --execute --inputs "$base/bootstrap/s52-right-inputs-r1.json" \
  --inputs-sha256 02c15fc346f3baa15c522d21c7acf441e5a0c47ee37096a5ed77d4e8d868ea89 --go "$base/bootstrap/s52-right-go-r2.json" \
  --go-sha256 6a5b1cf4acf85b7d2e482d8d23b98d55e0d419644c442dfe0ece69766dc42c3b --driver "$base/source/scripts/run_post_e_h2.py" \
  --output "$base/right-h2-run-01" \
  --expected-head aa03ca51a819fee45c9ffe029e0ee11fb535a6e7
