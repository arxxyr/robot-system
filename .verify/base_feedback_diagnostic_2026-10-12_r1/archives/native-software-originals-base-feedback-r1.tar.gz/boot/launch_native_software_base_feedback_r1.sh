#!/bin/bash
set -eu
export PYTHONDONTWRITEBYTECODE=1
tmux set-option -p remain-on-exit on
exec /home/loosqk/.local/share/uv/python/cpython-3.12.13-linux-aarch64-gnu/bin/python3 /home/loosqk/robot-checks/base-feedback-r1-software/boot/native_software_quality_base_feedback_r1.py > /home/loosqk/robot-checks/base-feedback-r1-software/boot/base-feedback-r1-software-driver.log 2>&1
