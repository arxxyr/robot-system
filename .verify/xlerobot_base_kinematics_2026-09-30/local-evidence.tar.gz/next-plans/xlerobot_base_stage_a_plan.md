# XLeRobot 底盘阶段 A：纯运动学实现计划

状态：root 方案及独立设计审查通过，允许隔离实施；当前不是实现完成或硬件验收。

目标来自用户“底盘也按照 xlerobot 的模式”：保留机身速度 vx 前、vy 左、wz 逆时针的 SI 语义，轮顺序 front=8、left=7、right=9，三轮全向映射和超限同比缩放。依据已保存的现场上游 `common/units.py` / `common/config.py`；不照搬其中未经标定的 raw1023=6rad/s 假设或 EEPROM 切模式行为。

## 文件与职责

- 新增 `crates/robot-kinematics-xlerobot/src/base.rs`，仅纯类型和确定性数学；运动学留在 S1 使用的 kinematics 实现层。
- `lib.rs` 仅导出模块并校正文档范围；不修改原 ArmIK 算法或接口。
- 不改 Cargo 依赖、schema、S0、adapter、启动配置、正式安装件和冻结设计文档。
- `BaseKinematics` 通用 trait、里程计积分和 S1/S0 实际执行链留给后续独立候选；本阶段不宣称已接通底盘。

## 类型与函数合同

1. `PlanarBodyVelocity`：三个具名 f64 字段 vx_m_s、vy_m_s、wz_rad_s，避免把轮速/原始寄存器值伪装成机身速度。
2. `XLeRobotWheelVelocities`：具名 front_rad_s、left_rad_s、right_rad_s；导出的 ID 顺序常量固定 `[8,7,9]`。提供从 `(ids,[f64;3])` 的严格构造，错误 ID/顺序或非有限值拒绝；原始数组输出顺序始终一致。
3. `XLeRobotOmniKinematics::new(wheel_radius_m,base_radius_m,max_wheel_rad_s)`：参数必须有限且严格正；没有默认几何或默认实测轮速上限。极端有限值导致系数/计算非有限时返回明确错误，不静默输出。
4. `body_to_wheels`：先校验输入有限，再计算三轮角速度，输出检查有限；不隐式限幅。
5. `wheels_to_body`：严格 wheel 类型/顺序，输出具名机身速度，检查有限。即便具名 public 字段可直接构造，也在调用时重检所有输入，不能只依赖构造器。
6. `limit_body_velocity`：返回具名三轮角速度和统一 scale；无超界时 scale=1，超界时三轮统一乘 max/peak。不能逐轮 clip 改变方向，不做整数 raw 换算。首次比例舍入使轮速略超上限时，统一比例向下调一ULP并重算全部三轮；不能把普通有限指令误判为不可表示。最多修正一次，重算仍超限或极端值使 scale 下溢为0时拒绝；上限不放宽。
7. 错误用明确 enum，区分非法几何、非有限输入、轮 ID/顺序与不可表示的计算结果；无需堆分配、时钟、IO 或运行时依赖。

## 精确数学

令 r 为轮半径、L 为底盘半径，a=√3/2，q=L*wz：

```
wf=(vy+q)/r
wl=(a*vx-vy/2+q)/r
wr=(-a*vx-vy/2+q)/r

vx=r*(wl-wr)/√3
vy=r*(2*wf-wl-wr)/3
wz=r*(wf+wl+wr)/(3*L)
```

与上游 θ=[0°,240°,120°] 矩阵等价；前进轮比例 `(0,+1,-1)`、左移 `(+2,-1,-1)`、逆时针 `(+1,+1,+1)`。

## 软件验收

- 三个独立基向量带非单位几何的绝对数值断言；零向量。
- 组合机身速度的前后变换 round-trip，另用手算轮速→机身 golden 验证逆式，不只测试自洽。
- 正负对称、顺序 `[8,7,9]` 与错误/重复 ID 拒绝。
- 一轮和多轮超限时统一 scale，逆算实际机身方向保持；无超限原值保持。独立锁定peak=20/123、max=.1的舍入超限例，保守修正比例后全部轮速严格不超上限。
- 每个输入分量的 NaN/±Inf、每个几何参数的非正/NaN/±Inf；计算溢出、直构 wheel 非有限输入和 scale 下溢0拒绝。
- latest floating nightly 更新并记录；fmt、根 Clippy 零警告与该 crate 全部测试。不重复跑未改模块全仓测试。
- 实现由原生子 agent、另一个 agent 独审，root 最终验收及按既有授权提交；不 push、不部署。

## 后续依赖与当前边界

现场 Phase/速度单位/零速语义尚未核实。当前维护 V2 live 入口将三轮明确 DEFERRED，在首次 wheel 调用前拒绝；不通过伪造 verified 字段打开。

后续实际执行链需 typed base velocity → S1 kinematics → S0 mode-aware decode → Feetech Goal_Velocity；停止、取消、失联和 Disable 都有零速/断扭确认。同一物理 USB 的右臂和底盘必须保持唯一 writer，不能新起第二个 daemon 抢串口，也不能把全总线切 Velocity。base-only 受监督阶段只证明底盘执行链，头部/双臂/同时整车与 H2 各自保留完整目标。

人工断电确认尚待用户回复；本计划和阶段 A 都不访问 UART 或下发新动作。旧右 H2 整体 FAIL、本次左腕回程 +6raw FAIL、D15 OPEN/DEFERRED 和 deployable=false 保持。
