set -eu
export PATH=/home/loosqk/.cargo/bin:/home/loosqk/.local/bin:$PATH
export CARGO_HOME=/home/loosqk/robot-checks/viz-orin-a6957cc-20260930-r1/cargo-home
export CARGO_NET_OFFLINE=true
export RUSTUP_AUTO_INSTALL=0
export PYTHONDONTWRITEBYTECODE=1
cd /home/loosqk/robot-checks/xlerobot-base-si-20260930-r2/bootstrap
printf '%s\n' '2c009d80035d8917096ad088553df56561457149c6c1bf2c5ff74e53f913f22d  run_precommit.py' | sha256sum -c -
exec taskset -c 0-3 uv run --no-project python run_precommit.py
