set -eu
export PATH=/home/loosqk/.cargo/bin:/home/loosqk/.local/bin:$PATH
export CARGO_HOME=/home/loosqk/robot-checks/viz-orin-a6957cc-20260930-r1/cargo-home
export CARGO_NET_OFFLINE=true
export RUSTUP_AUTO_INSTALL=0
export PYTHONDONTWRITEBYTECODE=1
cd /home/loosqk/robot-checks/xlerobot-base-si-20260930-r2/bootstrap
printf '%s\n' 'ab044601dbbc4f08d35c55982bf95d5a620e65102b889604612edd34a5fbe914  snapshot_inputs.py' | sha256sum -c -
exec uv run --no-project python snapshot_inputs.py
