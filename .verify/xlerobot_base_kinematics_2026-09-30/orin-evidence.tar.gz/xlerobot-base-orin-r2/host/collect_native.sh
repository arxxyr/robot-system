set -eu
export PATH=/home/loosqk/.cargo/bin:/home/loosqk/.local/bin:$PATH
export PYTHONDONTWRITEBYTECODE=1
cd /home/loosqk/robot-checks/xlerobot-base-si-20260930-r2/bootstrap
printf '%s\n' 'e93b33ab7bf12ec6e410c9e019cf3a31cd537ae8842865aae9cdac83c91649c8  collect_native.py' | sha256sum -c -
exec uv run --no-project python collect_native.py --base /home/loosqk/robot-checks/xlerobot-base-si-20260930-r2 --out /home/loosqk/robot-checks/xlerobot-base-si-20260930-native-r2.tar.gz --collect
