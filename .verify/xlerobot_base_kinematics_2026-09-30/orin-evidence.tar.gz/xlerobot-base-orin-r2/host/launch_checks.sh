set -eu
export PATH=/home/loosqk/.cargo/bin:/home/loosqk/.local/bin:$PATH
export CARGO_HOME=/home/loosqk/robot-checks/viz-orin-a6957cc-20260930-r1/cargo-home
export CARGO_NET_OFFLINE=true
export RUSTUP_AUTO_INSTALL=0
export PYTHONDONTWRITEBYTECODE=1
test "$(hostname)" = ubuntu
test "$(id -u)" = 1000
test "$(id -g)" = 1000
test "$(cat /proc/sys/kernel/random/boot_id)" = 6cf7ee3e-a3c5-4c91-80bc-4ca924818b53
BASE=/home/loosqk/robot-checks/xlerobot-base-si-20260930-r2
cd "$BASE/bootstrap"
printf '%s\n' '8c49aded71bc718ee03487e5ae5fc1a59b6cf1358e099ed9d899f802234e4488  base.rs' 'a919d5f6dc30d51b9a674a28b541025d0503381cde746e6ff52feed58112ebd1  lib.rs' 'ae1039d929326e55a48157ca688fc25b46ee6d31d4fd55b1233b3e9b2e46f350  run_checks.py' 'f9cf1528dc9d3f3bc031a2acb77d927349da6294f853b1c854fc717aedb7e487  expected_source.json' '6d5cfc0c72c14ccefcd0de40a7bfbdadb07f46546600e744f4257208e9824948  frozen_inputs.json' | sha256sum -c -
test "$(git -C "$BASE/source" rev-parse HEAD)" = 1c5758f97b7c502a38c850e8352ce970216bea53
test -z "$(git -C "$BASE/source" status --porcelain=v1 --untracked-files=all)"
test ! -e "$BASE/source/crates/robot-kinematics-xlerobot/src/base.rs"
cp base.rs "$BASE/source/crates/robot-kinematics-xlerobot/src/base.rs"
cp lib.rs "$BASE/source/crates/robot-kinematics-xlerobot/src/lib.rs"
exec taskset -c 0-3 uv run --no-project python run_checks.py
