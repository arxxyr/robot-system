"""仅验证三轮SI纯运动学候选；原H2源/七件/历史包只读核验。"""
import hashlib,importlib.util,json,os,re,signal,sys
from pathlib import Path
from types import SimpleNamespace
sys.dont_write_bytecode=True
BASE=Path('/home/loosqk/robot-checks/xlerobot-base-si-20260930-r2');SOURCE=BASE/'source';OUT=BASE/'checks-r1';CACHE=Path('/home/loosqk/robot-checks/h2-nightly-v2-20260930-r1/build');OLD=Path('/home/loosqk/robot-checks/h2-trace-owner-v2-20260930-r1');HEAD='1c5758f97b7c502a38c850e8352ce970216bea53'
STATUS=' M crates/robot-kinematics-xlerobot/src/lib.rs\n?? crates/robot-kinematics-xlerobot/src/base.rs\n'
def module(name,path):
    spec=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);return m
helper=module('base_runner',OLD/'bootstrap/run_release_v2.py');a=module('base_artifacts',SOURCE/'scripts/post_e_h2_artifacts.py');require=a.require;require(a.sha256(OLD/'bootstrap/run_release_v2.py')=='dad9bbc9405b8fac4d60d6efe794b36750e6a6f9ce9fdeba3debf7d3e1b9a471','helper身份不同');OUT.mkdir();r=helper.Runner(SimpleNamespace(source=SOURCE,out=OUT,target=CACHE,build_head=HEAD,formal_root=Path('/home/loosqk/repo/robot/robot-system')),a)
expected=a.strict_json((BASE/'bootstrap/expected_source.json').read_text());inputs=a.strict_json((BASE/'bootstrap/frozen_inputs.json').read_text());original_source=a.strict_json((OLD/'release-r1/source_before.json').read_text());result={'status':'FAIL','scope':'两文件三轮SI纯数学候选；latest nightly/fmt/根Clippy/该crate完整lib，非H2六配方/全workspace或硬件。','self_sha256':a.sha256(Path(__file__)),'source_head':HEAD,'receipts':[]};old={};before=None;original=None;compiler=None

def interrupted(signum,frame):helper.INTERRUPTED=signum
def candidate_source(label):
    _,p=r.command(label+'_head',['git','rev-parse','HEAD']);require(Path(p['stdout']).read_text().strip()==HEAD,'HEAD非1c')
    _,p=r.command(label+'_status',['git','status','--porcelain=v1','--untracked-files=all']);require(Path(p['stdout']).read_text()==STATUS,'候选改动范围变化')
    _,p=r.command(label+'_files',['git','ls-files','-z','--cached','--others','--exclude-standard']);names=Path(p['stdout']).read_text().rstrip('\0').split('\0');value=a.snapshot_source(SOURCE,names);require(value==expected and len(value['files'])==590,'590输入不匹配')
    for name,pinned in inputs.items():require(value['files'][name]['sha256']==pinned['sha256'] and value['files'][name]['bytes']==pinned['bytes'],'冻结两文件变化')
    helper.save(OUT/(label+'.json'),value);return value

def originals(label):
    _,p=r.command(label+'_old_head',['git','-C',str(OLD/'source'),'rev-parse','HEAD']);require(Path(p['stdout']).read_text().strip()==HEAD,'原源HEAD变化')
    _,p=r.command(label+'_old_status',['git','-C',str(OLD/'source'),'status','--porcelain=v1','--untracked-files=all']);require(Path(p['stdout']).read_bytes()==b'','原源非clean')
    source=a.snapshot_source(OLD/'source',list(original_source['files']));require(source==original_source,'原589源变化');files={}
    for kind in ('production','measurement'):
        manifest=a.strict_json((OLD/'release-r1'/f'{kind}.json').read_text());a.validate_artifact_set(manifest,source_manifest=source,expected_kind=kind,expected_head=HEAD)
        for name,item in manifest['artifacts'].items():files[kind+'/'+name]=a.elf_identity(item['path'])
        for name in (f'{kind}.json',):files['release/'+name]={'sha256':a.sha256(OLD/'release-r1'/name),'bytes':(OLD/'release-r1'/name).stat().st_size}
    for name in ('result.json','source_before.json','source_after.json'):files['release/'+name]={'sha256':a.sha256(OLD/'release-r1'/name),'bytes':(OLD/'release-r1'/name).stat().st_size}
    for name in ('h2-trace-owner-v2-20260930-native-r1.tar.gz','h2-maintenance-precommit-20260930-native-r1.tar.gz'):
        for suffix in ('','.index.json','.metadata.json'):
            path=OLD.parent/(name+suffix);files[name+suffix]={'sha256':a.sha256(path),'bytes':path.stat().st_size}
    value={'source':source,'files':files};helper.save(OUT/(label+'_originals.json'),value);return value

try:
    for sig in (signal.SIGTERM,signal.SIGINT,signal.SIGHUP):old[sig]=signal.signal(sig,interrupted)
    require(os.getuid()==1000 and os.getgid()==1000 and Path('/proc/sys/kernel/random/boot_id').read_text().strip()=='6cf7ee3e-a3c5-4c91-80bc-4ca924818b53','主机身份变化')
    before=candidate_source('source_before');original=originals('before')
    _,p=r.command('rustc_before_update',['rustc','-vV']);compiler_before=a.parse_rustc_identity(Path(p['stdout']).read_text());r.command('cargo_before_update',['cargo','-V'])
    r.command('latest_nightly_update',['rustup','update','nightly','--no-self-update'],300)
    _,p=r.command('rustc_after_update',['rustc','-vV']);compiler=a.parse_rustc_identity(Path(p['stdout']).read_text());_,p=r.command('cargo_after_update',['cargo','-V']);cargo=Path(p['stdout']).read_bytes()
    r.command('fmt',['cargo','fmt','--all'],300);after_fmt=candidate_source('source_after_fmt');require(after_fmt==before,'fmt改变冻结候选')
    r.command('clippy',['cargo','clippy','--locked','--all','--all-targets','--','-D','warnings'],7200)
    _,p=r.command('crate_lib',['cargo','test','--locked','-p','robot-kinematics-xlerobot','--lib'],7200);text=Path(p['stdout']).read_text();summaries=re.findall(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored;',text);require(summaries==[('30','0','0')],'该crate完整lib不是30/0/0');require(len(re.findall(r'test base::tests::[^ ]+ \.\.\. ok',text))==21 and len(re.findall(r'test tests::[^ ]+ \.\.\. ok',text))==9,'不是21新+9既有')
    _,p=r.command('rustc_after',['rustc','-vV']);require(a.parse_rustc_identity(Path(p['stdout']).read_text())==compiler,'门后rustc漂移');_,p=r.command('cargo_after',['cargo','-V']);require(Path(p['stdout']).read_bytes()==cargo,'门后cargo漂移')
    result.update(status='PASS',tests={'crate_total':30,'new_base_subset':21,'existing_arm_subset':9,'failed':0,'ignored':0,'full_workspace':'NOT_RUN','h2_six_recipes':'NOT_RUN','test_threads_override':None},compiler=compiler,compiler_before_update=compiler_before,compiler_after_update_after_equal=True,fmt_source_unchanged=True,source_files=590,aggregate=before['source_manifest_sha256'])
except BaseException as error:result['error']=repr(error)
finally:
    for name,check in [('source_after',lambda:candidate_source('source_after')),('after_originals',lambda:originals('after'))]:
        try:
            value=check();require(value==({'source_after':before,'after_originals':original}[name]),name+'变化或缺前值');result[name]='PASS'
        except BaseException as error:result.update(status='FAIL');result[name]=repr(error)
    result['receipts']=r.receipts;helper.save(OUT/'result.json',result)
    for sig,handler in old.items():signal.signal(sig,handler)
print(json.dumps(result,ensure_ascii=False),flush=True);raise SystemExit(0 if result['status']=='PASS' else 1)
