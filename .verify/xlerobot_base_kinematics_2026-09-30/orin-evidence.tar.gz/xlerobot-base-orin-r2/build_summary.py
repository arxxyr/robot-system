"""只读复核数学候选原件并冻结summary；不执行包内脚本或测试。"""
import hashlib,json,re,stat
from pathlib import Path

ROOT=Path(__file__).resolve().parent
R1=ROOT.parent/'xlerobot-base-orin-r1'
MAIN=Path('/Users/loosqk/repo/rust/robot-system')
TREE=ROOT.parents[1]
PINNED='0e580bd954d29014534c6d04707873c8e779e75ffb7b93add2a5095d136d4eaa'
COMMIT='5c543b0b8c73c7b72bc8284ced4fb22ead15734d'

def require(ok,message):
    if not ok:raise ValueError(message)
def sha(path):
    with Path(path).open('rb') as stream:return hashlib.file_digest(stream,'sha256').hexdigest()
def ref(path):
    p=Path(path);return {'path':str(p),'sha256':sha(p),'bytes':p.stat().st_size}
def read(path):return json.loads(Path(path).read_text())
def save(path,value):
    with Path(path).open('x') as stream:json.dump(value,stream,ensure_ascii=False,indent=2,allow_nan=False);stream.write('\n')
def local_path(stage,remote):
    base=Path('/home/loosqk/robot-checks/xlerobot-base-si-20260930-'+stage.name.rsplit('-',1)[1])
    return stage/'native-extracted'/Path(remote).relative_to(base)
def completion(stage,p):
    row=read(p);launch=read(p.parent/'launch.json')
    expected=101 if stage==R1 and p.relative_to(stage/'native-extracted').as_posix()=='checks-r1/clippy/completion.json' else 0
    for key in ('name','argv','cwd','env','pid','identity','bootstrap_argv'):
        require(row[key]==launch[key],str(p)+'启动/完成不同:'+key)
    require(row['exec_gate_released'] is True,str(p)+'启动门未放行')
    require(row['reaped'] and row['signals']==[] and not row['budget_exceeded'],str(p)+'非自然回收')
    require(row.get('runner_error')==("ValueError('命令原始退出码非零')" if expected==101 else None),str(p)+'Runner非预期错误')
    require(row['session_residual_after_cleanup']==[] and row['session_residual_before_cleanup']==[],str(p)+'残留会话')
    require(row['elapsed_ns']==row['ended_monotonic_ns']-row['started_monotonic_ns'] and row['elapsed_ns']<=row['timeout_seconds']*10**9,str(p)+'超预算')
    require(row['deadline_monotonic_ns']==row['started_monotonic_ns']+row['timeout_seconds']*10**9,str(p)+'期限变化')
    require(row['identity']['boot_id']=='6cf7ee3e-a3c5-4c91-80bc-4ca924818b53' and row['identity']['pid']==row['pid'],str(p)+'主机/PID不同')
    for key in ('stdout','stderr'):
        q=local_path(stage,row[key]);require(sha(q)==row[key+'_sha256'] and q.stat().st_size==row[key+'_bytes'],str(p)+'日志不同')
    require(row['exit_code']==expected,str(p)+'非预期退出')
    return {'completion':ref(p),'name':row['name'],'argv':row['argv'],'pid':row['pid'],'exit_code':row['exit_code'],'reaped':True,'started_at':row['started_at'],'finished_at':row['finished_at'],'elapsed_ns':row['elapsed_ns'],'timeout_seconds':row['timeout_seconds']}
def result(stage,tree):
    p=stage/'native-extracted'/tree/'result.json';value=read(p)
    for item in value['receipts']:
        q=local_path(stage,item['path']);require(sha(q)==item['sha256'],'result引用SHA不符')
    return value
def native(stage):
    value=read(stage/'native_archive_verification.json');require(value['status']=='PASS','归档未核')
    return {'archive':ref(stage/'native-evidence.tar.gz'),'index':ref(stage/'native-evidence.index.json'),'metadata':ref(stage/'native-evidence.metadata.json'),'verification':ref(stage/'native_archive_verification.json'),'indexed_files':value['indexed_files'],'directories':value['directories'],'members':value['tar_members'],'extracted':value['extracted']}

origins=[];stages={};all_direct=[];all_hosts=[]
for stage in (R1,ROOT):
    x=stage/'native-extracted';qa=result(stage,'checks-r1');snapshot=result(stage,'source-inputs-r1')
    source=read(x/'checks-r1/source_before.json')
    require(len(source['files'])==590,'不是590')
    for name in ('source_after_fmt','source_after'):
        require(read(x/'checks-r1'/f'{name}.json')==source,'QA源漂移')
    require(read(x/'source-inputs-r1/source_before.json')==source and read(x/'source-inputs-r1/source_after.json')==source,'副本源漂移')
    require(snapshot['status']=='PASS' and snapshot['files']==590,'副本未通过')
    require(qa['source_after']=='PASS' and qa['after_originals']=='PASS','QA后验不通过')
    for name in ('before','after'):origins.append(read(x/'checks-r1'/f'{name}_originals.json'))
    direct=[completion(stage,p) for p in sorted(x.rglob('completion.json'))]
    all_direct+=direct;hosts=[]
    for p in sorted((stage/'host').glob('*.owner/result.json')):
        row=read(p);require(row['reaped'] and row['owner_sent_signals']==[] and row['received_signals']=={} and row['errors']==[],str(p)+'owner不完整')
        require(row['wait_returncode']==(1 if stage==R1 and p.parent.name=='checks.owner' else 0),str(p)+'owner非预期退出')
        q=Path(row['log']['path']);require(ref(q)==row['log'],str(p)+'owner日志变化')
        if 'input' in row:require(ref(row['input']['path'])==row['input'],str(p)+'owner输入变化')
        hosts.append({'receipt':ref(p),'owner_pid':row['owner_pid'],'child_pid':row['pid'],'wait_returncode':row['wait_returncode'],'reaped':True,'started_utc':row['started_utc'],'finished_utc':row['finished_utc']})
    all_hosts+=hosts
    for name in ('rustc_before_update','rustc_after_update'):
        text=(x/'checks-r1'/name/'stdout.log').read_text();require('commit-hash: '+COMMIT in text and 'host: aarch64-unknown-linux-gnu' in text,'compiler不同')
    after=('diagnostic-r1/rustc_after_failure' if stage==R1 else 'checks-r1/rustc_after')
    require('commit-hash: '+COMMIT in (x/after/'stdout.log').read_text(),'final compiler不同')
    cargo=(x/'checks-r1/cargo_after_update/stdout.log').read_bytes()
    after_cargo=('diagnostic-r1/cargo_after_failure' if stage==R1 else 'checks-r1/cargo_after')
    require((x/after_cargo/'stdout.log').read_bytes()==cargo,'cargo漂移')
    stages[stage.name]={'qa':ref(x/'checks-r1/result.json'),'status':qa['status'],'source_files':590,'aggregate':source['source_manifest_sha256'],'source_before':ref(x/'checks-r1/source_before.json'),'source_after_fmt':ref(x/'checks-r1/source_after_fmt.json'),'source_after':ref(x/'checks-r1/source_after.json'),'snapshot':ref(x/'source-inputs-r1/result.json'),'native':native(stage),'direct_children':direct,'host_owners':hosts,'compiler_commit':COMMIT,'cargo':cargo.decode().strip(),'latest_update_stdout':ref(x/'checks-r1/latest_nightly_update/stdout.log'),'latest_update_stderr':ref(x/'checks-r1/latest_nightly_update/stderr.log')}

r1=stages[R1.name];r2=stages[ROOT.name]
require(r1['status']=='FAIL' and r2['status']=='PASS','两次结果不正确')
require(len(r1['direct_children'])==28 and len(r2['direct_children'])==48 and len(all_hosts)==17,'回收计数不正确')
require(not (R1/'native-extracted/checks-r1/crate_lib').exists(),'r1测试不应执行')
r1['failure']={'reason':'clippy::similar_names，cfg(test) helper vx_m_s与vy_m_s局部名相近','clippy_exit_code':101,'crate_total':30,'crate_status':'NOT_RUN','failed_run_unchanged':True,'stdout':ref(R1/'native-extracted/checks-r1/clippy/stdout.log'),'stderr':ref(R1/'native-extracted/checks-r1/clippy/stderr.log')}
require('similar_names' in (R1/'native-extracted/checks-r1/clippy/stderr.log').read_text(),'没有原失败')
qa=result(ROOT,'checks-r1');r2['tests']=qa['tests']
test=(ROOT/'native-extracted/checks-r1/crate_lib/stdout.log').read_text()
require(re.findall(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored;',test)==[('30','0','0')],'测试计数错误')
base_names=re.findall(r'test (base::tests::[^ ]+) \.\.\. ok',test);arm_names=re.findall(r'test (tests::[^ ]+) \.\.\. ok',test)
require(len(base_names)==21 and len(arm_names)==9,'子集计数错误');r2['tests']['actual_names']={'new_base_subset':base_names,'existing_arm_subset':arm_names}
before=read(ROOT/'native-extracted/precommit-r1/source_before.json');require(before==read(ROOT/'expected_source.json') and before['source_manifest_sha256']==PINNED,'precommit源不匹配')
for name in ('source_after_fmt','source_after'):require(read(ROOT/'native-extracted/precommit-r1'/f'{name}.json')==before,'precommit源漂移')
pre=result(ROOT,'precommit-r1');require(pre['status']=='PASS' and pre['compiler']==qa['compiler'],'precommit未通过')
for name in ('before','after'):origins.append(read(ROOT/'native-extracted/precommit-r1'/f'{name}_originals.json'))
require(all(v==origins[0] for v in origins),'原H2源/七件/两包首尾变化')
pre_fmt=read(ROOT/'native-extracted/precommit-r1/fmt/completion.json');pre_clippy=read(ROOT/'native-extracted/precommit-r1/clippy/completion.json')
require(pre_fmt['ended_monotonic_ns']<pre_clippy['started_monotonic_ns'],'fmt/Clippy顺序错误')

prior=origins[0]['source'];require(len(prior['files'])==589 and prior['source_manifest_sha256']=='83048e983bb7a13c2f75ae23e593ec301f129b10b412db8f4f80176ca434f62f','原589身份不正确')
added=set(before['files'])-set(prior['files']);removed=set(prior['files'])-set(before['files']);changed=[n for n in sorted(set(before['files'])&set(prior['files'])) if before['files'][n]!=prior['files'][n]]
require(added=={'crates/robot-kinematics-xlerobot/src/base.rs'} and not removed and changed==['crates/robot-kinematics-xlerobot/src/lib.rs'],'相对1c改动范围扩大')
current={}
for label,path in [('worktree',TREE),('main',MAIN)]:
    actual={}
    for name,item in before['files'].items():
        p=path/name;info=p.lstat();require(stat.S_ISREG(info.st_mode),'本机源非普通文件');actual[name]={'sha256':sha(p),'bytes':info.st_size,'executable':bool(info.st_mode&stat.S_IXUSR)}
    require(actual==before['files'],'本机590非同源:'+label);current[label]={'path':str(path),'files':590,'aggregate':PINNED,'verified_per_file':True}
base_path='crates/robot-kinematics-xlerobot/src/base.rs'
old_base=(R1/'native-extracted/source-inputs-r1/files'/base_path).read_bytes();new_base=(ROOT/'native-extracted/source-inputs-r1/files'/base_path).read_bytes()
require(old_base.split(b'#[cfg(test)]')[0]==new_base.split(b'#[cfg(test)]')[0],'r1到r2生产代码变化')
handoff=read(R1/'previous_stage_archive_handoff.json')
for item in handoff['files']:require(ref(item['path'])==item,'上一阶段本机冻结件变化')
code=read(ROOT/'frozen_inputs.json');require(code=={n:{k:before['files'][n][k] for k in item} for n,item in code.items()},'冻结两文件不一致')
value={'schema':'XLEROBOT_BASE_SI_ORIN_SOFTWARE_V1','status':'PASS_SOFTWARE_R2_WITH_R1_FAIL_PRESERVED','source_head':'1c5758f97b7c502a38c850e8352ce970216bea53','scope':'三轮SI纯数学库；Orin最新nightly、fmt、根Clippy、该crate完整30(21新+9旧)与独立提交前fmt→Clippy。非全workspace/release/H2六配方或硬件运动验证。','frozen_inputs':code,'source_files':590,'aggregate':PINNED,'compiler':qa['compiler'],'source_delta_from_1c':{'added':sorted(added),'removed':sorted(removed),'changed':changed,'identical_original_inputs':588},'r1_to_r2_production_prefix_sha256':hashlib.sha256(new_base.split(b'#[cfg(test)]')[0]).hexdigest(),'r1_to_r2_production_prefix_unchanged':True,'stages':stages,'precommit':{'result':ref(ROOT/'native-extracted/precommit-r1/result.json'),'source_before':ref(ROOT/'native-extracted/precommit-r1/source_before.json'),'source_after':ref(ROOT/'native-extracted/precommit-r1/source_after.json'),'fmt':ref(ROOT/'native-extracted/precommit-r1/fmt/completion.json'),'clippy':ref(ROOT/'native-extracted/precommit-r1/clippy/completion.json'),'direct_children':19,'source_unchanged':True,'fmt_finished_before_clippy_started':True,'crate_tests':'NOT_RERUN'},'real_reaping':{'direct_children_total':len(all_direct),'r1_direct_children':28,'r2_qa_direct_children':23,'r2_snapshot_direct_children':6,'r2_precommit_direct_children':19,'host_owners':len(all_hosts),'all_reaped':True,'expected_nonzero_direct':1,'expected_nonzero_host':1,'no_signal_no_kill_no_auto_retry':True},'original_h2_preservation':{'read_only_windows':6,'all_equal':True,'source_files':589,'source_aggregate':prior['source_manifest_sha256'],'source_head_1c_clean':True,'seven_frozen_elfs':True,'release_manifests_and_results_unchanged':True,'two_previous_remote_native_archive_sets_unchanged':True,'observed_files':origins[0]['files']},'previous_local_stage_handoff':ref(R1/'previous_stage_archive_handoff.json'),'previous_local_stage_9_references_unchanged':True,'local_current_compilation_inputs':current,'static_helper_rename_review':ref(ROOT/'test_helper_rename_review.json'),'restrictions':{'UART':'NOT_ACCESSED','hardware_GO':'NOT_CREATED_OR_USED','enable_ClearEStop_protection_write':'NOT_PERFORMED','service_start_install':'NOT_PERFORMED','commit_push':'NOT_PERFORMED_BY_CHILD','physical_power_off':'PENDING','D15':'OPEN_DEFERRED','deployable':False,'old_H2_and_maintenance_hardware_FAIL':'UNCHANGED','raw_register_conversion_phase_odometry_control_integration':'OUT_OF_SCOPE'},'independent_review':'PENDING_ROOT_ASSIGNED_REVIEWER'}
save(ROOT/'summary.json',value)
print(json.dumps({'summary':ref(ROOT/'summary.json'),'status':value['status'],'direct_children':len(all_direct),'host_owners':len(all_hosts),'native_r1':native(R1),'native_r2':native(ROOT)},ensure_ascii=False))
