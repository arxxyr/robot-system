set -eu
export PATH=/home/loosqk/.cargo/bin:/home/loosqk/.local/bin:$PATH
export CARGO_HOME=/home/loosqk/robot-checks/viz-orin-a6957cc-20260930-r1/cargo-home
export CARGO_NET_OFFLINE=true
export RUSTUP_AUTO_INSTALL=0
export PYTHONDONTWRITEBYTECODE=1
test "$(hostname)" = ubuntu
test "$(id -u)" = 1000
test "$(id -g)" = 1000
test "$(cat /proc/sys/kernel/random/boot_id)" = 6cf7ee3e-a3c5-4c91-80bc-4ca924818b53
BASE=/home/loosqk/robot-checks/xlerobot-base-si-20260930-r1
cd "$BASE/bootstrap"
printf '%s\n' 'a06f97298343ede8ef6f96f8ef4f5f9bcc9d80c3a85eb843ea6f476d6c2795b0  base.rs' 'a919d5f6dc30d51b9a674a28b541025d0503381cde746e6ff52feed58112ebd1  lib.rs' 'e70f9e6579121f27b082bb8f0c2ce89447f4326df2deb97ffb634275622cc5cc  run_checks.py' '5d9a0dbe0f9640756b066c3d1bf5ecb5e27ed92a13a8ed409893b4a1e7442a3a  expected_source.json' '78a120264ce09dc32a873e1bdd7e33a938c43fd4fe0f05cb4a592f5d6f2d5de5  frozen_inputs.json' | sha256sum -c -
test "$(git -C "$BASE/source" rev-parse HEAD)" = 1c5758f97b7c502a38c850e8352ce970216bea53
test -z "$(git -C "$BASE/source" status --porcelain=v1 --untracked-files=all)"
test ! -e "$BASE/source/crates/robot-kinematics-xlerobot/src/base.rs"
cp base.rs "$BASE/source/crates/robot-kinematics-xlerobot/src/base.rs"
cp lib.rs "$BASE/source/crates/robot-kinematics-xlerobot/src/lib.rs"
exec taskset -c 0-3 uv run --no-project python run_checks.py
