set -eu
export PATH=/home/loosqk/.cargo/bin:/home/loosqk/.local/bin:$PATH
export PYTHONDONTWRITEBYTECODE=1
cd /home/loosqk/robot-checks/xlerobot-base-si-20260930-r1/bootstrap
printf '%s\n' '79bf11850de74a2e6d5521fbc9aa77fb40aa9b9279964a03dc5a19f3abe6d505  collect_native.py' | sha256sum -c -
exec uv run --no-project python collect_native.py --base /home/loosqk/robot-checks/xlerobot-base-si-20260930-r1 --out /home/loosqk/robot-checks/xlerobot-base-si-20260930-native-r1.tar.gz --collect
