set -eu
export PATH=/home/loosqk/.cargo/bin:/home/loosqk/.local/bin:$PATH
export CARGO_HOME=/home/loosqk/robot-checks/viz-orin-a6957cc-20260930-r1/cargo-home
export CARGO_NET_OFFLINE=true
export RUSTUP_AUTO_INSTALL=0
export PYTHONDONTWRITEBYTECODE=1
cd /home/loosqk/robot-checks/xlerobot-base-si-20260930-r1/bootstrap
printf '%s\n' 'c85f431f725ab78d3908429bea617bb565fda17301c901a31707a70a46734c3f  snapshot_inputs.py' | sha256sum -c -
exec uv run --no-project python snapshot_inputs.py
