"""首轮失败后的只读compiler身份；不继续Cargo测试或改源。"""
import importlib.util,json,signal,sys
from pathlib import Path
from types import SimpleNamespace
sys.dont_write_bytecode=True
BASE=Path('/home/loosqk/robot-checks/xlerobot-base-si-20260930-r1');SOURCE=BASE/'source';OUT=BASE/'diagnostic-r1'
def module(name,path):
    spec=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);return m
helper=module('diag_runner',Path('/home/loosqk/robot-checks/h2-trace-owner-v2-20260930-r1/bootstrap/run_release_v2.py'));a=module('diag_artifacts',SOURCE/'scripts/post_e_h2_artifacts.py');OUT.mkdir();r=helper.Runner(SimpleNamespace(source=SOURCE,out=OUT,target=Path('/home/loosqk/robot-checks/h2-nightly-v2-20260930-r1/build'),build_head='1c5758f97b7c502a38c850e8352ce970216bea53',formal_root=Path('/home/loosqk/repo/robot/robot-system')),a);result={'status':'FAIL','scope':'原ClippyFAIL保持；仅采失败后compiler，不执行crate测试。'};old={}
def interrupted(sig,frame):helper.INTERRUPTED=sig
try:
    for sig in (signal.SIGTERM,signal.SIGINT,signal.SIGHUP):old[sig]=signal.signal(sig,interrupted)
    _,p=r.command('rustc_after_failure',['rustc','-vV']);value=a.parse_rustc_identity(Path(p['stdout']).read_text());before=a.parse_rustc_identity((BASE/'checks-r1/rustc_after_update/stdout.log').read_text());a.require(value==before,'compiler变化');r.command('cargo_after_failure',['cargo','-V']);result.update(status='PASS',compiler_before_after_equal=True,compiler=value,original_result_status='FAIL',crate_lib='NOT_RUN')
except BaseException as error:result['error']=repr(error)
finally:
    result['receipts']=r.receipts;helper.save(OUT/'result.json',result)
    for sig,handler in old.items():signal.signal(sig,handler)
print(json.dumps(result,ensure_ascii=False));raise SystemExit(0 if result['status']=='PASS' else 1)
