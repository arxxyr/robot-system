"""追加验收 oracle 的纯软件反例；不执行 Cargo、ELF 或硬件。"""

import contextlib
import copy
import importlib.util
import io
import json
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch


PATH = Path(__file__).with_name("post_release_checks.py")
SPEC = importlib.util.spec_from_file_location("post_release_fixture", PATH)
p = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(p)


class PostChecksTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name)

    def report(self):
        directory = self.root / "000_runtime_sla_probe"
        directory.mkdir()
        (directory / "robot.toml").write_text('[[hardware]]\nadapter="mock_serial_rt"\nauto_enable=false\n')
        (directory / "events.csv").write_text("fixture\n")
        artifacts = {name: {"path": "/fixture/" + name, "sha256": "a" * 64, "sidecar": {}}
                     for name in ("s0_daemon", "robot_rpc_gateway", "comm_fault_e2e")}
        env = {"runtime_only": True, "hardware_only": False, "physical_uart": False,
               "mock_lease": True, "s48_cache_observation": False}
        groups = [{"external": external, "in_flight": flight, "requested_in_flight": flight,
                   "matched": True, "mock_lease": True, "real_rpc_recovery_verified": True}
                  for external in (False, True) for flight in (False, True) for _ in range(2)]
        data = {"environment": env, "measurement": {"runtime_only": True, "hardware_only": False,
                 "mock_lease": True, "trace_dropped": 0, "groups": groups, "events_csv": str(directory / "events.csv")},
                "final_state": {"ok": True}, "final_trace": {"valid": True, "children_stopped": True},
                "feetech_wire_check": {"hardware_only": False, "physical_measurement": False, "dropped": 0, "truncated": 0}}
        for name, value in (("environment.json", env), ("final_stop.json", data["final_state"]),
                            ("final_trace.json", data["final_trace"])):
            (directory / name).write_text(json.dumps(value))
        report = {"schema_version": 1, "status": "PASS", "invocation": {"phase": "Mock", "case_filter": "AC-12",
                  "config": None, "config_sha256": None, "hardware_id": None, "current_exe": "/fixture/comm_fault_e2e",
                  "current_exe_sha256": "a" * 64},
                  "hardware": {"H1": "NEEDS_HUMAN", "H2": "NEEDS_HUMAN", "H3": "NEEDS_HUMAN", "D15": "OPEN"},
                  "artifacts": [{"name": name, "path": item["path"], "sha256": item["sha256"],
                                 "build": {key: value for key, value in item.items() if key != "sidecar"}}
                                for name, item in artifacts.items()],
                  "cases": [{"case": "runtime_estop_sampling_and_recovery", "ac": "AC-12/13", "status": "PASS", "evidence": data}]}
        return report, {"artifacts": artifacts}

    @staticmethod
    def scenes():
        rows = []
        for index, reply in enumerate(["Ack", "Ack", "Ack", "Error", "WrongIdentity", "DryRun", "ZeroTimestamp", "Ack", "Ack"]):
            rows.append({"reply": reply, "server_joined": True, "active_requests": 0,
                         "ordinary": index == 1, "delay_ms": [2100, 2100, 3300][index] if index < 3 else 0,
                         "server_reply_elapsed_ns": 2_100_000_001 if index == 0 else None,
                         "evidence": {"ok": index == 0, "disable": {"message": "Timeout expired", "code": "Cancelled"} if index in (1, 2) else {}}})
        return rows

    @staticmethod
    def stdout(rows, summary="test result: ok. 6 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out;"):
        return "\n".join("test fixture ... " + json.dumps(row) for row in rows) + "\n" + summary

    def test_default_plan_has_no_actions(self):
        with patch.object(p, "load") as load, patch.object(p, "run") as run:
            with contextlib.redirect_stdout(io.StringIO()) as stream:
                self.assertEqual(p.main([]), 0)
            self.assertEqual(json.loads(stream.getvalue())["actions_started"], 0)
            load.assert_not_called()
            run.assert_not_called()

    def test_complete_mock_evidence_passes(self):
        report, manifest = self.report()
        self.assertEqual(p.validate_mock(report, manifest, self.root)["samples"], 8)

    def test_mock_rejects_missing_samples_bad_source_physical_claim_and_bad_stop(self):
        original, manifest = self.report()
        for mutate in (lambda r: r["cases"][0]["evidence"]["measurement"]["groups"].pop(),
                       lambda r: r["invocation"].update(config="/real/config"),
                       lambda r: r["invocation"].update(current_exe_sha256="b" * 64),
                       lambda r: r["hardware"].update(H2="PASS"),
                       lambda r: r["cases"][0]["evidence"]["final_state"].update(ok=False),
                       lambda r: r["cases"][0]["evidence"]["environment"].update(physical_uart=True),
                       lambda r: r["cases"].clear()):
            value = copy.deepcopy(original)
            mutate(value)
            with self.subTest(mutate=mutate), self.assertRaises(ValueError):
                p.validate_mock(value, manifest, self.root)

    def test_mock_actual_config_and_original_files_are_checked(self):
        report, manifest = self.report()
        directory = self.root / "000_runtime_sla_probe"
        (directory / "final_trace.json").write_text("{}")
        with self.assertRaisesRegex(ValueError, "原始文件"):
            p.validate_mock(report, manifest, self.root)
        (directory / "robot.toml").write_text('[[hardware]]\nadapter="feetech_sts3215"\nauto_enable=false\n')
        with self.assertRaisesRegex(ValueError, "无设备"):
            p.validate_mock(report, manifest, self.root)

    def test_loopback_six_tests_nine_real_scenes(self):
        self.assertEqual(len(p.validate_loopback(self.stdout(self.scenes()))), 9)

    def test_loopback_rejects_false_green_counts_short_delay_or_unjoined_server(self):
        for mutate in (lambda rows: rows.pop(), lambda rows: rows[0].update(server_joined=False),
                       lambda rows: rows[0].update(server_reply_elapsed_ns=2_099_999_999),
                       lambda rows: rows[1].update(ordinary=False),
                       lambda rows: rows[2]["evidence"]["disable"].update(code="Unavailable")):
            rows = self.scenes()
            mutate(rows)
            with self.subTest(mutate=mutate), self.assertRaises(ValueError):
                p.validate_loopback(self.stdout(rows))
        with self.assertRaises(ValueError):
            p.validate_loopback(self.stdout(self.scenes(), "test result: ok. 5 passed; 0 failed; 1 ignored;"))


if __name__ == "__main__":
    unittest.main()
