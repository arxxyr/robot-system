set -eu
export PATH=/home/loosqk/.cargo/bin:/home/loosqk/.local/bin:$PATH
export CARGO_HOME=/home/loosqk/robot-checks/viz-orin-a6957cc-20260930-r1/cargo-home
export CARGO_NET_OFFLINE=true
export RUSTUP_AUTO_INSTALL=0
cd /home/loosqk/robot-checks/h2-nightly-v2-20260930-r1
exec taskset -c 0-3 uv run --no-project python - <<'PY'
import hashlib,importlib.util,json,sys,tarfile
from pathlib import Path
from types import SimpleNamespace
base=Path.cwd()
source=base/'source'
sys.path.insert(0,str(source/'scripts'))
import post_e_h2_artifacts as a
helper_path=base/'bootstrap/run_release_v2.py'
assert a.sha256(helper_path)=='d6b20da28de8d5ae077a93cb2fb5ba7f27a66b8145df9e7e91951cb14ac0b12b'
spec=importlib.util.spec_from_file_location('helper',helper_path)
helper=importlib.util.module_from_spec(spec);spec.loader.exec_module(helper)
out=base/'final-quality-r1';out.mkdir()
runner=helper.Runner(SimpleNamespace(source=source,target=base/'build',out=out,build_head='59120e34bebd991accac41696425b1c743870a19'),a)
before=runner.source('source_before')
assert before==json.loads((base/'release-r1/source_before.json').read_text())
runner.command('rustc',['rustc','-vV'])
runner.command('fmt',['cargo','fmt','--all','--','--check'],300)
runner.command('clippy',['cargo','clippy','--locked','--all','--all-targets','--','-D','warnings'],1800)
assert runner.source('source_after')==before
helper.save(out/'result.json',{'status':'PASS','source_files':len(before['files']),'source_manifest_sha256':before['source_manifest_sha256'],'receipts':runner.receipts,'scope':'最终文档提交前相同 Rust 编译输入 fmt 与根 Clippy；无新硬件测试'})
archive=base/'final-quality-r1.tar.gz'
with tarfile.open(archive,'x:gz') as tar:
    tar.add(out,arcname=out.name)
print(json.dumps({'archive':str(archive),'sha256':a.sha256(archive),'bytes':archive.stat().st_size}))
PY
