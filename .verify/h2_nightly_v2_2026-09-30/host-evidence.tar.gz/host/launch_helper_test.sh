set -eu
export PATH=/home/loosqk/.cargo/bin:/home/loosqk/.local/bin:$PATH
BASE=/home/loosqk/robot-checks/h2-nightly-v2-20260930-r1
cd "$BASE/bootstrap"
printf '%s\n' 'd6b20da28de8d5ae077a93cb2fb5ba7f27a66b8145df9e7e91951cb14ac0b12b  run_release_v2.py' '1a098ea98df2570a3a02898af63bc05002603b99da1a7195e08dd80894c0ee6a  test_runner_native.py' | sha256sum -c -
exec uv run --no-project python test_runner_native.py --helper "$BASE/bootstrap/run_release_v2.py" --artifacts "$BASE/source/scripts/post_e_h2_artifacts.py" --out "$BASE/helper-native-r1"
