"""收口本轮纯软件证据；保留失败，不把软件通过改写为真机通过。"""
import gzip
import hashlib
import io
import json
from pathlib import Path
import shutil
import tarfile

ROOT = Path.cwd()
WORK = ROOT / 'target/post_e_h2_rt/s50/nightly_v2'
OUT = ROOT / '.verify/h2_nightly_v2_2026-09-30'
RAW = WORK / 'host/native-extracted'


def sha(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def read(path):
    return json.loads(path.read_text())


def save(path, value):
    with path.open('x') as stream:
        stream.write(json.dumps(value, ensure_ascii=False, indent=2) + '\n')


reviews = ['native_release_review.json', 'helper_native_review.json',
           'post_release_runtime_review.json', 'native_archive_review.json',
           'd15_closure_doc_review.json']
for name in reviews:
    assert (WORK / name).is_file(), name
    report = read(WORK / name)
    assert report['status'] == ('APPROVED_STATIC' if name == 'd15_closure_doc_review.json' else 'PASS'), name
    assert not report.get('blocking_findings'), name

release = read(RAW / 'release-r1/result.json')
post = read(RAW / 'post-release-r1/post_release_result.json')
assert release['status'] == post['status'] == 'PASS'
assert len(release['receipts']) == 18 and len(post['receipts']) == 17
assert read(WORK / 'host/final_quality_readback.json')['status'] == 'PASS'
assert read(WORK / 'host/final_fmt_local.json')['wait_returncode'] == 0
assert read(WORK / 'host/formal_after.json')['wait_returncode'] == 0

original = WORK / 'host/h2-nightly-v2-20260930-r1-evidence.tar.gz'
metadata = read(Path(str(original) + '.metadata.json'))
assert sha(original) == metadata['archive_sha256']
for src, name in [(original, 'native.tar.gz'),
                  (Path(str(original) + '.index.json'), 'native.index.json'),
                  (Path(str(original) + '.metadata.json'), 'native.metadata.json')]:
    dst = OUT / name
    assert not dst.exists()
    shutil.copyfile(src, dst)
    assert sha(dst) == sha(src)

# 下载包与大源码 bundle 已单独记录；原件提取副本不重复入本机包。
excluded_dirs = {'__pycache__', 'native-extracted', 'helper-native-r1', 'precommit-evidence'}
excluded_names = {'source.bundle', 'precommit.tar.gz',
                  'h2-nightly-v2-20260930-r1-evidence.tar.gz',
                  'h2-nightly-v2-20260930-r1-evidence.tar.gz.index.json',
                  'h2-nightly-v2-20260930-r1-evidence.tar.gz.metadata.json'}
paths = sorted(p for p in WORK.rglob('*') if p.is_file()
               and not any(x in excluded_dirs for x in p.relative_to(WORK).parts)
               and p.name not in excluded_names)
archive = OUT / 'host-evidence.tar.gz'
rows = []
with tarfile.open(archive, 'x:gz') as tar:
    for path in paths:
        assert not path.is_symlink()
        raw = path.read_bytes()
        name = path.relative_to(WORK).as_posix()
        item = tarfile.TarInfo(name)
        item.size, item.mode = len(raw), 0o644
        tar.addfile(item, io.BytesIO(raw))
        rows.append({'path': name, 'sha256': hashlib.sha256(raw).hexdigest(), 'bytes': len(raw)})
    raw = (json.dumps(rows, ensure_ascii=False, indent=2) + '\n').encode()
    item = tarfile.TarInfo('index.json'); item.size = len(raw)
    tar.addfile(item, io.BytesIO(raw))
with tarfile.open(archive) as tar:
    assert len(tar.getmembers()) == len(rows) + 1
    assert json.load(tar.extractfile('index.json')) == rows
    for row in rows:
        raw = tar.extractfile(row['path']).read()
        assert len(raw) == row['bytes'] and hashlib.sha256(raw).hexdigest() == row['sha256']
with gzip.open(archive, 'rb') as stream:
    while stream.read(1024 * 1024):
        pass

review_dir = OUT / 'reviews'; review_dir.mkdir()
for name in reviews:
    shutil.copyfile(WORK / name, review_dir / name)

source = read(RAW / 'release-r1/source_before.json')
artifacts = []
for kind in ['production', 'measurement']:
    manifest = read(RAW / 'release-r1' / (kind + '.json'))
    for name in manifest['artifacts']:
        path = RAW / 'release-r1' / kind / name
        artifacts.append({'kind': kind, 'name': name, 'sha256': sha(path), 'bytes': path.stat().st_size})

summary = {
    'status': 'H2_NATIVE_SOFTWARE_PREPARATION_ACCEPTED',
    'build_head': '59120e34bebd991accac41696425b1c743870a19',
    'source': {'files': len(source['files']), 'sha256': source['source_manifest_sha256']},
    'toolchain': {'channel': 'nightly', 'release': '1.101.0-nightly',
                  'commit': '5c543b0b8c73c7b72bc8284ced4fb22ead15734d',
                  'host': 'aarch64-unknown-linux-gnu',
                  'update': '真实 rustup update nightly 成功；前版本完整备份，未默认日期 pin'},
    'checks': {'native_recipes': 6, 'frozen_elf': 7, 'native_python_tests': 71,
               'native_helper_cases': 14, 'frozen_help': 7,
               'frozen_mock_ac12_groups': 4, 'frozen_mock_samples_per_group': 2,
               'source_bound_tonic_tests': 6, 'source_bound_tonic_scenes': 9,
               'fmt': 'PASS', 'root_clippy': 'PASS', 'default_plan_only': 'PASS',
               'full_workspace_rerun': False},
    'artifacts': artifacts,
    'evidence': {
        'native': {'path': 'native.tar.gz', 'sha256': sha(OUT / 'native.tar.gz'),
                   'bytes': metadata['archive_bytes'], 'indexed_files': metadata['indexed_files']},
        'native_index': {'path': 'native.index.json', 'sha256': sha(OUT / 'native.index.json')},
        'host': {'path': archive.name, 'sha256': sha(archive), 'bytes': archive.stat().st_size,
                 'indexed_files': len(rows), 'readback_verified': True},
        'product_precommit': {'path': 'precommit.json', 'sha256': sha(OUT / 'precommit.json')},
        'source_bundle_sha256': '4ee855e7c3e96317d6f0504179b3b24906902ddc5eb8f89e60c371d2efea0cc7'
    },
    'reviews': [{'path': 'reviews/' + name, 'sha256': sha(review_dir / name)} for name in reviews],
    'root_acceptance': '已复核产品差异、原生结果、回环场景、完整归档、独立报告与正式隔离；仅接受本轮软件准备',
    'formal_after': {'observed_until_utc': '2026-09-30T04:29:11.183228+00:00',
                     'head': 'ca14f0e6cf6df8ecc6baaaa8dff2dddb64abbd0a', 'clean': True,
                     'installed_four_unchanged': True, 'six_services': 'inactive/dead/MainPID0',
                     'control_processes_observed': 0},
    'retained_failures': [
        '产品阶段 macOS 68 中 65 PASS、2 FAIL+1 ERROR，另3项Linux专属未运行；原生71PASS',
        '辅助驱动早轮测试、路径与快速进程回执问题及修订原件保留',
        'release只读取证r1系统Python API不支持而失败，r2兼容/r3 uv原件均保留',
        'helper exit7、超时143、launch失败-15、EOF125为负控原退出，不抹成普通命令成功',
        '右H2历史最终Disable失败及其他历史失败不由本次软件通过覆盖'
    ],
    'hardware': {'new_h2_executed': False, 'right_h2': '历史整体FAIL，待当次现场事实与独立GO后完整重测',
                 'candidate_e_d15': 'OPEN', 'deployable': False,
                 'd15_document': '../../team-swe/specs/d15_hardware_fail_safe.CLOSURE.md',
                 'd15_document_state': '工作单，非Spec Approved、非硬件实现或验收'},
    'limits': ['未安装、未启动正式服务、未触串口或真实电机', '未push',
               'mock每组2样本不替代真机100预热+1000正式，软件回环不证明物理断扭',
               'loopback为同源测试执行文件；冻结测量ELF另由mock验证',
               '软件快照不能证明当前电源、扭矩、支撑或独立保护装置状态']
}
save(OUT / 'summary.json', summary)
print(json.dumps({'summary_sha256': sha(OUT / 'summary.json'), 'evidence': summary['evidence']}, ensure_ascii=False))
