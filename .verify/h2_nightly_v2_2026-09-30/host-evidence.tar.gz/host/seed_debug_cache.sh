set -eu
BASE=/home/loosqk/robot-checks/h2-nightly-v2-20260930-r1
OLD=/home/loosqk/robot-checks/viz-orin-a6957cc-20260930-r1
test ! -e "$BASE/build/debug"
# 只复制以前隔离软件检查的调试缓存；新 release 仍由六条原始 Cargo 命令产生。
cp -a --reflink=auto "$OLD/build/debug" "$BASE/build/debug"
test ! -e "$BASE/build/release"
du -sh "$BASE/build/debug"
