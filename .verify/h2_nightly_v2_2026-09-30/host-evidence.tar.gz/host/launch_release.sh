set -eu
export PATH=/home/loosqk/.cargo/bin:/home/loosqk/.local/bin:$PATH
export CARGO_HOME=/home/loosqk/robot-checks/viz-orin-a6957cc-20260930-r1/cargo-home
export CARGO_NET_OFFLINE=true
export RUSTUP_AUTO_INSTALL=0
BASE=/home/loosqk/robot-checks/h2-nightly-v2-20260930-r1
cd "$BASE/bootstrap"
printf '%s\n' 'd6b20da28de8d5ae077a93cb2fb5ba7f27a66b8145df9e7e91951cb14ac0b12b  run_release_v2.py' | sha256sum -c -
exec taskset -c 0-3 uv run --no-project python run_release_v2.py --run-builds --source "$BASE/source" --target "$BASE/build" --out "$BASE/release-r1" --build-head 59120e34bebd991accac41696425b1c743870a19 --formal-root /home/loosqk/repo/robot/robot-system
