set -eu
export PATH=/home/loosqk/.cargo/bin:/home/loosqk/.local/bin:$PATH
export CARGO_HOME=/home/loosqk/robot-checks/viz-orin-a6957cc-20260930-r1/cargo-home
export CARGO_NET_OFFLINE=true
export RUSTUP_AUTO_INSTALL=0
BASE=/home/loosqk/robot-checks/h2-nightly-v2-20260930-r1
cd "$BASE/bootstrap"
printf '%s\n' '4f567265b93687411324811363ab4d79a1730ff5a0d41bb745a37942c385449e  post_release_checks.py' 'd6b20da28de8d5ae077a93cb2fb5ba7f27a66b8145df9e7e91951cb14ac0b12b  run_release_v2.py' | sha256sum -c -
exec taskset -c 0-3 uv run --no-project python post_release_checks.py --run-checks --source "$BASE/source" --target "$BASE/build" --release "$BASE/release-r1" --out "$BASE/post-release-r1" --build-head 59120e34bebd991accac41696425b1c743870a19 --formal-root /home/loosqk/repo/robot/robot-system --helper "$BASE/bootstrap/run_release_v2.py"
