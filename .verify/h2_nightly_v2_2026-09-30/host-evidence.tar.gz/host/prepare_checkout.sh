set -eu
BASE=/home/loosqk/robot-checks/h2-nightly-v2-20260930-r1
FORMAL=/home/loosqk/repo/robot/robot-system
cd "$BASE/bootstrap"
printf '%s\n' '4ee855e7c3e96317d6f0504179b3b24906902ddc5eb8f89e60c371d2efea0cc7  source.bundle' | sha256sum -c -
test "$(git -C "$FORMAL" rev-parse HEAD)" = ca14f0e6cf6df8ecc6baaaa8dff2dddb64abbd0a
test -z "$(git -C "$FORMAL" status --porcelain)"
test ! -e "$BASE/source"
# 独立 checkout 只读取正式仓库对象，不改它的 HEAD、工作区、配置或服务。
git clone --shared --no-checkout "$FORMAL" "$BASE/source"
git -C "$BASE/source" bundle verify "$BASE/bootstrap/source.bundle"
git -C "$BASE/source" fetch "$BASE/bootstrap/source.bundle" HEAD
git -C "$BASE/source" checkout --detach 59120e34bebd991accac41696425b1c743870a19
git -C "$BASE/source" rev-parse HEAD
git -C "$BASE/source" status --porcelain
test -z "$(git -C "$BASE/source" status --porcelain)"
test "$(git -C "$FORMAL" rev-parse HEAD)" = ca14f0e6cf6df8ecc6baaaa8dff2dddb64abbd0a
test -z "$(git -C "$FORMAL" status --porcelain)"
