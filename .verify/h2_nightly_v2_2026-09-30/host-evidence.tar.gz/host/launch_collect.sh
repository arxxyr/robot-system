set -eu
export PATH=/home/loosqk/.cargo/bin:/home/loosqk/.local/bin:$PATH
BASE=/home/loosqk/robot-checks/h2-nightly-v2-20260930-r1
cd "$BASE/bootstrap"
printf '%s\n' 'c6f504835416659089aafff58c4a1d93bc29ea1ed185e0374b46b5e76d832520  collect_native.py' | sha256sum -c -
exec uv run --no-project python collect_native.py --collect --base "$BASE" --out /home/loosqk/robot-checks/h2-nightly-v2-20260930-r1-evidence.tar.gz
