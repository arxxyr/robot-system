import base64, hashlib, json, os, stat, subprocess
from pathlib import Path
base=Path('/home/loosqk/robot-checks/h2-nightly-v2-20260930-r1')
release=base/'release-r1'
source=base/'source'
formal=Path('/home/loosqk/repo/robot/robot-system/target/release')
expected_head='59120e34bebd991accac41696425b1c743870a19'
def identity(p):
    s=p.lstat()
    assert stat.S_ISREG(s.st_mode), str(p)
    with p.open('rb') as f:
        header=f.read(64); f.seek(0); h=hashlib.file_digest(f,'sha256').hexdigest()
    s2=p.lstat(); assert (s.st_dev,s.st_ino,s.st_size,s.st_mtime_ns,s.st_ctime_ns)==(s2.st_dev,s2.st_ino,s2.st_size,s2.st_mtime_ns,s2.st_ctime_ns)
    return {'path':str(p),'resolved':str(p.resolve()),'sha256':h,'bytes':s.st_size,'mode':stat.S_IMODE(s.st_mode),'device':s.st_dev,'inode':s.st_ino,'nlink':s.st_nlink,'mtime_ns':s.st_mtime_ns,'elf_header_hex':header.hex()}
assert release.is_dir() and not release.is_symlink()
sets={kind:json.loads((release/(kind+'.json')).read_text()) for kind in ('production','measurement')}
frozen={item['path'] for manifest in sets.values() for item in manifest['artifacts'].values()}
assert len(frozen)==7
out={'scope':'只读原件/源/冻结7ELF/正式4文件，不执行产物或构建','files':{},'actual_frozen':{},'source_actual':{},'formal_actual':{},'git':{}}
for directory, dirs, files in os.walk(release, followlinks=False):
    for name in dirs: assert not (Path(directory)/name).is_symlink()
    for name in sorted(files):
        path=Path(directory)/name; entry=identity(path)
        if str(path) in frozen:
            out['actual_frozen'][str(path)]=entry
        else:
            raw=path.read_bytes(); assert hashlib.sha256(raw).hexdigest()==entry['sha256']
            entry['base64']=base64.b64encode(raw).decode(); out['files'][str(path)]=entry
before=json.loads((release/'source_before.json').read_text())
for name, expected in before['files'].items():
    path=source/name; assert path.resolve().is_relative_to(source) and '..' not in Path(name).parts
    row=identity(path)
    out['source_actual'][name]={'sha256':row['sha256'],'bytes':row['bytes'],'executable':bool(row['mode'] & stat.S_IXUSR)}
for name in ('s0_daemon','xlerobot_deploy','s1_daemon','robot_rpc_gateway'):
    out['formal_actual'][name]=identity(formal/name)
for name,argv in [('head',['git','-C',str(source),'rev-parse','HEAD']),('status',['git','-C',str(source),'status','--porcelain=v1','--untracked-files=all']),('inventory',['git','-C',str(source),'ls-files','-z','--cached','--others','--exclude-standard'])]:
    p=subprocess.Popen(argv,stdout=subprocess.PIPE,stderr=subprocess.PIPE,env={**os.environ,'GIT_OPTIONAL_LOCKS':'0'})
    try: stdout,stderr=p.communicate(timeout=20)
    except subprocess.TimeoutExpired:
        p.kill(); stdout,stderr=p.communicate(); raise RuntimeError('只读Git超时，直接child已wait')
    out['git'][name]={'argv':argv,'pid':p.pid,'wait_returncode':p.returncode,'reaped':True,'stdout':stdout.decode(),'stderr':stderr.decode()}
    assert p.returncode==0
assert out['git']['head']['stdout'].strip()==expected_head and out['git']['status']['stdout']==''
print(json.dumps(out,ensure_ascii=False,separators=(',',':')))
