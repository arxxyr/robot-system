"""仅临时目录验证归档边界；不读取或修改 native 真实结果。"""

import contextlib
import importlib.util
import io
import json
from pathlib import Path
import os
import tarfile
import tempfile
import unittest
from unittest.mock import patch


SCRIPT = Path(__file__).resolve().with_name("collect_native.py")
SPEC = importlib.util.spec_from_file_location("collector_fixture", SCRIPT)
c = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(c)


class CollectorTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name).resolve()
        self.base = self.root / "native"
        self.base.mkdir()
        self.out = self.root / "evidence.tar.gz"

    def populate(self):
        for name in c.TREES:
            (self.base / name).mkdir()
            (self.base / name / "raw-result.json").write_text('{"status":"FAIL","exit_code":7}\n')
        (self.base / "bootstrap").mkdir()
        for name in c.BOOTSTRAP_FILES:
            (self.base / "bootstrap" / name).write_text("原始输入\n")
        for kind, names in c.FROZEN.items():
            folder = self.base / "release-r1" / kind
            folder.mkdir()
            for name in names:
                (folder / name).write_bytes(b"\x7fELF\x00\xfforiginal")
                (folder / name).chmod(0o751)
                (folder / (name + ".build.json")).write_text('{"status":"FAIL"}\n')
        for name in ("production.json", "measurement.json", "result.json"):
            (self.base / "release-r1" / name).write_text('{"status":"FAIL"}\n')
        for name in ("source", "build", "nightly-before", "cargo-home"):
            (self.base / name).mkdir()
            (self.base / name / "excluded").write_text("不得归档\n")
        (self.base / "bootstrap/source.bundle").write_text("不得归档\n")

    def run_collector(self, *args):
        with contextlib.redirect_stdout(io.StringIO()):
            return c.main(["--base", str(self.base), "--out", str(self.out), *args])

    def metadata(self):
        return json.loads(Path(str(self.out) + ".metadata.json").read_text())

    def test_default_plan_allows_missing_inputs_without_writes(self):
        self.assertEqual(self.run_collector(), 0)
        self.assertEqual(list(self.base.iterdir()), [])
        self.assertFalse(self.out.exists())
        self.assertFalse(Path(str(self.out) + ".metadata.json").exists())

    def test_roundtrip_preserves_fail_bytes_and_mode_excludes_unselected(self):
        self.populate()
        self.assertEqual(self.run_collector("--collect"), 0)
        self.assertEqual(self.metadata()["status"], "PASS")
        with tarfile.open(self.out, "r:gz") as archive:
            self.assertEqual(archive.extractfile("release-r1/raw-result.json").read(), b'{"status":"FAIL","exit_code":7}\n')
            self.assertEqual(archive.getmember("release-r1/production/s0_daemon").mode, 0o751)
            self.assertEqual(len(archive.getnames()), len(set(archive.getnames())))
            self.assertFalse(any(name.split("/")[0] in ("source", "build", "nightly-before", "cargo-home") for name in archive.getnames()))
            self.assertNotIn("bootstrap/source.bundle", archive.getnames())
            self.assertEqual(archive.extractfile(c.INDEX_NAME).read(), Path(str(self.out) + ".index.json").read_bytes())

    def test_missing_tree_is_failure(self):
        self.assertEqual(self.run_collector("--collect"), 1)
        self.assertEqual(self.metadata()["status"], "FAIL")
        self.assertFalse(self.out.exists())

    def test_missing_frozen_member_is_failure(self):
        self.populate()
        (self.base / "release-r1/production/s0_daemon").unlink()
        self.assertEqual(self.run_collector("--collect"), 1)
        self.assertFalse(self.out.exists())

    def test_leaf_symlink_is_rejected(self):
        self.populate()
        (self.base / "release-r1/link").symlink_to(SCRIPT)
        self.assertEqual(self.run_collector("--collect"), 1)
        self.assertFalse(self.out.exists())

    def test_directory_symlink_is_rejected(self):
        self.populate()
        (self.base / "release-r1/link-dir").symlink_to(self.base / "source", target_is_directory=True)
        self.assertEqual(self.run_collector("--collect"), 1)
        self.assertFalse(self.out.exists())

    def test_fifo_is_rejected_without_opening(self):
        self.populate()
        os.mkfifo(self.base / "release-r1/pipe")
        self.assertEqual(self.run_collector("--collect"), 1)
        self.assertFalse(self.out.exists())

    def test_output_under_base_is_rejected_before_write(self):
        self.populate()
        self.out = self.base / "self.tar.gz"
        with self.assertRaises(ValueError):
            self.run_collector("--collect")
        self.assertFalse(self.out.exists())

    def test_existing_archive_is_never_overwritten(self):
        self.populate()
        self.out.write_bytes(b"existing")
        with self.assertRaises(ValueError):
            self.run_collector("--collect")
        self.assertEqual(self.out.read_bytes(), b"existing")

    def test_existing_metadata_is_never_overwritten(self):
        self.populate()
        path = Path(str(self.out) + ".metadata.json")
        path.write_bytes(b"existing")
        with self.assertRaises(ValueError):
            self.run_collector("--collect")
        self.assertEqual(path.read_bytes(), b"existing")
        self.assertFalse(self.out.exists())

    def test_changed_input_preserves_failed_archive(self):
        self.populate()
        original = c.write_archive

        def changed(*args):
            original(*args)
            (self.base / "release-r1/raw-result.json").write_text("改变后的原件\n")

        with patch.object(c, "write_archive", side_effect=changed):
            self.assertEqual(self.run_collector("--collect"), 1)
        self.assertEqual(self.metadata()["status"], "FAIL")
        self.assertTrue(self.out.exists())
        self.assertEqual(self.metadata()["partial_archive_preserved"], str(self.out))

    def test_truncated_archive_fails_readback(self):
        self.populate()
        self.assertEqual(self.run_collector("--collect"), 0)
        data = Path(str(self.out) + ".index.json").read_bytes()
        self.out.write_bytes(self.out.read_bytes()[:-16])
        with self.assertRaises((EOFError, OSError, ValueError)):
            c.verify_archive(self.out, json.loads(data), data)


if __name__ == "__main__":
    unittest.main()
