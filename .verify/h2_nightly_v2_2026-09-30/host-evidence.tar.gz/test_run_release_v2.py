"""本轮 runner 的纯 mock 回执与所有权回归；不启动真实子进程。"""

import contextlib
import importlib.util
import io
import json
from pathlib import Path
import tempfile
from types import SimpleNamespace
import unittest
from unittest.mock import patch


HERE = Path(__file__).resolve().parent
REPO = HERE.parents[3]


def load(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


r = load("release_v2_fixture", HERE / "run_release_v2.py")
a = load("artifacts_fixture", REPO / "scripts/post_e_h2_artifacts.py")


class FakeProcess:
    pid = 12345

    def __init__(self, code=0):
        self.code = code

    def wait(self, timeout=None):
        return self.code


class RunnerTests(unittest.TestCase):
    def setUp(self):
        r.INTERRUPTED = None
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name)
        self.options = SimpleNamespace(source=self.root, target=self.root, out=self.root)
        self.runner = r.Runner(self.options, a)
        original_read = Path.read_text
        original_link = r.os.readlink

        def read(path, *args, **kwargs):
            if str(path) == "/proc/sys/kernel/random/boot_id":
                return "aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaaa\n"
            return original_read(path, *args, **kwargs)

        def readlink(path, *args, **kwargs):
            if str(path) == "/proc/12345/exe":
                return "/fixture/python"
            return original_link(path, *args, **kwargs)

        patches = [patch.object(Path, "read_text", read),
                   patch.object(r, "proc_entry", return_value={"pid": 12345, "start_ticks": 123,
                                                               "sid": 12345, "pgid": 12345, "state": "S"}),
                   patch.object(r.os, "readlink", side_effect=readlink),
                   patch.object(r.os, "write", return_value=1)]
        for item in patches:
            item.start()
            self.addCleanup(item.stop)

    def completion(self, name):
        return json.loads((self.root / name / "completion.json").read_text())

    def test_default_plan_never_constructs_runner_or_spawns(self):
        with patch.object(r, "Runner") as runner, patch.object(r.subprocess, "Popen") as popen:
            with contextlib.redirect_stdout(io.StringIO()) as output:
                self.assertEqual(r.main([]), 0)
            self.assertEqual(json.loads(output.getvalue())["actions_started"], 0)
            runner.assert_not_called()
            popen.assert_not_called()

    def test_overlapping_formal_and_source_paths_rejected_before_run(self):
        paths = {}
        for name in ("source", "target", "formal-root"):
            path = (self.root / name).resolve()
            path.mkdir()
            paths[name] = path
        paths["out"] = (self.root / "out").resolve()
        for name, owner in (("source", "formal-root"), ("target", "formal-root"),
                            ("out", "formal-root"), ("target", "source"), ("out", "source")):
            changed = dict(paths)
            changed[name] = changed[owner] / name
            if name != "out":
                changed[name].mkdir(exist_ok=True)
            argv = ["--run-builds", "--build-head", "a" * 40]
            for key, value in changed.items():
                argv.extend(["--" + key, str(value)])
            with self.subTest(name=name, owner=owner), patch.object(r.platform, "system", return_value="Linux"):
                with patch.object(r.platform, "machine", return_value="aarch64"), patch.object(r, "run") as run:
                    with contextlib.redirect_stderr(io.StringIO()), self.assertRaises(SystemExit):
                        r.main(argv)
                    run.assert_not_called()

    def test_natural_wait_produces_valid_p7_completion(self):
        with patch.object(r.subprocess, "Popen", return_value=FakeProcess()), patch.object(r, "session_members", return_value=[]):
            reference, row = self.runner.command("natural", ["rustc", "-vV"])
        self.assertEqual(a.validate_completion(reference)["pid"], 12345)
        self.assertTrue(row["reaped"])
        self.assertEqual(row["signals"], [])
        self.assertEqual(row["identity_phase"], "bootstrap")
        self.assertEqual(row["identity"]["exe"], "/fixture/python")
        self.assertEqual(row["bootstrap_argv"][4:], ["rustc", "-vV"])
        self.assertTrue(row["exec_gate_released"])

    def test_identity_and_launch_are_recorded_before_exec_permission(self):
        observed = []
        original_save = r.save

        def save(path, value):
            observed.append(path.name)
            return original_save(path, value)

        def permit(fd, value):
            self.assertEqual(value, b"G")
            self.assertIn("launch.json", observed)
            observed.append("GO")
            return 1

        with patch.object(r.subprocess, "Popen", return_value=FakeProcess()), patch.object(r, "session_members", return_value=[]):
            with patch.object(r, "save", side_effect=save), patch.object(r.os, "write", side_effect=permit):
                self.runner.command("ordered_gate", ["rustc", "-vV"])
        self.assertEqual(observed, ["launch.json", "GO", "completion.json"])

    def test_timeout_reaps_owned_child_and_preserves_failure(self):
        def cleanup(process, actions):
            actions.append({"pid": process.pid, "signal": "SIGTERM"})
            return -15, True

        with patch.object(r.subprocess, "Popen", return_value=FakeProcess()), patch.object(r, "session_members", return_value=[]):
            with patch.object(r, "stop_owned", side_effect=cleanup) as stop:
                with self.assertRaises(ValueError):
                    self.runner.command("timeout", ["cargo", "build"], timeout=0)
                stop.assert_called_once()
        row = self.completion("timeout")
        self.assertTrue(row["reaped"])
        self.assertEqual(row["exit_code"], -15)
        self.assertIn("TimeoutError", row["runner_error"])

    def test_nonzero_exit_is_not_replaced_by_successful_cleanup(self):
        with patch.object(r.subprocess, "Popen", return_value=FakeProcess(1)), patch.object(r, "session_members", return_value=[]):
            with patch.object(r, "stop_owned", return_value=(1, True)):
                with self.assertRaises(ValueError):
                    self.runner.command("nonzero", ["cargo", "build"])
        row = self.completion("nonzero")
        self.assertEqual(row["exit_code"], 1)
        self.assertIn("runner_error", row)

    def test_launch_receipt_failure_still_cleans_owned_process(self):
        original = r.save

        def write(path, value):
            if path.name == "launch.json":
                raise OSError("fixture launch write failure")
            return original(path, value)

        with patch.object(r.subprocess, "Popen", return_value=FakeProcess()), patch.object(r, "session_members", return_value=[]):
            with patch.object(r, "save", side_effect=write), patch.object(r, "stop_owned", return_value=(-15, True)) as stop:
                with patch.object(r.os, "write") as release:
                    with self.assertRaises(ValueError):
                        self.runner.command("launch_error", ["cargo", "build"])
                    release.assert_not_called()
                stop.assert_called_once()
        self.assertTrue(self.completion("launch_error")["reaped"])

    def test_residual_descendant_is_failure_even_after_cleanup(self):
        with patch.object(r.subprocess, "Popen", return_value=FakeProcess()), patch.object(r, "session_members", side_effect=[[{"pid": 678}], []]):
            with patch.object(r, "stop_owned", return_value=(0, True)) as stop:
                with self.assertRaises(ValueError):
                    self.runner.command("residual", ["cargo", "build"])
                stop.assert_called_once()
        row = self.completion("residual")
        self.assertEqual(row["session_residual_before_cleanup"], [{"pid": 678}])
        self.assertIn("runner_error", row)


if __name__ == "__main__":
    unittest.main()
