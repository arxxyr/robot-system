"""只打包当前受测脚本及完整 Rust 输入清单，不包含构建缓存。"""
import importlib.util
import io
import json
from pathlib import Path
import subprocess
import tarfile

root = Path.cwd()
out = root / 'target/post_e_h2_rt/s50/nightly_v2/host'
spec = importlib.util.spec_from_file_location('artifacts', root / 'scripts/post_e_h2_artifacts.py')
a = importlib.util.module_from_spec(spec)
spec.loader.exec_module(a)
names = subprocess.check_output(['git', 'ls-files', '-z', '--cached', '--others', '--exclude-standard']).decode().rstrip('\0').split('\0')
source = a.snapshot_source(root, names)
scripts = ['scripts/post_e_h2_artifacts.py', 'scripts/run_post_e_h2.py', 'scripts/post_e_h2_report.py',
           'scripts/tests/test_post_e_h2_artifacts.py', 'scripts/tests/test_run_post_e_h2.py']
index = {name: {'sha256': a.sha256(root / name), 'bytes': (root / name).stat().st_size} for name in scripts}
with tarfile.open(out / 'precommit.tar.gz', 'x:gz') as tar:
    for name in scripts:
        tar.add(root / name, arcname=name, recursive=False)
    tar.add(out / 'precommit.py', arcname='precommit.py', recursive=False)
    for name, value in [('current-source.json', source), ('scripts-index.json', index)]:
        data = (json.dumps(value, ensure_ascii=False, indent=2) + '\n').encode()
        item = tarfile.TarInfo(name)
        item.size = len(data)
        tar.addfile(item, io.BytesIO(data))
(out / 'current-source.json').write_text(json.dumps(source, ensure_ascii=False, indent=2) + '\n')
print(json.dumps({'archive_sha256': a.sha256(out / 'precommit.tar.gz'), 'rust_files': len(source['files']), 'source_manifest_sha256': source['source_manifest_sha256'], 'scripts': index}, ensure_ascii=False))
