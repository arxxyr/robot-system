set -eu
export PATH=/home/loosqk/.cargo/bin:/home/loosqk/.local/bin:$PATH
TASK_ROOT=/home/loosqk/robot-checks/h2-nightly-v2-20260930-r1
test ! -e "$TASK_ROOT"
mkdir -p "$TASK_ROOT/build" "$TASK_ROOT/bootstrap"
cp -a --reflink=auto /home/loosqk/.rustup/toolchains/nightly-aarch64-unknown-linux-gnu "$TASK_ROOT/nightly-before"
rustc +nightly -Vv > "$TASK_ROOT/bootstrap/nightly-before.txt"
sha256sum "$TASK_ROOT/nightly-before/bin/rustc" "$TASK_ROOT/nightly-before/bin/cargo"
timeout --signal=TERM --kill-after=10s 180 rustup update nightly --no-self-update > "$TASK_ROOT/bootstrap/update-nightly.log" 2>&1
cat "$TASK_ROOT/bootstrap/update-nightly.log"
rustc +nightly -Vv
cat /sys/devices/system/cpu/online
cat /sys/devices/system/cpu/isolated
