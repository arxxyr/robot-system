"""当前 Rust 输入逐项绑定到既有隔离源码；执行本次提交前检查与新 Python 套件。"""
import importlib.util
import json
import os
from pathlib import Path
import sys

HERE = Path(__file__).resolve().parent
BASE = HERE.parent
OLD = Path('/home/loosqk/robot-checks/viz-orin-a6957cc-20260930-r1')
sys.path.insert(0, str(HERE / 'scripts'))
import post_e_h2_artifacts as a
spec = importlib.util.spec_from_file_location('prior_software_runner', OLD / 'run_native.py')
gate = importlib.util.module_from_spec(spec)
spec.loader.exec_module(gate)
out = BASE / 'precommit-evidence'
out.mkdir()
expected = json.loads((HERE / 'current-source.json').read_text())
actual = a.snapshot_source(OLD / 'source', list(expected['files']))
a.require(actual == expected, '当前完整 Rust 输入与被检查的隔离源码不符')
gate.save(out / 'rust_source_binding.json', actual)
bundle = json.loads((HERE / 'scripts-index.json').read_text())
for name, identity in bundle.items():
    path = HERE / name
    a.require(path.stat().st_size == identity['bytes'] and a.sha256(path) == identity['sha256'], 'Python 输入身份不符')
gate.save(out / 'scripts_binding.json', bundle)
env, shown, removed = a.fixed_build_environment(OLD / 'build')
gate.save(out / 'environment.json', {'shown': shown, 'removed': removed})
gate.run_command(OLD / 'source', out, env, 'rustc', ['rustc', '-vV'], 60)
gate.run_command(OLD / 'source', out, env, 'fmt', ['cargo', 'fmt', '--all', '--', '--check'], 300)
gate.run_command(OLD / 'source', out, env, 'clippy', ['cargo', 'clippy', '--locked', '--all', '--all-targets', '--', '-D', 'warnings'], 1800)
gate.run_command(HERE, out, env, 'python', ['uv', 'run', '--no-project', 'python', '-m', 'unittest', 'discover', '-s', 'scripts/tests', '-p', 'test_*.py', '-v'], 300)
gate.run_command(HERE, out, env, 'plan_only', ['uv', 'run', '--no-project', 'python', 'scripts/run_post_e_h2.py', '--side', 'right'], 60)
a.require(json.loads((out / 'plan_only.log').read_text())['mode'] == 'PLAN_ONLY', '默认入口非计划')
a.require(a.snapshot_source(OLD / 'source', list(expected['files'])) == expected, 'Rust 输入在检查中变化')
gate.save(out / 'result.json', {'status': 'PASS', 'hardware_started': False, 'scope': '当前相同 Rust 输入的全根 Clippy 与新 Python 脚本回归；不作为新 release 构建证明'})
