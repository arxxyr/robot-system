set -eu
export PATH=/home/loosqk/.cargo/bin:/home/loosqk/.local/bin:$PATH
export CARGO_HOME=/home/loosqk/robot-checks/viz-orin-a6957cc-20260930-r1/cargo-home
export CARGO_NET_OFFLINE=true
BASE=/home/loosqk/robot-checks/h2-nightly-v2-20260930-r1
cd "$BASE/bootstrap"
printf '%s\n' 'fdf7cd138ab7893bab1b5cb0545084e191556e2b86e4ec0cecf9a29eadcf79cd  precommit.tar.gz' | sha256sum -c -
mkdir "$BASE/precommit"
tar xzf precommit.tar.gz -C "$BASE/precommit"
cd "$BASE/precommit"
exec uv run --no-project python precommit.py
