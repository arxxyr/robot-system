"""本机命令证据与自有子进程回收，不覆盖已有回执。"""
import argparse,datetime,hashlib,json,os,signal,subprocess,time
from pathlib import Path
parser=argparse.ArgumentParser()
parser.add_argument("--label",required=True)
parser.add_argument("--timeout",type=int,default=120)
parser.add_argument("--input")
parser.add_argument("command",nargs=argparse.REMAINDER)
a=parser.parse_args()
cmd=a.command[1:] if a.command[:1]==["--"] else a.command
base=Path(__file__).resolve().parent
assert a.label.replace("_","").replace("-","").isalnum()
log=base/(a.label+".log"); receipt=base/(a.label+".json")
assert not log.exists() and not receipt.exists()
start=datetime.datetime.now(datetime.timezone.utc).isoformat(); mono=time.monotonic_ns()
inp=open(a.input,"rb") if a.input else subprocess.DEVNULL
timed_out=False
with log.open("xb") as f:
    child=subprocess.Popen(cmd,stdin=inp,stdout=f,stderr=subprocess.STDOUT,start_new_session=True)
    try:
        code=child.wait(timeout=a.timeout)
    except subprocess.TimeoutExpired:
        timed_out=True
        os.killpg(child.pid,signal.SIGTERM)
        try: code=child.wait(timeout=10)
        except subprocess.TimeoutExpired:
            os.killpg(child.pid,signal.SIGKILL)
            code=child.wait()
if a.input: inp.close()
data=log.read_bytes()
row={"command":cmd,"pid":child.pid,"wait_returncode":code,"reaped":True,"timed_out":timed_out,"started_utc":start,"finished_utc":datetime.datetime.now(datetime.timezone.utc).isoformat(),"elapsed_ns":time.monotonic_ns()-mono,"log":log.name,"log_sha256":hashlib.sha256(data).hexdigest(),"log_bytes":len(data)}
receipt.write_text(json.dumps(row,ensure_ascii=False,indent=2)+"\n")
print(json.dumps(row,ensure_ascii=False),flush=True)
print(data.decode(errors="replace")[-14000:],flush=True)
raise SystemExit(124 if timed_out else code)
