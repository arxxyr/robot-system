"""归档 V2 产品阶段真实检查与原始失败，release 准备另立阶段。"""
import hashlib
import io
import json
from pathlib import Path
import tarfile

ROOT = Path.cwd()
WORK = ROOT / 'target/post_e_h2_rt/s50/nightly_v2'
OUT = ROOT / '.verify/h2_nightly_v2_2026-09-30'
OUT.mkdir(exist_ok=True)
def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()
paths = sorted(p for folder in (WORK / 'host', WORK / 'local') for p in folder.rglob('*') if p.is_file() and '__pycache__' not in p.parts)
rows = []
archive = OUT / 'precommit.tar.gz'
with tarfile.open(archive, 'x:gz') as tar:
    for path in paths:
        data = path.read_bytes()
        name = str(path.relative_to(WORK))
        item = tarfile.TarInfo(name)
        item.size = len(data)
        item.mode = 0o644
        tar.addfile(item, io.BytesIO(data))
        rows.append({'path': name, 'sha256': hashlib.sha256(data).hexdigest(), 'bytes': len(data)})
    data = (json.dumps(rows, ensure_ascii=False, indent=2) + '\n').encode()
    item = tarfile.TarInfo('index.json')
    item.size = len(data)
    tar.addfile(item, io.BytesIO(data))
with tarfile.open(archive) as tar:
    assert len(tar.getmembers()) == len(rows) + 1
    for row in rows:
        data = tar.extractfile(row['path']).read()
        assert len(data) == row['bytes'] and hashlib.sha256(data).hexdigest() == row['sha256']
native = WORK / 'host/precommit-evidence'
assert json.loads((native / 'result.json').read_text())['status'] == 'PASS'
assert 'Ran 71 tests' in (native / 'python.log').read_text() and (native / 'python.log').read_text().endswith('\nOK\n')
source = json.loads((WORK / 'host/current-source.json').read_text())
result = {
    'status': 'PRODUCT_SOFTWARE_PASS_RELEASE_PREPARATION_PENDING',
    'archive': {'path': archive.name, 'sha256': sha(archive), 'bytes': archive.stat().st_size, 'indexed_files': len(rows), 'readback_verified': True},
    'code_base': 'a1e0ad3cb76f59d7c11306753d4976cf19b11e5e',
    'changed_product_files': json.loads((WORK / 'local/result.json').read_text())['changed_files'],
    'source': {'files': len(source['files']), 'sha256': source['source_manifest_sha256'], 'binding': '当前 Rust 编译域逐项与已有隔离源码相同；本轮新执行 fmt / 根 Clippy，不是新 release 构建'},
    'toolchain': {'channel': 'nightly', 'release': '1.101.0-nightly', 'commit': '5c543b0b8c73c7b72bc8284ced4fb22ead15734d', 'update_status': '真实 rustup update nightly 成功，已是最新；原 nightly 目录完整备份'},
    'checks': {'local_fmt': 'PASS', 'native_fmt': 'PASS', 'native_root_clippy': 'PASS', 'native_python_tests': 71, 'native_plan_only': 'PASS', 'local_targeted_tests': 20},
    'retained_failures': {'mac_broader': '68 中 65 PASS、2 FAIL + 1 ERROR；另 3 项 Linux 专属未运行，平台原因见原件；原生完整 71 已 PASS', 'initial_fixture': '临时目录规范路径夹具首轮 FAIL 保留'},
    'review': {'product_independent': '/root/next_step_review，六产品文件静态独审通过', 'root': '原生结果、源码绑定、产品差异及目标文档勘误已验收'},
    'limits': ['新七件 release 尚未构建验收', '未启动硬件、正式业务服务或安装', '右 H2 仍原整体 FAIL', '候选 E D15 OPEN', 'deployable=false']
}
(OUT / 'precommit.json').write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n')
print(json.dumps({'archive': result['archive'], 'summary_sha256': sha(OUT / 'precommit.json')}, ensure_ascii=False))
