#!/usr/bin/env python3
"""V2 冻结七件的纯软件追加验收；默认 PLAN_ONLY，不做部署或现场测量。"""

import argparse
from collections import Counter
import importlib.util
import json
from pathlib import Path
import platform
import re
import signal
import sys
import tomllib


def require(condition, message):
    if not condition:
        raise ValueError(message)


def load(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def validate_mock(report, measurement, evidence_root):
    """只接受唯一 AC-12/13 软件场景，不能将空报告或物理场景计入通过。"""
    require(report["schema_version"] == 1 and report["status"] == "PASS", "mock 报告未通过")
    invocation = report["invocation"]
    require(invocation["phase"] == "Mock" and invocation["case_filter"] == "AC-12"
            and invocation["config"] is None and invocation["config_sha256"] is None
            and invocation["hardware_id"] is None, "不是批准的无现场参数 mock")
    tool = measurement["artifacts"]["comm_fault_e2e"]
    require(invocation["current_exe"] == tool["path"] and invocation["current_exe_sha256"] == tool["sha256"],
            "mock 运行工具与冻结件不符")
    require(report["hardware"] == {"H1": "NEEDS_HUMAN", "H2": "NEEDS_HUMAN", "H3": "NEEDS_HUMAN", "D15": "OPEN"},
            "软件报告错误宣称硬件通过")
    expected = measurement["artifacts"]
    require(len(report["artifacts"]) == 3 and {row["name"] for row in report["artifacts"]} == set(expected),
            "mock 三件来源集合不符")
    for row in report["artifacts"]:
        item = expected[row["name"]]
        require(row["path"] == item["path"] and row["sha256"] == item["sha256"]
                and row["build"] == {key: value for key, value in item.items() if key != "sidecar"},
                "mock 三件来源与完整 sidecar 不符")
    require(len(report["cases"]) == 1, "mock 不是唯一批准 case")
    case = report["cases"][0]
    require(case["case"] == "runtime_estop_sampling_and_recovery" and case["ac"] == "AC-12/13"
            and case["status"] == "PASS", "mock 场景身份或结果不符")
    data = case["evidence"]
    env, measured = data["environment"], data["measurement"]
    require(env["runtime_only"] is True and env["hardware_only"] is False and env["physical_uart"] is False
            and env["mock_lease"] is True and env["s48_cache_observation"] is False, "mock 环境越界")
    require(measured["runtime_only"] is True and measured["hardware_only"] is False
            and measured["mock_lease"] is True and measured["trace_dropped"] == 0, "mock 测量来源或事件丢失")
    groups = measured["groups"]
    require(len(groups) == 8 and Counter((row["external"], row["in_flight"]) for row in groups)
            == Counter({(False, False): 2, (False, True): 2, (True, False): 2, (True, True): 2}),
            "mock 未完整取得四组各两样本")
    for row in groups:
        require(row["matched"] is True and row["mock_lease"] is True and row["real_rpc_recovery_verified"] is True
                and row["requested_in_flight"] == row["in_flight"], "mock 样本或实际恢复未匹配")
    require(data["final_state"]["ok"] is True and data["final_trace"]["valid"] is True
            and data["final_trace"]["children_stopped"] is True, "mock 最终停止或回收证据失败")
    wire = data["feetech_wire_check"]
    require(wire["hardware_only"] is False and wire["physical_measurement"] is False
            and wire["dropped"] == 0 and wire["truncated"] == 0, "wire 软件记录边界不符")
    directory = evidence_root / "000_runtime_sla_probe"
    require(measured["events_csv"] == str(directory / "events.csv"), "mock 原事件路径越界")
    config = tomllib.loads((directory / "robot.toml").read_text())
    require(len(config["hardware"]) == 1 and config["hardware"][0]["adapter"] == "mock_serial_rt"
            and config["hardware"][0]["auto_enable"] is False
            and "address" not in config["hardware"][0], "mock 实际配置不是无设备软件 adapter")
    for name, expected_value in (("environment.json", env), ("final_stop.json", data["final_state"]),
                                 ("final_trace.json", data["final_trace"])):
        require(json.loads((directory / name).read_text()) == expected_value, "mock 原始文件与报告不一致：" + name)
    require((directory / "events.csv").is_file(), "mock 原事件文件缺失")
    return {"cases": 1, "groups": 4, "samples": 8, "physical_uart": False, "hardware_pass": False}


def validate_loopback(stdout):
    summaries = re.findall(r"test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored;", stdout)
    require(summaries == [("6", "0", "0")], "loopback 不是严格 6/0/0")
    scenes = []
    for line in stdout.splitlines():
        start = line.find("{")
        if start < 0:
            continue
        try:
            row = json.loads(line[start:])
        except json.JSONDecodeError:
            continue
        if "server_joined" in row:
            scenes.append(row)
    require(len(scenes) == 9, "缺少九条实际 loopback 场景原件")
    require(all(row["server_joined"] is True and row["active_requests"] == 0 for row in scenes),
            "loopback 服务未真实回收")
    require(Counter(row["reply"] for row in scenes) == Counter({"Ack": 5, "Error": 1, "WrongIdentity": 1,
                                                                 "DryRun": 1, "ZeroTimestamp": 1}), "loopback 回执反例不完整")
    success = [row for row in scenes if row["evidence"]["ok"] is True]
    require(len(success) == 1 and success[0]["delay_ms"] == 2100 and success[0]["ordinary"] is False
            and success[0]["server_reply_elapsed_ns"] >= 2_100_000_000, "真实 2.1 秒正确 Ack 未通过")
    timeouts = [row for row in scenes if row["evidence"]["disable"].get("message") == "Timeout expired"]
    require({(row["ordinary"], row["delay_ms"]) for row in timeouts} == {(True, 2100), (False, 3300)}
            and len(timeouts) == 2 and all(row["evidence"]["disable"]["code"] == "Cancelled" for row in timeouts),
            "普通 2 秒或最终 3 秒超时负控缺失")
    return scenes


def run(options, helper, a):
    options.out.mkdir()
    runner = helper.Runner(options, a)
    result = {"status": "FAIL", "deployable": False, "scope": "冻结七件 help、唯一 AC-12 mock 与纯 tonic loopback；不部署、不触 UART。",
              "self_sha256": a.sha256(Path(__file__)), "helper_sha256": a.sha256(options.helper),
              "module_sha256": a.sha256(options.source / "scripts/post_e_h2_artifacts.py")}
    manifests, initial, source = {}, None, None
    installed = {name: options.formal_root / "target/release" / name for name in a.INSTALLED_NAMES}

    def snapshot():
        frozen = {}
        for kind, manifest in manifests.items():
            a.validate_artifact_set(manifest, source_manifest=source, expected_kind=kind, expected_head=options.build_head)
            for name, item in manifest["artifacts"].items():
                frozen[kind + "/" + name] = a.elf_identity(item["path"])
        return {"frozen": frozen, "formal": a.validate_target_isolation(options.target, installed)["installed"],
                "manifests": {kind: a.sha256(options.release / (kind + ".json")) for kind in manifests}}

    try:
        prior = a.strict_json((options.release / "result.json").read_text())
        require(prior["status"] == "PASS" and prior["source_after"] == "PASS" and prior["isolation_after"] == "PASS",
                "release 原构建没有整体通过")
        require(prior["runner_sha256"] == result["helper_sha256"]
                and prior["artifacts_module_sha256"] == result["module_sha256"], "不是同版已验收 helper/产品模块")
        result["release_result_sha256"] = a.sha256(options.release / "result.json")
        source = runner.source("source_before")
        for kind in ("production", "measurement"):
            reference = prior["artifacts"][kind]
            require(reference["path"] == str(options.release / (kind + ".json")), "release 清单引用越界")
            manifest = a.read_pinned_json(reference)
            require(manifest["schema"] == "P7_RELEASE_ARTIFACTS_V2" and manifest["build_root"] == str(options.source)
                    and manifest["artifact_directory"] == str(options.release / kind)
                    and manifest["source_manifest"]["path"] == str(options.release / "source_before.json"),
                    "V2 根路径与本次来源不符")
            manifests[kind] = manifest
        require(all(manifests["production"][key] == manifests["measurement"][key]
                    for key in ("rustc_before", "rustc_after", "rustc_identity")), "两套 V2 不共用编译器窗口")
        initial = snapshot()
        require(len(initial["frozen"]) == 7, "不是完整七件冻结产物")
        helper.save(options.out / "identities_before.json", initial)
        _, rustc = runner.command("rustc_before", ["rustc", "-vV"])
        compiler = a.parse_rustc_identity(Path(rustc["stdout"]).read_text())
        require(compiler == manifests["production"]["rustc_identity"], "追加验证工具链与 release 构建发生漂移")
        for kind, manifest in manifests.items():
            for name, item in manifest["artifacts"].items():
                _, row = runner.command("help_" + kind + "_" + name, [item["path"], "--help"], 30)
                require(Path(row["stdout"]).stat().st_size + Path(row["stderr"]).stat().st_size > 0, "help 输出为空")
        mock_root = options.out / "mock_ac12"
        require(not mock_root.exists(), "mock 证据目录不得复用")
        measurement = manifests["measurement"]
        _, _ = runner.command("run_mock_ac12", [measurement["artifacts"]["comm_fault_e2e"]["path"],
                               "--phase", "mock", "--case", "AC-12", "--bin-dir", measurement["artifact_directory"],
                               "--evidence-dir", str(mock_root)], 300)
        report = a.strict_json((mock_root / "report.json").read_text())
        result["mock"] = validate_mock(report, measurement, mock_root)
        result["mock_report_sha256"] = a.sha256(mock_root / "report.json")
        _, loopback = runner.command("final_stop_transport", ["cargo", "test", "--locked", "-p", "robot-tests",
            "--no-default-features", "--features", "comm-fault-rpc", "--test", "final_stop_transport",
            "--", "--ignored", "--test-threads=1", "--nocapture"], 7200)
        scenes = validate_loopback(Path(loopback["stdout"]).read_text())
        helper.save(options.out / "loopback_scenes.json", scenes)
        result["loopback"] = {"tests": 6, "scenes": 9, "all_servers_joined": True}
        _, after = runner.command("rustc_after", ["rustc", "-vV"])
        require(a.parse_rustc_identity(Path(after["stdout"]).read_text()) == compiler, "追加测试期间编译器变化")
        result["status"] = "PASS"
    except BaseException as error:
        result["error"] = repr(error)
    finally:
        for label, check in (("source_after", lambda: runner.source("source_after")), ("identities_after", snapshot)):
            try:
                value = check()
                if label == "source_after":
                    require(source is not None and value == source, "追加测试后源码发生变化或缺初始快照")
                else:
                    helper.save(options.out / "identities_after.json", value)
                    require(initial is not None and value == initial, "冻结七件/两清单/正式四件前后变化")
                result[label] = "PASS"
            except BaseException as error:
                result[label] = repr(error)
                result["status"] = "FAIL"
        try:
            require(a.sha256(options.helper) == result["helper_sha256"]
                    and a.sha256(options.source / "scripts/post_e_h2_artifacts.py") == result["module_sha256"]
                    and a.sha256(options.release / "result.json") == result["release_result_sha256"], "脚本或构建总回执发生变化")
        except BaseException as error:
            result.update(status="FAIL", metadata_error=repr(error))
        result["receipts"] = runner.receipts
        helper.save(options.out / "post_release_result.json", result)
    return 0 if result["status"] == "PASS" else 1


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--run-checks", action="store_true")
    for name in ("source", "target", "release", "out", "formal-root", "helper"):
        parser.add_argument("--" + name, type=Path)
    parser.add_argument("--build-head")
    options = parser.parse_args(argv)
    if not options.run_checks:
        print(json.dumps({"mode": "PLAN_ONLY", "actions_started": 0, "deployable": False,
                          "steps": ["V2/源/七ELF严格读回", "七件help", "唯一AC-12 mock", "6测试9场景loopback", "前后身份核验"]}, ensure_ascii=False))
        return 0
    if platform.system() != "Linux" or platform.machine() != "aarch64":
        parser.error("仅允许原生 Linux aarch64")
    if not re.fullmatch(r"[0-9a-f]{40}", options.build_head or ""):
        parser.error("要求完整 build-head")
    for name in ("source", "target", "release", "out", "formal_root", "helper"):
        path = getattr(options, name)
        if path is None or not path.is_absolute() or ".." in path.parts or path != path.resolve():
            parser.error(name + " 必须是规范绝对路径")
        if name not in ("out", "helper") and not path.is_dir():
            parser.error(name + " 必须是已有目录")
    roots = [options.source, options.target, options.release, options.out, options.formal_root]
    if any(left.is_relative_to(right) or right.is_relative_to(left)
           for index, left in enumerate(roots) for right in roots[index + 1:]):
        parser.error("五个目录必须两两独立")
    if options.out.exists() or not options.out.parent.is_dir() or not options.helper.is_file():
        parser.error("要求新 out 目录和已有 helper 文件")
    sys.dont_write_bytecode = True
    helper = load("approved_release_helper", options.helper)
    a = load("post_release_artifacts", options.source / "scripts/post_e_h2_artifacts.py")
    previous = {}

    def interrupted(signum, _frame):
        helper.INTERRUPTED = signum

    try:
        for sig in (signal.SIGTERM, signal.SIGINT, signal.SIGHUP):
            previous[sig] = signal.signal(sig, interrupted)
        return run(options, helper, a)
    finally:
        for sig, handler in previous.items():
            signal.signal(sig, handler)


if __name__ == "__main__":
    raise SystemExit(main())
