#!/usr/bin/env python3
"""Linux 上的无害 helper 动态夹具；不运行 Cargo、SSH、服务、串口或 H2。"""

import argparse
import importlib.util
import json
import os
from pathlib import Path
import platform
import signal
import subprocess
import sys
import time
from types import SimpleNamespace


def load(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    for name in ("helper", "artifacts", "out"):
        parser.add_argument("--" + name, type=Path, required=True)
    options = parser.parse_args()
    if platform.system() != "Linux":
        parser.error("仅在 Linux 执行真实 /proc 与自有 session 夹具")
    for name in ("helper", "artifacts", "out"):
        path = getattr(options, name)
        if not path.is_absolute() or ".." in path.parts or path != path.resolve():
            parser.error(name + " 必须为规范绝对路径")
    if options.out.exists() or not options.out.parent.is_dir():
        parser.error("out 必须为已有父目录下的全新目录")
    sys.dont_write_bytecode = True
    helper, a = load("native_release_helper", options.helper), load("native_artifacts", options.artifacts)
    options.out.mkdir()
    for name in ("source", "target", "commands"):
        (options.out / name).mkdir()
    runner = helper.Runner(SimpleNamespace(source=options.out / "source", target=options.out / "target",
                                          out=options.out / "commands"), a)
    # 版本查询不允许工具链缺失时触发自动安装；准备入口须事先更新 nightly。
    runner.env["RUSTUP_AUTO_INSTALL"] = "0"
    identities = {name: {"path": str(path), "sha256": a.sha256(path)}
                  for name, path in (("helper", options.helper), ("artifacts", options.artifacts))}
    result = {"status": "FAIL", "scope": "Linux 无害 child/临时文件机制夹具；无 Cargo 或硬件。",
              "identities_before": identities, "cases": [], "receipts": runner.receipts}
    original_save = helper.save
    previous_handlers = {}

    def interrupted(signum, _frame):
        helper.INTERRUPTED = signum

    for sig in (signal.SIGTERM, signal.SIGINT, signal.SIGHUP):
        previous_handlers[sig] = signal.signal(sig, interrupted)

    def checked_completion(name, expected_code, failed):
        path = options.out / "commands" / name / "completion.json"
        row = a.strict_json(path.read_text())
        a.require(row["exit_code"] == expected_code and row["reaped"] is True, "未实际 wait 或退出码改变")
        a.require(row.get("session_residual_after_cleanup") == [], "直接 child 所属会话未清空")
        a.require(not helper.session_members(row["pid"]), "现场复读仍有自有会话进程")
        a.require(("runner_error" in row) == failed, "失败回执被改写为成功")
        a.require(row["identity_phase"] == "bootstrap" and Path(row["identity"]["exe"]).is_absolute(),
                  "未如实记录 bootstrap 实际身份")
        reference = {"path": str(path), "sha256": a.sha256(path)}
        if not failed:
            a.validate_completion(reference)
        else:
            try:
                a.validate_completion(reference)
            except ValueError:
                pass
            else:
                raise AssertionError("失败回执意外通过自然成功校验")
        return row

    try:
        # 快命令重复三个独立进程；不靠延长命令执行时间逃避 /proc/exe 竞态。
        for index in range(3):
            for label, command in (("true", ["/bin/true"]), ("git", ["git", "--version"]),
                                   ("rustc", ["rustc", "-vV"])):
                name = f"fast_{index}_{label}"
                _, row = runner.command(name, command, 10)
                checked_completion(name, 0, False)
                if label == "rustc":
                    a.parse_rustc_identity(Path(row["stdout"]).read_text(),
                                           183 if platform.machine() == "aarch64" else 62)
                result["cases"].append({"name": name, "status": "PASS", "pid": row["pid"]})

        name = "exit_seven"
        try:
            runner.command(name, [sys.executable, "-c", "raise SystemExit(7)"], 10)
        except ValueError:
            pass
        else:
            raise AssertionError("exit 7 意外成功")
        row = checked_completion(name, 7, True)
        result["cases"].append({"name": name, "status": "PASS", "observed_exit": row["exit_code"]})

        name, marker = "launch_gate", options.out / "gate_target_ran.json"
        observed = []

        def intercept(path, value):
            if path.name == "launch.json":
                a.require(not marker.exists(), "launch 落盘前目标已运行")
                time.sleep(0.05)
                a.require(not marker.exists(), "未 GO 时目标越过启动门")
                observed.append("target_absent_before_launch")
            original_save(path, value)
            if path.name == "launch.json":
                a.require(not marker.exists(), "launch 已落盘但尚未 GO，目标提前运行")
                observed.append("target_absent_after_launch_before_GO")

        helper.save = intercept
        try:
            runner.command(name, [sys.executable, "-c",
                                 "import os,pathlib,sys; pathlib.Path(sys.argv[1]).write_text(str(os.getpid()))", str(marker)], 10)
        finally:
            helper.save = original_save
        row = checked_completion(name, 0, False)
        a.require(marker.read_text() == str(row["pid"]), "放行后目标未沿同一 PID 执行")
        result["cases"].append({"name": name, "status": "PASS", "observations": observed, "same_pid": row["pid"]})

        name, marker = "launch_write_failure", options.out / "failed_launch_must_not_run"

        def reject_launch(path, value):
            if path.name == "launch.json":
                raise OSError("injected_launch_write_failure")
            return original_save(path, value)

        helper.save = reject_launch
        try:
            try:
                runner.command(name, [sys.executable, "-c",
                                     "from pathlib import Path; import sys; Path(sys.argv[1]).touch()", str(marker)], 10)
            except ValueError:
                pass
            else:
                raise AssertionError("launch 写入失败被当作成功")
        finally:
            helper.save = original_save
        row = a.strict_json((options.out / "commands" / name / "completion.json").read_text())
        a.require(row["exit_code"] != 0 and "injected_launch_write_failure" in row.get("runner_error", ""),
                  "原 launch 写入错误未保留")
        a.require(not marker.exists() and not Path(row["launch_receipt"]).exists()
                  and not row.get("exec_gate_released", False), "启动回执失败后仍放行或执行了目标")
        checked_completion(name, row["exit_code"], True)
        result["cases"].append({"name": name, "status": "PASS", "pid": row["pid"],
                                "observed_exit": row["exit_code"], "target_absent": True,
                                "original_error": row["runner_error"]})

        # 保留真实负例：父进程和其子进程均在同一新 session，父在 TERM 时负责 wait 子。
        name, child_file = "owned_timeout", options.out / "timeout_child.pid"
        code = """import os, signal, subprocess, sys, time
from pathlib import Path
child = None
def stop(signum, frame):
    signal.signal(signal.SIGTERM, signal.SIG_IGN)
    if child is not None:
        child.terminate()
        child.wait(timeout=2)
    raise SystemExit(143)
signal.signal(signal.SIGTERM, stop)
child = subprocess.Popen([sys.executable, '-c', 'import time; time.sleep(30)'])
Path(sys.argv[1]).write_text(str(child.pid))
time.sleep(30)
"""
        try:
            runner.command(name, [sys.executable, "-c", code, str(child_file)], 2)
        except ValueError:
            pass
        else:
            raise AssertionError("超时负例意外成功")
        row = a.strict_json((options.out / "commands" / name / "completion.json").read_text())
        a.require(row["exit_code"] != 0 and "TimeoutError" in row.get("runner_error", "") and row["signals"],
                  "没有触发真实超时清理")
        checked_completion(name, row["exit_code"], True)
        child_pid = int(child_file.read_text())
        a.require(helper.proc_entry(child_pid) is None, "受控 descendant 未被父进程回收")
        result["cases"].append({"name": name, "status": "PASS", "parent_pid": row["pid"],
                                "child_pid": child_pid, "observed_exit": row["exit_code"], "child_absent": True})

        name, marker = "eof_refuses_exec", options.out / "eof_target_must_not_exist"
        a.require(helper.INTERRUPTED is None, "已收到中断，不再启动 EOF 夹具")
        read_fd, write_fd = os.pipe()
        process, events, code, reaped = None, [], None, False
        try:
            command = [sys.executable, "-c", helper.BOOTSTRAP, str(read_fd), sys.executable, "-c",
                       "from pathlib import Path; import sys; Path(sys.argv[1]).touch()", str(marker)]
            with (options.out / "eof.stdout").open("xb") as stdout, (options.out / "eof.stderr").open("xb") as stderr:
                process = subprocess.Popen(command, pass_fds=(read_fd,), start_new_session=True,
                                           stdin=subprocess.DEVNULL, stdout=stdout, stderr=stderr, env=runner.env)
                os.close(read_fd)
                read_fd = None
                os.close(write_fd)
                write_fd = None
                code = process.wait(timeout=3)
                reaped = True
                a.require(code == 125 and not marker.exists(), "EOF 未拒绝 exec 或退出码异常")
                a.require(not helper.session_members(process.pid), "EOF 夹具会话未清空")
        finally:
            for fd in (read_fd, write_fd):
                if fd is not None:
                    os.close(fd)
            if process is not None and (not reaped or helper.session_members(process.pid)):
                code, reaped = helper.stop_owned(process, events)
            original_save(options.out / "eof_receipt.json", {"argv": command, "pid": process.pid if process else None,
                          "wait_returncode": code, "reaped": reaped, "signals": events,
                          "target_exists": marker.exists(), "session_residual": helper.session_members(process.pid) if process else []})
        a.require(not events, "EOF 正常拒绝路径却需要额外清场")
        result["cases"].append({"name": name, "status": "PASS", "wait_returncode": code, "reaped": reaped})
        a.require(len(result["cases"]) == 14, "真实完成的夹具 case 集合不完整")
        result["status"] = "PASS"
    except BaseException as error:
        result["error"] = repr(error)
    finally:
        helper.save = original_save
        result["identities_after"] = {name: {"path": str(path), "sha256": a.sha256(path)}
                                      for name, path in (("helper", options.helper), ("artifacts", options.artifacts))}
        if result["identities_after"] != identities:
            result.update(status="FAIL", identity_error="helper 或共享模块发生变化")
        if helper.INTERRUPTED is not None:
            result.update(status="FAIL", interrupted_signal=helper.INTERRUPTED)
        result["completed_cases"] = len(result["cases"])
        original_save(options.out / "native_fixture_result.json", result)
        for sig, handler in previous_handlers.items():
            signal.signal(sig, handler)
    print(json.dumps(result, ensure_ascii=False), flush=True)
    return 0 if result["status"] == "PASS" else 1


if __name__ == "__main__":
    raise SystemExit(main())
