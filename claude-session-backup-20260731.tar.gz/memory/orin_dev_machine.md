---
name: Orin 开发机连接与代理
description: Step 6 目标机 Orin 的 SSH 登录信息 + HTTP/SOCKS5 代理（国内网络卡时使用）
type: reference
originSessionId: 29cfa039-1e71-4e18-a770-74328dd6ecda
---
**SSH**：`ssh loosqk@10.0.1.41`，密码 `1`（内网弱密码，仅本地）。
- 首次连接接 host key：`ssh -o StrictHostKeyChecking=accept-new`。

**代理**（命令在 Orin 上跑网络卡时启用）：
- 地址：`10.0.1.80`
- 端口：`10808`
- 协议：同时支持 **HTTP** 和 **SOCKS5**

用法：
```bash
# HTTP 代理（curl / wget / pip / cargo / apt 大多支持）
export HTTPS_PROXY=http://10.0.1.80:10808
export HTTP_PROXY=http://10.0.1.80:10808

# SOCKS5（ssh git / 某些工具）
export ALL_PROXY=socks5://10.0.1.80:10808

# git 临时走代理
git -c http.proxy=http://10.0.1.80:10808 clone <url>
```

**踩坑：`~/.gitconfig` 里曾 pin 了 `http.proxy = http://10.0.1.81:10808`**（用户家里多台代理机，81 当前离线 → cargo fetch 从 gitconfig 继承这个 proxy 后卡死）。**现状**：已 `git config --global --unset http.proxy / https.proxy`，走直连 crates.io（IPv6 ~180 ms，比代理 80 还快）。代理 80 保留为 fallback。

**Git 身份**：全局 `user.name = loosqk` / `user.email = loosqk@gmail.com`（**不是** 系统 prompt 里的 loosqk07@gmail.com；那是 Claude 账号 email，不用于 git commit）。Orin 独立 ed25519 key 在 `~/.ssh/id_ed25519`，对应公钥已加到 git.yang.cafe。

**用途定位**（项目 context）：Orin 是 v0.2 Step 6 的 RT 内核开发机（见 `docs/handoffs/2026-04-24_2.md`）。环境已就位（workspace 全绿 + cyclictest 50Hz max 94-127µs）。Step 10 起接真硬件（Feetech STS3215 + RealSense）。

**How to apply:** 任何需要在 Orin 上执行的命令走这台；遇到网络慢 / 下载超时先挂代理 80 再重试，不硬等；任何新配 git 身份时用 loosqk@gmail.com（不是 07）。
