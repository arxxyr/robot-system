---
name: nightly-float-no-pin
description: robot-system 工具链永远浮动最新 nightly、不锁定日期；新 lint 一律 fix-forward
metadata: 
  node_type: memory
  type: feedback
  originSessionId: 9fc2059c-d70b-423c-b863-bc1cf056c83e
---

reviewer 2026-07-13 指令："用最新的nightly" + "不要锁定"。背景：2026-07-12 升 iceoryx2 0.9.3 后解除 nightly-2026-06-08 pin，回 `channel = "nightly"`；两天后 nightly 滚动（07-09 → 07-12）带来新 clippy lint（redundant_else / bool_to_int_with_if），我按 fix-forward 就地修（`f54e19e`）并在报告里说明"不回 pin"，reviewer 以这两条指令确认该政策。

**Why:** 浮动最新 nightly 是仓库硬要求（docs/00_design.md §9）；pin 日期只是真编译破坏（如 E0599 那种上游 dep 编译不过）时的逃生舱，且用后必须登记解除条件（先例：CHANGELOG 2026-06-24 登记 4 → 2026-07-12 解除 1）。琐碎 lint 命中不构成 pin 理由。

**How to apply:** `rust-toolchain.toml` 保持 `channel = "nightly"`，不因新 clippy lint / 小回归写日期 pin；命中新 lint 就地修，独立 🎨/🐛 commit（与 docs 分条）。只有真编译破坏才走"pin 上一已验证日期 + CHANGELOG 登记解除条件"路径，且需 reviewer ACK。相关：[[feedback-commit-split-behavior-vs-literal]]。
