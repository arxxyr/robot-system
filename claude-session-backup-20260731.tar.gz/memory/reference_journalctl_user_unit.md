---
name: journalctl user unit 跨发行版查询
description: Orin/Tegra 上 user service 日志走 system journal，smoke / 诊断要用 _SYSTEMD_USER_UNIT matcher 而不是 --user -u
type: reference
originSessionId: f20e3979-3ae3-4a1f-89fe-acb04b79790e
---
`journalctl --user -u <unit>` 在 Ubuntu Tegra (Orin AGX) 上看不到 user
service 日志：

- 现象：`No journal files were found.` / `-- No entries --`。
- 根因：发行版默认**没**启 user journal namespace（`/var/log/journal/<user>/`
  不存在），user services stdout/stderr 走 **system journal**。
- 跟 FRIDAY workstation 的差别：FRIDAY 启用了 user journal，所以
  `--user -u <unit>` 能看到日志，给人"跨机器一致"的错觉。

**跨发行版稳的查询写法**（兼容 user journal 启用 / 不启用两种配置）：

```bash
journalctl _SYSTEMD_USER_UNIT=<unit_name>.service --no-pager [--output short-iso]
```

走 system journal `_SYSTEMD_USER_UNIT=<unit>` 索引字段。FRIDAY + Orin
AGX 实测都过。

**应用场景**：
- `crates/robot-tests/src/bin/freeze_systemd_smoke.rs` `journalctl_user`
  helper 已用此 matcher（commit `b33b5c4`）。
- 后续任何写跨机器 user systemd smoke / 诊断脚本，**默认**走
  `_SYSTEMD_USER_UNIT=<unit>`，**不**默认 `--user -u`。
- 手动诊断时如果 `journalctl --user -u <unit>` 返空，立刻试
  `journalctl _SYSTEMD_USER_UNIT=<unit>`，大概率能看到完整输出。

**反例**（不要用）：
- `journalctl --user -u <unit>` —— 跟 user journal namespace 启用与否
  耦合，跨发行版不稳。
- `journalctl --user-unit <unit>` —— 仍然要 `--user` 视角，部分发行版
  下也会读不到。
