---
name: candidate-e-execute-progress
description: robot-system 候选 E（替换 dimos-deploy 控制执行面）Execute 进展与接班约束——重装系统 2026-07-17 保存点
metadata: 
  node_type: memory
  type: project
  originSessionId: 9fc2059c-d70b-423c-b863-bc1cf056c83e
---

候选 E **Plan Approved — supervised-demo scope**（reviewer 2026-07-15，Spec round 10 复核）。Execute 严格串行序：`(1)→(2)→(3)→(4)→(5)→(6)→(8)→(7)→(9)→(10-demo)`。

**已完成并 push 到 origin/master（截至 2026-07-17，重装保存点 `799ce7b`）**：
- 段(1) `dca9a52` layout 计算权威 `compute_layout_id`
- 段(2) `539887f`(feat)+`2a08732`(docs) config typed motor_ids + 身份锁 + 全仓 census + 新权威 arm config ×2
- 段(3) `737b555`(feat)+`548e05a`(docs) S0 layout 落地 + command gate
- 段(4) `f51e5cc`(🎨)+`1537252`(feat)+`799ce7b`(docs) S1 layout + mock_s1 --config + robot-rpc client::layout 校验

**接班约束（conversation-only，git 看不出）**：段(4) 三条**已 push 但 reviewer 尚未 ACK**（为重装保存提前 push）。**下一步 = 段(5)（G1 语义段：S1 常驻 state cache + scripted_start_pose + 末点发布保证 + idle_hold_target 穷尽规则），但必须先等段(4) round ACK 再开工**——勿在 ACK 前进段(5)。

**每段 gate（P.0 + PX-5）**：`cargo fmt --all` + `cargo clippy --workspace --all-targets -- -D warnings` + **`cargo clippy -p robot-tests --all-features --all-targets -- -D warnings`**（feature 面永久 gate）+ workspace test（**空载单跑**——满载会触发既有 flake `robot-s0 systemd_notify::watchdog_withholds_ping_when_observer_stalled`，PX-4 登记，段(8) 确定性化）+ release-first 重建两条 + 六 smoke。commit 拆分：feat/build 与 docs 分开，Cargo.lock 随 feat。

**六 smoke 精确调用（本轮踩坑复核）**：scripted/ik 需 `--hardware-id smoke_arm|ik_arm --config <configs/...> --phase all`；pubsub `--bin-dir target/release --hardware-id smoke_arm --config configs/crash_restart_smoke.toml --phase all`；clear_estop `--bin-dir target/release --case all`；robotctl `--config configs/robotctl_smoke.toml --hardware-id ik_arm --phase all`；freeze_systemd 需先 `cargo build --release -p robot-s0 --features test-freeze-hook` 再 `--daemon-bin target/release/s0_daemon --iterations 1`。

权威 Spec = `team-swe/specs/v0_5_dimos_replace.md`（P.1 段表 + P.2.x 函数级 + P.4 diff 登记）。相关：[[dimos_paths]]（移植参考源 + Orin 标定路径，本地仓库重装需重新准备）。
