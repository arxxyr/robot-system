---
name: dimos 项目本机路径
description: robot-system 项目中 dimos 移植参考源 + Orin 部署仓的本机 Linux 实际路径（02_start_here.md 写的是 macOS 路径，本机不同）
type: reference
originSessionId: 1a25a97d-7e25-478c-b8b8-ec52cd6dcd61
---
robot-system 在 Linux 本机上有两份 dimos 仓库，路径与 `docs/02_start_here.md`（写的是 macOS `/Users/loosqk/...`）不一致：

- **`/home/loosqk/repo/robot/dimos`** —— 官方上游 dimos 框架（顶层就是 `dimos/` Python 包）。**不是**移植目标，仅在需要查上游框架时参考。

- **`/home/loosqk/repo/robot/dimos-deploy`** —— XLeRobot 实际部署仓（顶层 `src/xlerobot_dimos/`）。**这才是 robot-system 移植/对照参考源**：
  - `src/xlerobot_dimos/common/feetech_io/` —— Feetech STS3215 Python 驱动（8 文件：`bus.py`/`registers.py`/`encoding.py`/`types.py`/`calibration.py`/`patches.py`/`_ranges_input.py`/`__init__.py`），Step 7 真 adapter 的 Rust 移植蓝本。
  - `docs/06_lerobot_replace_spec.md` —— 寄存器操作序列权威规范。
  - `src/xlerobot_dimos/common/units.py` —— 弧度↔raw / 三轮全向运动学。
  - `calibration/` —— 校准 JSON 示例（如存在）。
  - `assets/xlerobot/` —— URDF + STL。

Orin（10.0.1.41）上的 dimos 部署：systemd 单元 `xlerobot-coordinator.service`（电机+相机+Rerun 桥）+ `xlerobot-web.service`。Step 10 / Step 7 真机阶段前必须 `sudo systemctl stop xlerobot-coordinator xlerobot-web` 释放硬件占用。

**2026-07-10 用户拍板（premise 变更）**：dimos-deploy 是用户本人仓库、仅 demo 验证用、**后续不再使用**；robot-system 目标 = **完全替换 dimos-deploy**（非接线共存）。dimos-deploy 当前 master `9ece6bd` 冻结 = 只读移植参考 + 候选 E 功能基线；**0 PR / 不装 gRPC client**。详 robot-system `docs/handoffs/v0.5_dimos_buyin_decision.md`。
