---
name: 行为改动 vs 字面同步分两条 commit
description: v0.3 A1/A2 实现期间，PR 必须把控制流/状态机/行为改动跟字面同步（注释/CLI help/err msg/config comment）拆成两条独立 commit
type: feedback
originSessionId: f20e3979-3ae3-4a1f-89fe-acb04b79790e
---
v0.3 A1 / A2 实现期间，commit 必须按"行为面"分组，**不混提**：

- **行为 commit**：控制流 / 状态机 / 数据结构 / 函数签名 / 实际逻辑改动。
- **字面同步 commit**：注释 / doc comment / CLI help text / `tracing` err msg literal /
  config TOML 注释 / 文档 markdown 等不影响运行时行为的字符串改动。

混提两类时即便 reviewer 不否决，也要在 commit message / CHANGELOG 里明文标
注"实施面向：行为改动 + 字面同步"，让 review 能独立校准。

**Why**：reviewer 在 `a8cfffd` ("ClearEStop control action 口径全仓库同步")
复核时点出非阻断注意：commit 不是纯 docs/，还动了 .rs 注释 / CLI help /
err msg / config 注释。安全层面没否决，但希望"路径上也不能碰源码文件"
能被单独记账，避免日后字面同步 commit 暗藏控制流改动滑进 review 盲区。

**How to apply**：
- 写 commit 前自检 diff：如果包含 `.rs` / `.toml` / `.json` 任何**非注释 /
  非字符串 literal** 的改动，分一个独立 commit。
- 若一定要混（比如同一个改动既要改 err msg 又要改 err 触发条件），commit
  message 第一段必须明文写 "实施面向：行为改动 + 字面同步"，列清两边各
  动了什么。
- A1 (ClearEStop control-plane slice) / A2 (freeze hook + systemd e2e)
  实现期间默认按这条规则跑；reviewer round N 否决能直接打回"行为 + 字面
  混提"的 PR。
- v0.4+ 是否继续保留这条规则按届时 reviewer 拍板。
