---
name: Handoff 文档约定
description: docs/handoffs/ 目录的追加规则 + README.md 列表需手动同步
type: project
originSessionId: 29cfa039-1e71-4e18-a770-74328dd6ecda
---
`docs/handoffs/` 是 session 续接快照，不是 spec、不走 CHANGELOG。

规则：
- 每次 session 结束追加 `<YYYY-MM-DD>.md`；同日多次加后缀 `<YYYY-MM-DD>_<n>.md`（如 `2026-04-24_2.md`）。
- 过期 handoff 保留不删（演进历史）。
- `docs/handoffs/README.md` 末尾有一张"列表"表，**每追加一份 handoff 必须手动加一行**（自动化未接入）。
- 冲突裁决顺序里 handoff 不入列；权威仍是 `00_design.md` > 项目 CLAUDE.md > 全局 CLAUDE.md > `02_start_here.md`。

**Why:** 用户 2026-04-24 刚引入这套续接机制（commit 4609a3a），想降低跨 session / 跨机器 resume 成本；但 README 的列表更新是手动的，容易漏。

**How to apply:** session 尾声若有实质决定/进展，主动提示"要不要追加一份 handoff"，并提醒同步 README 列表那一行。判断门槛：本次 session 若只改一两行代码或纯问答，不用追加。
