---
name: Python 工具链首选 uv
description: 所有 Python 相关操作（装包 / venv / 运行脚本）默认用 uv，除非用户另指示
type: feedback
originSessionId: 29cfa039-1e71-4e18-a770-74328dd6ecda
---
Python 操作默认用 **uv**：
- `uv venv` 建 venv（不用 `python -m venv`）
- `uv pip install` / `uv add`（不用裸 pip / poetry / pdm）
- `uv run <script>` / `uv run python ...`（替代手动激活 venv）
- 安装 uv 本身：`curl -LsSf https://astral.sh/uv/install.sh | sh`

**Why:** 用户 2026-04-24 明示"Python 的话首选 uv，记住这条"。uv 速度和锁文件都优于 pip/poetry。

**How to apply:** 任何涉及 Python 包管理 / venv / 脚本执行的场景直接走 uv；只有当目标环境明确不可能装 uv（比如要修别人仓库的既有 poetry / pip 流程）才回退原生工具。
